/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author pc144
 */
public class challan_purchase_edit_delete extends javax.swing.JPanel {
Font myFont = new Font("",Font.PLAIN,9);
int i=0,j=0,k=0,l=0,m=0;   // For Mandatory
    int x=0;       // For Non-Mandatory
    /**
     * Creates new form challan_purchase_edit_delete
     */
    
    public void set(){
        search_txt.requestFocusInWindow();        
        search_txt.setFocusable(true);
                
    }
    
    public void user(String u_name){
       jLabel11.setText(u_name);
    }
    public challan_purchase_edit_delete() {
        initComponents();
         update_table();
         search();
        fill_combo();
        jTextField1.setVisible(false);
        jTextField2.setVisible(false);
        jTextField3.setVisible(false);
        
        jLabel3.setFont(myFont);
        jLabel3.setEnabled(false);
        jLabel3.setVisible(false);
        
        jLabel14.setFont(myFont);
        jLabel14.setEnabled(false);
        jLabel14.setVisible(false);
        
        jLabel10.setFont(myFont);
        jLabel10.setEnabled(false);
        jLabel10.setVisible(false);
        
        jLabel1.setFont(myFont);
        jLabel1.setEnabled(false);
        jLabel1.setVisible(false);
        
        jLabel12.setFont(myFont);
        jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        jLabel13.setFont(myFont);
        jLabel13.setEnabled(false);
        jLabel13.setVisible(false);
        
        jLabel11.setVisible(false);
        
        invoice_no_txt.setEditable(false);
        
        create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
    }
    
      // Invoice No
    
    public void invoice(){
   if(invoice_no_txt.getText().length()==0)
      {
          invoice_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel3.setEnabled(true);
          jLabel3.setForeground(Color.red);
          jLabel3.setVisible(true);
             
      }  
      else
      {
           invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel3.setEnabled(false);  
           jLabel3.setVisible(false);
           i=1;
          
      }
    }
    
    // date
    
    public void date(){
     if(date_txt.getText().length()==0)
        {
                 date_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);
        }
        else
        {
            String content = date_txt.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel14.setEnabled(false);  
            jLabel14.setVisible(false);
            j=1;
            if(!matchFound)

            {

                 date_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);

            }
        }
    }
    
    // Party Name
    
    public void party(){
    if(party_combo.getSelectedItem().equals(""))
      {
          party_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel10.setEnabled(true);
          jLabel10.setForeground(Color.red);
          jLabel10.setVisible(true);
             
      }  
      else
      {
           party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel10.setEnabled(false);  
           jLabel10.setVisible(false);
           k=1;
      }
    }
    
    // Purcahse Ledger
    
    public void purchase(){
     if(purchase_combo.getSelectedItem().equals(""))
      {
          purchase_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel12.setEnabled(true);
          jLabel12.setForeground(Color.red);
          jLabel12.setVisible(true);
             
      }  
      else
      {
           purchase_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel12.setEnabled(false);  
           jLabel12.setVisible(false);
           l=1;
      }
        
    }
    
    // Godown
    
    public void godown(){
     if(godown_combo.getSelectedItem().equals(""))
      {
          godown_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
             
      }  
      else
      {
           godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           m=1;
      }
        
    }

    public void update_table()
    { 
       
         
        try{
        
               Connection con = Database.getConnection();
               Statement ps =con.createStatement();
               ResultSet rs=ps.executeQuery("SELECT purchase_challan_no as PURCHASE_CHALLAN_NO from purchase_challan_1");
               product_table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));

               System.out.println("Done");
          
            }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
            }
            
        
        product_table.addKeyListener(new java.awt.event.KeyAdapter()

            {

            public void keyReleased(java.awt.event.KeyEvent e)

            {

            int keyvalue=e.getKeyCode();
            if(keyvalue==KeyEvent.VK_ENTER)
                            {
                                                                
                             int row=product_table.getSelectedRow();
                             int col=product_table.getSelectedColumn();

                            if(product_table.getValueAt(row, 0) != null){
                            String s1= (String)product_table.getValueAt(row, 0);


            //JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());

            System.out.println(" Value in the row clicked :"+ " " +row+"");
            System.out.println(" Value in the col clicked :"+ " " +col+"");
            System.out.println(" Value in the col,row clicked :"+ " " +s1+"");

          try{
         
            Connection con = Database.getConnection();
            Statement ps1 =con.createStatement();
            Statement ps2 =con.createStatement();
            Statement ps3 =con.createStatement();
            ResultSet rs1 =ps1.executeQuery("SELECT purchase_narration,purchase_challan_godown_name,purchase_challan_id,purchase_challan_no,purchase_challan_date,purchase_challan_party_name,purchase_challan_current_balance,purchase_challan_sale_ledger from purchase_challan_1 where purchase_challan_no='"+s1+"' ");
            while(rs1.next())
                {
                
                String  aa=rs1.getString("purchase_challan_id");
                jTextField1.setText(aa);
                
                String a1=rs1.getString("purchase_challan_no");
                invoice_no_txt.setText(a1);
                jTextField2.setText(a1);

                String a2=rs1.getString("purchase_challan_date");
                date_txt.setText("");
                date_txt.setText(a2);
                                
                String a3=rs1.getString("purchase_challan_party_name");
                party_combo.setSelectedItem(a3);
                
                String a4=rs1.getString("purchase_challan_current_balance");
                curbalnc_txt.setText(a4);
                
                String a5=rs1.getString("purchase_challan_sale_ledger");
                purchase_combo.setSelectedItem(a5);
                
                String a6=rs1.getString("purchase_challan_godown_name");
                godown_combo.setSelectedItem(a6);
                
                String narration=rs1.getString("purchase_narration");
                challan_purchase_narration.setText(narration);
                System.out.println(narration);
                
                
                
                   Statement ps4 =con.createStatement();
                ResultSet rs2=ps4.executeQuery("SELECT * from user_activity_table where table_name='purchase_challan_1' and value='"+s1+"'");
                while(rs2.next())
            {
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                                                
                
            
            // Code to Save & Edit Sale Table 3 with value from JTextField 3
            String sch3 = jTextField2.getText().toString();
            System.out.println(sch3);
            Integer srch3 = Integer.parseInt(sch3);
            System.out.println("Invoice No.:"+srch3);
            
            ResultSet rs3=ps3.executeQuery("SELECT * from purchase_challan_2 where purchase_challan_no='"+srch3+"' ");
            while (rs3.next())
            {
                String ax = rs3.getString("purchase_challan_id");
                jTextField3.setText(ax);
            }

                }
            //Code to fill Item Table
           DefaultTableModel y1 = (DefaultTableModel)table1.getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            }
        
            
            
           ResultSet rs2=ps2.executeQuery("SELECT * from purchase_challan_2 where purchase_challan_no='"+s1+"' ");
           //sale_item AS Item, sale_unit AS Unit, sale_quantity AS Quantity, sale_rate AS Rate, sale_amount AS Amount, sale_tax AS Amount, sale_taxable_amnt AS Taxable_Amt, sale_disc AS Discount, sale_disc_amnt AS Discount_Amt, sale_total AS Total
           //table1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs2));
           
           int li_row=0;
           int rw = 0;
           
           Vector <String> r[] = (Vector <String> []) new Vector[1000];
           
           
           table1.getColumnModel().getColumn(3).setMinWidth(0);
           table1.getColumnModel().getColumn(3).setMaxWidth(0);
           table1.getColumnModel().getColumn(3).setResizable(false);
//           
           while(rs2.next())
                 {
                 y1.addRow(r[rw]); 
                  
                 String scitem=rs2.getString("purchase_challan_item");
                 table1.setValueAt(scitem, li_row, 0);
                
                 String scunit=rs2.getString("purchase_challan_unit");
                 table1.setValueAt(scunit, li_row, 1);
                 
                 Double sqty = Double.parseDouble(rs2.getString("purchase_challan_quantity"));
                 table1.setValueAt(sqty, li_row, 2);
                 
                 
                
                 
                 rw++;
                 li_row++;
                 }
           
           
            
       
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        

                }  }

        }

        }

        );
            Action delete = new AbstractAction()
        {
            public void actionPerformed(ActionEvent e)
            {

            }
        };
    }
    
    
     public void fill_combo()
    {
      party_combo.removeAll();
      purchase_combo.removeAll();
      godown_combo.removeAll();
        
        try{
        
            Connection con = Database.getConnection();
            
            // Adding Items to Party Ledger
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("select distinct l_name from ledger order by l_id");
            
               while(rs.next())
              {
                  String name=rs.getString("l_name");
                  party_combo.addItem(name);
                  purchase_combo.addItem(name);
              }
               
            //              String name1="Others";
            //              group.addItem(name1);
            
            //Adding Items to Purchase Ledger
            Statement ps2 =con.createStatement();
            ResultSet rs2=ps2.executeQuery("select distinct gd_name from godown order by gd_id");
            
               while(rs2.next())
              {
                  String name2=rs2.getString("gd_name");
                  godown_combo.addItem(name2);
              }
               
            //Adding Items to Unit in Table
            Statement ps3 = con.createStatement();
            ResultSet rs3=ps3.executeQuery("select distinct u_name from unit order by u_id");
            
            
               while(rs3.next())
              {
                  String name3=rs3.getString("u_name");
                  unit_combox.addItem(name3);
              }   
               
            //Adding Products to Item in Table
            Statement ps4 = con.createStatement();
            ResultSet rs4 = ps4.executeQuery("select distinct product_name from product order by p_id");
            
            
               while(rs4.next())
              {
                  String name4=rs4.getString("product_name");
                  item_combox.addItem(name4);
              }    
//               
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
    }
     
 public void search()
    {
       search_txt.addKeyListener(new java.awt.event.KeyAdapter()

       {

        public void keyReleased(java.awt.event.KeyEvent e)

        {
        String s1=search_txt.getText();
        String s3=s1;
     
        try{
        Connection con = Database.getConnection();
        Statement ps =con.createStatement();
        ResultSet rs=ps.executeQuery("SELECT purchase_challan_no as PURCHASE_CHALLAN_NO from purchase_challan_1 where purchase_challan_no like '"+s3+"%'"); 


        product_table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));

        }catch (SQLException e1){
        System.out.println("Sql Exception" + e1.toString());
        }
        
                
        }
     });
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane1 = new javax.swing.JOptionPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        invoice_no_txt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        date_txt = new javax.swing.JTextField();
        party_combo = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        purchase_combo = new javax.swing.JComboBox();
        jLabel12 = new javax.swing.JLabel();
        godown_combo = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        curbalnc_txt = new numeric.textField.NumericTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        challan_purchase_narration = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        save_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        clear_button = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        search_txt = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        product_table = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        create_date = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        update_date = new javax.swing.JTextField();

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("PURCHASE CHALLAN EDIT / DELETE");

        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Challan No:");

        invoice_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        invoice_no_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                invoice_no_txtFocusLost(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("Date:");

        date_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                date_txtActionPerformed(evt);
            }
        });
        date_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                date_txtFocusLost(evt);
            }
        });

        party_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        party_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                party_comboActionPerformed(evt);
            }
        });
        party_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                party_comboFocusLost(evt);
            }
        });

        jLabel3.setText("Enter Invoice No.!");

        jLabel14.setText("Enter Valid Date Format!");

        jLabel10.setText("Enter Party Name!");

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Current Balance:");

        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Purchase Ledger:");

        purchase_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        purchase_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        purchase_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purchase_comboActionPerformed(evt);
            }
        });
        purchase_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                purchase_comboFocusLost(evt);
            }
        });

        jLabel12.setText("Select Ledger!");

        godown_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        godown_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                godown_comboActionPerformed(evt);
            }
        });
        godown_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                godown_comboFocusLost(evt);
            }
        });

        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Godown Name:");

        jLabel13.setText("Select Godown!");

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Party's Name:");

        jLabel1.setText("Enter Valid Balance!");

        curbalnc_txt.setText("numericTextField1");
        curbalnc_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                curbalnc_txtFocusLost(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Narration:");

        challan_purchase_narration.setColumns(20);
        challan_purchase_narration.setRows(5);
        jScrollPane4.setViewportView(challan_purchase_narration);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(party_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(curbalnc_txt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(invoice_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel4))
                                            .addComponent(purchase_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(godown_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(date_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(invoice_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(date_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jLabel3))
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(party_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(curbalnc_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(purchase_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(godown_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        save_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save_button.setText("Save");
        save_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_buttonActionPerformed(evt);
            }
        });

        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete_button.setText("Delete");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });

        clear_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        clear_button.setText("Clear");
        clear_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(delete_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(save_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(clear_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(save_button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(delete_button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(clear_button)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Item", "Unit", "Quantity", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(table1);
        table1.getColumn("Item").setCellEditor(new DefaultCellEditor(item_combox));

        table1.getColumn("Unit").setCellEditor(new DefaultCellEditor(unit_combox));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        search_txt.setToolTipText("");
        search_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_txtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(search_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(search_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
        );

        product_table.setForeground(new java.awt.Color(0, 0, 255));
        product_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        product_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                product_tableMouseClicked(evt);
            }
        });
        product_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                product_tableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(product_table);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(36, 36, 36))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rows", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Action-remove-icon.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/add-2-icon.png"))); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                .addComponent(jButton7))
        );

        jLabel11.setText("jLabel11");

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 10), java.awt.Color.cyan)); // NOI18N

        jLabel16.setForeground(new java.awt.Color(51, 153, 0));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Create User:");

        jLabel17.setForeground(new java.awt.Color(51, 153, 0));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Create Date:");

        jLabel18.setForeground(new java.awt.Color(51, 153, 0));
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel18.setText("Update User:");

        jLabel19.setForeground(new java.awt.Color(51, 153, 0));
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel19.setText("Update Date:");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel11)
                                .addGap(123, 123, 123)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1044, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 611, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void invoice_no_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_invoice_no_txtFocusLost
        if(invoice_no_txt.getText().length()==0)
        {
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel3.setEnabled(true);
            jLabel3.setForeground(Color.red);
            jLabel3.setVisible(true);

        }
        else
        {
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel3.setEnabled(false);
            jLabel3.setVisible(false);
            i=1;

        }
    }//GEN-LAST:event_invoice_no_txtFocusLost

    private void date_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_date_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_date_txtActionPerformed

    private void date_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_date_txtFocusLost
        if(date_txt.getText().length()==0)
        {
            date_txt.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel14.setEnabled(true);
            jLabel14.setForeground(Color.red);
            jLabel14.setVisible(true);
        }
        else
        {
            String content = date_txt.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel14.setEnabled(false);
            jLabel14.setVisible(false);
            j=1;
            if(!matchFound)

            {

                date_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel14.setEnabled(true);
                jLabel14.setForeground(Color.red);
                jLabel14.setVisible(true);

            }
        }
    }//GEN-LAST:event_date_txtFocusLost

    private void party_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_party_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_party_comboActionPerformed

    private void party_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_party_comboFocusLost
        if(party_combo.getSelectedItem().equals(""))
        {
            party_combo.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel10.setEnabled(true);
            jLabel10.setForeground(Color.red);
            jLabel10.setVisible(true);

        }
        else
        {
            party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel10.setEnabled(false);
            jLabel10.setVisible(false);
            k=1;
        }
    }//GEN-LAST:event_party_comboFocusLost

    private void purchase_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purchase_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_purchase_comboActionPerformed

    private void purchase_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_purchase_comboFocusLost
        if(purchase_combo.getSelectedItem().equals(""))
        {
            purchase_combo.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel12.setEnabled(true);
            jLabel12.setForeground(Color.red);
            jLabel12.setVisible(true);

        }
        else
        {
            purchase_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel12.setEnabled(false);
            jLabel12.setVisible(false);
            l=1;
        }
    }//GEN-LAST:event_purchase_comboFocusLost

    private void godown_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_godown_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_godown_comboActionPerformed

    private void godown_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_godown_comboFocusLost
        if(godown_combo.getSelectedItem().equals(""))
        {
            godown_combo.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel13.setEnabled(true);
            jLabel13.setForeground(Color.red);
            jLabel13.setVisible(true);

        }
        else
        {
            godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel13.setEnabled(false);
            jLabel13.setVisible(false);
            m=1;
        }
    }//GEN-LAST:event_godown_comboFocusLost

    private void save_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_buttonActionPerformed
        // TODO add your handling code here:
          if(invoice_no_txt.getText().equals(""))
     {
           JOptionPane.showMessageDialog(this,"Select Invoice No!"); 
     }

   
       
  else {
      
    invoice();
    date();
    party();
    purchase();
    godown(); 
         if(i==1&&j==1&&k==1&&l==1&&m==1&&x==0)
    {          
        try{
            Connection con = Database.getConnection();
            Statement ps5 =con.createStatement();
            Integer sx = Integer.parseInt(jTextField1.getText().toString());
            Integer sx1 = Integer.parseInt(jTextField3.getText().toString());
            
            
             log_table.table_update("purchase_challan_1",jLabel11.getText(),invoice_no_txt.getText());
            //Updating Sale Table 1
            PreparedStatement ps1=con.prepareStatement("update purchase_challan_1 set purchase_challan_no='"+invoice_no_txt.getText()+"', purchase_challan_date='"+date_txt.getText()+"', purchase_challan_party_name='"+party_combo.getSelectedItem().toString()+"', purchase_challan_current_balance='"+curbalnc_txt.getText()+"', purchase_challan_purchase_ledger='"+purchase_combo.getSelectedItem().toString()+"', purchase_challan_godown_name='"+godown_combo.getSelectedItem().toString()+"' where purchase_challan_id='"+sx+"'");
            ps1.executeUpdate();

            PreparedStatement ps2=con.prepareStatement("DELETE FROM purchase_challan_2 WHERE purchase_challan_no='"+jTextField2.getText()+"'");
            ps2.executeUpdate();

            int p=table1.getRowCount();
            for(int i=0;i<p;i++)
            {
                String item=table1.getValueAt(i,0).toString();
                String unit=table1.getValueAt(i,1).toString();
                String quantity=table1.getValueAt(i,2).toString();
                //

                PreparedStatement ps3=con.prepareStatement("insert into purchase_challan_2 (purchase_challan_no, purchase_challan_item, purchase_challan_unit, purchase_challan_quantity)values('"+invoice_no_txt.getText()+"','"+item+"','"+unit+"','"+quantity+"')");
                //
                ps3.executeBatch();
                ps3.executeUpdate();

                System.out.println(item);
                System.out.println(unit);
                System.out.println(quantity);

            }
            System.out.println("Update Successfully");
            update_table();
            search();
            
           invoice_no_txt.setText(null);
        party_combo.setSelectedIndex(0);
        curbalnc_txt.setText(null);
        purchase_combo.setSelectedIndex(0);
        godown_combo.setSelectedIndex(0);
        date_txt.setText(null);
        
         create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);

        
        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        purchase_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

       
        jLabel3.setVisible(false);
        
       
        jLabel14.setVisible(false);
        
       
        jLabel10.setVisible(false);
        
       
        jLabel1.setVisible(false);
       
        jLabel12.setVisible(false);
        
        
        jLabel13.setVisible(false);
        
         //TABLE RESET
           int p2=table1.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
           
        
                
                
                
        table1.setValueAt(a1, i, 0);
        table1.setValueAt(a2, i, 1);
        table1.setValueAt(a3, i, 2);
        
            }
        con.close();
        }
        catch(Exception we){
            System.out.println(we);

        }
    }
          }

    }//GEN-LAST:event_save_buttonActionPerformed

    private void search_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_txtActionPerformed

    }//GEN-LAST:event_search_txtActionPerformed

    private void product_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_product_tableMouseClicked
        //Deleting all rows from Table 1
        DefaultTableModel y = (DefaultTableModel)table1.getModel();
        int fr = y.getRowCount();
        while (fr>=1)
        {
            int a=y.getRowCount()- 1;
            y.removeRow(a);
            fr--;
        }

        int new1=product_table.getSelectedRow();
        String table_click=(product_table.getModel().getValueAt(new1, 0).toString());

        try{

            Connection con = Database.getConnection();
            Statement ps1 =con.createStatement();
            Statement ps3 =con.createStatement();
            ResultSet rs1=ps1.executeQuery("SELECT * from purchase_challan_1 where purchase_challan_no='"+table_click+"' ");

            while(rs1.next())
            {
                String  aa=rs1.getString("purchase_challan_id");
                jTextField1.setText(aa);

                String a1=rs1.getString("purchase_challan_no");
                invoice_no_txt.setText(a1);
                jTextField2.setText(a1);

                String a2=rs1.getString("purchase_challan_date");
                date_txt.setText("");
                date_txt.setText(a2);

                String a3=rs1.getString("purchase_challan_party_name");
                party_combo.setSelectedItem(a3);

                String a4=rs1.getString("purchase_challan_current_balance");
                curbalnc_txt.setText(a4);

                String a5=rs1.getString("purchase_challan_sale_ledger");
                purchase_combo.setSelectedItem(a5);

                String a6=rs1.getString("purchase_challan_godown_name");
                godown_combo.setSelectedItem(a6);
                
                String narration=rs1.getString("purchase_narration");
                challan_purchase_narration.setText(narration);
                
                
                
                   Statement ps4 =con.createStatement();
                ResultSet rs2=ps4.executeQuery("SELECT * from user_activity_table where table_name='purchase_challan_1' and value='"+table_click+"'");
                while(rs2.next())
            {
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }

                // Code to Save & Edit Sale Table 3 with value from JTextField 3
                String sch3 = jTextField2.getText().toString();
                System.out.println(sch3);
                Integer srch3 = Integer.parseInt(sch3);
                System.out.println("Invoice No.:"+srch3);

                ResultSet rs3=ps3.executeQuery("SELECT * from purchase_challan_2 where purchase_challan_no='"+srch3+"' ");
                while (rs3.next())
                {
                    String ax = rs3.getString("purchase_challan_id");
                    jTextField3.setText(ax);
                }

            }

            Statement ps2 =con.createStatement();
            ResultSet rs2=ps2.executeQuery("SELECT * from purchase_challan_2 where purchase_challan_no='"+table_click+"' ");
            //sale_item AS Item, sale_unit AS Unit, sale_quantity AS Quantity, sale_rate AS Rate, sale_amount AS Amount, sale_tax AS Amount, sale_taxable_amnt AS Taxable_Amt, sale_disc AS Discount, sale_disc_amnt AS Discount_Amt, sale_total AS Total
            //table1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs2));

            int li_row=0;
            int rw = 0;
            Vector <String> r[] = (Vector <String> []) new Vector[1000];

            table1.getColumnModel().getColumn(3).setMinWidth(0);
            table1.getColumnModel().getColumn(3).setMaxWidth(0);
            table1.getColumnModel().getColumn(3).setResizable(false);

            while(rs2.next())
            {
                y.addRow(r[rw]);

                table1.setValueAt(rs2.getString("purchase_challan_item"),li_row, 0);

                table1.setValueAt(rs2.getString("purchase_challan_unit"),li_row, 1);

                Double sqty = Double.parseDouble(rs2.getString("purchase_challan_quantity"));
                table1.setValueAt(sqty, li_row, 2);

                rw++;
                li_row++;
            }

            //jComboBox1.removeAll();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
    }//GEN-LAST:event_product_tableMouseClicked

    private void clear_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_buttonActionPerformed
        // TODO add your handling code here:
         invoice_no_txt.setText(null);
        party_combo.setSelectedIndex(0);
        curbalnc_txt.setText(null);
        purchase_combo.setSelectedIndex(0);
        godown_combo.setSelectedIndex(0);
        date_txt.setText(null);
        
         create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);

        
        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        purchase_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

       
        jLabel3.setVisible(false);
        
       
        jLabel14.setVisible(false);
        
       
        jLabel10.setVisible(false);
        
       
        jLabel1.setVisible(false);
       
        jLabel12.setVisible(false);
        
        
        jLabel13.setVisible(false);
        
         //TABLE RESET
           int p2=table1.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
           
        
                
                
                
        table1.setValueAt(a1, i, 0);
        table1.setValueAt(a2, i, 1);
        table1.setValueAt(a3, i, 2);
        
            }
    }//GEN-LAST:event_clear_buttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
        // TODO add your handling code here:
          int p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
          if(p==0){
        try{
            Connection con = Database.getConnection();
   
              PreparedStatement del=con.prepareStatement("DELETE FROM purchase_challan_1 WHERE purchase_challan_no='"+jTextField2.getText()+"' ");
              del.executeUpdate();
               PreparedStatement del2=con.prepareStatement("DELETE FROM purchase_challan_2 WHERE purchase_challan_no='"+jTextField2.getText()+"' ");
            del2.executeUpdate();
            
            log_table.table_delete("purchase_challan_1",jLabel11.getText());
            
            jOptionPane1.showMessageDialog(this,"Purchase Challan Deleted");
            invoice_no_txt.setText(null);
        party_combo.setSelectedIndex(0);
        curbalnc_txt.setText(null);
        purchase_combo.setSelectedIndex(0);
        godown_combo.setSelectedIndex(0);
        date_txt.setText(null);
        
         create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);

        
        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        purchase_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

       
        jLabel3.setVisible(false);
        
       
        jLabel14.setVisible(false);
        
       
        jLabel10.setVisible(false);
        
       
        jLabel1.setVisible(false);
       
        jLabel12.setVisible(false);
        
        
        jLabel13.setVisible(false);
        
         //TABLE RESET
           int p2=table1.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
           
        
                
                
                
        table1.setValueAt(a1, i, 0);
        table1.setValueAt(a2, i, 1);
        table1.setValueAt(a3, i, 2);
        
            }
            update_table();
            search();
            con.close();
        }
        catch(Exception e){
            System.out.println(e);
            
        }
          }
    }//GEN-LAST:event_delete_buttonActionPerformed

    private void curbalnc_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_curbalnc_txtFocusLost
     if(curbalnc_txt.getText().length()==0)
        {
            curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel1.setEnabled(false);
            jLabel1.setVisible(false);
            x=0;
        }
        else
        {
            String content = curbalnc_txt.getText();
            Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel1.setEnabled(false);
            jLabel1.setVisible(false);
            x=0;
            if(!matchFound)
            {
                x=1;
                curbalnc_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel1.setEnabled(true);
                jLabel1.setForeground(Color.red);
                jLabel1.setVisible(true);

            }
        }
    }//GEN-LAST:event_curbalnc_txtFocusLost

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        DefaultTableModel y = (DefaultTableModel)table1.getModel();

        int a=y.getRowCount()- 1;

        y.removeRow(a);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        DefaultTableModel y = (DefaultTableModel)table1.getModel();

        Vector <String> r = new Vector <String>();
        y.addRow(r);
        int i=table1.getRowCount();
        System.out.println("no."+i);
    }//GEN-LAST:event_jButton7ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea challan_purchase_narration;
    private javax.swing.JButton clear_button;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private numeric.textField.NumericTextField curbalnc_txt;
    private javax.swing.JTextField date_txt;
    private javax.swing.JButton delete_button;
    private javax.swing.JComboBox godown_combo;
    private javax.swing.JTextField invoice_no_txt;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JComboBox party_combo;
    private javax.swing.JTable product_table;
    private javax.swing.JComboBox purchase_combo;
    private javax.swing.JButton save_button;
    private javax.swing.JTextField search_txt;
    private javax.swing.JTable table1;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    // End of variables declaration//GEN-END:variables
JComboBox item_combox = new JComboBox();
    JComboBox unit_combox = new JComboBox();
}
