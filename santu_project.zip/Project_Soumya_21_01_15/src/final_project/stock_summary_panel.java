
package final_project;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

// Steve Webb 16/09/04 swebb99_uk@hotmail.com

public class stock_summary_panel extends JPanel {
    String head_trans;
     JTable table = new JTable( /*dm, new GroupableTableColumnModel()*/); 
    stock_summary_panel() 
    {
       
}
 public void print(){
            System.out.println(head_trans);
    HashMap param=new HashMap();
    param.put("stock_main_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\stock_summary_main.jasper", param);
    viewer1.setVisible(true);

}
    public void stock(String t1)
    {
        
        head_trans=t1;
          this.setLayout(new BorderLayout());
        //super( "Multi-Width Header Example" );
          table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }

            
        });
        DefaultTableModel dm = new DefaultTableModel();
        dm.setDataVector(new Object[][]{
            {"","", "","","","","","","",""},
            {"","", "","","","","","",""}},
            new Object[]{"Particulars","Quantity", "Amount","Quantity", "Amount","Quantity", "Amount","Quantity", "Rate","Amount"});
            
            // Setup table
           
            table.setAutoscrolls(false);
       // jScrollPane1.setViewportView(table_1);
        if (table.getColumnModel().getColumnCount() > 0) 
             {
            table.getColumnModel().getColumn(0).setMinWidth(120);
             }
            table.setColumnModel(new GroupableTableColumnModel());
            table.setTableHeader(new GroupableTableHeader((GroupableTableColumnModel)table.getColumnModel()));
            table.setModel(dm);
            
            // Setup Column Groups
            GroupableTableColumnModel cm = (GroupableTableColumnModel)table.getColumnModel();
            ColumnGroup g_name = new ColumnGroup( "Opening");
            g_name.add(cm.getColumn(1));
            
//            
            g_name.add(cm.getColumn(2));
            //g_name.add(cm.getColumn(3));
            ColumnGroup g_lang = new ColumnGroup("Purchase");
            g_lang.add(cm.getColumn(3));
           
//           
            g_lang.add(cm.getColumn(4));
            // g_lang.add(cm.getColumn(6));
          
            ColumnGroup g_lang1 = new ColumnGroup("Sale");
            g_lang1.add(cm.getColumn(5));
            g_lang1.add(cm.getColumn(6));
             //g_lang1.add(cm.getColumn(9));
            ColumnGroup g_lang2 = new ColumnGroup("Closing");
            g_lang2.add(cm.getColumn(7));
            g_lang2.add(cm.getColumn(8));
            g_lang2.add(cm.getColumn(9));
           //  cm.getColumn(9).setHeaderRenderer(new GroupableTableCellRenderer());

            GroupableTableHeader header = (GroupableTableHeader)table.getTableHeader();
            cm.addColumnGroup(g_name);
            cm.addColumnGroup(g_lang);
            cm.addColumnGroup(g_lang1);
            cm.addColumnGroup(g_lang2);
            // Finish off gui
            JScrollPane scroll = new JScrollPane(table);
            this.add(scroll);
            
               int fr = dm.getRowCount();
            while (fr>=1)
            {   
            int a=dm.getRowCount()- 1;
            dm.removeRow(a);
            fr--;
            }
           try
           {
              
           
           Connection con = Database.getConnection();
               
         
           
        
                Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT  p_name,inv_open,inv_open_amount,inv_purchase,inv_pur_amount,inv_sale,inv_sale_amount,(inv_open + inv_purchase - inv_sale),(inv_open_amount + inv_pur_amount - inv_sale_amount) / (inv_open + inv_purchase - inv_sale) , (inv_open_amount + inv_pur_amount - inv_sale_amount) FROM `"+t1+"` ");
        ResultSetMetaData md1=rs.getMetaData();
      int col=md1.getColumnCount();
           while(rs.next())
                 {
                  Object row1[]=new Object[col];
                   for(int x=0;x<row1.length;x++)
                   {
                 
                        row1[x]=rs.getObject(x+1);
                  
                   }
                   dm.addRow(row1);
                 }
           
              
                    
           
          table.setModel(dm);
                 dm.fireTableDataChanged();
           }
         
         
        catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
          
         
 
           
            //this.setExtendedState(getExtendedState());
    }
    

        
    }

 
/**
 * Demo renderer just to prove they can be used.
 */
class GroupableTableCellRenderer extends DefaultTableCellRenderer {
    /**
     *
     * @param table
     * @param value
     * @param selected
     * @param focused
     * @param row
     * @param column
     * @return
     */
    public Component getTableCellRendererComponent(JTable table, Object value,
    boolean selected, boolean focused, int row, int column) {
        JTableHeader header = table.getTableHeader();
        if (header != null) {
         Border border=BorderFactory.createLineBorder(Color.BLUE);
         table.setBorder(border);
        }
      //  setHorizontalAlignment(SwingConstants.CENTER);
        setText(value != null ? value.toString() : " ");
        setBorder(UIManager.getBorder("TableHeader.cellBorder"));
        return this;
    }
     
}

