/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.KeyStroke;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.DefaultMutableTreeNode;
import org.jdesktop.swingx.JXTable;
import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.decorator.Highlighter;
import org.jdesktop.swingx.decorator.HighlighterFactory;
import org.jdesktop.swingx.renderer.DefaultTableRenderer;
import org.jdesktop.swingx.renderer.StringValue;

/**
 *
 * @author Ardhendu
 */
public class stock_review_panel extends javax.swing.JPanel {

    /**
     * Creates new form stock_review_panel
     */
    public stock_review_panel() {
        initComponents();
         DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(new TableRowData("CF","","","",true));
        try{
        
            Class.forName("com.mysql.jdbc.Driver");
            String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
            Connection con = (Connection) DriverManager.getConnection(ConnUrl);
            Statement ps2 = con.createStatement();
            Statement ps = con.createStatement();
            Statement ps3 = con.createStatement();
            ResultSet rs2 = ps2.executeQuery("SELECT * from inv_group");
         
            while(rs2.next())
            {
    	   ResultSet rs3 = ps3.executeQuery("SELECT sum((inv_open + inv_purchase - inv_sale)) as quantity ,sum(0(inv_open_amount + inv_pur_amount - inv_sale_amount) / (inv_open + inv_purchase - inv_sale)) as rate , sum((inv_open_amount + inv_pur_amount - inv_sale_amount)) as amount FROM `"+rs2.getString("inv_g_name")+"`");
            while(rs3.next())
            {
            DefaultMutableTreeNode incomeNode = new DefaultMutableTreeNode(new TableRowData(rs2.getString("inv_g_name"),rs3.getString("quantity"),rs3.getString("rate"),rs3.getString("amount"),true));
          
            ResultSet rs = ps.executeQuery("SELECT  p_name,(inv_open + inv_purchase - inv_sale) as quantity,(inv_open_amount + inv_pur_amount - inv_sale_amount) / (inv_open + inv_purchase - inv_sale) as rate , (inv_open_amount + inv_pur_amount - inv_sale_amount) as amount  FROM `"+rs2.getString("inv_g_name")+"` ");
            while(rs.next())
            {
            incomeNode.add(new DefaultMutableTreeNode(new TableRowData(rs.getString("p_name"),rs.getString("quantity"),rs.getString("rate"),rs.getString("rate"),false)));
            }
            rootNode.add(incomeNode);
            
            }
            }
            
            }catch (SQLException q)
                {
                    System.out.println("Sql Exception" + q.toString());
                }
        catch(ClassNotFoundException ce)
        {
            System.out.println("ClassNotFoundException" + ce.toString());
        }
//    	incomeNode.add(new DefaultMutableTreeNode(new TableRowData("Salary2","250002","50002","3000002",false)));
//    	incomeNode.add(new DefaultMutableTreeNode(new TableRowData("Salary3","250003","50003","3000003",false)));
//    	incomeNode.add(new DefaultMutableTreeNode(new TableRowData("Salary4","250004","50004","3000004",false)));
//    	incomeNode.add(new DefaultMutableTreeNode(new TableRowData("Salary5","250005","50005","3000005",false)));
    	
    	
    	rootNode.add(new DefaultMutableTreeNode());
    	
//    	DefaultMutableTreeNode expenseNode = new DefaultMutableTreeNode(new TableRowData("Expenses","25000","5000","300000",true));
//    	expenseNode.add(new DefaultMutableTreeNode(new TableRowData("Salary1","250001","50001","3000001",false)));
//    	expenseNode.add(new DefaultMutableTreeNode(new TableRowData("Salary2","250002","50002","3000002",false)));
//    	expenseNode.add(new DefaultMutableTreeNode(new TableRowData("Salary3","250003","50003","3000003",false)));
//    	expenseNode.add(new DefaultMutableTreeNode(new TableRowData("Salary4","250004","50004","3000004",false)));
//    	expenseNode.add(new DefaultMutableTreeNode(new TableRowData("Salary5","250005","50005","3000005",false)));
//    	
//    	rootNode.add(expenseNode);
	
    	JXTreeTable binTree = new JXTreeTable(new MyTreeModel(rootNode));
    	binTree.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        binTree.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }

            
        });
    	Highlighter highligher = HighlighterFactory.createSimpleStriping(HighlighterFactory.BEIGE);
    	binTree.setHighlighters(highligher);
        binTree.setShowGrid(false);
        binTree.setShowsRootHandles(false);
         configureCommonTableProperties(binTree);
        binTree.setTreeCellRenderer(new TreeTableCellRenderer());
        binTree.expandAll();
        
        binTree.addMouseListener(new MouseAdapter() {

        public void mouseClicked(MouseEvent e) {

        JXTreeTable bin = (JXTreeTable) e.getComponent();
        if (bin.isCollapsed(bin.getSelectedRow())) {
        bin.expandRow(bin.getSelectedRow());
        } else {
        bin.collapseRow(bin.getSelectedRow());
        }
        }

        });
        
        //key event
        
        binTree.addKeyListener(new java.awt.event.KeyAdapter()

            {
                //@Override
            public void keyPressed(java.awt.event.KeyEvent e)

            {

            int keyvalue=e.getKeyCode();
            if(keyvalue==KeyEvent.VK_ENTER)
                            {
                               // System.out.println("Ardhendu");
                               JXTreeTable bin = (JXTreeTable) e.getComponent();
        if (bin.isCollapsed(bin.getSelectedRow())) {
        bin.expandRow(bin.getSelectedRow());
        } else {
        bin.collapseRow(bin.getSelectedRow());
        }   
                                
                            }
            Action delete = new AbstractAction()
        {
            public void actionPerformed(ActionEvent e)
            {

            }
        };

        }

        }

        );
  
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

 private void  configureCommonTableProperties(JXTable table) {
        table.setColumnControlVisible(true);
        StringValue toString = new StringValue() {

            public String getString(Object value) {
                if (value instanceof Point) {
                    Point p = (Point) value;
                    return createString(p.x, p.y);
                } else if (value instanceof Dimension) {
                    Dimension dim = (Dimension) value;
                    return createString(dim.width, dim.height);
                }
               return "";
            }

            private String createString(int width, int height) {
                return "(" + width + ", " + height + ")";
            }
            
        };
        TableCellRenderer renderer = new DefaultTableRenderer(toString);
        table.setDefaultRenderer(Point.class, renderer);
        table.setDefaultRenderer(Dimension.class, renderer);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
