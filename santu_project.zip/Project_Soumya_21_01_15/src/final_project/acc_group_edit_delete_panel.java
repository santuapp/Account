package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class acc_group_edit_delete_panel extends javax.swing.JPanel {
     Font myFont = new Font("",Font.PLAIN,9);
      int i=0,j=0;
       String user_activity_id="";
    /**
     * Creates new form acc_group_edit_delete_panel
     */
      
      public void set(){
          search_txt.requestFocusInWindow();
          search_txt.setFocusable(true);
      }
    public acc_group_edit_delete_panel() {
//         JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
        initComponents();
        set();
       //group_name_txt.setFocusable(true);
        //group_name_txt.setEditable(false);
        
        
        
           try{

             Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct g_name from acc_group order by acc_g_id");
          
            while(rs.next())
            {
                String name=rs.getString("g_name");

                under_combo.addItem(name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
       
        
        jLabel4.setFont(myFont);
        jLabel4.setEnabled(false);
        jLabel4.setVisible(false);
        
        jLabel5.setFont(myFont);
        jLabel5.setEnabled(false);
        jLabel5.setVisible(false);
        
        jLabel6.setVisible(false);
        create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
        under_combo.setVisible(true);
        update_table();
         search();
          group_id.setVisible(false);
            name.setVisible(false);
          //setDefaultCloseOperation(DISPOSE_ON_CLOSE);
          table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }

            
        });
        
        
    }
    
    
    public void user(String u_name){
        jLabel6.setText(u_name);
        
    }
      // group name
    
    public void group(){
              if(group_name_txt.getText().length()==0)
      {
          group_name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel4.setEnabled(true);
          jLabel4.setForeground(Color.red);
          jLabel4.setVisible(true);
             
      }  
      else
      {
           group_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel4.setEnabled(false);  
           jLabel4.setVisible(false);
           i=1;
      }
        
    }
    
    // under
    
    public void under(){
           if(under_combo.getSelectedItem().equals(""))
       {
          under_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel5.setEnabled(true);
          jLabel5.setForeground(Color.red);
          jLabel5.setVisible(true);
       }
       else
       {
           under_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel5.setEnabled(false);  
           jLabel5.setVisible(false);
           j=1;
       }
        
    }
    
  
   
    
    
      public void search(){
        search_txt.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   String s1=search_txt.getText();

 
 
 String s3=s1;
     
                    try{
        Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT g_name as `GROUP NAME` from acc_group where g_name like '"+s3+"%' and acc_g_id>4"); 
          
              
                table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
                con.close();
                    }catch (SQLException e1){
        System.out.println("Sql Exception" + e1.toString());
        }
        
                
}
            });
    }
            public void update_table()
{ 
       
        try{
        
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT g_name as `GROUP NAME`  from acc_group where acc_g_id > 4 ");
          table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
           
          
          con.close();
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
       
        
        table.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   
int keyvalue=e.getKeyCode();
if(keyvalue==KeyEvent.VK_ENTER)
                {
                   // jComboBox1.setVisible(false);
//jTextField2.setVisible(true);
                 int row=table.getSelectedRow();
                 int col=table.getSelectedColumn();
                
                if(table.getValueAt(row, 0) != null){
                String s1= (String)table.getValueAt(row, 0);
                
                
//JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());

System.out.println(" Value in the row clicked :"+ " " +row+"");
System.out.println(" Value in the col clicked :"+ " " +col+"");
System.out.println(" Value in the col,row clicked :"+ " " +s1+"");

          try{
         
            Connection con1 = Database.getConnection();;
        Statement ps1 =con1.createStatement();
          //Statement ps2 =con1.createStatement();
           ResultSet rs1=ps1.executeQuery("SELECT * from acc_group where g_name='"+s1+"' ");
       while(rs1.next())
                {
                    
                           // jComboBox1.removeAll(); 
                    
                  String  id=rs1.getString(1);
                  group_name_txt.setText(id);
                  name.setText(id);
                  
                     String  aa=rs1.getString(2);
                     under_combo.setSelectedItem(aa);
                     
                      Statement ps2 =con1.createStatement();
                ResultSet rs2=ps2.executeQuery("SELECT * from user_activity_table where table_name='acc_group' and value='"+name.getText()+"'");
                while(rs2.next())
            {
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                   
                }
       
          con1.close();
         
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
       

                }  }



}

}

);
    Action delete = new AbstractAction()
{
    public void actionPerformed(ActionEvent e)
    {
        
    }
};
 
 
}
             private void tableMouseClicked(java.awt.event.MouseEvent evt) {                                   

            int new1=table.getSelectedRow();
            String table_click=(table.getModel().getValueAt(new1, 0).toString());
        try{
         
          Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
        // Statement ps2 =con1.createStatement();
           ResultSet rs1=ps1.executeQuery("SELECT * from acc_group where g_name='"+table_click+"' ");
            //jComboBox1.removeAll();
       while(rs1.next())
                {
                      String  id=rs1.getString(3);
                      group_id.setText(id);
                       String  gname=rs1.getString(1);
                       
                       name.setText(gname);
                    group_name_txt.setText(gname);
                     String  aa=rs1.getString(2);
                     under_combo.setSelectedItem(aa);
                
                     
                      Statement ps2 =con1.createStatement();
                ResultSet rs2=ps2.executeQuery("SELECT * from user_activity_table where table_name='acc_group' and value='"+name.getText()+"'");
                while(rs2.next())
            {
                
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                     
                }
       
          con1.close();
          //jComboBox1.removeAll();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
       
        
        

// TODO add your handling code here:
    }     
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        save = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        group_id = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        group_name_txt = new javax.swing.JTextField();
        under_combo = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        create_date = new javax.swing.JTextField();
        create_user = new javax.swing.JTextField();
        update_date = new javax.swing.JTextField();
        update_user = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        search_txt = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();

        jPanel1.setLayout(new java.awt.GridBagLayout());

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        save.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save.setText("Save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        delete.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete.setText("Delete");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        jButton3.setText("Clear");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(delete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(save, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(save)
                .addGap(44, 44, 44)
                .addComponent(delete)
                .addGap(41, 41, 41)
                .addComponent(jButton3)
                .addContainerGap())
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.ipady = 102;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 10, 60, 0);
        jPanel1.add(jPanel2, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 58;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(11, 10, 0, 0);
        jPanel1.add(group_id, gridBagConstraints);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 0, 255))); // NOI18N

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("*Group Name:");

        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("*Under:");

        group_name_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        group_name_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                group_name_txtFocusLost(evt);
            }
        });

        under_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        under_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        under_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                under_comboFocusLost(evt);
            }
        });

        jLabel4.setText("Enter Group Name!");

        jLabel5.setText("Select Under!");

        jLabel6.setText("jLabel6");

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 10), java.awt.Color.cyan)); // NOI18N

        jLabel8.setForeground(new java.awt.Color(51, 153, 0));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Creation Date:");

        jLabel9.setForeground(new java.awt.Color(51, 153, 0));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Updated By:");

        jLabel10.setForeground(new java.awt.Color(51, 153, 0));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Updation Date:");

        jLabel7.setForeground(new java.awt.Color(51, 153, 0));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Created By:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(update_date, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                    .addComponent(update_user)
                    .addComponent(create_date)
                    .addComponent(create_user))
                .addContainerGap())
        );

        jPanel6Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel10, jLabel7, jLabel8, jLabel9});

        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9))
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6)
                            .addComponent(under_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(group_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(group_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(under_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 4;
        gridBagConstraints.ipadx = 47;
        gridBagConstraints.ipady = 13;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 10, 60, 0);
        jPanel1.add(jPanel3, gridBagConstraints);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(search_txt, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(search_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
        );

        table.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        table.setForeground(new java.awt.Color(0, 0, 255));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 10;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 6;
        gridBagConstraints.ipady = 250;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 10, 60, 25);
        jPanel1.add(jPanel4, gridBagConstraints);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Edit/Delete Group Ledger");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(11, 131, 0, 0);
        jPanel1.add(jLabel1, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 87;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(11, 6, 0, 0);
        jPanel1.add(name, gridBagConstraints);

        jScrollPane2.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 825, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
  // Validation Start...
//       JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE); 
        if(name.getText().equals(""))
     {
           jopt1.showMessageDialog(this,"Select Group Name!"); 
     }
        
      else {
       group();
      under();  
         if(i==1&&j==1)
    {       
      
        
      
        try{

           
            
            Connection con2 = Database.getConnection();;
             Statement ps5 =con2.createStatement(); 
                           ResultSet rs5=ps5.executeQuery("SELECT g_name from acc_group where g_name='"+group_name_txt.getText()+"'");

//if(rs5.next())
//{
//     jopt2.showMessageDialog(this,"Group Already Exsist"); 
//}
//else{
            PreparedStatement ps10=con2.prepareStatement("update user_activity_table set value='"+group_name_txt.getText()+"' where  value='"+name.getText()+"'");
            ps10.executeUpdate();
                           
            log_table.table_update("acc_group",group_name_txt.getText(),user_activity_id);
                PreparedStatement ps1=con2.prepareStatement("update acc_group set g_name='"+group_name_txt.getText()+"',g_under='"+under_combo.getSelectedItem().toString()+"' where  acc_g_id='"+group_id.getText()+"'");
                ps1.executeUpdate();
                  Statement pss0 =con2.createStatement();
                 
           Statement stmt1=con2.createStatement();
                 
                stmt1.executeUpdate("drop table `"+group_name_txt.getText()+"`");
                if(name.getText()!=group_name_txt.getText())
                {
                    PreparedStatement psss=con2.prepareStatement("CREATE TABLE IF NOT EXISTS `"+group_name_txt.getText()+"` like `asset`");
                    psss.executeUpdate();               
                }
                
            


//}
       
con2.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        jopt1.showMessageDialog(this,"Group Updated");
                update_table();
                set();
                search();
            
                reset();
         
        }
    }
      
    }//GEN-LAST:event_saveActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        int p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(p==0)
        {
            try{

                log_table.table_delete("acc_group", jLabel6.getText());
                
               Connection con1 = Database.getConnection();
                Statement ps5 =con1.createStatement(); 
            ResultSet rs5=ps5.executeQuery("SELECT distinct acc_group.flag,l_under from acc_group,ledger where ledger.l_under='"+name.getText()+"' and acc_group.flag=1");

            if(rs5.next())
            {
               
               
                 jopt1.showMessageDialog(this,"Group can't be deleted "+""+"\n"+""+"Delete the transactions first"); 
                 
                 
            }
            
            else{
                PreparedStatement ps1=con1.prepareStatement("delete from  acc_group where acc_g_id='"+group_id.getText()+"'");

                ps1.executeUpdate();
                Statement stmt1=con1.createStatement();
                 
                stmt1.executeUpdate("drop table `"+group_name_txt.getText()+"`");

              
              
          
         
               con1.close();
            }
            }catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
            JOptionPane.showMessageDialog(null, "Group Deleted");
            set();
            search();
             reset();

             update_table();
 
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_deleteActionPerformed

    private void group_name_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_group_name_txtFocusLost
//        // TODO add your handling code here:
//        if(group_name_txt.getText().length()==0){
//            
//            group_name_txt.setBorder(javax.swing.BorderFactory.createLineBorder(Color.RED));
//            jLabel4.setForeground(Color.RED);
//            jLabel4.setEnabled(true);
//            jLabel4.setVisible(true);
//            
//        }
//        else
//            group_name_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//            jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//            jLabel4.setEnabled(false);
//            jLabel4.setVisible(false);
        
             if(group_name_txt.getText().length()==0)
      {
          group_name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel4.setEnabled(true);
          jLabel4.setForeground(Color.red);
          jLabel4.setVisible(true);
             
      }  
      else
      {
           group_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel4.setEnabled(false);  
           jLabel4.setVisible(false);
           i=1;
      }
    }//GEN-LAST:event_group_name_txtFocusLost

    private void under_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_under_comboFocusLost
//        // TODO add your handling code here:
//         if(under_combo.getSelectedItem()==null){
//            
//            under_combo.setBorder(javax.swing.BorderFactory.createLineBorder(Color.RED));
//        }
//        else
//            under_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              if(under_combo.getSelectedItem().equals(""))
       {
          under_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel5.setEnabled(true);
          jLabel5.setForeground(Color.red);
          jLabel5.setVisible(true);
       }
       else
       {
           under_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel5.setEnabled(false);  
           jLabel5.setVisible(false);
           j=1;
       }
    }//GEN-LAST:event_under_comboFocusLost

    public void reset(){
         group_name_txt.setText(null);
        under_combo.setSelectedItem("");
        create_user.setText(null);
        create_date.setText(null);
        update_user.setText(null);
        update_date.setText(null);
        under_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        group_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        
        jLabel4.setVisible(false);
        jLabel5.setVisible(false);
        
        
    }
    
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        set();
            search();
             reset();

             update_table();
        
    }//GEN-LAST:event_jButton3ActionPerformed

    
    public void fill_combo_ref(){
         try{

             Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct g_name from acc_group order by acc_g_id");
          
            while(rs.next())
            {
                String name=rs.getString("g_name");

                under_combo.addItem(name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private javax.swing.JButton delete;
    private javax.swing.JTextField group_id;
    private javax.swing.JTextField group_name_txt;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField name;
    private javax.swing.JButton save;
    private javax.swing.JTextField search_txt;
    private javax.swing.JTable table;
    private javax.swing.JComboBox under_combo;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    // End of variables declaration//GEN-END:variables
private javax.swing.JOptionPane jopt1;
private javax.swing.JOptionPane jopt2;
}
