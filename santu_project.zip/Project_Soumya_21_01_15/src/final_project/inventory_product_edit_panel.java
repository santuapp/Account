package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import org.jdesktop.xswingx.PromptSupport;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author virtual vista
 */
public class inventory_product_edit_panel extends javax.swing.JPanel {
           

    Font myFont = new Font("",Font.PLAIN,9);

int i=0,j=0,k=0;   // For Mandatory
int x=0,y=0,z=0;       // For Non Mandatory
String user_activity_id="";

    /**
     * Creates new form inventory_product_edit_panel
     */

public void set(){
    search_txt.requestFocusInWindow();
    search_txt.setFocusable(true);
}

public void user(String u_name){
    jLabel20.setText(u_name);
}

public void set1(){
    item_name_txt.requestFocusInWindow();
    item_name_txt.setFocusable(true);
}
    public inventory_product_edit_panel() {
      
        initComponents();
        set();
        fill_combo();
        update_table();
        search();
        table_clicked();
        jTextField1.setVisible(false);
        it_name.setVisible(false);
        grp_name.setVisible(false);
        
       // item_name_txt.setFocusable(true);
      //  item_name_txt.setEditable(false);
       
        group.setEditable(false);
        PromptSupport.setPrompt("0.00", discount_txt);
        PromptSupport.setPrompt("0.00", tax_txt);
        PromptSupport.setPrompt("0.00", quantity_txt);
        PromptSupport.setPrompt("0.00", rate_txt);
        PromptSupport.setPrompt("0.00", value_txt);
        
         jLabel12.setFont(myFont);
        jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        jLabel13.setFont(myFont);
        jLabel13.setEnabled(false);
        jLabel13.setVisible(false);
        
        jLabel14.setFont(myFont);
        jLabel14.setEnabled(false);
        jLabel14.setVisible(false);
        
        jLabel15.setFont(myFont);
        jLabel15.setEnabled(false);
        jLabel15.setVisible(false);
        
        jLabel16.setFont(myFont);
        jLabel16.setEnabled(false);
        jLabel16.setVisible(false);
        
        jLabel17.setFont(myFont);
        jLabel17.setEnabled(false);
        jLabel17.setVisible(false);
        
        jLabel18.setFont(myFont);
        jLabel18.setEnabled(false);
        jLabel18.setVisible(false);
        
        jLabel19.setFont(myFont);
        jLabel19.setEnabled(false);
        jLabel19.setVisible(false);
        
        
        jLabel11.setFont(myFont);
        jLabel11.setEnabled(false);
        jLabel11.setVisible(false);
        
        
        jLabel20.setVisible(false);
        
        //Discounts & Tax
        
        jLabel7.setVisible(false);
        discount_txt.setVisible(false);
        jLabel14.setVisible(false);
        jLabel8.setVisible(false);
        tax_txt.setVisible(false);
        jLabel15.setVisible(false);
        
         create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
    }
    
           // VaLIDATION..........................
        
    // item name
        
        public void item(){
            if(item_name_txt.getText().length()==0)
      {
          item_name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel11.setEnabled(true);
          jLabel11.setForeground(Color.red);
          jLabel11.setVisible(true);
             
      }  
      else
      {
           item_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel11.setEnabled(false);  
           jLabel11.setVisible(false);
           i=1;
      }    
            
            
        }
        
    // group
        
        public void group(){
              if(group.getSelectedItem().equals(""))
       {
          group.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel12.setEnabled(true);
          jLabel12.setForeground(Color.red);
          jLabel12.setVisible(true);
       }
       else
       {
           group.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel12.setEnabled(false);  
           jLabel12.setVisible(false);
           j=1;
       }
        }
        
      // unit
        
        public void unit(){
                     if(unit.getSelectedItem().equals(""))
       {
          unit.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
       }
       else
       {
           unit.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           k=1;
       }
        }
        
      // quantity
        
//        public void quantity(){
//              if(quantity_txt.getText().length()==0)
//        {
//            quantity_txt.setBorder(BorderFactory.createLineBorder(Color.red));
//            jLabel17.setEnabled(true);
//            jLabel17.setForeground(Color.red);
//            jLabel17.setVisible(true);
//        }
//        else
//        {
//             String content = quantity_txt.getText();
//             Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
//             Matcher m = p.matcher(content);
//             boolean matchFound = m.matches();
//             quantity_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//             jLabel17.setEnabled(false);  
//             jLabel17.setVisible(false);
//             l=1;
//           
//            if(!matchFound)
//
//            {
//                 quantity_txt.setBorder(BorderFactory.createLineBorder(Color.red));
//                 jLabel17.setEnabled(true);
//                 jLabel17.setForeground(Color.red);
//                 jLabel17.setVisible(true);
//                 
//            }
//        }
//        }

    public void fill_combo()
    {
      try{
        
            Connection con = Database.getConnection();
            
            // Adding Items to Group
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("select distinct inv_g_name from inv_group order by inv_g_id");
            
               while(rs.next())
              {
                  String name=rs.getString("inv_g_name");
                  group.addItem(name);
              }
               
            //              String name1="Others";
            //              group.addItem(name1);
            
            //Adding Items to Unit
            Statement ps2 =con.createStatement();
            ResultSet rs2=ps2.executeQuery("select distinct u_name from unit order by u_id");
            
               while(rs2.next())
              {
                  String name2=rs2.getString("u_name");
                  unit.addItem(name2);
              }
                           
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
          
    
    }
    
        public void update_table()
    { 
       
        try{
        
               Connection con = Database.getConnection();
               Statement ps =con.createStatement();
               ResultSet rs=ps.executeQuery("SELECT product_name as `PRODUCT NAME` from product");
               product_table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));

               System.out.println("Done");
          
         
            }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
            }
            
        
        product_table.addKeyListener(new java.awt.event.KeyAdapter()

            {

            public void keyReleased(java.awt.event.KeyEvent e)

            {

            int keyvalue=e.getKeyCode();
            if(keyvalue==KeyEvent.VK_ENTER)
                            {
                                                                
                             int row=product_table.getSelectedRow();
                             int col=product_table.getSelectedColumn();

                            if(product_table.getValueAt(row, 0) != null){
                            String s1= (String)product_table.getValueAt(row, 0);


            //JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());

            System.out.println(" Value in the row clicked :"+ " " +row+"");
            System.out.println(" Value in the col clicked :"+ " " +col+"");
            System.out.println(" Value in the col,row clicked :"+ " " +s1+"");

          try{
         
            Connection con1 = Database.getConnection();
            Statement ps1 =con1.createStatement();
            Statement ps2 =con1.createStatement();
            ResultSet rs1 =ps1.executeQuery("SELECT * from product where product_name='"+s1+"' ");
            while(rs1.next())
                {
                
                    set1();
                String  aa=rs1.getString("p_id");
                jTextField1.setText(aa);
                
                String a1=rs1.getString("product_name");
                item_name_txt.setText(a1);
                it_name.setText(a1);
                String a2=rs1.getString("p_group");
                group.setSelectedItem(a2);
                grp_name.setText(a2);
                String a3=rs1.getString("p_unit");
                unit.setSelectedItem(a3);
                
                String a4=rs1.getString("p_quantity");
                quantity_txt.setText(a4);
                
                String a5=rs1.getString("p_rate");
                rate_txt.setText(a5);

                String a6=rs1.getString("p_discount");
                discount_txt.setText(a6);
                                
                String a7=rs1.getString("p_tax");
                tax_txt.setText(a7);
                
                String a8=rs1.getString("product_code");
                product_code_txt.setText(a8);
                
                String a9=rs1.getString("p_value");
                value_txt.setText(a9);
                
                 Statement ps3 =con1.createStatement();
                ResultSet rs2=ps3.executeQuery("SELECT * from user_activity_table where table_name='product' and value='"+it_name.getText()+"'");
                while(rs2.next())
            {
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                
                
                }
       
          
         
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
       

                }  }

        }

        }

        );
            Action delete = new AbstractAction()
        {
            public void actionPerformed(ActionEvent e)
            {

            }
        };


        }
  
     public void search()
    {
       search_txt.addKeyListener(new java.awt.event.KeyAdapter()

       {

        public void keyReleased(java.awt.event.KeyEvent e)

        {
        String s1=search_txt.getText();
        String s3=s1;
     
        try{
        Connection con = Database.getConnection();
        Statement ps =con.createStatement();
        ResultSet rs=ps.executeQuery("SELECT product_name as `PRODUCT NAME` from product where product_name like '"+s3+"%'"); 


        product_table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));

        }catch (SQLException e1){
        System.out.println("Sql Exception" + e1.toString());
        }
        
                
        }
     });
    }
    
        
        
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane1 = new javax.swing.JOptionPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        save_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        clear_button = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        item_name_txt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        product_code_txt = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        discount_txt = new numeric.textField.NumericTextField();
        tax_txt = new numeric.textField.NumericTextField();
        quantity_txt = new numeric.textField.NumericTextField();
        rate_txt = new numeric.textField.NumericTextField();
        value_txt = new numeric.textField.NumericTextField();
        jLabel16 = new javax.swing.JLabel();
        group = new com.jidesoft.swing.AutoCompletionComboBox();
        unit = new com.jidesoft.swing.AutoCompletionComboBox();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        search_txt = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        product_table = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        grp_name = new javax.swing.JTextField();
        it_name = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        create_date = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        update_date = new javax.swing.JTextField();

        setLayout(new java.awt.BorderLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Inventory Product Edit/Delete");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        save_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        save_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save_button.setText("Save");
        save_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_buttonActionPerformed(evt);
            }
        });

        delete_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete_button.setText("Delete");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });

        clear_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        clear_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        clear_button.setText("Clear");
        clear_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clear_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(save_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(delete_button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(save_button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(delete_button)
                .addGap(33, 33, 33)
                .addComponent(clear_button)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Item Name:");

        item_name_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        item_name_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                item_name_txtFocusLost(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Group:");

        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Unit:");

        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Discount(%):");

        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Tax(%):");

        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Product Code:");

        product_code_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel10.setForeground(new java.awt.Color(0, 0, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Value:");

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Quantity:");

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Rate:");

        jLabel11.setText("Enter Item Name!");

        jLabel12.setText("Select Group!");

        jLabel13.setText("Select Unit!");

        jLabel14.setText("Enter Disc. Percentage!");

        jLabel15.setText("Enter Tax Percentage!");

        jLabel17.setText("Enter Quantity!");

        jLabel18.setText("Enter Rate!");

        jLabel19.setText("Enter Valid Value!");

        discount_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        discount_txt.setText("numericTextField1");
        discount_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                discount_txtFocusLost(evt);
            }
        });

        tax_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        tax_txt.setText("numericTextField1");
        tax_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tax_txtFocusLost(evt);
            }
        });

        quantity_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        quantity_txt.setText("numericTextField1");
        quantity_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                quantity_txtFocusLost(evt);
            }
        });

        rate_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        rate_txt.setText("numericTextField1");
        rate_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                rate_txtFocusLost(evt);
            }
        });

        value_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        value_txt.setText("numericTextField1");

        jLabel16.setText("Enter Product Code!");

        group.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));

        unit.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(quantity_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rate_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 32, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(item_name_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(discount_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tax_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(product_code_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(value_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(group, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(unit, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel10, jLabel2, jLabel3, jLabel4, jLabel5, jLabel6, jLabel7, jLabel8, jLabel9});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(item_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(group, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(unit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addGap(2, 2, 2)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(discount_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tax_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15)
                .addGap(5, 5, 5)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_code_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel16)
                .addGap(3, 3, 3)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 5, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(quantity_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(rate_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel18)
                .addGap(7, 7, 7)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(value_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel19))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        search_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_txtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(search_txt, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(search_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        product_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        product_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                product_tableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(product_table);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jLabel20.setText("jLabel20");

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 13), java.awt.Color.cyan)); // NOI18N

        jLabel21.setForeground(new java.awt.Color(51, 153, 0));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("Create User:");

        jLabel22.setForeground(new java.awt.Color(51, 153, 0));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel22.setText("Create Date:");

        jLabel23.setForeground(new java.awt.Color(51, 153, 0));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel23.setText("Update User:");

        jLabel24.setForeground(new java.awt.Color(51, 153, 0));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel24.setText("Update Date:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(it_name, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(grp_name, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel20))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jPanel4, jPanel6});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(it_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(grp_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void save_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_buttonActionPerformed
       if(item_name_txt.getText().equals(""))
     {
           JOptionPane.showMessageDialog(this,"Select Product!"); 
     }
    else{
        item();
        group();
        unit();
   //     quantity();
        
        if(i==1&&j==1&&k==1&&x==0&&y==0&&z==0)
                     {
      
        String invoice = jTextField1.getText();
        
        if (invoice!="")
      {  
        try{

             Connection con2 = Database.getConnection();
             Statement ps5 =con2.createStatement(); 
             log_table.table_update("product", item_name_txt.getText(), user_activity_id);
             PreparedStatement ps1=con2.prepareStatement("update product set product_name='"+item_name_txt.getText()+"',p_group='"+group.getSelectedItem().toString()+"',p_unit='"+unit.getSelectedItem().toString()+"',product_code='"+product_code_txt.getText()+"',p_discount='"+discount_txt.getText()+"',p_tax='"+tax_txt.getText()+"',p_quantity='"+quantity_txt.getText()+"',p_rate='"+rate_txt.getText()+"',p_value='"+value_txt.getText()+"' where p_id='"+jTextField1.getText()+"'");
             ps1.executeUpdate();
             
             PreparedStatement ps3=con2.prepareStatement("delete from  `"+grp_name.getText()+"` where p_name='"+it_name.getText()+"'");

                ps3.executeUpdate();
                
             PreparedStatement ps2=con2.prepareStatement("insert into `"+group.getSelectedItem().toString()+"`(p_name,inv_open,inv_open_amount)values('"+item_name_txt.getText()+"','"+quantity_txt.getText()+"','"+value_txt.getText()+"')");
            ps2.executeUpdate();
                   
                    
                              
         con2.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
        jOptionPane1.showMessageDialog(this,"Product Details Updated");
        
        reset();
        set();
         update_table(); 
        search();
      }
      else
      {
      jOptionPane1.showMessageDialog(this,"Select a valid Product Name");
      }
        jTextField1.setText(null);
        search_txt.setText(null);
        update_table();
                     }
       }
    }//GEN-LAST:event_save_buttonActionPerformed

    
    public void table_clicked(){
          product_table.addMouseListener(new MouseListener() {
            
           
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                System.out.println("Hello Jerry");
                
                if (evt.getButton() == MouseEvent.BUTTON1 && evt.getClickCount()>1)
                {   
                Point p = evt.getPoint();
                    
                int rowled=product_table.rowAtPoint(p);
                //int rowled=led_sum.table.getSelectedRow();
                String table_click=(product_table.getModel().getValueAt(rowled, 0).toString());
                
                System.out.println(" Value in the col,row clicked :"+ " " +table_click+"");
                   // }
                
                  try{
         
            Connection con1 = Database.getConnection();
            Statement ps1 =con1.createStatement();
            Statement ps2 =con1.createStatement();
            ResultSet rs1=ps1.executeQuery("SELECT * from product where product_name='"+table_click+"' ");
            //jComboBox1.removeAll();
       
           while(rs1.next())
                {
                    set1();
                 String  aa=rs1.getString("p_id");
                jTextField1.setText(aa);
                
                String a1=rs1.getString("product_name");
                item_name_txt.setText(a1);
                it_name.setText(a1);
                String a2=rs1.getString("p_group");
                group.setSelectedItem(a2);
                grp_name.setText(a2);
                String a3=rs1.getString("p_unit");
                unit.setSelectedItem(a3);
                
                String a4=rs1.getString("p_quantity");
                quantity_txt.setText(a4);
                
                String a5=rs1.getString("p_rate");
                rate_txt.setText(a5);

                String a6=rs1.getString("p_discount");
                discount_txt.setText(a6);
                                
                String a7=rs1.getString("p_tax");
                tax_txt.setText(a7);
                
                String a8=rs1.getString("product_code");
                product_code_txt.setText(a8);
                
                String a9=rs1.getString("p_value");
                value_txt.setText(a9);
                
                 Statement ps3 =con1.createStatement();
                ResultSet rs2=ps3.executeQuery("SELECT * from user_activity_table where table_name='product' and value='"+it_name.getText()+"'");
                while(rs2.next())
            {
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                }
       
          con1.close();
          //jComboBox1.removeAll();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
    
            
                
                    }}

                @Override
                public void mousePressed(MouseEvent e) {
                     product_table.getCellEditor().stopCellEditing();
                   // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                  //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

                @Override
                public void mouseExited(MouseEvent e) {
                  //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
                
                });
     }
    
    
    
    private void product_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_product_tableMouseClicked
         
            int new1=product_table.getSelectedRow();
            String table_click=(product_table.getModel().getValueAt(new1, 0).toString());
            
            try{
         
            Connection con1 = Database.getConnection();
            Statement ps1 =con1.createStatement();
            Statement ps2 =con1.createStatement();
            ResultSet rs1=ps1.executeQuery("SELECT * from product where product_name='"+table_click+"' ");
            //jComboBox1.removeAll();
       
           while(rs1.next())
                {
                    set1();
                 String  aa=rs1.getString("p_id");
                jTextField1.setText(aa);
                
                String a1=rs1.getString("product_name");
                item_name_txt.setText(a1);
                it_name.setText(a1);
                String a2=rs1.getString("p_group");
                group.setSelectedItem(a2);
                grp_name.setText(a2);
                String a3=rs1.getString("p_unit");
                unit.setSelectedItem(a3);
                
                String a4=rs1.getString("p_quantity");
                quantity_txt.setText(a4);
                
                String a5=rs1.getString("p_rate");
                rate_txt.setText(a5);

                String a6=rs1.getString("p_discount");
                discount_txt.setText(a6);
                                
                String a7=rs1.getString("p_tax");
                tax_txt.setText(a7);
                
                String a8=rs1.getString("product_code");
                product_code_txt.setText(a8);
                
                String a9=rs1.getString("p_value");
                value_txt.setText(a9);
                
                 Statement ps3 =con1.createStatement();
                ResultSet rs2=ps3.executeQuery("SELECT * from user_activity_table where table_name='product' and value='"+it_name.getText()+"'");
                while(rs2.next())
            {
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                }
       
          
          //jComboBox1.removeAll();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        
    }//GEN-LAST:event_product_tableMouseClicked

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
        
        int p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(p==0)
        {
            try{
                Connection con1 = Database.getConnection();
                Statement ps5 =con1.createStatement(); 
            ResultSet rs5=ps5.executeQuery("SELECT distinct product.flag from product where product_name='"+it_name.getText()+"' and product.flag=1");

            if(rs5.next())
            {
               
               
                 jopt1.showMessageDialog(this,"Product can't be deleted "+""+"\n"+""+"Delete the transactions first"); 
                 
                 
            }
            else{
                PreparedStatement ps1=con1.prepareStatement("delete from product where p_id='"+jTextField1.getText()+"'");

                ps1.executeUpdate();
                  
                System.out.println("Done");
                
                log_table.table_delete("product",jLabel20.getText());
            con1.close();
            }
            }
            catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
            
            
        jOptionPane1.showMessageDialog(this,"Product Details Deleted");
       reset();
       set();
       update_table();
       search();
        
    }//GEN-LAST:event_delete_buttonActionPerformed
   }
    
    //reset
    public void reset(){
        jTextField1.setText(null);
        search_txt.setText(null);
        //update_table();
        
        item_name_txt.setText(null);
        group.setSelectedIndex(0);
        unit.setSelectedIndex(0);
        product_code_txt.setText(null);
        discount_txt.setText(null);
        tax_txt.setText(null);
        quantity_txt.setText(null);
        rate_txt.setText(null);
        value_txt.setText(null);
        
        create_user.setText(null);
        create_date.setText(null);
        update_user.setText(null);
        update_date.setText(null);
        
        
        item_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        group.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        unit.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        product_code_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        discount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        tax_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        quantity_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        rate_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        value_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        
         
        jLabel12.setVisible(false);       
        jLabel13.setVisible(false);        
        jLabel14.setVisible(false);        
        jLabel15.setVisible(false);        
        jLabel16.setVisible(false);        
        jLabel17.setVisible(false);        
        jLabel18.setVisible(false);        
        jLabel19.setVisible(false);       
        jLabel11.setVisible(false);
    }
    
    private void clear_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_buttonActionPerformed
        reset();
        set();
         update_table(); 
        search();
    }//GEN-LAST:event_clear_buttonActionPerformed

    private void search_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_txtActionPerformed

    private void item_name_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_item_name_txtFocusLost
             if(item_name_txt.getText().length()==0)
      {
          item_name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel11.setEnabled(true);
          jLabel11.setForeground(Color.red);
          jLabel11.setVisible(true);
             
      }  
      else
      {
           item_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel11.setEnabled(false);  
           jLabel11.setVisible(false);
           i=1;
      }    
    }//GEN-LAST:event_item_name_txtFocusLost

    private void discount_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_discount_txtFocusLost
       if(discount_txt.getText().length()==0)
            {
                   discount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                   jLabel14.setEnabled(false);  
                   jLabel14.setVisible(false);
                   x=0;
            }
            else
              {
                       String content = discount_txt.getText();
                       Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
                       Matcher m = p.matcher(content);
                       boolean matchFound = m.matches();
                       discount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel14.setEnabled(false);  
                       jLabel14.setVisible(false);
                       x=0;
                     if(!matchFound)
                    {
                        x=1;
                      discount_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                      jLabel14.setEnabled(true);
                      jLabel14.setForeground(Color.red);
                      jLabel14.setVisible(true);
                     
                    }
               }
    }//GEN-LAST:event_discount_txtFocusLost

    private void tax_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tax_txtFocusLost
        if(tax_txt.getText().length()==0)
            {
                      tax_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                      jLabel15.setEnabled(false);  
                      jLabel15.setVisible(false); 
                      y=0;
            } 
            else
              { 
                       String content = tax_txt.getText();
                       Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
                       Matcher m = p.matcher(content);
                       boolean matchFound = m.matches();
                       tax_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel15.setEnabled(false);  
                       jLabel15.setVisible(false);
                       y=0;
                     if(!matchFound)
                    {
                        y=1;
                       tax_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                       jLabel15.setEnabled(true);
                       jLabel15.setForeground(Color.red);
                       jLabel15.setVisible(true);
                     
                    }
               }
    }//GEN-LAST:event_tax_txtFocusLost

    private void quantity_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_quantity_txtFocusLost
//              if(quantity_txt.getText().length()==0)
//        {
//            quantity_txt.setBorder(BorderFactory.createLineBorder(Color.red));
//            jLabel17.setEnabled(true);
//            jLabel17.setForeground(Color.red);
//            jLabel17.setVisible(true);
//        }
//        else
//        {
//             String content = quantity_txt.getText();
//             Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
//             Matcher m = p.matcher(content);
//             boolean matchFound = m.matches();
//             quantity_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//             jLabel17.setEnabled(false);  
//             jLabel17.setVisible(false);
//             l=1;
//           
//            if(!matchFound)
//
//            {
//                 quantity_txt.setBorder(BorderFactory.createLineBorder(Color.red));
//                 jLabel17.setEnabled(true);
//                 jLabel17.setForeground(Color.red);
//                 jLabel17.setVisible(true);
//                 
//            }
//        }
    }//GEN-LAST:event_quantity_txtFocusLost

    private void rate_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_rate_txtFocusLost
           String mobile  = rate_txt.getText();
        Pattern pattern = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
        Matcher matcher = pattern.matcher(mobile);
        if (matcher.matches()) {
        }
        else
        {

            rate_txt.setText("");
            JOptionPane.showMessageDialog(null, "Enter Number!");
        }
        
        String quant = quantity_txt.getText();
        String rte = rate_txt.getText();
        
        if (!"".equals(quant))
        {
            Integer qty=Integer.parseInt(quant);
            Float rt = Float.parseFloat(rte);
            Float val = qty*rt;
            value_txt.setText(val.toString());
        }
        else
        {
            Integer qty=1;
            Float rt = Float.parseFloat(rte);
            Float val = qty*rt;
            value_txt.setText(val.toString());
        }
    }//GEN-LAST:event_rate_txtFocusLost
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clear_button;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private javax.swing.JButton delete_button;
    private numeric.textField.NumericTextField discount_txt;
    private com.jidesoft.swing.AutoCompletionComboBox group;
    private javax.swing.JTextField grp_name;
    private javax.swing.JTextField it_name;
    private javax.swing.JTextField item_name_txt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField product_code_txt;
    private javax.swing.JTable product_table;
    private numeric.textField.NumericTextField quantity_txt;
    private numeric.textField.NumericTextField rate_txt;
    private javax.swing.JButton save_button;
    private javax.swing.JTextField search_txt;
    private numeric.textField.NumericTextField tax_txt;
    private com.jidesoft.swing.AutoCompletionComboBox unit;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    private numeric.textField.NumericTextField value_txt;
    // End of variables declaration//GEN-END:variables
private javax.swing.JOptionPane jopt1;
}
