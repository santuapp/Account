package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import org.jdesktop.xswingx.PromptSupport;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class vendor_edit_delete_panel extends javax.swing.JPanel {
    Font myFont = new Font("",Font.PLAIN,9);
    int i=0,j=0,k=0;                    // for Mandatory
    int x=0,y=0,z=0,p=0,q=0; 
    String user_activity_id="";
// For Non Mandatory
    /**
     * Creates new form vendor_edit_delete_panel
     */
     String country_name="";
    String country_id1="";
    String isd="";
    String state_name="";
    String state_id="";
    
    String city_name1="";
    String city_id="";
    
    
    
     public void set(){
         search_txt.requestFocusInWindow();
         search_txt.setFocusable(true);
     }
     
     public void user(String u_name){
         jLabel19.setText(u_name);
     }
    
    public vendor_edit_delete_panel() {
//         JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
        initComponents();
        set();
        jLabel19.setVisible(false);
        
        create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
        v_name.setFocusable(true);
       // v_name.setEditable(false);
        //v_name.getCaret().setVisible(true);
        
        DOB_label.setVisible(false);
        v_dob.setVisible(false);
        v_under_txt.setVisible(false);
        Under_label.setEnabled(false);
        v_under.setEnabled(false);
        
        jLabel3.setFont(myFont);
        jLabel3.setEnabled(false);
        jLabel3.setVisible(false);
        
        jLabel4.setFont(myFont);
        jLabel4.setEnabled(false);
        jLabel4.setVisible(false);
        
        jLabel5.setFont(myFont);
        jLabel5.setEnabled(false);
        jLabel5.setVisible(false);
        
        jLabel6.setFont(myFont);
        jLabel6.setEnabled(false);
        jLabel6.setVisible(false);
        
        jLabel7.setFont(myFont);
        jLabel7.setEnabled(false);
        jLabel7.setVisible(false);
        
        jLabel8.setFont(myFont);
        jLabel8.setEnabled(false);
        jLabel8.setVisible(false);
              
        jLabel9.setFont(myFont);
        jLabel9.setEnabled(false);
        jLabel9.setVisible(false);
        
        jLabel10.setFont(myFont);
        jLabel10.setEnabled(false);
        jLabel10.setVisible(false);
        
        jLabel11.setFont(myFont);
        jLabel11.setEnabled(false);
        jLabel11.setVisible(false);
        
        jLabel12.setFont(myFont);
        jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        jLabel13.setFont(myFont);
        jLabel13.setEnabled(false);
        jLabel13.setVisible(false);
        
        jLabel14.setFont(myFont);
        jLabel14.setEnabled(false);
        jLabel14.setVisible(false);
        
        jLabel15.setFont(myFont);
        jLabel15.setEnabled(false);
        jLabel15.setVisible(false);
        
        jLabel16.setFont(myFont);
        jLabel16.setEnabled(false);
        jLabel16.setVisible(false);
        
        jLabel17.setFont(myFont);
        jLabel17.setEnabled(false);
        jLabel17.setVisible(false);
        
        jLabel18.setFont(myFont);
        jLabel18.setEnabled(false);
        jLabel18.setVisible(false);
     
        PromptSupport.setPrompt("John Smith", v_name);
        PromptSupport.setPrompt("dd/mm/yyyy", v_dob);
        PromptSupport.setPrompt("12,ABC Road", v_add);
        PromptSupport.setPrompt("123456", v_pin);
        PromptSupport.setPrompt("abc@xyz.com", v_eid);
        PromptSupport.setPrompt("+911234567890", v_mb_no);
        PromptSupport.setPrompt("+91123456789", v_ph_no);
        PromptSupport.setPrompt("12345678901", v_cst);
        PromptSupport.setPrompt("12345678901", v_vat_no);
        PromptSupport.setPrompt("AAAPL1234C", v_pan);
            update_table();
            search();
           // company();
            
             country();
        state();
        city();
            
            
        //c_company.setEnabled(true);
        v_under_txt.setVisible(false);
        v_id.setVisible(false);
     name_v.setVisible(false);
      
        table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }

            
        });
         try{
        
        Connection con = Database.getConnection();
        Statement ps =con.createStatement();
        ResultSet rs=ps.executeQuery("select distinct g_name from acc_group group by acc_g_id");
          while(rs.next())
          {
              String name=rs.getString("g_name");
             
              v_under.addItem(name);
             
          }
          con.close();
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
     
        
    }
    
  class FocusGrabber implements Runnable {
       private JComponent component;
 
       public FocusGrabber(JComponent component) 
       {
       this.component = component;
       }

       public void run() 
       {
       component.grabFocus();
       }
}
  
  
   public void company(){
         try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct company_name from company_creation");
          
            while(rs.next())
            {
                  String company1=rs.getString("company_name");
//                country_id1=rs.getString("country_id");
//                isd=rs.getString("isd_code");

                v_company.addItem(company1);
               
            }
          // con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }
   
   
   public void country(){
         try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select * from country_name order by country_id");
          
            while(rs.next())
            {
                country_name=rs.getString("country_name");
                country_id1=rs.getString("country_id");
                isd=rs.getString("isd_code");

                v_country.addItem(country_name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }
    
    public void state(){
          try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct * from state_name order by state_id");
          
            while(rs.next())
            {
                String name=rs.getString("state_name");
                String id=rs.getString("state_id");

                v_state.addItem(name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
    }
    
    
     public void city(){
          try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct * from city_name order by city_id");
          
            while(rs.next())
            {
                String city_name1=rs.getString("city_name");
                String city_id1=rs.getString("city_id");

                //v_city.addItem(city_name1);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
    }

   
   
         ///v_name
     
     public void c_name()
     {
          if(v_name.getText().length()==0)
            {
                i=0;
             v_name.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel3.setEnabled(true);
             jLabel3.setForeground(Color.red);
             jLabel3.setVisible(true);
            }
          else
           {
            String content = v_name.getText();
            Pattern p = Pattern.compile("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z][\\'\\,\\.\\- ]*)*$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
         //   System.out.println(matchFound);
            v_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel3.setEnabled(false);  
            jLabel3.setVisible(false);
            i=1;
                if(!matchFound)
                 {
                     i=0;

                     v_name.setBorder(BorderFactory.createLineBorder(Color.red));
                     jLabel3.setEnabled(true);
                     jLabel3.setForeground(Color.red);
                     jLabel3.setVisible(true);
                
                 }
           }
     }
     // under
     public void under(){
          if(v_under.getSelectedItem().equals(""))
       {
          v_under.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel4.setEnabled(true);
          jLabel4.setForeground(Color.red);
          jLabel4.setVisible(true);
       }
       else
       {
           v_under.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel4.setEnabled(false);  
           jLabel4.setVisible(false);
           j=1;
       }
     }
     
       // phone no
     
     public void phone(){
         if(v_ph_no.getText().length()==0)
        {
            k=0;
            v_ph_no.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel14.setEnabled(true);
            jLabel14.setForeground(Color.red);
            jLabel14.setVisible(true);
        }
        else
        {
            String content = v_ph_no.getText();
            Pattern p = Pattern.compile("[+]\\d{3,16}");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            v_ph_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel14.setEnabled(false);  
            jLabel14.setVisible(false);
             k=1;
           
            if(!matchFound)

            {
                 k=0;
                 v_ph_no.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);
                
                 
            }
        }
     }
 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    @SuppressWarnings("unchecked")
    
      
 public void search(){
        search_txt.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   String s1=search_txt.getText();

 
 
 String s3=s1;
     
                    try{
                   Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT v_name as `VENDOR NAME` from vendor where v_name like '"+s3+"%'"); 
          
              
                table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
                con.close();
                    }catch (SQLException e1){
        System.out.println("Sql Exception" + e1.toString());
        }
        
                
}
            });
    }
           public void update_table()
{ 
       
        try{
        
           Connection con = Database.getConnection();
           Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT v_name as `VENDOR NAME` from vendor ");
          table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
           
          System.out.println("Done");
          con.close();
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
       
        
        table.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   
int keyvalue=e.getKeyCode();
if(keyvalue==KeyEvent.VK_ENTER)
                {
                   // jComboBox1.setVisible(false);
//jTextField2.setVisible(true);
                 int row=table.getSelectedRow();
                 int col=table.getSelectedColumn();
                
                if(table.getValueAt(row, 0) != null){
                String s1= (String)table.getValueAt(row, 0);
                
                
//JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());

System.out.println(" Value in the row clicked :"+ " " +row+"");
System.out.println(" Value in the col clicked :"+ " " +col+"");
System.out.println(" Value in the col,row clicked :"+ " " +s1+"");

          try{
         
           Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
          Statement ps2 =con1.createStatement();
           ResultSet rs1=ps1.executeQuery("SELECT * from vendor where v_name='"+s1+"' ");
       while(rs1.next())
                {
                    
                           // jComboBox1.removeAll(); 
                    
                  String  id=rs1.getString(1);
                  v_id.setText(id);
                     String  aa=rs1.getString(2);
                     name_v.setText(aa);
                     System.out.println("LOG UPDATE USER ID " + name_v.getText());
                
                      v_name.setText(aa);
                    String a1=rs1.getString(3);
                  v_under_txt.setText(rs1.getString("v_under"));
                   v_under.setSelectedItem(rs1.getString("v_under"));
                   
                    String a6=rs1.getString(9);
                   v_pin.setText(a6);
                    
          
                 String a4=rs1.getString(11);
                   v_eid.setText(a4);
                    String a5=rs1.getString(5);
                    String g1="Male";
                     String g2="Female";
                     if(a5.compareTo(g1)==0){
                      m_radio.setSelected(true);
                    }
                     else if(a5.compareTo(g2)==0){
                        f_radio.setSelected(true);
                       
                        
                    }
                     else{
                         company_radio.setSelected(true);
                     }
                    String a7=rs1.getString(6);
                    v_add.setText(a7);
                    
                     String a8=rs1.getString("v_city");
                     v_city.setText(a8);
                     
                     String a10=rs1.getString("v_country");
                    v_country.setSelectedItem(a10);
                     
                       String a9=rs1.getString("v_state");
                    v_state.setSelectedItem(a9);
                    
                     
                    
                    
                     String a13=rs1.getString(12);
                    v_mb_no.setText(a13);
                    String a14=rs1.getString(13);
                  v_ph_no.setText(a14);
                   
                    String a16=rs1.getString(14);
                    v_vat_no.setText(a16);
                      String a18=rs1.getString(15);
                    v_cst.setText(a18);
                    String a19=rs1.getString(16);
                   v_pan.setText(a19);
                
                   
                    String a30=rs1.getString(17);
                    v_opening.setText(a30);
                    
                    String company_name=rs1.getString("v_company_name");
                    v_company.setSelectedItem(company_name);
                    
                     Statement ps3 =con1.createStatement();
                ResultSet rs2=ps3.executeQuery("SELECT * from user_activity_table where table_name='vendor' and value='"+name_v.getText()+"'");
                while(rs2.next())
            {
                user_activity_id=rs2.getString("id");
                System.out.println("LOG UPDATE USER ID " + user_activity_id);
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                }
       
          con1.close();
         
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        

                }  }



}

}

);
    Action delete = new AbstractAction()
{
    public void actionPerformed(ActionEvent e)
    {
        
    }
};
 
 
}
   
           
           
           private void tableMouseClicked(java.awt.event.MouseEvent evt) 
           {                                   
v_under.removeAll();
      
            int new1=table.getSelectedRow();
            String table_click=(table.getModel().getValueAt(new1, 0).toString());
        try{
         
           Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
         Statement ps2 =con1.createStatement();
                //   ResultSet rs2=ps2.executeQuery("SELECT DAYOFMONTH(v_dob) AS day,MONTH(v_dob) as month,YEAR(v_dob) as year from vendor where v_name='"+table_click+"'");
           ResultSet rs1=ps1.executeQuery("SELECT * from vendor where v_name='"+table_click+"' ");
            //jComboBox1.removeAll();
       while(rs1.next())
                {
                      String  id=rs1.getString("v_id");
                  v_id.setText(id);
                  
                     String  aa=rs1.getString("v_name");
                      v_name.setText(aa);
                      name_v.setText(aa);
                      
                    String a1=rs1.getString("v_under");
                    v_under_txt.setText(a1);
                  v_under.setSelectedItem(a1);
                  
                   String a2=rs1.getString("v_dob");
                  v_dob.setText(a2);
                     
                    String a6=rs1.getString("v_pin");
                   v_pin.setText(a6);
                        
                 String a4=rs1.getString("v_eid");
                   v_eid.setText(a4);
                   
                    String a5=rs1.getString(5);
                    String g1="Male";
                     String g2="Female";
                     if(a5.compareTo(g1)==0){
                      m_radio.setSelected(true);
                    }
                     else if(a5.compareTo(g2)==0){
                        f_radio.setSelected(true);
                       
                        
                    }
                     else{
                         company_radio.setSelected(true);
                     }
                    String a7=rs1.getString("v_address");
                    v_add.setText(a7);
                    
                     String a8=rs1.getString("v_city");
                     v_city.setText(a8);
                     
                      String a10=rs1.getString("v_country");
                    v_country.setSelectedItem(a10);
                     
                       String a9=rs1.getString("v_state");
                    v_state.setSelectedItem(a9);
                    
                    
                     
                     
                     String a13=rs1.getString("v_mb_no");
                    v_mb_no.setText(a13);
                    
                    String a14=rs1.getString("v_ph_no");
                  v_ph_no.setText(a14);
                   
                    String a16=rs1.getString("v_vat_no");
                    v_vat_no.setText(a16);
                    
                      String a18=rs1.getString("v_cst_no");
                    v_cst.setText(a18);
                    
                    String a19=rs1.getString("v_pan");
                   v_pan.setText(a19);
                
                    
                    String a30=rs1.getString("opening_balance");
                    v_opening.setText(a30);
                    
                     String company_name=rs1.getString("v_company_name");
                    v_company.setSelectedItem(company_name);
                    
                     Statement ps3 =con1.createStatement();
                ResultSet rs2=ps3.executeQuery("SELECT * from user_activity_table where table_name='vendor' and value='"+name_v.getText()+"'");
                while(rs2.next())
            {
                 user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                System.out.println("LOG UPDATE USER ID " + user_activity_id);
                
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                
                }
        
          con1.close();
          //jComboBox1.removeAll();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
       
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        v_under_txt = new javax.swing.JTextField();
        v_id = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        v_name = new javax.swing.JTextField();
        DOB_label = new javax.swing.JLabel();
        Under_label = new javax.swing.JLabel();
        m_radio = new javax.swing.JRadioButton();
        f_radio = new javax.swing.JRadioButton();
        company_radio = new javax.swing.JRadioButton();
        Add_label = new javax.swing.JLabel();
        St_label = new javax.swing.JLabel();
        Cou_label = new javax.swing.JLabel();
        Pn_label = new javax.swing.JLabel();
        Em_label = new javax.swing.JLabel();
        v_eid = new javax.swing.JTextField();
        Mb_label = new javax.swing.JLabel();
        v_mb_no = new javax.swing.JTextField();
        Ph_label = new javax.swing.JLabel();
        v_ph_no = new javax.swing.JTextField();
        VT_label = new javax.swing.JLabel();
        v_vat_no = new javax.swing.JTextField();
        CT_label = new javax.swing.JLabel();
        v_cst = new javax.swing.JTextField();
        Pan_label = new javax.swing.JLabel();
        v_pan = new javax.swing.JTextField();
        v_dob = new javax.swing.JTextField();
        v_under = new javax.swing.JComboBox();
        v_company = new javax.swing.JComboBox();
        v_add = new javax.swing.JTextField();
        v_pin = new numeric.textField.NumericTextField();
        v_opening = new numeric.textField.NumericTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        Cty_label = new javax.swing.JLabel();
        v_city = new javax.swing.JTextField();
        v_state = new com.jidesoft.swing.AutoCompletionComboBox();
        v_country = new com.jidesoft.swing.AutoCompletionComboBox();
        jPanel3 = new javax.swing.JPanel();
        save_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        clear_button = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        search_txt = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        name_v = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        create_date = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        update_date = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();

        jPanel1.setForeground(new java.awt.Color(0, 0, 255));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Informations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 0, 255))); // NOI18N
        jPanel2.setPreferredSize(new java.awt.Dimension(426, 594));

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText(" Name:");

        v_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                v_nameFocusLost(evt);
            }
        });

        DOB_label.setForeground(new java.awt.Color(0, 0, 255));
        DOB_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        DOB_label.setText("Date Of Birth:");

        Under_label.setForeground(new java.awt.Color(0, 0, 255));
        Under_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Under_label.setText("Under:");

        buttonGroup1.add(m_radio);
        m_radio.setForeground(new java.awt.Color(0, 0, 255));
        m_radio.setText("Male");
        m_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                m_radioActionPerformed(evt);
            }
        });

        buttonGroup1.add(f_radio);
        f_radio.setForeground(new java.awt.Color(0, 0, 255));
        f_radio.setText("Female");
        f_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f_radioActionPerformed(evt);
            }
        });

        buttonGroup1.add(company_radio);
        company_radio.setForeground(new java.awt.Color(0, 0, 255));
        company_radio.setText("Company");
        company_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                company_radioActionPerformed(evt);
            }
        });

        Add_label.setForeground(new java.awt.Color(0, 0, 255));
        Add_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Add_label.setText("Address:");

        St_label.setForeground(new java.awt.Color(0, 0, 255));
        St_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        St_label.setText("State:");

        Cou_label.setForeground(new java.awt.Color(0, 0, 255));
        Cou_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Cou_label.setText("Country:");

        Pn_label.setForeground(new java.awt.Color(0, 0, 255));
        Pn_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Pn_label.setText("Pin:");

        Em_label.setForeground(new java.awt.Color(0, 0, 255));
        Em_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Em_label.setText("Email Id:");

        v_eid.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_eid.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                v_eidFocusLost(evt);
            }
        });

        Mb_label.setForeground(new java.awt.Color(0, 0, 255));
        Mb_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Mb_label.setText("Mobile No:");

        v_mb_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_mb_no.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                v_mb_noFocusLost(evt);
            }
        });

        Ph_label.setForeground(new java.awt.Color(0, 0, 255));
        Ph_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Ph_label.setText("Phone No:");

        v_ph_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_ph_no.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                v_ph_noFocusLost(evt);
            }
        });

        VT_label.setForeground(new java.awt.Color(0, 0, 255));
        VT_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        VT_label.setText("VAT No:");

        v_vat_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        CT_label.setForeground(new java.awt.Color(0, 0, 255));
        CT_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        CT_label.setText("CST No:");

        v_cst.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        Pan_label.setForeground(new java.awt.Color(0, 0, 255));
        Pan_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Pan_label.setText("Pan No:");

        v_pan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        v_dob.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_dob.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                v_dobFocusLost(evt);
            }
        });

        v_under.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Sundry Creditors" }));
        v_under.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_under.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                v_underFocusLost(evt);
            }
        });

        v_company.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "", "Sole Proprietorship", "Partnership", "Limited Liability Partnership", "Private Limited Company", "Public Limited Company", "HUF (Hindu Undivided Family)", "Cooperative", "Family Owned Business", "Unlimited Company", "Public Sector Unit (PSU)" }));
        v_company.setToolTipText("");
        v_company.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        v_add.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        v_pin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_pin.setText("numericTextField1");
        v_pin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                v_pinFocusLost(evt);
            }
        });

        v_opening.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_opening.setText("0.00");
        v_opening.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                v_openingFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                v_openingFocusLost(evt);
            }
        });

        jLabel3.setText("Enter Vendor Name!");

        jLabel4.setText("Select Under!");

        jLabel5.setText("Select Any One!");

        jLabel6.setText("Enter Valid Date of Birth");

        jLabel7.setText("Enter Valid Address!");

        jLabel8.setText("Enter Valid City Name!");

        jLabel9.setText("Enter State Name!");

        jLabel10.setText("Enter Valid Country Name!");

        jLabel11.setText("Enter Valid Pincode!");

        jLabel12.setText("Enter Valid Email ID!");

        jLabel13.setText("Enter Valid Mobile Number!");

        jLabel14.setText("Enter Valid Phone Number!");

        jLabel15.setText("Enter Valid VAT Number!");

        jLabel16.setText("Enter Valid CST Number!");

        jLabel17.setText("Enter Valid PAN Number!");

        jLabel18.setText("Enter Opening Balance!");

        jLabel24.setForeground(new java.awt.Color(0, 0, 255));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel24.setText("Openning Balance:");

        Cty_label.setForeground(new java.awt.Color(0, 0, 255));
        Cty_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Cty_label.setText("City:");

        v_state.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select" }));
        v_state.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                v_stateActionPerformed(evt);
            }
        });

        v_country.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select" }));
        v_country.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                v_countryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(company_radio, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(v_company, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(m_radio)
                        .addGap(43, 43, 43)
                        .addComponent(f_radio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 131, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Under_label, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(v_name, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(v_under, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Add_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(St_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Cou_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Pn_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Em_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Mb_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Ph_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(VT_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(CT_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Pan_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(jLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(Cty_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(DOB_label, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(v_dob, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_add, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13)
                                    .addComponent(v_pin, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_eid, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_mb_no, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_ph_no, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_vat_no, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_cst, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_pan, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_opening, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_city, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_state, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_country, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(25, 25, 25))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(v_name, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Under_label)
                    .addComponent(v_under, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(company_radio)
                    .addComponent(v_company, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(m_radio)
                    .addComponent(f_radio)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DOB_label)
                    .addComponent(v_dob, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Add_label)
                    .addComponent(v_add, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cou_label)
                    .addComponent(v_country, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addGap(6, 6, 6)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(St_label)
                    .addComponent(v_state, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cty_label)
                    .addComponent(v_city, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(v_pin, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pn_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(v_eid, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Em_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(v_mb_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Mb_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(v_ph_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Ph_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(VT_label)
                    .addComponent(v_vat_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(CT_label))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(v_cst, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(v_pan, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pan_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel17)
                .addGap(7, 7, 7)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(v_opening, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel18)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 0, 255))); // NOI18N

        save_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        save_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save_button.setText("Save");
        save_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_buttonActionPerformed(evt);
            }
        });

        delete_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete_button.setText("Delete");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });

        clear_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        clear_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        clear_button.setText("Clear");
        clear_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(delete_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(save_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(clear_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(save_button)
                .addGap(22, 22, 22)
                .addComponent(delete_button)
                .addGap(22, 22, 22)
                .addComponent(clear_button)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 0, 255))); // NOI18N

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        search_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_txtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(search_txt)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(search_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        table.setForeground(new java.awt.Color(0, 0, 255));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 21, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Vendor Edit/Delete");

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 10), java.awt.Color.cyan)); // NOI18N

        jLabel20.setForeground(new java.awt.Color(51, 153, 0));
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel20.setText("Created By:");

        jLabel21.setForeground(new java.awt.Color(51, 153, 0));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("Creation Date:");

        jLabel22.setForeground(new java.awt.Color(51, 153, 0));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel22.setText("Updated By:");

        jLabel23.setForeground(new java.awt.Color(51, 153, 0));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel23.setText("Updation Date:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_date, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel19.setText("jLabel19");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(297, 297, 297)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(v_under_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(v_id, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(name_v, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(jLabel19))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 271, Short.MAX_VALUE)
                                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap(153, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(v_under_txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(v_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(name_v, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(318, 318, 318))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel19)
                        .addGap(103, 103, 103)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 892, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jScrollPane2.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane2)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane2)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void save_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_buttonActionPerformed
//JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
 if(v_id.getText().equals(""))
     {
           jopt1.showMessageDialog(this,"Select Vendor Name!"); 
     }
    else{
        c_name();
        under();
        phone();
        if(i==1&&j==1&&k==1&&x==0&&y==0&&z==0&&p==0&&q==0)
        {
                          
                      
        try{

            Connection con2 = Database.getConnection();

            // if(city_txt.isVisible())
            // {
            Statement ps5 =con2.createStatement(); 
            ResultSet rs5=ps5.executeQuery("SELECT l_name,v_name from ledger,vendor where l_name='"+v_name.getText()+"' and l_name=v_name and v_id!='"+v_id.getText()+"'");

//                if(rs5.next())
//                    {
//                    jopt1.showMessageDialog(this,"Vendor Already Exsist"); 
//                    }
//                else{
            
//            PreparedStatement ps10=con2.prepareStatement("update user_activity_table set value='"+v_name.getText()+"' where  value='"+name_v.getText()+"'");
//                ps10.executeUpdate();
//            
                    
                   log_table.table_update("vendor",v_name.getText(), user_activity_id);
                   //System.out.println("Log Table data pass"+user_activity_id);
                PreparedStatement ps1=con2.prepareStatement("update vendor set v_name='"+v_name.getText()+"',v_under='"+v_under.getSelectedItem().toString()+"',v_address='"+v_add.getText()+"',v_country='"+v_country.getSelectedItem().toString()+"',v_state='"+v_state.getSelectedItem().toString()+"',v_city='"+v_city.getText()+"',v_pin='"+v_pin.getText()+"',v_eid='"+v_eid.getText()+"',v_mb_no='"+v_mb_no.getText()+"',v_ph_no='"+v_ph_no.getText()+"',v_vat_no='"+v_vat_no.getText()+"',v_cst_no='"+v_cst.getText()+"',v_pan='"+v_pan.getText()+"', opening_balance='"+v_opening.getText()+"',v_dob='"+v_dob.getText()+"',v_gender='"+gender+"',v_company_name='"+v_company.getSelectedItem().toString()+"' where  v_id='"+v_id.getText()+"' ");
                ps1.executeUpdate();
                PreparedStatement ps11=con2.prepareStatement("update ledger set l_name='"+v_name.getText()+"',l_under='"+v_under.getSelectedItem().toString()+"',l_address='"+v_add.getText()+"',l_country='"+v_country.getSelectedItem().toString()+"',l_state='"+v_state.getSelectedItem().toString()+"',l_city='"+v_city.getText()+"', l_opning_balance='"+v_opening.getText()+"' where  l_name='"+name_v.getText()+"'");
                ps11.executeUpdate();
                PreparedStatement ps3=con2.prepareStatement("delete from  `"+v_under_txt.getText()+"` where l_name='"+name_v.getText()+"'");
                ps3.executeUpdate();
                PreparedStatement ps4=con2.prepareStatement("insert into `"+v_under.getSelectedItem().toString()+"`(l_name,credit)values('"+v_name.getText()+"','"+v_opening.getText()+"')");
                ps4.executeUpdate();
                
                
                
                 try{
           Connection con1 = Database.getConnection();
           Statement ps6 =con1.createStatement(); 
           ResultSet rs6=ps6.executeQuery("SELECT city_name from city_name where city_name='"+v_city.getText()+"'");

if(rs6.next())
{
 //    jopt1.showMessageDialog(this,"City Already Exsist"); 
}
else{
    PreparedStatement ps2=con1.prepareStatement("insert into city_name (country_id,state_id,city_name)values('"+country_id1+"','"+state_id+"','"+v_city.getText()+"')");
            ps2.executeUpdate();
            
            jopt1.showMessageDialog(this,"New City Saved"); 
}
con1.close();
            }
            catch(Exception e){
                
            }
                
                
                
                
                jopt1.showMessageDialog(this,"Vendor Updated");
                
                 m_radio.setSelected(false);
            f_radio.setSelected(false);
            company_radio.setSelected(false);
                //jComboBox1.removeAll();
                // }
            /* else{
                PreparedStatement ps1=con2.prepareStatement("update ledger set l_name='"+under_txt.getText()+"',l_under='"+jComboBox1.getSelectedItem().toString()+"',l_address='"+state_txt.getText()+"',l_state='"+country_txt.getText()+"',l_acc_no='"+jTextField5.getText()+"',l_pan='"+jTextField5.getText()+"',l_sale_tax_no='"+jTextField6.getText()+"',l_branch='"+jTextField7.getText()+"',l_bsr_code='"+jTextField8.getText()+"',l_opning_balance='"+jTextField9.getText()+"',l_persentage='"+jTextField10.getText()+"' where  l_id='"+jTextField12.getText()+"'");
                ps1.executeUpdate();
                jopt1.showMessageDialog(this,"Ledger Updated");
                update_table();
                under_txt.setText(null);
                city_txt.setText(null);
                state_txt.setText(null);
                country_txt.setText(null);
                jTextField5.setText(null);
                jTextField6.setText(null);
                jTextField7.setText(null);
                jTextField8.setText(null);
                jTextField9.setText(null);
                jTextField10.setText(null);
                jTextField11.setText(null);
                jTextField12.setText(null);
                jComboBox1.removeAll();
            }*/
      //  }
                con2.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
                                          
                     update_table();
                reset();
                search();
                set();
                       
                                 
                   }
}
     
    }//GEN-LAST:event_save_buttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
        int p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(p==0)
        {
            try{

                Connection con1 = Database.getConnection();
                 Statement ps5 =con1.createStatement(); 
            ResultSet rs5=ps5.executeQuery("SELECT distinct flag from company_main_table where ledger='"+name_v.getText()+"' and type!='Opening'");

            if(rs5.next())
            {
               // String fl=rs5.getString("flag");
               
                 jopt1.showMessageDialog(this,"Customer can't be deleted "+""+"\n"+""+"Delete the transactions first"); 
                 
                 
            }
            
            else{
                 log_table.table_delete("vendor",jLabel19.getText());
                PreparedStatement ps1=con1.prepareStatement("delete from  vendor where v_id='"+v_id.getText()+"'");

                ps1.executeUpdate();
                PreparedStatement ps11=con1.prepareStatement("delete from  ledger where l_name='"+name_v.getText()+"'");

                ps11.executeUpdate();
                PreparedStatement ps3=con1.prepareStatement("delete from  `"+v_under_txt.getText()+"` where l_name='"+name_v.getText()+"' ");

                ps3.executeUpdate();
                System.out.println("Done");
                
               
                
            }
            con1.close();
            }catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
            
             jopt1.showMessageDialog(this,"Vendor Deleted");
            m_radio.setSelected(false);
            f_radio.setSelected(false);
            company_radio.setSelected(false);
           reset(); 
       set();
       search();
       update_table();

        }
        // TODO add your handling code here:
    }//GEN-LAST:event_delete_buttonActionPerformed

    private void search_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_txtActionPerformed

    private void company_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_company_radioActionPerformed
     v_company.setEnabled(true);
      DOB_label.setVisible(false);
       v_dob.setVisible(false);
        gender=v_company.getSelectedItem().toString();
    }//GEN-LAST:event_company_radioActionPerformed

    private void m_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_m_radioActionPerformed
      gender="Male";
       v_company.setEnabled(false);
       DOB_label.setVisible(true);
       v_dob.setVisible(true);
    }//GEN-LAST:event_m_radioActionPerformed

    private void f_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f_radioActionPerformed
       gender="Female";
        v_company.setEnabled(false);
         DOB_label.setVisible(true);
       v_dob.setVisible(true);
    }//GEN-LAST:event_f_radioActionPerformed

    
    public void reset(){
          v_name.setText(null);
        v_under_txt.setText(null);
        v_id.setText(null);
        v_name.setText(null);
        v_company.setSelectedIndex(0);
        v_under.setSelectedIndex(0);
        v_country.setSelectedIndex(0);
        v_state.removeAllItems();
        v_state.addItem("Select");
        
        
        v_opening.setText("0.00");
        v_pin.setText(null);
        v_dob.setText(null);
        v_eid.setText(null);
        v_mb_no.setText("");
        v_ph_no.setText("");
        v_vat_no.setText(null);
        v_cst.setText(null);
        v_pin.setText(null);
        v_add.setText(null);
        v_city.setText(null);
        
        v_pan.setText(null);
        name_v.setText(null);
        search_txt.setText(null);
         create_user.setText(null);
        create_date.setText(null);
        update_user.setText(null);
        update_date.setText(null);
        
        v_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_company.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_ph_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_pin.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_eid.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_mb_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        v_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        jLabel3.setVisible(false);
        jLabel4.setVisible(false);
        jLabel6.setVisible(false);
        jLabel11.setVisible(false);
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
        jLabel14.setVisible(false);
    }
    
    private void clear_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_buttonActionPerformed
       reset(); 
       set();
       search();
       update_table();
       m_radio.setSelected(false);
            f_radio.setSelected(false);
            company_radio.setSelected(false);
      
    }//GEN-LAST:event_clear_buttonActionPerformed

    private void v_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_nameFocusLost
      if(v_name.getText().length()==0)
        {
             v_name.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel3.setEnabled(true);
             jLabel3.setForeground(Color.red);
             jLabel3.setVisible(true);
        }
        else
        {
            String content = v_name.getText();
            Pattern p = Pattern.compile("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z][\\'\\,\\.\\- ]*)*$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
         //   System.out.println(matchFound);
            v_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel3.setEnabled(false);  
            jLabel3.setVisible(false);
            i=1;
            if(!matchFound)
            {

                v_name.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel3.setEnabled(true);
                jLabel3.setForeground(Color.red);
                jLabel3.setVisible(true);
                
            }
        }
    }//GEN-LAST:event_v_nameFocusLost

    private void v_dobFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_dobFocusLost
              if(v_dob.getText().length()==0)
        {
             v_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel6.setEnabled(false);  
             jLabel6.setVisible(false);
             x=0;   
        }
        else
        {
            String content = v_dob.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            v_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel6.setEnabled(false);  
            jLabel6.setVisible(false);
            x=0;
            
            if(!matchFound)

            {
                 x=1;

                 v_dob.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel6.setEnabled(true);
                 jLabel6.setForeground(Color.red);
                 jLabel6.setVisible(true);

            }
        }
    }//GEN-LAST:event_v_dobFocusLost

    private void v_pinFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_pinFocusLost
      if(v_pin.getText().length()==0)
        {
              v_pin.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              jLabel11.setEnabled(false);  
              jLabel11.setVisible(false);
              y=0;
        }
        else
        {
            String pin = v_pin.getText();
            String regEx = "\\d{6}";
            Pattern p = Pattern.compile(regEx);
            Matcher m = p.matcher(pin);
            v_pin.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel11.setEnabled(false);  
            jLabel11.setVisible(false);
            y=0;
            if(m.find()==false)
            {
                y=1;
                v_pin.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel11.setEnabled(true);
                jLabel11.setForeground(Color.red);
                jLabel11.setVisible(true);

            }
        }
    }//GEN-LAST:event_v_pinFocusLost

    private void v_eidFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_eidFocusLost
           if(v_eid.getText().length()==0)
        {
             v_eid.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel12.setEnabled(false);  
             jLabel12.setVisible(false);
             z=0;
        }
        else
        {
            String email =v_eid.getText();
            String regEx1 = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
            Pattern p1 = Pattern.compile(regEx1);
            Matcher m1 = p1.matcher(email);
            v_eid.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel12.setEnabled(false);  
            jLabel12.setVisible(false);
            z=0;

            if(m1.find()==false)
            {
                z=1;
                v_eid.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel12.setEnabled(true);
                jLabel12.setForeground(Color.red);
                jLabel12.setVisible(true);

            }
        }
    }//GEN-LAST:event_v_eidFocusLost

    private void v_mb_noFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_mb_noFocusLost
         if(v_mb_no.getText().length()==0)
        {
             v_mb_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel13.setEnabled(false);  
             jLabel13.setVisible(false);
             p=0;
        }
        else
        {
            String pin =v_mb_no.getText();
            String regEx = "[+]\\d{10,12}";
            Pattern p1 = Pattern.compile(regEx);
            Matcher m = p1.matcher(pin);
            boolean matchFound = m.matches();
            v_mb_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel13.setEnabled(false);  
            jLabel13.setVisible(false);
            p=0;
            if(!matchFound)
            {
                p=1;
                v_mb_no.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel13.setEnabled(true);
                jLabel13.setForeground(Color.red);
                jLabel13.setVisible(true);
            }

        }
    }//GEN-LAST:event_v_mb_noFocusLost

    private void v_ph_noFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_ph_noFocusLost
         if(v_ph_no.getText().length()==0)
        {
            k=0;
            v_ph_no.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel14.setEnabled(true);
            jLabel14.setForeground(Color.red);
            jLabel14.setVisible(true);
        }
        else
        {
            String content = v_ph_no.getText();
            Pattern p = Pattern.compile("[+]\\d{3,16}");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            v_ph_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel14.setEnabled(false);  
            jLabel14.setVisible(false);
             k=1;
           
            if(!matchFound)

            {
                 k=0;
                 v_ph_no.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);
                
                 
            }
        }
    }//GEN-LAST:event_v_ph_noFocusLost

    private void v_underFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_underFocusLost
          if(v_under.getSelectedItem().equals(""))
       {
          v_under.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel4.setEnabled(true);
          jLabel4.setForeground(Color.red);
          jLabel4.setVisible(true);
       }
       else
       {
           v_under.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel4.setEnabled(false);  
           jLabel4.setVisible(false);
           j=1;
       }
    }//GEN-LAST:event_v_underFocusLost

    private void v_openingFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_openingFocusLost
      if(v_opening.getText().length()==0)
        {
            v_opening.setText("0.00");
            v_opening.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              jLabel18.setEnabled(false);  
              jLabel18.setVisible(false);
              q=0;
        }
        else
        {
            String content = v_opening.getText();
            Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            v_opening.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel18.setEnabled(false);  
            jLabel18.setVisible(false);
            q=0;
            if(!matchFound)
            {
                q=1;
                v_opening.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel18.setEnabled(true);
                jLabel18.setForeground(Color.red);
                jLabel18.setVisible(true);

            }
        }
    }//GEN-LAST:event_v_openingFocusLost

    private void v_stateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_v_stateActionPerformed
        // TODO add your handling code here:
//        String c_name=v_state.getSelectedItem().toString();
//          if(c_name==" "){
//           // c_city.setSelectedItem(" ");
//        }
//          else{
//        try{
//            Connection con1 = Database.getConnection();
//            Statement ps =con1.createStatement();
//            ResultSet rs=ps.executeQuery("select distinct country_id,state_id from state_name where state_name='"+c_name+"'");
//          //c_state.removeAllItems();
//            while(rs.next())
//            {
//                
//                state_id=rs.getString("state_id");
//                //isd=rs.getString("isd_code");
//
//                v_state.addItem(state_name);
//               
//            }
////            Statement ps1 =con1.createStatement();
////            ResultSet rs1=ps1.executeQuery("select distinct country_id,state_id,city_name from city_name where country_id='"+country_id1+"' and state_id='"+state_id+"'");
////           // c_city.removeAllItems();
////            while(rs1.next())
////                
////            {
////                city_name1=rs1.getString("city_name");
////                //state_id=rs1.getString("state_id");
////                //System.out.print(state_id);
////                v_city.setSelectedItem(city_name1);
////     
//        }
//        catch(Exception e){
//            
//        }
//          }
    }//GEN-LAST:event_v_stateActionPerformed

    private void v_countryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_v_countryActionPerformed
        // TODO add your handling code here:
         String c_name=v_country.getSelectedItem().toString();

        try{
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct country_id,isd_code from country_name where country_name='"+c_name+"'");
          
            while(rs.next())
            {
                
                country_id1=rs.getString("country_id");
//                l_country.addItem(country_name);   
                isd=rs.getString("isd_code");
            }
            v_state.removeAllItems();
            Statement ps1 =con1.createStatement();
            ResultSet rs1=ps1.executeQuery("SELECT DISTINCT state_name FROM state_name WHERE country_id='"+country_id1+"' ORDER BY state_name");
            //System.out.println("State "+ rs1);
             v_state.addItem("Select");
             //l_state.requestFocus();
            
            while(rs1.next())
                
            {
               
                state_name=rs1.getString("state_name");
                v_state.addItem(state_name);
            }
            
            con1.close();
        }
        catch(Exception e){
            
        }
        System.out.println(country_id1);
        v_ph_no.setText("+"+isd);
        v_mb_no.setText("+"+isd);
    }//GEN-LAST:event_v_countryActionPerformed

    private void v_openingFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_v_openingFocusGained
        
        v_opening.setText("");
    }//GEN-LAST:event_v_openingFocusGained
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Add_label;
    private javax.swing.JLabel CT_label;
    private javax.swing.JLabel Cou_label;
    private javax.swing.JLabel Cty_label;
    private javax.swing.JLabel DOB_label;
    private javax.swing.JLabel Em_label;
    private javax.swing.JLabel Mb_label;
    private javax.swing.JLabel Pan_label;
    private javax.swing.JLabel Ph_label;
    private javax.swing.JLabel Pn_label;
    private javax.swing.JLabel St_label;
    private javax.swing.JLabel Under_label;
    private javax.swing.JLabel VT_label;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton clear_button;
    private javax.swing.JRadioButton company_radio;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private javax.swing.JButton delete_button;
    private javax.swing.JRadioButton f_radio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton m_radio;
    private javax.swing.JTextField name_v;
    private javax.swing.JButton save_button;
    private javax.swing.JTextField search_txt;
    private javax.swing.JTable table;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    private javax.swing.JTextField v_add;
    private javax.swing.JTextField v_city;
    private javax.swing.JComboBox v_company;
    private com.jidesoft.swing.AutoCompletionComboBox v_country;
    private javax.swing.JTextField v_cst;
    private javax.swing.JTextField v_dob;
    private javax.swing.JTextField v_eid;
    private javax.swing.JTextField v_id;
    private javax.swing.JTextField v_mb_no;
    private javax.swing.JTextField v_name;
    private numeric.textField.NumericTextField v_opening;
    private javax.swing.JTextField v_pan;
    private javax.swing.JTextField v_ph_no;
    private numeric.textField.NumericTextField v_pin;
    private com.jidesoft.swing.AutoCompletionComboBox v_state;
    private javax.swing.JComboBox v_under;
    private javax.swing.JTextField v_under_txt;
    private javax.swing.JTextField v_vat_no;
    // End of variables declaration//GEN-END:variables
private javax.swing.JOptionPane jopt1;
private String gender;
}
