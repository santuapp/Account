package final_project;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author virtual vista
 */

public class Bank_Status1 extends javax.swing.JFrame implements ContainerListener{
private final GridBagConstraints gridBagConstraints;
    /**
     * Creates new form Bank_Status_4demo
     */ static String aa;
    public Bank_Status1(String hh) {
        aa=hh;
        initComponents();
        gridBagConstraints = new java.awt.GridBagConstraints();
         gridBagConstraints.insets=new Insets(0,0,0,0);
            
            addContainerListener(this);
            
            int bak=0,r=4,r1=0,a1=0,a2=0,a3=0,a4=0,a5=0,a6=0,a7=0,a8=0,a9=0,a10=0,a11=0,a12=0,a13=0,lr=0,a101=0,a201=0,a301=0,a401=0,a501=0,a601=0,a701=0,a801=0,a901=0,a1001=0,a1101=0,a1201=0,a1301=0;
             int count=0,uu=0,ll=0;
             double opening_balance=0.0d,t_debit=0.0d,t_credit=0.0d,total_balance=0.0d,total_closing=0.0d,closing_balance=0.0d,db=0.0d,cr=0.0d;
        String opening="",total_debit="",total_credit="",total_debit_value="",total_credit_value="",closing="",date="",balance="",totaldebit="",totalcredit="";
          try{
        
           Class.forName("com.mysql.jdbc.Driver");
           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
        Statement ps =con.createStatement();
        Statement ps1 =con.createStatement();
         Statement ps2 =con.createStatement();
          Statement ps3 =con.createStatement();
           Statement ps4 =con.createStatement();
            Statement ps5 =con.createStatement();
           // ResultSet rs3=ps2.executeQuery("select sum(ledger.l_opning_balance) as open from ledger  where  ledger.l_under='Bank'");
       // ResultSet rs=ps.executeQuery("select * from bank_status ");
         ResultSet rs4=ps3.executeQuery("select bank_date from bank_status where bank_name='"+aa+"'");
       
        //while(rs3.next()){
           // opening=rs3.getString("open");
         //  opening_balance=Double.parseDouble(opening);
          // System.out.println(opening);
      //  }
        while(rs4.next()){
            
            count++;
        }
           
            
            JLabel[] datelabel=new JLabel[500000];
            JLabel[] dategaplabel=new JLabel[500000];
            JLabel[] partilrlabel=new JLabel[500000];
            JLabel[] partilrgaplabel=new JLabel[500000];
            JLabel[] voucherlabel=new JLabel[500000];
            JLabel[] vouchergaplabel=new JLabel[500000];
            JLabel[] chequelabel=new JLabel[500000];
            JLabel[] chequegaplabel=new JLabel[500000];
            JLabel[] depositlabel=new JLabel[500000];
            JLabel[] depositgaplabel=new JLabel[500000];
            JLabel[] withdwlabel=new JLabel[500000];
            JLabel[] withdwgaplabel=new JLabel[500000];
            JLabel[] closinglabel=new JLabel[500000];
            
             JLabel[] datelabel1=new JLabel[500000];
            JLabel[] dategaplabel1=new JLabel[500000];
            JLabel[] partilrlabel1=new JLabel[500000];
            JLabel[] partilrgaplabel1=new JLabel[500000];
            JLabel[] voucherlabel1=new JLabel[500000];
            JLabel[] vouchergaplabel1=new JLabel[500000];
            JLabel[] chequelabel1=new JLabel[500000];
            JLabel[] chequegaplabel1=new JLabel[500000];
            JLabel[] depositlabel1=new JLabel[500000];
            JLabel[] depositgaplabel1=new JLabel[500000];
            JLabel[] withdwlabel1=new JLabel[500000];
            JLabel[] withdwgaplabel1=new JLabel[500000];
            JLabel[] closinglabel1=new JLabel[500000];
            
            // Panel 1 start.....y=2
            
            JLabel tohead=new JLabel("Date");
            tohead.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            tohead.setHorizontalAlignment(SwingConstants.CENTER);
            gridBagConstraints.weightx=0.083;
            jPanel1.add(tohead,gridBagConstraints);
            
            JLabel blankhead4=new JLabel(" ");
            blankhead4.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead4,gridBagConstraints);
            
            JLabel refhead=new JLabel("Particular");
            refhead.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.5;
            jPanel1.add(refhead,gridBagConstraints);
            
            JLabel blankhead5=new JLabel(" ");
            blankhead5.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead5,gridBagConstraints);
            
            JLabel refhead1=new JLabel("Voucher Type");
            refhead1.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead1.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead1,gridBagConstraints);
            
            JLabel blankhead6=new JLabel(" ");
            blankhead6.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead6,gridBagConstraints);
            
            JLabel refhead2=new JLabel("Cheque No");
            refhead2.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=24;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead2.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead2,gridBagConstraints);
            
            JLabel blankhead7=new JLabel(" ");
            blankhead7.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead7,gridBagConstraints);
            
            JLabel refhead3=new JLabel("Deposit");
            refhead3.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead3.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead3,gridBagConstraints);
            
            JLabel blankhead8=new JLabel(" ");
            blankhead8.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=38;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead8,gridBagConstraints);
            
            JLabel refhead4=new JLabel("Withdrawal");
            refhead4.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=40;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead4.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead4,gridBagConstraints);
            
            JLabel blankhead9=new JLabel(" ");
            blankhead9.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=46;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead9,gridBagConstraints);
            
            JLabel refhead5=new JLabel("Closing Balance");
            refhead5.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=48;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead5.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead5,gridBagConstraints);
            
            //y=3...........
            
            JLabel tohead14=new JLabel(" ");
            tohead14.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            tohead14.setHorizontalAlignment(SwingConstants.CENTER);
            gridBagConstraints.weightx=0.083;
            jPanel1.add(tohead14,gridBagConstraints);
            
            JLabel blankhead10=new JLabel(" ");
            blankhead10.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead10,gridBagConstraints);
            
            JLabel refhead6=new JLabel("Opening");
            refhead6.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead6.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.5;
            jPanel1.add(refhead6,gridBagConstraints);
            
            JLabel blankhead11=new JLabel(" ");
            blankhead11.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead11,gridBagConstraints);
            
            JLabel blankhead12=new JLabel(" ");
            blankhead12.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead12,gridBagConstraints);
            
            JLabel blankhead13=new JLabel(" ");
            blankhead13.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead13,gridBagConstraints);
            
            JLabel refhead7=new JLabel("100000000");
            refhead7.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead7.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead7,gridBagConstraints);
            
            JLabel blankhead14=new JLabel(" ");
            blankhead14.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=38;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead14,gridBagConstraints);
            
            JLabel blankhead15=new JLabel(" ");
            blankhead15.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=46;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead15,gridBagConstraints);
            
            JLabel refhead8=new JLabel("1000000");
            refhead8.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=48;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead8.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead8,gridBagConstraints);
            
            // y=4 start....
            
             //Content Array (date,gap,particular,gap,voucher,gap,cheque,gap,deposit,gap,withdw,gap,closing) displaying
            
             ResultSet rs5=ps4.executeQuery("select bank_date from bank_status where bank_name='"+aa+"'");
           
        while(rs5.next())
        {
          // uu++;
            
            date=rs5.getString("bank_date");
             if(date!=null){
          ResultSet rs3=ps2.executeQuery("select  ledger,sum(debit) as debit,cheque_no from bank_status  where  bank_name='"+aa+"' and bank_date='"+date+"' group by bank_name,bank_date");
           while(rs3.next()){
               totaldebit=rs3.getString("debit");
                  if( totaldebit!=null){
                   //String totalcredit=rs3.getString("credit");
                   db=Double.parseDouble(totaldebit);
                    // double cr=Double.parseDouble(totalcredit);
                     closing_balance=(db - cr) + closing_balance;
                     balance=Double.toString(closing_balance);
                     
               if(db>0.0d){
            datelabel[a1]=new JLabel();
            dategaplabel[a2]=new JLabel();
            partilrlabel[a3]=new JLabel();
            partilrgaplabel[a4]=new JLabel();
            voucherlabel[a5]=new JLabel();
            vouchergaplabel[a6]=new JLabel();
            chequelabel[a7]=new JLabel();
            chequegaplabel[a8]=new JLabel();
            depositlabel[a9]=new JLabel();
            depositgaplabel[a10]=new JLabel();
            withdwlabel[a11]=new JLabel();
            withdwgaplabel[a12]=new JLabel();
            closinglabel[a13]=new JLabel();
             
      datelabel[a1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            datelabel[a1].setHorizontalAlignment(SwingConstants.CENTER);
            gridBagConstraints.weightx=0.083;
            jPanel1.add(datelabel[a1],gridBagConstraints);
            datelabel[a1].setText(date);
            
         
            dategaplabel[a2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(dategaplabel[a2],gridBagConstraints);
             dategaplabel[a2].setText(" ");
           
            partilrlabel[a3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            partilrlabel[a3].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.5;
            jPanel1.add(partilrlabel[a3],gridBagConstraints);
            partilrlabel[a3].setText(rs3.getString("ledger"));
            
            
            partilrgaplabel[a4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(partilrgaplabel[a4],gridBagConstraints);
             partilrgaplabel[a4].setText(" ");
           
            voucherlabel[a5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            voucherlabel[a5].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(voucherlabel[a5],gridBagConstraints);
            voucherlabel[a5].setText("RECEIPT");
            
            
            vouchergaplabel[a6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(vouchergaplabel[a6],gridBagConstraints);
            vouchergaplabel[a6].setText(" ");
           
            chequelabel[a7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=24;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            chequelabel[a7].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(chequelabel[a7],gridBagConstraints);
            chequelabel[a7].setText(rs3.getString("cheque_no"));
            
            
            chequegaplabel[a8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(chequegaplabel[a8],gridBagConstraints);
            chequegaplabel[a8].setText(" ");
            
            depositlabel[a9].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            depositlabel[a9].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(depositlabel[a9],gridBagConstraints);
            depositlabel[a9].setText(totaldebit);
            
            
            depositgaplabel[a10].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=38;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(depositgaplabel[a10],gridBagConstraints);
             depositgaplabel[a10].setText(" ");
            
            withdwlabel[a11].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=40;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            withdwlabel[a11].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(withdwlabel[a11],gridBagConstraints);
            withdwlabel[a11].setText("");
            
            
            withdwgaplabel[a12].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=46;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(withdwgaplabel[a12],gridBagConstraints);
             withdwgaplabel[a12].setText(" ");
            
            closinglabel[a13].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=48;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            closinglabel[a13].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(closinglabel[a13],gridBagConstraints);
            closinglabel[a13].setText(balance);
            a1++;
           //  a1++;
              a2++;
              a3++;
                a4++;
                a5++;
                  a6++;
                  a7++;
                    a8++;
                     a9++;
                    a10++;
                       a11++;
                        a12++;
             a13++;
          
               }
           }
                    r++;
           }
          
                 
            
           //ResultSet rs56=ps5.executeQuery("select  ledger,sum(credit) as credit,cheque_no from bank_status  where  bank_name='"+aa+"' and bank_date='"+date+"' group by bank_name,bank_date");
         
          // while(rs56.next())
         //  {
              
              // String totaldebit=rs3.getString("debit");
             //  totalcredit=rs56.getString("credit");
                    //db=Double.parseDouble(totaldebit);
           //    if(totalcredit!=null){
                 //   cr=Double.parseDouble(totalcredit);
                   //  closing_balance=(db - cr) + closing_balance;
                   //  balance=Double.toString(closing_balance);
                   //  System.out.println(balance);
           
                       // System.out.println(db);
                        //   System.out.println(cr);
                          
     /*     
         datelabel1[a101]=new JLabel();
            dategaplabel1[a201]=new JLabel();
            partilrlabel1[a301]=new JLabel();
            partilrgaplabel1[a401]=new JLabel();
            voucherlabel1[a501]=new JLabel();
            vouchergaplabel1[a601]=new JLabel();
            chequelabel1[a701]=new JLabel();
            chequegaplabel1[a801]=new JLabel();
            depositlabel1[a901]=new JLabel();
            depositgaplabel1[a1001]=new JLabel();
            withdwlabel1[a1101]=new JLabel();
            withdwgaplabel1[a1201]=new JLabel();
            closinglabel1[a1301]=new JLabel();
       
           datelabel1[a1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            datelabel1[a1].setHorizontalAlignment(SwingConstants.CENTER);
            gridBagConstraints.weightx=0.083;
            jPanel1.add(datelabel1[a1],gridBagConstraints);
            datelabel1[a1].setText(date);
            
        
            dategaplabel1[a2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(dategaplabel1[a2],gridBagConstraints);
             dategaplabel1[a2].setText(" ");
           
            partilrlabel1[a3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            partilrlabel1[a3].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.5;
            jPanel1.add(partilrlabel1[a3],gridBagConstraints);
            partilrlabel1[a3].setText(rs56.getString("ledger"));
            
            
            partilrgaplabel1[a4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(partilrgaplabel1[a4],gridBagConstraints);
             partilrgaplabel1[a4].setText(" ");
           
            voucherlabel1[a5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            voucherlabel1[a5].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(voucherlabel1[a5],gridBagConstraints);
            voucherlabel1[a5].setText("RECEIPT");
            
            
            vouchergaplabel1[a6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(vouchergaplabel1[a6],gridBagConstraints);
            vouchergaplabel1[a6].setText(" ");
           
            chequelabel1[a7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=24;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            chequelabel1[a7].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(chequelabel1[a7],gridBagConstraints);
            chequelabel1[a7].setText(rs56.getString("cheque_no"));
            
            
            chequegaplabel1[a8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(chequegaplabel1[a8],gridBagConstraints);
            chequegaplabel1[a8].setText(" ");
            
            depositlabel1[a9].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            depositlabel1[a9].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(depositlabel1[a9],gridBagConstraints);
            depositlabel1[a9].setText(" ");
            
            
            depositgaplabel1[a10].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=38;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(depositgaplabel1[a10],gridBagConstraints);
             depositgaplabel1[a10].setText(" ");
            
            withdwlabel1[a11].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=40;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            withdwlabel1[a11].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(withdwlabel1[a11],gridBagConstraints);
            withdwlabel1[a11].setText(totalcredit);
            
            
            withdwgaplabel1[a12].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=46;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(withdwgaplabel1[a12],gridBagConstraints);
             withdwgaplabel1[a12].setText(" ");
            
            closinglabel1[a13].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=48;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            closinglabel1[a13].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(closinglabel1[a13],gridBagConstraints);
            closinglabel1[a13].setText(balance);
           
                     
        
           }}
         
         
                                r++;  
       
                a1++;
           //  a1++;
              a2++;
               a3++;
                a4++;
                 a5++;
                  a6++;
                   a7++;
                    a8++;
                     a9++;
                      a10++;
                       a11++;
                        a12++;
                         a13++;  */
               }}
          System.out.println(r);
 }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        catch(ClassNotFoundException ce)
        {
            System.out.println("ClassNotFoundException" + ce.toString());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new java.awt.GridBagLayout());
        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(762, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bank_Status1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Bank_Status1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Bank_Status1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Bank_Status1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    @Override
    public void componentAdded(ContainerEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void componentRemoved(ContainerEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
}
