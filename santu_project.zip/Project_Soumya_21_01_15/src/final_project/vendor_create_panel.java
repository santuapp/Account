package final_project;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import org.jdesktop.xswingx.PromptSupport;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class vendor_create_panel extends javax.swing.JPanel {
String gender="";
 Font myFont = new Font("",Font.PLAIN,9);
 int i=0,j=0,k=0;    // For Mandatory
 int x=0,y=0,z=0,p=0,q=0;    // For Non Mandatory
 int a=0,b=0;      // For Selection Other
 
    /**
     * Creates new form vendor_create_panel
     */
  String country_name="";
    String country_id1="";
    String isd="";
    String state_name="";
    String state_id="";
    
    String city_name1="";
    String city_id="";
 
 
 public void set(){
     c_name.requestFocusInWindow();
     c_name.setFocusable(true);
 }
 public void user(String u_name){
     jLabel18.setText(u_name);
 }
    public vendor_create_panel() {
//         JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
        initComponents();
      
        set();
        c_name.setFocusable(true);
        c_name.getCaret().setVisible(true);
        
         
         jLabel3.setVisible(false);
         c_dob.setVisible(false);
         
         jLabel17.setEnabled(false);
         under.setEnabled(false);
        
        jLabel4.setFont(myFont);
        jLabel4.setEnabled(false);
        jLabel4.setVisible(false);
        
        jLabel20.setFont(myFont);
        jLabel20.setEnabled(false);
        jLabel20.setVisible(false);
        
        jLabel21.setFont(myFont);
        jLabel21.setEnabled(false);
        jLabel21.setVisible(false);
       
        
        jLabel23.setFont(myFont);
        jLabel23.setEnabled(false);
        jLabel23.setVisible(false);
        
        jLabel24.setFont(myFont);
        jLabel24.setEnabled(false);
        jLabel24.setVisible(false);
        
        jLabel25.setFont(myFont);
        jLabel25.setEnabled(false);
        jLabel25.setVisible(false);
        
        jLabel26.setFont(myFont);
        jLabel26.setEnabled(false);
        jLabel26.setVisible(false);
        
        jLabel27.setFont(myFont);
        jLabel27.setEnabled(false);
        jLabel27.setVisible(false);
        
        jLabel28.setFont(myFont);
        jLabel28.setEnabled(false);
        jLabel28.setVisible(false);
        
        jLabel29.setFont(myFont);
        jLabel29.setEnabled(false);
        jLabel29.setVisible(false);
        
        jLabel30.setFont(myFont);
        jLabel30.setEnabled(false);
        jLabel30.setVisible(false);
        
        jLabel31.setFont(myFont);
        jLabel31.setEnabled(false);
        jLabel31.setVisible(false);
        
        jLabel32.setFont(myFont);
        jLabel32.setEnabled(false);
        jLabel32.setVisible(false);
        
        jLabel33.setFont(myFont);
        jLabel33.setEnabled(false);
        jLabel33.setVisible(false);
        
        jLabel18.setVisible(false);
//        jLabel34.setFont(myFont);
//        jLabel34.setEnabled(false);
//        jLabel34.setVisible(false);
//        
//        jLabel35.setFont(myFont);
//        jLabel35.setEnabled(false);
//        jLabel35.setVisible(false);
        
        jLabel36.setFont(myFont);
        jLabel36.setEnabled(false);
        jLabel36.setVisible(false);
        
       
        
        PromptSupport.setPrompt("John Smith", c_name);
        PromptSupport.setPrompt("dd/mm/yyyy", c_dob);
        PromptSupport.setPrompt("12, ABC Road", c_add);
        PromptSupport.setPrompt("123456", c_pin_no);
        PromptSupport.setPrompt("abc@xyz.com", c_eid);
        PromptSupport.setPrompt("+911234567890", c_mb_no);
        PromptSupport.setPrompt("+91123456789", c_ph_no);
        PromptSupport.setPrompt("12345678901", c_cst_no);
        PromptSupport.setPrompt("12345678901", c_vat_no);
        PromptSupport.setPrompt("AAAPL1234C", c_pan_no);
        
        //company();
         country();
       // state();
        //city();
//         initcall();
      
        
    c_company.setEnabled(false);
//        try{
//        
//           Connection con = Database.getConnection();
//           Statement ps =con.createStatement();
//           ResultSet rs=ps.executeQuery("select distinct g_name from acc_group group by acc_g_id");
//          while(rs.next())
//          {
//              String name=rs.getString("g_name");
//              under.addItem(name);
//          }
//          
//           
//         con.close();
//        }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
       
    }
     class FocusGrabber implements Runnable {
  private JComponent component;

  public FocusGrabber(JComponent component) {
    this.component = component;
  }

  public void run() {
    component.grabFocus();
  }
}
   
     
      public void company(){
         try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct company_name from company_creation");
          
            while(rs.next())
            {
                  String company1=rs.getString("company_name");
//                country_id1=rs.getString("country_id");
//                isd=rs.getString("isd_code");

                c_company.addItem(company1);
               
            }
          // con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }
      
      public void country(){
         try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select * from country_name order by country_id");
          
            while(rs.next())
            {
                country_name=rs.getString("country_name");
                country_id1=rs.getString("country_id");
                isd=rs.getString("isd_code");

                v_country.addItem(country_name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }
    
    public void state(){
          try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct * from state_name order by state_id");
          
            while(rs.next())
            {
                String name=rs.getString("state_name");
                String id=rs.getString("state_id");

                v_state.addItem(name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
    }
    
    
     public void city(){
          try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct * from city_name order by city_id");
          
            while(rs.next())
            {
                String city_name1=rs.getString("city_name");
                String city_id1=rs.getString("city_id");

              //  v_city.addItem(city_name1);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
    }
     
    ///c_name
     
     public void c_name(){
          if(c_name.getText().length()==0)
        {
             c_name.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel4.setEnabled(true);
             jLabel4.setForeground(Color.red);
             jLabel4.setVisible(true);
        }
        else
        {
            String content = c_name.getText();
            Pattern p = Pattern.compile("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z][\\'\\,\\.\\- ]*)*$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            System.out.println(matchFound);
            c_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel4.setEnabled(false);  
            jLabel4.setVisible(false);
            i=1;
            if(!matchFound)
            {

                c_name.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel4.setEnabled(true);
                jLabel4.setForeground(Color.red);
                jLabel4.setVisible(true);
                
            }
        }
     }
     // under
     public void under(){
          if(under.getSelectedItem().equals(""))
       {
          under.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel20.setEnabled(true);
          jLabel20.setForeground(Color.red);
          jLabel20.setVisible(true);
       }
       else
       {
           under.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel20.setEnabled(false);  
           jLabel20.setVisible(false);
           j=1;
       }
     }
     
     
      // Other Name
    
    
//    public void name_other(){
//            if(jTextField11.getText().length()==0)
//      {
//          jTextField11.setBorder(BorderFactory.createLineBorder(Color.red));
//          jLabel34.setEnabled(true);
//          jLabel34.setForeground(Color.red);
//          jLabel34.setVisible(true);
//          a=1;
//             
//      }  
//      else
//      {
//           jTextField11.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//           jLabel34.setEnabled(false);  
//           jLabel34.setVisible(false);
//           a=0;
//           
//          
//      }
//        
//    }
    
    
    // Other Under
    
//    public void under_other(){
//           if(jComboBox2.getSelectedItem().equals(""))
//      {
//          jComboBox2.setBorder(BorderFactory.createLineBorder(Color.red));
//          jLabel35.setEnabled(true);
//          jLabel35.setForeground(Color.red);
//          jLabel35.setVisible(true);
//          b=1;
//             
//      }  
//      else
//      {
//           jComboBox2.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//           jLabel35.setEnabled(false);  
//           jLabel35.setVisible(false);
//           b=0;
//      }
//        
//    }
//   
   // gender
     
//     public void gender(){
//         if(buttongroup.isSelected(null))
//         {
//              jLabel36.setEnabled(true);
//              jLabel36.setForeground(Color.red);
//              jLabel36.setVisible(true);
//              k=1;
//         }
//     }
//     
 
   
      
     // phone no
     
     public void phone(){
         if(c_ph_no.getText().length()==0)
        {
            k=0;
            c_ph_no.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel32.setEnabled(true);
            jLabel32.setForeground(Color.red);
            jLabel32.setVisible(true);
        }
        else
        {
            String content = c_ph_no.getText();
            Pattern p = Pattern.compile("[+]\\d{3,16}");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            c_ph_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel32.setEnabled(false);  
            jLabel32.setVisible(false);
             k=1;
           
            if(!matchFound)

            {
                 k=0;
                 c_ph_no.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel32.setEnabled(true);
                 jLabel32.setForeground(Color.red);
                 jLabel32.setVisible(true);
                
                 
            }
        }
     }
//  private void initcall() {
//        
//        
//       // c_under.setEditable(true);
//        
//        //
//        // Create an ActionListener for the JComboBox component.
//        //
//        c_under.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent event) {
//                //
//                // Get the source of the component, which is our combo
//                // box.
//                //
//                JComboBox jComboBox1 = (JComboBox) event.getSource();
//
//                Object selected = jComboBox1.getSelectedItem();
//                if(selected.toString().equals("Others"))
//                {
//                jTextField11.setEnabled(true);
//                jComboBox2.setEnabled(true);
//                jLabel18.setEnabled(true);
//                jLabel19.setEnabled(true);
//               jPanel2.setEnabled(true);
//                jButton3.setEnabled(true);
//                name_other();
//                under_other();
//                
//                
//        try{
//         
//           Connection con = Database.getConnection();//(Connection) DriverManager.getConnection(ConnUrl);
//           Statement ps =con.createStatement();
//           ResultSet rs=ps.executeQuery("select distinct g_name from acc_group group by acc_g_id");
//            while(rs.next())
//          {
//              String name=rs.getString("g_name");
//             
//              jComboBox2.addItem(name);
//              
//          }
//         
//        }catch (Exception ex) {
//            System.out.println("Database.getConnection() Error -->" + ex.getMessage());
//         
//        }
//                }
//          else 
//                { 
//                    jTextField11.setEnabled(false);
//                jComboBox2.setEnabled(false);
//                jLabel13.setEnabled(false);
//                jLabel14.setEnabled(false);
//               jPanel1.setEnabled(false);
//                jButton3.setEnabled(false);
//                jComboBox2.removeAllItems();
//                 
//                }
//            }
//        });
//
//    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
     
      public void group_table()
  {
        try{

         
            Connection con = Database.getConnection();;

            Statement ps1 =con.createStatement();
            ResultSet rs1=ps1.executeQuery("select distinct g_name from acc_group order by acc_g_id");
            while(rs1.next())
            {
                String name=rs1.getString("g_name");
                under.addItem(name);
            }
        con.close();
    }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
        }
  }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        buttongroup = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        c_name = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        under = new javax.swing.JComboBox();
        company = new javax.swing.JRadioButton();
        c_company = new javax.swing.JComboBox();
        male = new javax.swing.JRadioButton();
        female = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        c_dob = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        c_add = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        c_pin_no = new numeric.textField.NumericTextField();
        jLabel10 = new javax.swing.JLabel();
        c_eid = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        c_mb_no = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        c_vat_no = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        c_pan_no = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        c_opening = new numeric.textField.NumericTextField();
        reset_button = new javax.swing.JButton();
        submit_button = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        v_state = new com.jidesoft.swing.AutoCompletionComboBox();
        v_city = new javax.swing.JTextField();
        v_country = new com.jidesoft.swing.AutoCompletionComboBox();
        jPanel5 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        c_ph_no = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        c_cst_no = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        jPanel1.setLayout(new java.awt.GridBagLayout());

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 13), java.awt.Color.blue)); // NOI18N

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("*Name:");

        c_name.setToolTipText("Input Name");
        c_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                c_nameFocusLost(evt);
            }
        });

        jLabel17.setForeground(new java.awt.Color(0, 0, 255));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("*Under:");

        under.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Sundry Creditors" }));
        under.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        under.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                underFocusLost(evt);
            }
        });

        buttongroup.add(company);
        company.setForeground(new java.awt.Color(0, 0, 255));
        company.setText("*Company");
        company.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyActionPerformed(evt);
            }
        });
        company.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                companyFocusLost(evt);
            }
        });

        c_company.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "", "Sole Proprietorship", "Partnership", "Limited Liability Partnership", "Private Limited Company", "Public Limited Company", "HUF (Hindu Undivided Family)", "Cooperative", "Family Owned Business", "Unlimited Company", "Public Sector Unit (PSU)" }));
        c_company.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_company.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_companyActionPerformed(evt);
            }
        });

        buttongroup.add(male);
        male.setForeground(new java.awt.Color(0, 0, 255));
        male.setText("Male");
        male.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maleActionPerformed(evt);
            }
        });

        buttongroup.add(female);
        female.setForeground(new java.awt.Color(0, 0, 255));
        female.setText("Female");
        female.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                femaleActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("Date of Birth:");

        c_dob.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_dob.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_dobActionPerformed(evt);
            }
        });
        c_dob.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                c_dobFocusLost(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Address:");

        c_add.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("City:");

        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("State:");
        jLabel7.setToolTipText("");

        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Pin:");

        c_pin_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_pin_no.setText("numericTextField1");
        c_pin_no.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                c_pin_noFocusLost(evt);
            }
        });

        jLabel10.setForeground(new java.awt.Color(0, 0, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Email ID:");

        c_eid.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_eid.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                c_eidFocusLost(evt);
            }
        });

        jLabel11.setForeground(new java.awt.Color(0, 0, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Mobile No:");

        c_mb_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_mb_no.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                c_mb_noFocusLost(evt);
            }
        });

        jLabel13.setForeground(new java.awt.Color(0, 0, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("VAT No:");

        c_vat_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Country:");

        jLabel15.setForeground(new java.awt.Color(0, 0, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("PAN No:");

        c_pan_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel16.setForeground(new java.awt.Color(0, 0, 255));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Openning Balance:");
        jLabel16.setToolTipText("");

        c_opening.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_opening.setText("0.00");
        c_opening.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                c_openingFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                c_openingFocusLost(evt);
            }
        });

        reset_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        reset_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        reset_button.setText("Reset");
        reset_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reset_buttonActionPerformed(evt);
            }
        });

        submit_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        submit_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/folder-access-icon.png"))); // NOI18N
        submit_button.setText("Submit");
        submit_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submit_buttonActionPerformed(evt);
            }
        });

        jLabel4.setText("Enter Valid Name!");

        jLabel20.setText("Select Under!");

        jLabel21.setText("Enter Valid Date of Birth!");

        jLabel23.setText("Enter Your City Name!");

        jLabel24.setText("Enter Your State Name!");

        jLabel25.setText("Enter Your Country Name!");

        jLabel26.setText("Enter Your Valid Pincode!");

        jLabel27.setText("Enter Valid Email ID!");

        jLabel28.setText("Enter Valid Mobile Number!");

        jLabel29.setText("Enter Valid VAT Number!");

        jLabel30.setText("Enter Valid PAN Number!");

        jLabel31.setText("Enter Valid Opening Balance!");

        jLabel36.setText("Select Any One!");

        v_state.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select" }));
        v_state.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                v_stateActionPerformed(evt);
            }
        });

        v_country.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select" }));
        v_country.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                v_countryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(male, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(25, 25, 25)
                                        .addComponent(jLabel3)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(female)
                                .addGap(21, 21, 21))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(v_state, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(v_city, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(c_opening, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel30, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(reset_button)
                                .addGap(18, 18, 18)
                                .addComponent(submit_button))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(company)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel15))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(v_country, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(c_name, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                                        .addComponent(under, 0, 158, Short.MAX_VALUE)
                                        .addComponent(c_company, 0, 158, Short.MAX_VALUE)
                                        .addComponent(c_dob, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                                        .addComponent(c_add, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(c_pin_no, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                                        .addComponent(c_eid, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                                        .addComponent(c_mb_no, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                                        .addComponent(c_vat_no, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                                        .addComponent(c_pan_no, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)))))))
                .addGap(28, 28, 28))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {c_add, c_company, c_dob, c_eid, c_mb_no, c_name, c_opening, c_pan_no, c_pin_no, c_vat_no, under});

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel10, jLabel11, jLabel13, jLabel15, jLabel16, jLabel17, jLabel2, jLabel5, jLabel6, jLabel7, jLabel8});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(c_name, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(under, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel20)
                .addGap(4, 4, 4)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c_company, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(company))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(male, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(female, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel36))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(c_dob, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(c_add, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(v_country, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(v_state, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(v_city, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(c_pin_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(c_eid, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(c_mb_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(c_vat_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(c_pan_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(c_opening, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reset_button)
                    .addComponent(submit_button))
                .addContainerGap())
        );

        jLabel12.setForeground(new java.awt.Color(0, 0, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("*Phone No:");

        c_ph_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_ph_no.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                c_ph_noFocusLost(evt);
            }
        });

        jLabel14.setForeground(new java.awt.Color(0, 0, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("CST No:");

        c_cst_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel32.setText("Enter Valid Phone Number!");

        jLabel33.setText("Enter Valid CST Number!");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(c_cst_no, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c_ph_no, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel12, jLabel14});

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(c_ph_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel32)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(c_cst_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel33)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel18.setText("jLabel18");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(jLabel18)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(130, 130, 130))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 0, 31, 61);
        jPanel1.add(jPanel6, gridBagConstraints);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Vendor Registration Form");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 468;
        gridBagConstraints.ipady = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 61);
        jPanel1.add(jLabel1, gridBagConstraints);

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 685, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 872, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void c_ph_noFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_ph_noFocusLost
   if(c_ph_no.getText().length()==0)
        {
            k=0;
            c_ph_no.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel32.setEnabled(true);
            jLabel32.setForeground(Color.red);
            jLabel32.setVisible(true);
        }
        else
        {
            String content = c_ph_no.getText();
            Pattern p = Pattern.compile("[+]\\d{3,16}");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            c_ph_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel32.setEnabled(false);  
            jLabel32.setVisible(false);
             k=1;
           
            if(!matchFound)

            {
                k=0;
                 c_ph_no.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel32.setEnabled(true);
                 jLabel32.setForeground(Color.red);
                 jLabel32.setVisible(true);
                
                 
            }
        }   
    }//GEN-LAST:event_c_ph_noFocusLost

    private void c_dobFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_dobFocusLost
          if(c_dob.getText().length()==0)
        {
             c_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel21.setEnabled(false);  
             jLabel21.setVisible(false);
             x=0;
        }
        else
        {
            String content = c_dob.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            c_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel21.setEnabled(false);  
            jLabel21.setVisible(false);
            x=0;
            if(!matchFound)

            {
                x=1;

                 c_dob.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel21.setEnabled(true);
                 jLabel21.setForeground(Color.red);
                 jLabel21.setVisible(true);

            }
        }
    }//GEN-LAST:event_c_dobFocusLost

    private void c_dobActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_dobActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c_dobActionPerformed

    private void submit_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submit_buttonActionPerformed
//JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
        
        
        c_name();
        under();
  //      gender();
    
        phone();
         

      
if(i==1&&j==1&&k==1&&x==0&&y==0&&z==0&&p==0&&q==0&&a==0&&b==0)
{        
                
                
                
                
                            try{

                                Connection con = Database.getConnection();
                               
                                Statement ps5 =con.createStatement();
                                ResultSet rs5=ps5.executeQuery("SELECT v_name from vendor where v_name='"+c_name.getText()+"'");

                                if(rs5.next())
                                {
                                    jopt2.showMessageDialog(this,"Vendor Already Exsist");
                                }
                                else{
                                    
                                    log_table.table_create("vendor", c_name.getText());
                                    log_table.table_insert("vendor", c_name.getText());
                                    PreparedStatement ps=con.prepareStatement("insert into vendor(v_name,v_under,v_dob,v_gender,v_address,v_city,v_state,v_pin,v_country,v_eid,v_mb_no,v_ph_no,v_vat_no,v_cst_no,v_pan,opening_balance,v_company_name)values('"+c_name.getText()+"','"+under.getSelectedItem().toString()+"','"+c_dob.getText()+"','"+gender+"','"+c_add.getText()+"','"+v_city.getText()+"','"+v_state.getSelectedItem().toString()+"','"+c_pin_no.getText()+"','"+v_country.getSelectedItem().toString()+"','"+c_eid.getText()+"','"+c_mb_no.getText()+"','"+c_ph_no.getText()+"','"+c_vat_no.getText()+"','"+c_cst_no.getText()+"','"+c_pan_no.getText()+"','"+c_opening.getText()+"','"+c_company.getSelectedItem().toString()+"')");
                                    ps.executeUpdate();
                                   
                                    PreparedStatement ps3=con.prepareStatement("insert into `"+under.getSelectedItem().toString()+"`(l_name,debit,credit)values('"+c_name.getText()+"','0','"+c_opening.getText()+"')");
                                    ps3.executeUpdate();
                                     PreparedStatement ps4=con.prepareStatement("insert into ledger(l_name,l_under,l_address,l_state,l_opning_balance)values('"+c_name.getText()+"','"+under.getSelectedItem().toString()+"','"+c_add.getText()+"','"+v_state.getSelectedItem().toString()+"','"+c_opening.getText()+"')");
                                
                                     ps4.executeUpdate();
                                     PreparedStatement ps7=con.prepareStatement("insert into company_main_table (ledger,credit,type,flag)values('"+c_name.getText()+"','"+c_opening.getText()+"','Opening','0')");
                                     ps7.executeUpdate();
                                     
                                     
                                       try{
           Connection con1 = Database.getConnection();
           Statement ps6 =con1.createStatement(); 
           ResultSet rs6=ps6.executeQuery("SELECT city_name from city_name where city_name='"+v_city.getText()+"'");

if(rs6.next())
{
 //    jopt1.showMessageDialog(this,"City Already Exsist"); 
}
else{
    PreparedStatement ps1=con.prepareStatement("insert into city_name (country_id,state_id,city_name)values('"+country_id1+"','"+state_id+"','"+v_city.getText()+"')");
            ps1.executeUpdate();
            
            //jopt1.showMessageDialog(this,"New City Saved"); 
}
            }
            catch(Exception e){
                
            }
                                     
                                     
                                     
                                    System.out.println("saved");

                                    jopt1.showMessageDialog(this,"Vendor Created");
                                   // c_under.removeAllItems();
        //Reset                              
        reset();
        set();
                                    
                                    company.setSelected(false);
                                    male.setSelected(false);
                                    female.setSelected(false);
//                                    Statement ps1 =con.createStatement();
//                                    ResultSet rs1=ps1.executeQuery("select distinct g_name from acc_group group by acc_g_id");
//                                    while(rs1.next())
//                                    {
//                                        String name=rs1.getString("g_name");
//                                        under.addItem(name);
//                                    }
                                }
                                con.close();
                            }catch (SQLException e){
                                System.out.println("Sql Exception" + e.toString());
                            }
                           
        }
        

        //        ///
        //
        //
        //
        //

    }//GEN-LAST:event_submit_buttonActionPerformed

    
    public void reset(){
         c_name.setText(null);
        under.setSelectedIndex(0);
        c_company.setSelectedIndex(0);
        c_dob.setText(null);
        c_add.setText(null);
        v_country.setSelectedIndex(0);
        v_state.removeAllItems();
        v_state.addItem("Select");
        v_city.setText(null);
        
        
        c_pin_no.setText(null); 
        c_eid.setText(null);
        c_mb_no.setText(null);
        c_vat_no.setText(null);
        c_pan_no.setText(null);
        c_opening.setText("0.00");
        c_ph_no.setText(null);
        c_cst_no.setText(null);   
        
        
        c_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        under.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_company.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_add.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        //c_city.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        //c_state.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        //c_country.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_pin_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_eid.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_mb_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_vat_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_pan_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_opening.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_ph_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_cst_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));   
                
          
        jLabel4.setVisible(false);      
        jLabel20.setVisible(false);               
        jLabel21.setVisible(false);       
        jLabel23.setVisible(false);           
        jLabel24.setVisible(false);                
        jLabel25.setVisible(false);                
        jLabel26.setVisible(false);                
        jLabel27.setVisible(false);                
        jLabel28.setVisible(false);                
        jLabel29.setVisible(false);                
        jLabel30.setVisible(false);                
        jLabel31.setVisible(false);                
        jLabel32.setVisible(false);                
        jLabel33.setVisible(false);          
        jLabel36.setVisible(false);
    }
    
    private void reset_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reset_buttonActionPerformed

        reset();
        set();

    }//GEN-LAST:event_reset_buttonActionPerformed

    private void c_mb_noFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_mb_noFocusLost
        if(c_mb_no.getText().length()==0)
        {
             c_mb_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel28.setEnabled(false);  
             jLabel28.setVisible(false);
             p=0;
        }
        else
        {
            String pin =c_mb_no.getText();
            String regEx = "[+]\\d{10,12}";
            Pattern p1 = Pattern.compile(regEx);
            Matcher m = p1.matcher(pin);
            c_mb_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel28.setEnabled(false);  
            jLabel28.setVisible(false);
            p=0;
            if(m.find()==false)
            {
                p=1;
                c_mb_no.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel28.setEnabled(true);
                jLabel28.setForeground(Color.red);
                jLabel28.setVisible(true);
            }

        }
    }//GEN-LAST:event_c_mb_noFocusLost

    private void c_eidFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_eidFocusLost
        if(c_eid.getText().length()==0)
        {
             c_eid.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel27.setEnabled(false);  
             jLabel27.setVisible(false);
             z=0;
        }
        else
        {
            String email =c_eid.getText();
            String regEx1 = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
            Pattern p1 = Pattern.compile(regEx1);
            Matcher m1 = p1.matcher(email);
            c_eid.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel27.setEnabled(false);  
            jLabel27.setVisible(false);
            z=0;

            if(m1.find()==false)
            {
                z=1;
                c_eid.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel27.setEnabled(true);
                jLabel27.setForeground(Color.red);
                jLabel27.setVisible(true);

            }
        }

    }//GEN-LAST:event_c_eidFocusLost

    private void c_pin_noFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_pin_noFocusLost
        if(c_pin_no.getText().length()==0)
        {
              c_pin_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              jLabel26.setEnabled(false);  
              jLabel26.setVisible(false);
              y=0;
        }
        else
        {
            
            String pin = c_pin_no.getText();
            String regEx = "\\d{6}";
            Pattern p = Pattern.compile(regEx);
            Matcher m = p.matcher(pin);
            c_pin_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel26.setEnabled(false);  
            jLabel26.setVisible(false);
            y=0;
            if(m.find()==false)
            {
                y=1;
                c_pin_no.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel26.setEnabled(true);
                jLabel26.setForeground(Color.red);
                jLabel26.setVisible(true);

            }
        }
    }//GEN-LAST:event_c_pin_noFocusLost

    private void femaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_femaleActionPerformed
//       jLabel36.setEnabled(false);
//       jLabel36.setVisible(false);
//       
//        gender="Female";
//        c_company.setEnabled(false);
//        c_dob.setEnabled(true);
        
        // testing
        
         gender="Female";
        c_company.setEnabled(false);
         jLabel3.setVisible(true);
         c_dob.setVisible(true);
        
    }//GEN-LAST:event_femaleActionPerformed

    private void maleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maleActionPerformed
//       jLabel36.setEnabled(false);
//       jLabel36.setVisible(false);
//       
//        gander="Male";
//        c_company.setEnabled(false);
//        c_dob.setEnabled(true);
        
        //testing
        
        gander="Male";
         c_company.setEnabled(false);
         
         jLabel3.setVisible(true);
         c_dob.setVisible(true);
    }//GEN-LAST:event_maleActionPerformed

    private void c_companyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_companyActionPerformed
 
    }//GEN-LAST:event_c_companyActionPerformed

    private void companyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyActionPerformed
//       jLabel36.setEnabled(false);
//       jLabel36.setVisible(false);
//       
//        c_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//        jLabel21.setEnabled(false);
//        jLabel21.setVisible(false);
//        c_company.setEnabled(true);
//        c_dob.setEnabled(false);
//        gender=c_company.getSelectedItem().toString();
        
      
        // tsting
        
         c_company.setEnabled(true);
        gender=c_company.getSelectedItem().toString();
      
         jLabel3.setVisible(false);
         c_dob.setVisible(false);
       
       
    }//GEN-LAST:event_companyActionPerformed

    private void c_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_nameFocusLost
             if(c_name.getText().length()==0)
        {
            i=0;
             c_name.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel4.setEnabled(true);
             jLabel4.setForeground(Color.red);
             jLabel4.setVisible(true);
        }
        else
        {
            String content = c_name.getText();
            Pattern p = Pattern.compile("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z][\\'\\,\\.\\- ]*)*$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            System.out.println(matchFound);
            c_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel4.setEnabled(false);  
            jLabel4.setVisible(false);
              i=1;
            if(!matchFound)
            {
                i=0;

                c_name.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel4.setEnabled(true);
                jLabel4.setForeground(Color.red);
                jLabel4.setVisible(true);
              
            }
        }
    }//GEN-LAST:event_c_nameFocusLost

    private void underFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_underFocusLost
     if(under.getSelectedItem().equals(""))
       {
          under.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel20.setEnabled(true);
          jLabel20.setForeground(Color.red);
          jLabel20.setVisible(true);
       }
       else
       {
           under.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel20.setEnabled(false);  
           jLabel20.setVisible(false);
           j=1;
       }     
    }//GEN-LAST:event_underFocusLost

    private void companyFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_companyFocusLost
     
    }//GEN-LAST:event_companyFocusLost

    private void c_openingFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_openingFocusLost
        if(c_opening.getText().length()==0)
        {
              c_opening.setText("0.00");
              c_opening.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              jLabel31.setEnabled(false);  
              jLabel31.setVisible(false);
              q=0;
        }
        else
        {
            String content = c_opening.getText();
            Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            c_opening.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel31.setEnabled(false);  
            jLabel31.setVisible(false);
            q=0;
            if(!matchFound)
            {
                q=1;
                c_opening.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel31.setEnabled(true);
                jLabel31.setForeground(Color.red);
                jLabel31.setVisible(true);

            }
        }
    }//GEN-LAST:event_c_openingFocusLost

    private void v_stateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_v_stateActionPerformed
        // TODO add your handling code here:
//         String c_name=v_state.getSelectedItem().toString();
//          if(c_name==" "){
//           // c_city.setSelectedItem(" ");
//        }
//          else{
//        try{
//            Connection con1 = Database.getConnection();
//            Statement ps =con1.createStatement();
//            ResultSet rs=ps.executeQuery("select distinct country_id,state_id from state_name where state_name='"+c_name+"'");
//          //c_state.removeAllItems();
//            while(rs.next())
//            {
//                
//                state_id=rs.getString("state_id");
//                //isd=rs.getString("isd_code");
//
//                v_state.addItem(state_name);
//               
//            }
////            Statement ps1 =con1.createStatement();
////            ResultSet rs1=ps1.executeQuery("select distinct country_id,state_id,city_name from city_name where country_id='"+country_id1+"' and state_id='"+state_id+"'");
////           // c_city.removeAllItems();
////            while(rs1.next())
////                
////            {
////                city_name1=rs1.getString("city_name");
////                //state_id=rs1.getString("state_id");
////                //System.out.print(state_id);
////                v_city.setSelectedItem(city_name1);
////            }
//            
//            con1.close();
//        }
//        catch(Exception e){
//            
//        }
//        System.out.println(country_id1);
//        //c_ph_no.setText("+"+isd);
//       // c_mb_no.setText("+"+isd);
//          }
    }//GEN-LAST:event_v_stateActionPerformed

    private void v_countryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_v_countryActionPerformed
        // TODO add your handling code here:
          
         String c_name=v_country.getSelectedItem().toString();

        try{
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct country_id,isd_code from country_name where country_name='"+c_name+"'");
          
            while(rs.next())
            {
                
                country_id1=rs.getString("country_id");
//                l_country.addItem(country_name);   
                isd=rs.getString("isd_code");
            }
            v_state.removeAllItems();
            Statement ps1 =con1.createStatement();
            ResultSet rs1=ps1.executeQuery("SELECT DISTINCT state_name FROM state_name WHERE country_id='"+country_id1+"' ORDER BY state_name");
            //System.out.println("State "+ rs1);
             v_state.addItem("Select");
             //l_state.requestFocus();
            
            while(rs1.next())
                
            {
               
                state_name=rs1.getString("state_name");
                v_state.addItem(state_name);
            }
            
            con1.close();
        }
        catch(Exception e){
            
        }
        System.out.println(country_id1);
        c_ph_no.setText("+"+isd);
        c_mb_no.setText("+"+isd);
        
    }//GEN-LAST:event_v_countryActionPerformed

    private void c_openingFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_openingFocusGained
        // TODO add your handling code here:
        c_opening.setText("");
    }//GEN-LAST:event_c_openingFocusGained

  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttongroup;
    private javax.swing.JTextField c_add;
    private javax.swing.JComboBox c_company;
    private javax.swing.JTextField c_cst_no;
    private javax.swing.JTextField c_dob;
    private javax.swing.JTextField c_eid;
    private javax.swing.JTextField c_mb_no;
    private javax.swing.JTextField c_name;
    private numeric.textField.NumericTextField c_opening;
    private javax.swing.JTextField c_pan_no;
    private javax.swing.JTextField c_ph_no;
    private numeric.textField.NumericTextField c_pin_no;
    private javax.swing.JTextField c_vat_no;
    private javax.swing.JRadioButton company;
    private javax.swing.JRadioButton female;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton male;
    private javax.swing.JButton reset_button;
    private javax.swing.JButton submit_button;
    private javax.swing.JComboBox under;
    private javax.swing.JTextField v_city;
    private com.jidesoft.swing.AutoCompletionComboBox v_country;
    private com.jidesoft.swing.AutoCompletionComboBox v_state;
    // End of variables declaration//GEN-END:variables
 private javax.swing.JOptionPane jopt1;
    private javax.swing.JOptionPane jopt2;
private String gander;
}
