package final_project;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class stock_summary_report_panel extends javax.swing.JPanel {
private final GridBagConstraints gridBagConstraints;
    /**
     * Creates new form stock_summary_report_panel
     */
    public stock_summary_report_panel() {
        initComponents();
        
        gridBagConstraints = new java.awt.GridBagConstraints();
         gridBagConstraints.insets=new Insets(0,0,0,0);
            
          //  addContainerListener(this);
            
            int sck=0,r=4;
            
//            JLabel[] particlrlabel=new JLabel[200];
//            JLabel[] particlrgaplabel=new JLabel[200];
//            JLabel[] qtylabel=new JLabel[200];
//            JLabel[] qtygaplabel=new JLabel[200];
//            JLabel[] amtlabel=new JLabel[200];
//            JLabel[] opengaplabel=new JLabel[200];
//            JLabel[] qty1label=new JLabel[200];
//            JLabel[] qty1gaplabel=new JLabel[200];
//            JLabel[] amt2label=new JLabel[200];
//            JLabel[] purchasegaplabel=new JLabel[200];
//            JLabel[] qty2label=new JLabel[200];
//            JLabel[] qty2gaplabel=new JLabel[200];
//            JLabel[] amt3label=new JLabel[200];
//            JLabel[] salegaplabel=new JLabel[200];
//            JLabel[] qty3label=new JLabel[200];
//            JLabel[] qty3gaplabel=new JLabel[200];
//            JLabel[] ratelabel=new JLabel[200];
//            JLabel[] rategaplabel=new JLabel[200];
//            JLabel[] qty4label=new JLabel[200];
            
            
            // Panel 1 start.....y=2
            JLabel tohead=new JLabel("Particular");
            tohead.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.1;
            jPanel1.add(tohead,gridBagConstraints);
          
            JLabel blankhead4=new JLabel(" ");
            blankhead4.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead4,gridBagConstraints);
            
            JLabel refhead=new JLabel("Opening");
            refhead.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.225;
            jPanel1.add(refhead,gridBagConstraints);
            
            JLabel blankhead5=new JLabel(" ");
            blankhead5.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead5,gridBagConstraints);
            
            JLabel refhead1=new JLabel("Purchase");
            refhead1.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead1.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.225;
            jPanel1.add(refhead1,gridBagConstraints);
            
            JLabel blankhead6=new JLabel(" ");
            blankhead6.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead6,gridBagConstraints);
            
            JLabel refhead2=new JLabel("Sale");
            refhead2.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=24;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead2.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.225;
            jPanel1.add(refhead2,gridBagConstraints);
            
            JLabel blankhead7=new JLabel(" ");
            blankhead7.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead7,gridBagConstraints);
            
            JLabel refhead3=new JLabel("Closing");
            refhead3.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=8;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead3.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.225;
            jPanel1.add(refhead3,gridBagConstraints);
            
            //y=3 start......
            
            JLabel tohead1=new JLabel(" ");
            tohead1.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.1;
            jPanel1.add(tohead1,gridBagConstraints);
            
            JLabel blankhead8=new JLabel(" ");
            blankhead8.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead8,gridBagConstraints);
            
            JLabel refhead4=new JLabel("Quantity");
            refhead4.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead4.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.1125;
            jPanel1.add(refhead4,gridBagConstraints);
            
            JLabel blankhead9=new JLabel(" ");
            blankhead9.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=10;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead9,gridBagConstraints);
            
            JLabel refhead5=new JLabel("Amount");
            refhead5.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=12;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead5.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.1125;
            jPanel1.add(refhead5,gridBagConstraints);
            
            JLabel blankhead19=new JLabel(" ");
            blankhead19.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead19,gridBagConstraints);
            
            JLabel refhead14=new JLabel("Quantity");
            refhead14.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead14.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.1125;
            jPanel1.add(refhead14,gridBagConstraints);
            
            JLabel blankhead29=new JLabel(" ");
            blankhead29.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead29,gridBagConstraints);
            
            JLabel refhead15=new JLabel("Amount");
            refhead15.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=20;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead15.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.1125;
            jPanel1.add(refhead15,gridBagConstraints);
            
            JLabel blankhead39=new JLabel(" ");
            blankhead39.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead39,gridBagConstraints);
            
            JLabel refhead24=new JLabel("Quantity");
            refhead24.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=24;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead24.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.1125;
            jPanel1.add(refhead24,gridBagConstraints);
            
            JLabel blankhead49=new JLabel(" ");
            blankhead49.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=26;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead49,gridBagConstraints);
           
            JLabel refhead25=new JLabel("Amount");
            refhead25.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=28;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead25.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.1125;
            jPanel1.add(refhead25,gridBagConstraints);
            
            JLabel blankhead59=new JLabel(" ");
            blankhead59.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead59,gridBagConstraints);
            
            JLabel refhead26=new JLabel("Quantity");
            refhead26.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead26.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.075;
            jPanel1.add(refhead26,gridBagConstraints);
            
            JLabel blankhead60=new JLabel(" ");
            blankhead60.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=33;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead60,gridBagConstraints);
          
            JLabel refhead27=new JLabel("Rate");
            refhead27.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=35;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead27.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.075;
            jPanel1.add(refhead27,gridBagConstraints);
            
            JLabel blankhead61=new JLabel(" ");
            blankhead61.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=37;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead61,gridBagConstraints);
            
            JLabel refhead29=new JLabel("Amount");
            refhead29.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=39;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead29.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.075;
            jPanel1.add(refhead29,gridBagConstraints);
            
            // y=4 start....
            
        //Content Array Displaying(Particular,quantity,amout,rate)
            
//             while(rs1.next())
//             {
//                 particlrlabel[sck]=new JLabel();
//                 particlrgaplabel[sck]=new JLabel();
//                 qtylabel[sck]=new JLabel();
//                 qtygaplabel[sck]=new JLabel();
//                 amtlabel[sck]=new JLabel();
//                 opengaplabel[sck]=new JLabel();
//                 qty1label[sck]=new JLabel();
//                 qty1gaplabel[sck]=new JLabel();
//                 amt2label[sck]=new JLabel();
//                 purchasegaplabel[sck]=new JLabel();
//                 qty2label[sck]=new JLabel();
//                 qty2gaplabel[sck]=new JLabel();
//                 amt3label[sck]=new JLabel();
//                 salegaplabel[sck]=new JLabel();
//                 qty3label[sck]=new JLabel();
//                 qty3gaplabel[sck]=new JLabel();
//                 ratelabel[sck]=new JLabel();
//                 rategaplabel[sck]=new JLabel();
//                 qty4label[sck]=new JLabel();
//                 
//                
//            particlrlabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=5;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.1;
//            jPanel1.add(particlrlabel[sck],gridBagConstraints);
//            particlrlabel[sck].setText("Purchase1");
//            
//            
//            particlrgaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=6;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(particlrgaplabel[sck],gridBagConstraints);
//            particlrgaplabel[sck].setText("Purchasegap");
//            
//            
//            qtylabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=8;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            qtylabel[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.1125;
//            jPanel1.add(qtylabel[sck],gridBagConstraints);
//            qtylabel[sck].setText("Qty");
//            
//            
//            qtygaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=10;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(qtygaplabel[sck],gridBagConstraints);
//            qtygaplabel[sck].setText("Qtygap");
//            
//            
//            amtlabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=12;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            amtlabel[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.1125;
//            jPanel1.add(amtlabel[sck],gridBagConstraints);
//            amtlabel[sck].setText("Amt");
//            
//            
//            opengaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=14;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(opengaplabel[sck],gridBagConstraints);
//            opengaplabel[sck].setText("Opengap");
//            
//            
//            qty1label[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=16;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            qty1label[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.1125;
//            jPanel1.add(qty1label[sck],gridBagConstraints);
//            qty1label[sck].setText("Qty1");
//            
//            
//            qty1gaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(qty1gaplabel[sck],gridBagConstraints);
//            qty1gaplabel[sck].setText("Qty1gap");
//            
//           
//            amt2label[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=20;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            amt2label[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.1125;
//            jPanel1.add(amt2label[sck],gridBagConstraints);
//            amt2label[sck].setText("Qty2");
//            
//            
//            purchasegaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=22;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(purchasegaplabel[sck],gridBagConstraints);
//            purchasegaplabel[sck].setText("Purchase gap");
//            
//            
//            qty2label[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=24;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            qty2label[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.1125;
//            jPanel1.add(qty2label[sck],gridBagConstraints);
//            qty2label[sck].setText("Qty 2");
//            
//            
//            qty2gaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=26;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(qty2gaplabel[sck],gridBagConstraints);
//            qty2gaplabel[sck].setText("Qty2gap");
//           
//            
//            amt3label[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=28;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            amt3label[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.1125;
//            jPanel1.add(amt3label[sck],gridBagConstraints);
//            amt3label[sck].setText("Amt 3");
//            
//            
//            salegaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=30;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(salegaplabel[sck],gridBagConstraints);
//            salegaplabel[sck].setText("Salegap");
//            
//            
//            qty3label[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=32;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            qty3label[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.075;
//            jPanel1.add(qty3label[sck],gridBagConstraints);
//            salegaplabel[sck].setText("qty3");
//            
//            
//            qty3gaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=33;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(qty3gaplabel[sck],gridBagConstraints);
//            qty3gaplabel[sck].setText("qty3gap");
//          
//            
//            ratelabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=35;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            ratelabel[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.075;
//            jPanel1.add(ratelabel[sck],gridBagConstraints);
//            ratelabel[sck].setText("rate");
//            
//            
//            rategaplabel[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=37;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel1.add(rategaplabel[sck],gridBagConstraints);
//            ratelabel[sck].setText("rategap");
//            
//            
//            qty4label[sck].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
//            gridBagConstraints.gridx=39;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            qty4label[sck].setHorizontalAlignment(SwingConstants.CENTER);
//            //gridBagConstraints.anchor=gridBagConstraints.EAST;
//            gridBagConstraints.weightx=0.075;
//            jPanel1.add(qty4label[sck],gridBagConstraints);
//            qty4label[sck].setText("qty4");
//            
//            r++;
//            sck++;
////             
//             }
//            
//   
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        jPanel1.setLayout(new java.awt.GridBagLayout());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 371, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
