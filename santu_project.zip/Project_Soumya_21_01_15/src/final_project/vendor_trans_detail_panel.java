package final_project;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultRowSorter;
import javax.swing.KeyStroke;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class vendor_trans_detail_panel extends javax.swing.JPanel {
    
    //String to hold parameter
    String head_trans;
    String id;
    int flag=0;
    /**
     * Creates new form vendor_trans_detail_panel
     */
        public String s1="";
        public  int row,col;
        public vendor_trans_detail_panel() {
        initComponents();
      
        jPanel3.setVisible(false);
         
        table_1.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table_1.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {                                                                                  
            //action to be performed
        }

            
        });

    }
       
     public void print(){
    System.out.println(head_trans);
    HashMap param=new HashMap();
    param.put("vtp_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\vtp_print.jasper", param);
    viewer1.setVisible(true);
}
 public void  add_panel(String click)
 {
    flag=0;
     trans_label.setText("Details of:"+click);
     head_trans = click;
     
          try{
        
           
           Connection con = Database.getConnection();
           Statement psq3 =con.createStatement();
             PreparedStatement ps09=con.prepareStatement("DELETE FROM trans_vtp_temp");
                ps09.executeUpdate();
                Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("SELECT distinct TRANS_Date AS DATE, ledger as PARTICULERS, SUM(Debit) AS DEBIT, SUM(Credit) AS CREDIT, get_id AS TRANSACTION_ID, TYPE FROM company_main_table where type='Opening' and ledger='"+click+"'");
            System.out.println("SELECT distinct TRANS_Date AS DATE, ledger as PARTICULERS, SUM(Debit) AS DEBIT, SUM(Credit) AS CREDIT, get_id AS TRANSACTION_ID, TYPE FROM company_main_table where type='Opening' and ledger='"+click+"'");
            while(flag<=0){
            if(rs.next())
            {
                String de=rs.getString("debit");
                String cre=rs.getString("credit");
                PreparedStatement ps110=con.prepareStatement("insert into trans_vtp_temp ( vtp_debit, vtp_credit,vtp_type) values ('"+de+"','"+cre+"','Opening')");
                 System.out.println("insert into trans_vtp_temp ( vtp_ledger, vtp_debit, vtp_credit,vtp_type) values ('"+click+"','"+de+"','"+cre+"','Opening')");

                ps110.executeUpdate();
                System.out.println(de+"      "+cre);
                flag++;
            }
            }
               Statement psq =con.createStatement();
           ResultSet rsq=psq.executeQuery("SELECT distinct get_id FROM company_main_table where ledger='"+click+"' and get_id is not null");
           
           while(rsq.next())
           {
            id=rsq.getString("get_id");
             System.out.println(id+"A    ");
            
            Statement psa =con.createStatement();
            ResultSet rsa=psa.executeQuery("SELECT distinct TRANS_Date AS DATE, ledger as PARTICULERS, SUM(Debit) AS DEBIT, SUM(Credit) AS CREDIT, get_id AS TRANSACTION_ID, TYPE FROM company_main_table where get_id='"+id+"' and ledger!='"+click+"'");
            while(rsa.next())
            {
                
                  PreparedStatement ps102=con.prepareStatement("insert into trans_vtp_temp (vtp_trans_date, vtp_ledger, vtp_debit, vtp_credit, vtp_get_id, vtp_type) values ('"+rsa.getString("DATE")+"','"+rsa.getString("PARTICULERS")+"','"+rsa.getString("debit")+"','"+rsa.getString("credit")+"','"+rsa.getString("TRANSACTION_ID")+"','"+rsa.getString("type")+"')");
                     ps102.executeBatch();
                  ps102.executeUpdate();
                    
                  System.out.println("insert into trans_vtp_temp (vtp_trans_date, vtp_ledger, vtp_debit, vtp_credit, vtp_get_id, vtp_type) values ('"+rsa.getString("DATE")+"','"+rsa.getString("PARTICULERS")+"','"+rsa.getString("debit")+"','"+rsa.getString("credit")+"','"+rsa.getString("TRANSACTION_ID")+"','"+rsa.getString("type")+"')");
            }
         
            
           }
         
           
          Statement temp =con.createStatement();
            ResultSet tm=temp.executeQuery("SELECT vtp_trans_date as DATE, vtp_ledger AS PARTICULARS, vtp_debit AS DEBIT, vtp_credit as CREDIT, vtp_get_id AS `TRANSSACTION ID`, vtp_type as TYPE FROM trans_vtp_temp order by  (CASE VTP_TYPE WHEN 'Opening' Then 1 ELSE 100 END) ASC");
//           
//                  int li_row=0;
//           int rw = 0;
//           Vector <String> r[] = (Vector <String> []) new Vector[1000];
//             DefaultTableModel y1 = (DefaultTableModel)table_1.getModel();
//            int fr = y1.getRowCount();
//            while (fr>=1)
//            {   
//            int a=y1.getRowCount()- 1;
//            y1.removeRow(a);
//            fr--;
//            }
//           while(tm.next())
//                 {
//                      
//                         y1.addRow(r[rw]); 
//                    
//                 table_1.setValueAt(tm.getString("DATE"), li_row, 0);
//                  table_1.setValueAt(tm.getString("PARTICULARS"), li_row, 1);
//                  table_1.setValueAt(tm.getString("DEBIT"), li_row, 2);
//                   table_1.setValueAt(tm.getString("CREDIT"), li_row, 3);
//                    table_1.setValueAt(tm.getString("TRANSSACTION ID"), li_row, 4);
//                     table_1.setValueAt(tm.getString("TYPE"), li_row, 5);
//                     rw++;
//                 li_row++;
//                 }
             table_1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(tm));
         con.close();
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
          table_1.setPreferredScrollableViewportSize(table_1.getPreferredSize());
          table_1.setAutoCreateRowSorter(true);
          table_1.setRowHeight(25);
    	DefaultRowSorter sorter = ((DefaultRowSorter)table_1.getRowSorter());
    	ArrayList list = new ArrayList();
    	list.add( new RowSorter.SortKey(2, SortOrder.ASCENDING) );
    	sorter.setSortKeys(list);
    	sorter.sort();
//         Action delete = new AbstractAction()
//{
//    public void actionPerformed(ActionEvent e)
//    {
//        
//    }
//};
//     ButtonColumn buttonColumn0 = new ButtonColumn(table_1, delete, 0);
//     ButtonColumn buttonColumn1 = new ButtonColumn(table_1, delete, 1);
//     ButtonColumn buttonColumn2 = new ButtonColumn(table_1, delete, 2);
//     ButtonColumn buttonColumn3 = new ButtonColumn(table_1, delete, 3);
//     ButtonColumn buttonColumn4 = new ButtonColumn(table_1, delete, 4);
//     ButtonColumn buttonColumn5 = new ButtonColumn(table_1, delete, 5);
//    buttonColumn0.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn1.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn2.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn3.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn4.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn5.setMnemonic(KeyEvent.VK_ENTER);

    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        trans_label = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        trans_label.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        trans_label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Detail", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(0, 0, 255))); // NOI18N

        table_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        table_1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "Particulars", "Debit", "Credit", "Transaction Id", "Voucher Type"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table_1.setAutoscrolls(false);
        jScrollPane1.setViewportView(table_1);
        if (table_1.getColumnModel().getColumnCount() > 0) {
            table_1.getColumnModel().getColumn(1).setMinWidth(120);
        }

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 505, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
        );

        jButton1.setText("PRINT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(trans_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(229, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(205, 205, 205))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(trans_label, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     Integer row = table_1.getRowCount();
    
    //Inserting data into table for printing
//    try{
//
//                Class.forName("com.mysql.jdbc.Driver");
//                String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//
//                Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//                
//
//                //Deleting All Sale details from Sale Table 2
//                PreparedStatement ps9=con.prepareStatement("DELETE FROM trans_vtp_temp");
//                ps9.executeUpdate();

                //Inserting data into table for printing
//                for(int i=0;i<row;i++)
//                {
//                    String vtp_trans_date=table_1.getValueAt(i,0).toString();
//                    String vtp_ledger=table_1.getValueAt(i,1).toString();
//                    String vtp_debit=table_1.getValueAt(i,2).toString();
//                    String vtp_credit=table_1.getValueAt(i,3).toString();
//                    String vtp_get_id=table_1.getValueAt(i,4).toString();
//                    String vtp_type=table_1.getValueAt(i,5).toString();
//                    
//                    PreparedStatement ps10=con.prepareStatement("insert into trans_vtp_temp (vtp_trans_date, vtp_ledger, vtp_debit, vtp_credit, vtp_get_id, vtp_type) values ('"+vtp_trans_date+"','"+vtp_ledger+"','"+vtp_debit+"','"+vtp_credit+"','"+vtp_get_id+"','"+vtp_type+"')");
//
//                    ps10.executeBatch();
//                    ps10.executeUpdate();
//                   
//                }
                
               
//            }catch (SQLException q){
//                System.out.println("Sql Exception" + q.toString());
//            }
//            catch(ClassNotFoundException ce)
//            {
//                System.out.println("ClassNotFoundException" + ce.toString());
//            }
            
    HashMap param=new HashMap();
    param.put("header_label", head_trans);
    MyReportViewer viewer1=new MyReportViewer("C:\\Users\\pc1\\Documents\\NetBeansProjects\\demo_dev\\src\\vtp_report.jasper", param);
    viewer1.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable table_1;
    private javax.swing.JLabel trans_label;
    // End of variables declaration//GEN-END:variables
}
