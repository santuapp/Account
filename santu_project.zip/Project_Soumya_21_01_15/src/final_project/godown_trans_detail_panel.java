/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author Ardhendu
 */
public class godown_trans_detail_panel extends javax.swing.JPanel {
  String head_grp;

 String var_global="";

    /**
     * Creates new form godown_trans_detail_panel
     */
      String head_trans;
    String id;
    /**
     * Creates new form vendor_trans_detail_panel
     */
        public String s1="";
        public  int row,col;
    public godown_trans_detail_panel() {
        initComponents();
        table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }
        });
    }

//    public void fill_godown(String click)
//    
//    {
//        
//    jLabel1.setText("Details of:"+click);
//     head_trans = click;
//     
//          try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//           Statement psq3 =con.createStatement();
//            
//             
//           
//            Statement temp =con.createStatement();
//            ResultSet tm=temp.executeQuery("SELECT item AS PRODUCT , SUM(t_quantity + p_quantity - s_quantity) AS QUANTITY,UNIT FROM godown_detail WHERE gd_name_to='"+click+"' GROUP BY item");
//              table.setModel(DbUtils.resultSetToTableModel(tm));
//              
//              
//              
//            
//         
//        }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }
//          table.setPreferredScrollableViewportSize(table.getPreferredSize());
//          table.setAutoCreateRowSorter(true);
//          table.setRowHeight(25);
//    	DefaultRowSorter sorter = ((DefaultRowSorter)table.getRowSorter());
//    	ArrayList list = new ArrayList();
//    	list.add( new RowSorter.SortKey(2, SortOrder.ASCENDING) );
//    	sorter.setSortKeys(list);
//    	sorter.sort();
//    }

        
public void  fill_godown(String click){
    // h_label.setText(click);
        head_trans = click;
          var_global= click;

  TableColumnModel cmodel = table.getColumnModel(); 
        TextAreaRenderer textAreaRenderer = new TextAreaRenderer(); 
        cmodel.getColumn(0).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(1).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(2).setCellRenderer(textAreaRenderer);
        addRows(table);
        
 
      
    }

 private void addRows(JTable table)
    
    { 
           DefaultTableModel y1 = (DefaultTableModel)table .getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            }
        
       try{
        
            
            Connection con = Database.getConnection();
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("SELECT item AS PRODUCT , SUM(t_quantity + p_quantity - s_quantity) AS QUANTITY,unit AS UNIT FROM godown_detail WHERE gd_name_to='"+var_global+"' GROUP BY item");
           int li_row=0;
           int rw = 0;
           Vector <String> r[] = (Vector <String> []) new Vector[1000];
           
           
        
           
           while(rs.next())
                 {
                 y1.addRow(r[rw]); 
                    
                 table.setValueAt(rs.getString("PRODUCT"), li_row, 0);
                 table.setValueAt(rs.getString("QUANTITY"), li_row, 1);
                 table.setValueAt(rs.getString("UNIT"), li_row, 2);
                
                  
       
                 
                 rw++;
                 li_row++;
                 }
           

   
            System.out.println("Done");
          
         con.close();
            }catch (SQLException e)
                {
                System.out.println("Sql Exception" + e.toString());
                }
        
 }    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PRODUCT", "QUANTITY", "UNIT"
            }
        ));
        jScrollPane1.setViewportView(table);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
public void print(){
     System.out.println(head_trans);
    HashMap param=new HashMap();
    param.put("godown_main_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\godown_details_printable.jasper", param);
    viewer1.setVisible(true);
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
