package final_project;
import com.ibm.icu.text.DecimalFormat;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import org.jdesktop.xswingx.PromptSupport;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author virtual vista
 */
public class normal_sale_edit_panel extends javax.swing.JPanel implements FocusListener {
    Font myFont = new Font("",Font.PLAIN,9);
     int i=0,j=0,k=0,l=0,m=0;   // For Mandatory
     int x=0,y=0;              // For Non Mandatory
     
    public JPanel gb = new JPanel(new GridBagLayout());
    
    private GridBagConstraints gridBagConstraints;
    private GridBagConstraints gbc;
    
     int valid_check;
    
    int count = 1000, row = 0, rowfinal = 0;
    final JTextField[][] text_field=new JTextField[count][10];
    final JComboBox[] jComboBox1 = new JComboBox[count];
    final JComboBox[] jComboBox2 = new JComboBox[count];

    /**
     * Creates new form normal_sale_edit_panel
     */
    
    public void set(){
        search_txt.requestFocusInWindow();
        search_txt.setFocusable(true);
    }
    
    public void user(String u_name){
    jLabel18.setText(u_name);
    }
    
    String name4="",inv_no="";
    public normal_sale_edit_panel() {
        initComponents();
        
        calculation_total();
        fill_combo();
        valid_table();
        
        update_table();
        fill_combo();
       
        initialise();
        cell_caculate();
        search();
        jTextField1.setVisible(false);
        jTextField2.setVisible(false);
        jTextField3.setVisible(false);
        
        invoice_no_txt.setFocusable(true);
        invoice_no_txt.setEditable(false);
        
        PromptSupport.setPrompt("dd/mm/yyyy", date_txt);
        PromptSupport.setPrompt("0.00", curbalnc_txt);
        PromptSupport.setPrompt("0.00", gross_total);
        
        jLabel15.setFont(myFont);
        jLabel15.setEnabled(false);
        jLabel15.setVisible(false);
        
        jLabel10.setFont(myFont);
        jLabel10.setEnabled(false);
        jLabel10.setVisible(false);
        
        jLabel11.setFont(myFont);
        jLabel11.setEnabled(false);
        jLabel11.setVisible(false);
        
        jLabel12.setFont(myFont);
        jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        jLabel13.setFont(myFont);
        jLabel13.setEnabled(false);
        jLabel13.setVisible(false);
        
        jLabel14.setFont(myFont);
        jLabel14.setEnabled(false);
        jLabel14.setVisible(false);
        
        jLabel9.setFont(myFont);
        jLabel9.setEnabled(false);
        jLabel9.setVisible(false);
        
        jLabel18.setVisible(false);
        
        create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
        
        jPanel7.setLayout(new BorderLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gbc = new java.awt.GridBagConstraints();
        
        JPanel gb = new JPanel(new GridBagLayout());
        
        
//        TableCellRenderer r = table1.getTableHeader().getDefaultRenderer();
//        JLabel headerlabel = (JLabel)r;
//        headerlabel.setHorizontalAlignment(JLabel.CENTER);
    
        fill_gridpanel();

    }
    
    
      // Grid table heading
    
    
     public void fill_gridpanel()
    {
            jPanel7.removeAll();
        
            text_field[0][0] = new JTextField("Item");
            text_field[0][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.24;
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            
            text_field[0][0].setFont(myFont);
            gb.add(text_field[0][0],gridBagConstraints);
            
            text_field[0][0].setHorizontalAlignment(SwingConstants.CENTER);
            
            text_field[0][1] = new JTextField("Unit");
           
            text_field[0][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
           
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=11;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            text_field[0][1].setFont(myFont);
            
            gb.add(text_field[0][1],gridBagConstraints);
            text_field[0][1].setHorizontalAlignment(SwingConstants.CENTER);           

            text_field[0][2] = new JTextField("Quantity");            
            text_field[0][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[0][2].setFont(myFont);
           
            gb.add(text_field[0][2],gridBagConstraints);
            text_field[0][2].setHorizontalAlignment(SwingConstants.CENTER);
            
            //Santu added in 05-12-2014
            
            text_field[0][3] = new JTextField("Rate");            
            text_field[0][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=33;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[0][3].setFont(myFont);
            
            gb.add(text_field[0][3],gridBagConstraints);
            text_field[0][3].setHorizontalAlignment(SwingConstants.CENTER);
            
           //added on 05-12-2014
            
            text_field[0][4] = new JTextField("Amount");            
            text_field[0][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=44;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[0][4].setFont(myFont);
            
            gb.add(text_field[0][4],gridBagConstraints);
            text_field[0][4].setHorizontalAlignment(SwingConstants.CENTER);
            
            text_field[0][5] = new JTextField("Tax");            
            text_field[0][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=55;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[0][5].setFont(myFont);
            
            gb.add(text_field[0][5],gridBagConstraints);
            text_field[0][5].setHorizontalAlignment(SwingConstants.CENTER);
            
 
            text_field[0][6] = new JTextField("Taxable Amount");            
            text_field[0][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.013;
            gridBagConstraints.gridx=66;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[0][6].setFont(myFont);
           
            gb.add(text_field[0][6],gridBagConstraints);
            text_field[0][6].setHorizontalAlignment(SwingConstants.CENTER);
            
                        
            text_field[0][7] = new JTextField("Discount");            
            text_field[0][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=77;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[0][7].setFont(myFont);
          
            gb.add(text_field[0][7],gridBagConstraints);
            text_field[0][7].setHorizontalAlignment(SwingConstants.CENTER);
            

            text_field[0][8] = new JTextField("Discountable Amount");            
            text_field[0][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.013;
            gridBagConstraints.gridx=88;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[0][8].setFont(myFont);
           
            gb.add(text_field[0][8],gridBagConstraints);
            text_field[0][8].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[0][9] = new JTextField("Total");            
            text_field[0][9].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.weighty=0.00;
            gridBagConstraints.gridx=99;
            gridBagConstraints.gridy=0;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[0][9].setFont(myFont);
            
            gb.add(text_field[0][9],gridBagConstraints);
            text_field[0][9].setHorizontalAlignment(SwingConstants.CENTER);
            
            
            
       jPanel7.add(gb, BorderLayout.NORTH);
        
    }
    
    
      // Invoice No
    
    public void invoice(){
   if(invoice_no_txt.getText().length()==0)
      {
          invoice_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel9.setEnabled(true);
          jLabel9.setForeground(Color.red);
          jLabel9.setVisible(true);
             
      }  
      else
      {
           invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel9.setEnabled(false);  
           jLabel9.setVisible(false);
           i=1;
          
      }
    }
    
    // date
    
    public void date(){
     if(date_txt.getText().length()==0)
        {
                 date_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);
        }
        else
        {
            String content = date_txt.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel14.setEnabled(false);  
            jLabel14.setVisible(false);
            j=1;
            if(!matchFound)

            {

                 date_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);

            }
        }
    }
    
    // Party Name
    
    public void party(){
    if(party_combo.getSelectedItem().equals(""))
      {
          party_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel10.setEnabled(true);
          jLabel10.setForeground(Color.red);
          jLabel10.setVisible(true);
             
      }  
      else
      {
           party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel10.setEnabled(false);  
           jLabel10.setVisible(false);
           k=1;
      }
    }
    
    // Sale Ledger
    
    public void sale(){
     if(sale_combo.getSelectedItem().equals(""))
      {
          sale_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel12.setEnabled(true);
          jLabel12.setForeground(Color.red);
          jLabel12.setVisible(true);
             
      }  
      else
      {
           sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel12.setEnabled(false);  
           jLabel12.setVisible(false);
           l=1;
      }
        
    }
    
    // Godown
    
    public void godown(){
     if(godown_combo.getSelectedItem().equals(""))
      {
          godown_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
             
      }  
      else
      {
           godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           m=1;
      }
        
    }

    public void fill_combo()
    {
      party_combo.removeAll();
      sale_combo.removeAll();
      godown_combo.removeAll();
        
        try{
        
            
            Connection con = Database.getConnection();
            
            // Adding Items to Party Ledger
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("select distinct l_name from ledger order by l_id");
            
               while(rs.next())
              {
                  String name=rs.getString("l_name");
                  party_combo.addItem(name);
                  sale_combo.addItem(name);
              }
               
            //              String name1="Others";
            //              group.addItem(name1);
            
            //Adding Items to Purchase Ledger
            Statement ps2 =con.createStatement();
            ResultSet rs2=ps2.executeQuery("select distinct gd_name from godown order by gd_id");
            
               while(rs2.next())
              {
                  String name2=rs2.getString("gd_name");
                  godown_combo.addItem(name2);
              }
               
            //Adding Items to Unit in Table
            Statement ps3 = con.createStatement();
            ResultSet rs3=ps3.executeQuery("select distinct u_name from unit order by u_id");
            
            
               while(rs3.next())
              {
                  String name3=rs3.getString("u_name");
                  unit_combox.addItem(name3);
              }   
               
            //Adding Products to Item in Table
            Statement ps4 = con.createStatement();
            ResultSet rs4 = ps4.executeQuery("select distinct product_name from product order by p_id");
            
            
               while(rs4.next())
              {
                  String name4=rs4.getString("product_name");
                  item_combox.addItem(name4);
              }    
               
               //Add challan 
                 Statement ps5 = con.createStatement();
            ResultSet rs5 = ps5.executeQuery("select distinct sale_challan_no from sale_challan_1 order by sale_challan_id");
            
            
               while(rs5.next())
              {
                  String name5=rs5.getString("sale_challan_no");
                  challan_combox.addItem(name5);
              }    
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
           
     
     //Setting Current Date to Date Field  
     /*
     Date dt = new Date();
     SimpleDateFormat sdf = new SimpleDateFormat ("dd/MM/yyyy");
     String dtf = sdf.format(dt);
     date_txt.setText(dtf);
     */
    }
    
     public void update_table()
    { 
       
//         
//        try{
//        
//               
//               Connection con = Database.getConnection();
//               Statement ps =con.createStatement();
//               ResultSet rs=ps.executeQuery("SELECT sale_inv_no as SALES_INVOICE from sale_table1");
//               product_table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
//
//               System.out.println("Done");
//          
//         
//            }catch (SQLException e){
//            System.out.println("Sql Exception" + e.toString());
//            }
//            
//        
//        product_table.addKeyListener(new java.awt.event.KeyAdapter()
//
//            {
//
//            public void keyReleased(java.awt.event.KeyEvent e)
//
//            {
//
//            int keyvalue=e.getKeyCode();
//            if(keyvalue==KeyEvent.VK_ENTER)
//                            {
//                                                                
//                             int row=product_table.getSelectedRow();
//                             int col=product_table.getSelectedColumn();
//
//                            if(product_table.getValueAt(row, 0) != null){
//                            String s1= (String)product_table.getValueAt(row, 0);
//
//
//            //JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());
//
//            System.out.println(" Value in the row clicked :"+ " " +row+"");
//            System.out.println(" Value in the col clicked :"+ " " +col+"");
//            System.out.println(" Value in the col,row clicked :"+ " " +s1+"");
//
//          try{
//         
//            
//            Connection con1 = Database.getConnection();
//            Statement ps1 =con1.createStatement();
//            Statement ps2 =con1.createStatement();
//            Statement ps3 =con1.createStatement();
//            ResultSet rs1 =ps1.executeQuery("SELECT * from sale_table1 where sale_inv_no='"+s1+"' ");
//            while(rs1.next())
//                {
//                
//                String  aa=rs1.getString("sale_id");
//                jTextField1.setText(aa);
//                
//                String a1=rs1.getString("sale_inv_no");
//                invoice_no_txt.setText(a1);
//                jTextField2.setText(a1);
//
//                String a2=rs1.getString("sale_date");
//                date_txt.setText("");
//                date_txt.setText(a2);
//                                
//                String a3=rs1.getString("sale_party_name");
//                party_combo.setSelectedItem(a3);
//                
//                String a4=rs1.getString("sale_current_balance");
//                curbalnc_txt.setText(a4);
//                
//                String a5=rs1.getString("sale_ledger");
//                sale_combo.setSelectedItem(a5);
//                
//                String a6=rs1.getString("sale_gd_name");
//                godown_combo.setSelectedItem(a6);
//                
//                String a7=rs1.getString("sale_challan_no");
//                challan_combox.setSelectedItem(a7);
//                
//                String narration=rs1.getString("sale_narration");
//                sale_narration.setText(narration);
//                
//            
//            // Code to Save & Edit Sale Table 3 with value from JTextField 3
//            String sch3 = jTextField2.getText().toString();
//            System.out.println(sch3);
//            Integer srch3 = Integer.parseInt(sch3);
//            System.out.println("Invoice No.:"+srch3);
//            
//            ResultSet rs3=ps3.executeQuery("SELECT * from sale_table3 where sale_inv_no='"+srch3+"' ");
//            while (rs3.next())
//            {
//                String ax = rs3.getString("sale_id");
//                jTextField3.setText(ax);
//            }
//
//                }
//            //Code to fill Item Table
//           DefaultTableModel y1 = (DefaultTableModel)table1.getModel();
//            int fr = y1.getRowCount();
//            while (fr>=1)
//            {   
//            int a=y1.getRowCount()- 1;
//            y1.removeRow(a);
//            fr--;
//            }
//        
//            
//            
//           ResultSet rs2=ps2.executeQuery("SELECT * from sale_table2 where sale_inv_no='"+s1+"' ");
//        
////sale_item AS Item, sale_unit AS Unit, sale_quantity AS Quantity, sale_rate AS Rate, sale_amount AS Amount, sale_tax AS Amount, sale_taxable_amnt AS Taxable_Amt, sale_disc AS Discount, sale_disc_amnt AS Discount_Amt, sale_total AS Total
//           
//           //table1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs2));
//           
//           int li_row=0;
//           int rw = 0;
//           Vector <String> r[] = (Vector <String> []) new Vector[1000];
//           
//           
//           table1.getColumnModel().getColumn(10).setMinWidth(0);
//           table1.getColumnModel().getColumn(10).setMaxWidth(0);
//           table1.getColumnModel().getColumn(10).setResizable(false);
//           
//           while(rs2.next())
//                 {
//                 y1.addRow(r[rw]); 
//                    
//                 table1.setValueAt(rs2.getString("sale_item"), li_row, 0);
//                 table1.setValueAt(rs2.getString("sale_unit"), li_row, 1);
//                 
//                 Double sqty = Double.parseDouble(rs2.getString("sale_quantity"));
//                 table1.setValueAt(sqty, li_row, 2);
//                 
//                 Double srt = Double.parseDouble(rs2.getString("sale_rate"));
//                 table1.setValueAt(srt, li_row, 3);
//                 
//                 Double samnt = Double.parseDouble(rs2.getString("sale_amount"));
//                 table1.setValueAt(samnt, li_row, 4);
//                 
//                 Double stax = Double.parseDouble(rs2.getString("sale_tax"));
//                 table1.setValueAt(stax, li_row, 5);
//                 
//                 Double stxamnt = Double.parseDouble(rs2.getString("sale_taxable_amnt"));
//                 table1.setValueAt(stxamnt, li_row, 6);
//                 
//                 Double sdisc = Double.parseDouble(rs2.getString("sale_disc"));
//                 table1.setValueAt(sdisc, li_row, 7);
//                 
//                 Double sdamnt = Double.parseDouble(rs2.getString("sale_disc_amnt"));
//                 table1.setValueAt(sdamnt, li_row, 8);
//                 
//                 table1.setValueAt(rs2.getString("sale_total"), li_row, 9);
//                 
//                 table1.setValueAt(rs2.getString("sale_id"), li_row, 10);
//                 
//                 rw++;
//                 li_row++;
//                 }
//           
//           
//            
//       
//        }catch (SQLException q){
//        System.out.println("Sql Exception" + q.toString());
//        }
//        
//
//                }  }
//
//        }
//
//        }
//
//        );
//            Action delete = new AbstractAction()
//        {
//            public void actionPerformed(ActionEvent e)
//            {
//
//            }
//        };
        
     
        
 
        
        
        
            jPanel7.removeAll();
        
         
          try{
        
//              Class.forName("com.mysql.jdbc.Driver");
               String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
               Connection con = (Connection) DriverManager.getConnection(ConnUrl);
               
               
               
               Statement ps =con.createStatement();
               ResultSet rs=ps.executeQuery("SELECT sale_inv_no as SALES_INVOICE from sale_table1");
               product_table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));

               System.out.println("Done");
          
            }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
            }
         //   product_table.addFocusListener(this);
       

        product_table.addKeyListener(new java.awt.event.KeyAdapter()

            {

            public void keyReleased(java.awt.event.KeyEvent e)

            {

            int keyvalue=e.getKeyCode();
            if(keyvalue==KeyEvent.VK_ENTER)
                            {
                                                                
                             int row=product_table.getSelectedRow();
                             int col=product_table.getSelectedColumn();

                            if(product_table.getValueAt(row, 0) != null){
                            String s1= (String)product_table.getValueAt(row, 0);


            //JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());

            System.out.println(" Value in the row clicked :"+ " " +row+"");
            System.out.println(" Value in the col clicked :"+ " " +col+"");
            System.out.println(" Value in the col,row clicked :"+ " " +s1+"");
            fill_grid_table(s1);
          try{
         
                               
               String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
               Connection con1 = (Connection) DriverManager.getConnection(ConnUrl);
            
            
            Statement ps1 =con1.createStatement();
            Statement ps2 =con1.createStatement();
            Statement ps3 =con1.createStatement();
            ResultSet rs1 =ps1.executeQuery("SELECT * from sale_table1 where sale_inv_no='"+s1+"' ");
            while(rs1.next())
                {
                
                String  aa=rs1.getString("sale_id");
                jTextField1.setText(aa);
                
                String a1=rs1.getString("sale_inv_no");
                invoice_no_txt.setText(a1);
                jTextField2.setText(a1);

                String a2=rs1.getString("sale_date");
                date_txt.setText("");
                date_txt.setText(a2);
                                
                String a3=rs1.getString("sale_party_name");
                party_combo.setSelectedItem(a3);
                
                String a4=rs1.getString("sale_current_balance");
                curbalnc_txt.setText(a4);
                
                String a5=rs1.getString("sale_ledger");
                sale_combo.setSelectedItem(a5);
                
                String a6=rs1.getString("sale_gd_name");
                godown_combo.setSelectedItem(a6);
                
//                String a7=rs1.getString("sale_challan_no");
//                challan_combox.setSelectedItem(a7);
//                
                String narration=rs1.getString("sale_narration");
                sale_narration.setText(narration);
                                                
                
            
            // Code to Save & Edit Sale Table 3 with value from JTextField 3
            String sch3 = jTextField2.getText().toString();
            System.out.println(sch3);
            //Integer srch3 = Integer.parseInt(sch3);
            System.out.println("Invoice No.:"+sch3);
            
            ResultSet rs3=ps3.executeQuery("SELECT * from sale_table3 where sale_inv_no='"+sch3+"' ");
            while (rs3.next())
            {
                String ax = rs3.getString("sale_id");
                jTextField3.setText(ax);
                
                String a7=rs3.getString("sale_g_total");
                gross_total.setText(a7);
            }

                }
            //Code to fill Item Table
         
        
            
            
           
       
        
        //jPanel1.repaint();
        //jPanel1.revalidate();
        
        //jPanel1.add(gb);
        System.out.println("Total row"+row);
       
           
            
       
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        

                }  }

        }

        }

        );
         product_table.addFocusListener(new java.awt.event.FocusAdapter() {
    }
    );
            Action delete = new AbstractAction()
        {
            public void actionPerformed(ActionEvent e)
            {

            }
        };


        }
     
     
     
     
     
     
      public void fill_grid_table(String get_val){
          
            try{
         
                               
               String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
               Connection con1 = (Connection) DriverManager.getConnection(ConnUrl);
                  Statement ps23 =con1.createStatement();
               ResultSet rs2=ps23.executeQuery("SELECT * from sale_table2 where sale_inv_no='"+get_val+"' ");
           //sale_item AS Item, sale_unit AS Unit, sale_quantity AS Quantity, sale_rate AS Rate, sale_amount AS Amount, sale_tax AS Amount, sale_taxable_amnt AS Taxable_Amt, sale_disc AS Discount, sale_disc_amnt AS Discount_Amt, sale_total AS Total
           //table1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs2));
           
           int li_row=0;
           int rw = 0;
           
//           Vector <String> r[] = (Vector <String> []) new Vector[1000];
//           
//           
//           table1.getColumnModel().getColumn(10).setMinWidth(0);
//           table1.getColumnModel().getColumn(10).setMaxWidth(0);
//           table1.getColumnModel().getColumn(10).setResizable(false);
           
           
           
           
           //Code to redraw header when selection of specific invoice
          
              row = 0;
            gb.removeAll();
           
            text_field[row][0] = new JTextField("Item");
            text_field[row][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.24;
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][0].setFont(myFont);
            
           
            gb.add(text_field[row][0],gridBagConstraints);
            
            text_field[row][0].setHorizontalAlignment(SwingConstants.CENTER);
            
            text_field[row][1] = new JTextField("Unit");
           
            text_field[row][1].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
           
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=11;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            text_field[row][1].setFont(myFont);
            
            gb.add(text_field[row][1],gridBagConstraints);
            text_field[row][1].setHorizontalAlignment(SwingConstants.CENTER);           

            text_field[row][2] = new JTextField("Quantity");            
            text_field[row][2].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][2].setFont(myFont);
           
            gb.add(text_field[row][2],gridBagConstraints);
            text_field[row][2].setHorizontalAlignment(SwingConstants.CENTER);
           
            
            //Santu added in 05-12-2014
            
            text_field[row][3] = new JTextField("Rate");            
            text_field[row][3].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=33;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][3].setFont(myFont);
            
            
            gb.add(text_field[row][3],gridBagConstraints);
            text_field[row][3].setHorizontalAlignment(SwingConstants.CENTER);
            
           //added on 05-12-2014
            
            text_field[row][4] = new JTextField("Amount");            
            text_field[row][4].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=44;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][4].setFont(myFont);
            
            gb.add(text_field[row][4],gridBagConstraints);
            text_field[row][4].setHorizontalAlignment(SwingConstants.CENTER);
            
            text_field[row][5] = new JTextField("Tax");            
            text_field[row][5].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=55;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][5].setFont(myFont);
            
            gb.add(text_field[row][5],gridBagConstraints);
            text_field[row][5].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[row][6] = new JTextField("Taxable Amount");            
            text_field[row][6].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.013;
            gridBagConstraints.gridx=66;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][6].setFont(myFont);
           
            gb.add(text_field[row][6],gridBagConstraints);
            text_field[row][6].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[row][7] = new JTextField("Discount");            
            text_field[row][7].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=77;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][7].setFont(myFont);
          
            gb.add(text_field[row][7],gridBagConstraints);
            text_field[row][7].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[row][8] = new JTextField("Discountable Amount");            
            text_field[row][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.013;
            gridBagConstraints.gridx=88;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][8].setFont(myFont);
           
            gb.add(text_field[row][8],gridBagConstraints);
            text_field[row][8].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[row][9] = new JTextField("Total");            
            text_field[row][9].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.weighty=0.00;
            gridBagConstraints.gridx=99;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][9].setFont(myFont);
            
            gb.add(text_field[row][9],gridBagConstraints);
            text_field[row][9].setHorizontalAlignment(SwingConstants.CENTER);
           
            row++;
           
           
           while(rs2.next())
                 {
              
                   
                    
                 table1.setValueAt(rs2.getString("sale_item"), li_row, 0);
                 table1.setValueAt(rs2.getString("sale_unit"), li_row, 1);
                 
                 Double sqty = Double.parseDouble(rs2.getString("sale_quantity"));
                 table1.setValueAt(sqty, li_row, 2);
                 
                 Double srt = Double.parseDouble(rs2.getString("sale_rate"));
                 table1.setValueAt(srt, li_row, 3);
                 
                 Double samnt = Double.parseDouble(rs2.getString("sale_amount"));
                 table1.setValueAt(samnt, li_row, 4);
                 
                 Double stax = Double.parseDouble(rs2.getString("sale_tax"));
                 table1.setValueAt(stax, li_row, 5);
                 
                 Double stxamnt = Double.parseDouble(rs2.getString("sale_taxable_amnt"));
                 table1.setValueAt(stxamnt, li_row, 6);
                 
                 Double sdisc = Double.parseDouble(rs2.getString("sale_disc"));
                 table1.setValueAt(sdisc, li_row, 7);
                 
                 Double sdamnt = Double.parseDouble(rs2.getString("sale_disc_amnt"));
                 table1.setValueAt(sdamnt, li_row, 8);
                 
                 table1.setValueAt(rs2.getString("sale_total"), li_row, 9);
                 
                 table1.setValueAt(rs2.getString("sale_id"), li_row, 10);
                 
                 rw++;
                 li_row++;
                 
                 
                 
                     
                     
        //filling item table with gridbag rows and values
                 
        jComboBox1[row]= new JComboBox();

        jComboBox1[row].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
        gridBagConstraints.weightx=0.24;
        gridBagConstraints.weighty=0.0;
        gridBagConstraints.gridx=0;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipady = 7;

        fill_combo1(jComboBox1[row]);
        jComboBox1[row].setSelectedItem(rs2.getString("sale_item"));
        
        
        gb.add(jComboBox1[row],gridBagConstraints);

        jComboBox2[row]= new JComboBox();
        jComboBox2[row].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=11;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipady = 7;
        
        fill_combo2(jComboBox2[row]);
        jComboBox2[row].setSelectedItem(rs2.getString("sale_unit"));
        
        gb.add(jComboBox2[row],gridBagConstraints);

        //END IN 5 12-2014

        text_field[row][2] = new JTextField("0.00");
    
        text_field[row][2].setText(Double.toString(sqty));
        
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        //text_field[row][3].setFont(myfont);
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=22;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
         text_field[row][2].addFocusListener(this);

        //text_field[row][2].
        text_field[row][2].setText(rs2.getString("sale_quantity"));
        gb.add(text_field[row][2],gridBagConstraints);

        text_field[row][3] = new JTextField("0.00");
        text_field[row][3].setHorizontalAlignment(SwingConstants.RIGHT);

        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        //text_field[row][3].setFont(myfont);
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=33;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
         text_field[row][3].addFocusListener(this);
        
        text_field[row][3].setText(rs2.getString("sale_rate"));
        gb.add(text_field[row][3],gridBagConstraints);

        text_field[row][3].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[row][4] = new JTextField("0.00");
        text_field[row][4].setHorizontalAlignment(SwingConstants.RIGHT);
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        //text_field[row][4].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        text_field[row][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=44;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
         text_field[row][4].addFocusListener(this);
        
        text_field[row][4].setText(rs2.getString("sale_amount"));
        gb.add(text_field[row][4],gridBagConstraints);

        text_field[row][5] = new JTextField("0.00");
        text_field[row][5].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][5].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=55;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
         text_field[row][5].addFocusListener(this);
        
        text_field[row][5].setText(rs2.getString("sale_tax"));
        gb.add(text_field[row][5],gridBagConstraints);

        text_field[row][5].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[row][6] = new JTextField("0.00");
        text_field[row][6].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][6].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.013;
        gridBagConstraints.gridx=66;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
         text_field[row][6].addFocusListener(this);
        
        text_field[row][6].setText(rs2.getString("sale_taxable_amnt"));
        gb.add(text_field[row][6],gridBagConstraints);

        text_field[row][6].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[row][7] = new JTextField("0.00");
        text_field[row][7].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][7].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=77;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
         text_field[row][7].addFocusListener(this);
        
        text_field[row][7].setText(rs2.getString("sale_disc"));
        gb.add(text_field[row][7],gridBagConstraints);

        text_field[row][7].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[row][8] = new JTextField("0.00");
        text_field[row][8].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.013;
        gridBagConstraints.gridx=88;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
         text_field[row][8].addFocusListener(this);
        
        text_field[row][8].setText(rs2.getString("sale_disc_amnt"));
        gb.add(text_field[row][8],gridBagConstraints);

        text_field[row][8].setHorizontalAlignment(SwingConstants.RIGHT);
        
        
        text_field[row][9] = new JTextField("0.00");
        text_field[row][9].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][9].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=99;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
         text_field[row][9].addFocusListener(this);
        
        text_field[row][9].setText(rs2.getString("sale_total"));
        gb.add(text_field[row][9],gridBagConstraints);

        text_field[row][9].setHorizontalAlignment(SwingConstants.RIGHT);


        row++;
        
            
       //end of gridbag fill              
                     
            
                 
                  gb.revalidate();
                  gb.repaint();
                 
                  jPanel7.add(gb, BorderLayout.NORTH);
                  
                 }
           
            rowfinal = row;    
           
        
    }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
          
      }
     
     
     
     
     
     
     
     
  
     public void search()
    {
       search_txt.addKeyListener(new java.awt.event.KeyAdapter()

       {

        public void keyReleased(java.awt.event.KeyEvent e)

        {
        String s1=search_txt.getText();
        String s3=s1;
     
        try{
        
        Connection con = Database.getConnection();
        Statement ps =con.createStatement();
        ResultSet rs=ps.executeQuery("SELECT sale_inv_no as SALES_INVOICE from sale_table1 where sale_inv_no like '"+s3+"%'"); 
           

        product_table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));

        }catch (SQLException e1){
        System.out.println("Sql Exception" + e1.toString());
        }
        
                
        }
     });
    }
     
     
     
      public void initialise()
         {
//            table1.setRowHeight(25);
//            table1.getModel().addTableModelListener(new TableModelListener()
//        
//                {
//                  public void tableChanged (TableModelEvent e)
//                {
//		  double gtot=0.0d;
//            int n1=table1.getRowCount();
//            System.out.println(n1);
//            for (int i =0; i<=n1-1; i++)
//            {
//                if ((table1.getValueAt(i, 9)) !=null)
//            {
//                    String s1 = (String)table1.getValueAt(i, 9);
//                    double d1=Double.parseDouble(s1);
//                    System.out.println(s1);
//                    
//                    gtot=gtot+d1;
//                    System.out.println(gtot);
//                  
//            }
//                String s4=Double.toString(gtot);
//                    gross_total.setText(s4);
//            }
//            
//                }
//                }
//          );

         }

     public void cell_caculate()
     {
//          
//      table1.getModel().addTableModelListener(new TableModelListener()
//        
//                {
//                  public void tableChanged (TableModelEvent e)
//                {
//                  int n=table1.getRowCount();
//                  System.out.println(n);
//                  for (int j = 0; j<=n-1; j++)
//                    {
//                        if (((table1.getValueAt(j, 2)) !=null) && (table1.getValueAt(j, 3)) !=null)
//                        {
////                            String q1 = table1.getValueAt(j, 2).toString();
////                            
////                            double q = Double.parseDouble(q1);
//                            double q = (double) table1.getValueAt(j, 2);
//                            System.out.println(q);
//                            //double q1 = Double.parseDouble(q);
//                            double r = (double) table1.getValueAt(j, 3);
//                            System.out.println(r);
//                            // double r1 = Double.parseDouble(r);
//                            double gtotal=0.0d;
//                            double gtotal1=0.0d;
//                            double tax_amnt=0.0d;
//                            double disc_amnt=0.0d;
//                            double tot =  (q*r);
//                          // String tot1 = Double.toString(tot);
//                            System.out.println(tot);
//                            //System.out.flush();
//                           if (table1.getValueAt(j, 4) == null)
//                                {
//                               table1.setValueAt(tot, j, 4);
//                                }
//                           if (table1.getValueAt(j, 5) != null)
//                                {
//                                double tax = (Double)table1.getValueAt(j, 5);
//                                tax_amnt= (tot*tax)/100;
//                                
//                                if(table1.getValueAt(j, 6) == null)
//                                    {
//                                     System.out.println(tax_amnt);
//                                     table1.setValueAt(tax_amnt, j, 6);
//                                    }
//                                }
//                           if (table1.getValueAt(j, 7) != null) 
//                                {
//                                double disc = (Double)table1.getValueAt(j, 7);
//                                disc_amnt= (tot*disc)/100;
//                                
//                                if(table1.getValueAt(j, 8) == null)
//                                {
//                                  System.out.println(disc_amnt);
//                                  table1.setValueAt(disc_amnt, j, 8);
//                                }
//                                  
//                                }
//                           
//          
//                           if (table1.getValueAt(j, 8) != null&&table1.getValueAt(j, 6) != null&&table1.getValueAt(j, 4) != null&&table1.getValueAt(j, 9) == null)
//                           {
//                                    
//                                 gtotal= tax_amnt  + tot - disc_amnt;
//                                 
//                                 System.out.println(gtotal);
//                                 String gt=Double.toString(gtotal);
//                                     
//                                 //System.out.println(gtotal1);
//                                 table1.setValueAt(gt, j, 9);
//                                  
//                            }
//                         }
//                    }
//                }
//               }
//            );
     }
     
     
       
    // for Item combo filling in grid table
    
    
      public void fill_combo1(JComboBox jr)
    {
    try{
        
          
               
               Connection con = Database.getConnection();
            

//            //Adding Items to Unit in Table
//            Statement ps3 = con.createStatement();
//            ResultSet rs3 = ps3.executeQuery("select distinct u_name from unit order by u_id");
//            
//            
//               while(rs3.next())
//              {
//                  String name3=rs3.getString("u_name");
//                  jr.addItem(name3);
//              }   
               
            //Adding Products to Item in Table
            Statement ps4 = con.createStatement();
            ResultSet rs4 = ps4.executeQuery("select distinct product_name from product order by p_id");
            
            
               while(rs4.next())
              {
                  String name4=rs4.getString("product_name");
                  jr.addItem(name4);
              }    
               
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
    
    }
      
      
      // for unit combo filling in grid table
    
    
       public void fill_combo2( JComboBox add)
    {
      try{
        
            Connection con = Database.getConnection();           
            // Adding Items to Party Ledger
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("select distinct u_name from unit");            
               while(rs.next())
              {
                  String name=rs.getString("u_name");
                  add.addItem(name);
              }         
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
          
    
    }
       
                // Grid Table Calculation
           
    public  void calculation_total()
 {
          
       
     Double a,b,c,d,e = 0.0,f=0.0;
     DecimalFormat df = new DecimalFormat("0.00");
     //LOOP for traversing
     for(int i=1;i<rowfinal;i++){
  
            if(text_field[i][2].getText() != "" )
            {
                a =( (Double.parseDouble(text_field[i][2].getText())) * Double.parseDouble(text_field[i][3].getText()));
               String amount= df.format(a);
               text_field[i][4].setText(amount);              
            }

            if(text_field[i][4].getText() != "" && text_field[i][5].getText()!= ""  )
            {
               b =(Double.parseDouble(text_field[i][4].getText()) * Double.parseDouble(text_field[i][5].getText()))/100;
               String taxable_amount= df.format(b);
               text_field[i][6].setText(taxable_amount);               
            }
            if(text_field[i][4].getText() != "" && text_field[i][7].getText()!= ""  )
            {
               c = ((Double.parseDouble(text_field[i][4].getText())*Double.parseDouble(text_field[i][7].getText()))/100);
               String discount_amount= df.format(c);
               text_field[i][8].setText(discount_amount);
            }
            
            if(text_field[i][2].getText() != ""){
               d = (Double.parseDouble(text_field[i][4].getText())+Double.parseDouble(text_field[i][6].getText()) -Double.parseDouble(text_field[i][8].getText()));
                String total_amount= df.format(d);
                text_field[i][9].setText(total_amount);
            }
            if(text_field[i][9].getText() != ""){
                e = e + Double.parseDouble(text_field[i][9].getText());
                String net_total_amount= df.format(e);
                gross_total.setText(net_total_amount);
            }            
     }
     }
    
    // Table Validation
    
     public void valid_table()
     {
         valid_check=0;
       for(int i=1;i<row;i++){

     if(text_field[i][2].getText().matches("0.0") || text_field[i][3].getText().matches("0.0")){
        System.out.println(text_field[i][4].getText());
          text_field[i][2].setBorder(BorderFactory.createLineBorder(Color.red));
          text_field[i][3].setBorder(BorderFactory.createLineBorder(Color.red));
         
          //text_field[i][4].setBorder(BorderFactory.createLineBorder(Color.red));
//        text_field[i][2].setBackground(Color.RED);
//        text_field[i][3].setBackground(Color.red);
        //text_field[i][4].setBackground(Color.RED);
        
        valid_check=1;
                      
     }
     else{
          text_field[i][2].setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
          text_field[i][3].setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
         
//        text_field[i][2].setBackground(Color.WHITE);
//        text_field[i][3].setBackground(Color.WHITE);
       // text_field[i][4].setBackground(Color.WHITE);
     }
     
}
    
     }
       
       
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane1 = new javax.swing.JOptionPane();
        jopt1 = new javax.swing.JOptionPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        save = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        invoice_no_txt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        party_combo = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        sale_combo = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        godown_combo = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        date_txt = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        curbalnc_txt = new numeric.textField.NumericTextField();
        gross_total = new numeric.textField.NumericTextField();
        challan_combox = new com.jidesoft.swing.AutoCompletionComboBox();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        sale_narration = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        jPanel7 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        search_txt = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        product_table = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        create_date = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        update_date = new javax.swing.JTextField();

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 250));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Normal Sale Edit/Delete");

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        save.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save.setText("Save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        jButton5.setText("Delete");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        jButton6.setText("Clear");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5)
                    .addComponent(save, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton5, jButton6, save});

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(save)
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addGap(18, 18, 18)
                .addComponent(jButton6)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton5, jButton6, save});

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        jLabel3.setForeground(new java.awt.Color(0, 0, 250));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Invoice No:");

        invoice_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        invoice_no_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                invoice_no_txtFocusLost(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(0, 0, 250));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Party's Name:");

        party_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        party_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                party_comboFocusLost(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(0, 0, 250));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Current Balance:");

        jLabel6.setForeground(new java.awt.Color(0, 0, 250));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Sale Ledger:");

        sale_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        sale_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                sale_comboFocusLost(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(0, 0, 250));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Godown Name:");

        godown_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        godown_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                godown_comboFocusLost(evt);
            }
        });

        jLabel8.setForeground(new java.awt.Color(0, 0, 250));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Date:");

        date_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                date_txtFocusLost(evt);
            }
        });

        jLabel1.setForeground(java.awt.Color.blue);
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Total Amount:");

        jLabel9.setText("Enter Invoice No!");

        jLabel10.setText("Select Party Name!");

        jLabel11.setText("Enter Current Balance!");

        jLabel12.setText("Select Sale Ledger!");

        jLabel13.setText("Select Godown Name!");

        jLabel14.setText("Enter Valid Date!");

        jLabel15.setText("Enter Valid Amount!");

        curbalnc_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setText("numericTextField1");
        curbalnc_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                curbalnc_txtFocusLost(evt);
            }
        });

        gross_total.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        gross_total.setText("numericTextField1");
        gross_total.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                gross_totalFocusLost(evt);
            }
        });

        challan_combox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "----select---" }));
        challan_combox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                challan_comboxActionPerformed(evt);
            }
        });

        jLabel16.setForeground(new java.awt.Color(0, 0, 250));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Challan No.:");

        jLabel17.setForeground(new java.awt.Color(0, 0, 250));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Narration:");

        sale_narration.setColumns(20);
        sale_narration.setRows(5);
        jScrollPane4.setViewportView(sale_narration);

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Item", "Unit", "Quantity", "Rate", "Amount", "Tax", "Taxable Amt", "Discount", "Discount Amt", "Total", ""
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                true, true, true, true, true, true, true, true, true, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(table1);
        table1.getColumn("Unit").setCellEditor(new DefaultCellEditor(unit_combox));
        table1.getColumn("Item").setCellEditor(new DefaultCellEditor(item_combox));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 191, Short.MAX_VALUE)
        );

        jScrollPane6.setViewportView(jPanel7);

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rows", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        jButton8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/add-2-icon.png"))); // NOI18N
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Action-remove-icon.png"))); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addComponent(jButton8)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(gross_total, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 561, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator1)
                            .addComponent(jSeparator2)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(48, 48, 48)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(party_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(invoice_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(sale_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(godown_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel13)
                                    .addComponent(curbalnc_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 123, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(date_txt)
                            .addComponent(jLabel14)
                            .addComponent(challan_combox, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(jScrollPane4))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel3))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(invoice_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(date_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel14))))
                .addGap(12, 12, 12)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(party_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(challan_combox, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel16)))
                .addGap(8, 8, 8)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(curbalnc_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addGap(2, 2, 2)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sale_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addGap(4, 4, 4)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(godown_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addGap(9, 9, 9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gross_total, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel15)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        search_txt.setToolTipText("");
        search_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_txtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(search_txt)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(search_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
        );

        product_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        product_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                product_tableMouseClicked(evt);
            }
        });
        product_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                product_tableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(product_table);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel18.setText("jLabel18");

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.cyan));

        jLabel26.setForeground(new java.awt.Color(51, 102, 0));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel26.setText("Created By:");

        jLabel27.setForeground(new java.awt.Color(51, 102, 0));
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel27.setText("Created Date:");

        jLabel28.setForeground(new java.awt.Color(51, 102, 0));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel28.setText("Updated By:");

        jLabel29.setForeground(new java.awt.Color(51, 102, 0));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel29.setText("Update Date:");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel18)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel2)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel18)
                        .addGap(47, 47, 47)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(761, 761, 761))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jScrollPane1)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
//  if(invoice_no_txt.getText().equals(""))
//     {
//           JOptionPane.showMessageDialog(this,"Select Invoice No!"); 
//     }
//
//   
//       
//  else {
//        invoice();
//    date();
//    party();
//    sale();
//    godown(); 
//         if(i==1&&j==1&&k==1&&l==1&&m==1&&x==0&&y==0)
//    {          
//        String invoice = jTextField1.getText();
//        DefaultTableModel y = (DefaultTableModel)table1.getModel();
//        int fr = y.getRowCount();
//        
//        if (invoice!="")
//      {  
//        try{
//
//           
//            
//             Connection con2 = Database.getConnection();
//             Connection con3 = Database.getConnection();
//             Statement ps5 =con2.createStatement(); 
//             Integer sx = Integer.parseInt(jTextField1.getText().toString());
//             
//                      Statement un = con2.createStatement();
//            ResultSet un1 = un.executeQuery("select sale_item,p_group from sale_table2,product where sale_table2.sale_inv_no='"+jTextField2.getText()+"' and sale_table2.sale_item=product.product_name");
//       while(un1.next()){
//           
//           
//            PreparedStatement ps9=con2.prepareStatement("DELETE FROM `"+un1.getString("p_group")+"` WHERE trans_id='"+jTextField2.getText()+"'");
//             ps9.executeUpdate();
//           
//           
//       }
//             
//             
//             
//             //Updating Sale Table 1
//             
//             PreparedStatement ps1=con2.prepareStatement("update sale_table1 set sale_inv='"+invoice_no_txt.getText()+"', sale_date='"+date_txt.getText()+"', sale_party_name='"+party_combo.getSelectedItem().toString()+"', sale_current_balance='"+curbalnc_txt.getText()+"', sale_ledger='"+sale_combo.getSelectedItem().toString()+"', sale_gd_name='"+godown_combo.getSelectedItem().toString()+"' where sale_inv='"+jTextField2.getText()+"'");
//             ps1.executeUpdate();
//             
//             Statement ps6 =con2.createStatement(); 
//             Statement ps7 =con2.createStatement(); 
//             
//             //Deleting All Sale details from Sale Table 2 and godwon_deatil
//             PreparedStatement ps9=con2.prepareStatement("DELETE FROM sale_table2 WHERE sale_inv_no='"+jTextField2.getText()+"'");
//             ps9.executeUpdate();
//              PreparedStatement ps90=con2.prepareStatement("DELETE FROM godown_detail WHERE invoice='"+jTextField2.getText()+"'");
//             ps90.executeUpdate();
//             //Inserting Details of Sale into Sale Table 2
//             int p=table1.getRowCount();
//             
//          for(int i=0;i<p;i++)
//         {
//          String item=table1.getValueAt(i,0).toString();
//          String unit=table1.getValueAt(i,1).toString();
//          String quantity=table1.getValueAt(i,2).toString();
//          String amount=table1.getValueAt(i,4).toString();
//          String rate=table1.getValueAt(i,3).toString();
//          String tax=table1.getValueAt(i,5).toString();
//          String tax_amnt=table1.getValueAt(i,6).toString();
//          String disc=table1.getValueAt(i,7).toString();
//          String disc_amnt=table1.getValueAt(i,8).toString();
//          String total=table1.getValueAt(i,9).toString();
//                
//          PreparedStatement ps10=con2.prepareStatement("insert into sale_table2 (sale_inv_no, sale_item, sale_quantity, sale_unit, sale_amount, sale_rate, sale_tax, sale_taxable_amnt, sale_disc, sale_disc_amnt, sale_total,date,party_ledger,type)values('"+invoice_no_txt.getText()+"','"+item+"','"+quantity+"','"+unit+"','"+amount+"','"+rate+"','"+tax+"','"+tax_amnt+"','"+disc+"','"+disc_amnt+"','"+total+"','"+date_txt.getText()+"','"+party_combo.getSelectedItem().toString()+"','SALE')");
//           
//            ps10.executeBatch();
//            ps10.executeUpdate();
//            
//         PreparedStatement gds=con2.prepareStatement("insert into godown_detail (gd_name_to, item, s_quantity, unit,invoice,type,date)values('"+godown_combo.getSelectedItem().toString()+"','"+item+"','"+quantity+"','"+unit+"','"+invoice_no_txt.getText()+"','SALE','"+date_txt.getText()+"')");
//
//            gds.executeBatch();
//            gds.executeUpdate();
//              Statement ps400 = con2.createStatement();
//            ResultSet rs40 = ps400.executeQuery("select p_group from product where product_name='"+item+"'");
//            
//            
//               if(rs40.next())
//              {
//                   name4=rs40.getString("p_group");
//                  item_combox.addItem(name4);
//               
//            
//               PreparedStatement it=con2.prepareStatement("insert into `"+name4+"` (p_name, inv_sale,trans_id)values('"+item+"','"+quantity+"','"+invoice_no_txt.getText()+"')");
//           
//            it.executeBatch();
//            it.executeUpdate();
//            
//              }   
//         } 
          
          
          
          
          
          
             //Updating Sale Table 2
//             for (int tabrow = 0; tabrow < fr; tabrow++)
//                {
//                    String s_inv_no = jTextField2.getText();
//                    System.out.println("*** Save Starts ***");
//                    System.out.println(s_inv_no);
//                    String s_item = table1.getValueAt(tabrow,0).toString();
//                    System.out.println(s_item);
//                    String s_unt = table1.getValueAt(tabrow,1).toString();
//                    System.out.println(s_unt);
//                    Double s_quant = (Double) table1.getValueAt(tabrow,2);
//                    System.out.println(s_quant);
//                    Double s_rt = (Double) table1.getValueAt(tabrow,3);
//                    System.out.println(s_rt);
//                    Double s_amnt = (Double) table1.getValueAt(tabrow,4);
//                    System.out.println(s_amnt);
//                    Double s_t = (Double) table1.getValueAt(tabrow,5);
//                    System.out.println(s_t);
//                    Double s_amt_tx = (Double) table1.getValueAt(tabrow,6);
//                    System.out.println(s_amt_tx);
//                    Double s_dsc = (Double) table1.getValueAt(tabrow,7);
//                    System.out.println(s_dsc);
//                    Double s_dsc_amt = (Double) table1.getValueAt(tabrow,8);
//                    System.out.println(s_dsc_amt);
//                    
//                    String s1 = (String)table1.getValueAt(tabrow, 9);
//                    double d1=Double.parseDouble(s1);
//                    System.out.println(d1);
//                    
//                    Integer s_id = (Integer) table1.getValueAt(tabrow,10);
//                    System.out.println(s_id);
//                    
//                    PreparedStatement ps10=con2.prepareStatement("update sale_table2 set sale_inv_no='"+s_inv_no+"', sale_item='"+s_item+"', sale_unit='"+s_unt+"', sale_quantity='"+s_quant+"', sale_rate='"+s_rt+"', sale_amount='"+s_amnt+"', sale_tax='"+s_t+"', sale_taxable_amnt='"+s_amt_tx+"', sale_disc='"+s_dsc+"', sale_disc_amnt='"+s_dsc_amt+"', sale_total='"+d1+"' where sale_id='"+s_id+"'");
//                    
//                    ps10.executeBatch();
//                    ps10.executeUpdate();
//                }
          
          
          
          
           
          
          
          
             
//             //Updating Sale Table 3
//             String gtt = gross_total.getText().toString();
//             Double gt = Double.parseDouble(gtt);
//             
//             String isrch = jTextField3.getText().toString();
//             Integer src3 = Integer.parseInt(isrch);
//             System.out.println("Update details of Sale ID for Sale Table 3:"+src3);
//             
//             PreparedStatement ps8=con3.prepareStatement("update sale_table3 set sale_inv_no='"+invoice_no_txt.getText()+"', sale_g_total='"+gt+"', sale_ledger='"+sale_combo.getSelectedItem().toString()+"' where sale_invoice_no='"+jTextField2.getText()+"'");
//             ps8.executeUpdate();
//              PreparedStatement ps88=con3.prepareStatement("update company_main_table set ledger='"+party_combo.getSelectedItem().toString()+"', credit='"+gt+"' where get_id='"+jTextField2.getText()+"' and debit='0'");
//             ps88.executeUpdate();
//             
//             PreparedStatement ps889=con3.prepareStatement("update company_main_table set ledger='"+sale_combo.getSelectedItem().toString()+"', debit='"+gt+"' where get_id='"+jTextField2.getText()+"' and credit='0'");
//             ps889.executeUpdate();
//             
//             
//             
//             
//             
//             
//        }catch (SQLException q){
//            System.out.println("Sql Exception" + q.toString());
//        }
//       
//        
//        jOptionPane1.showMessageDialog(this,"Sale Details Updated");
//        
//         invoice_no_txt.setText(null);
//        date_txt.setText(null);
//        party_combo.setSelectedIndex(0);
//        curbalnc_txt.setText(null);
//        sale_combo.setSelectedIndex(0);
//        godown_combo.setSelectedIndex(0);
//        gross_total.setText(null);
//        challan_combox.setSelectedItem(null);
//        sale_narration.setText(null);
//        
//        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//        date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//        sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//        gross_total.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//
//        jLabel9.setVisible(false);
//        jLabel14.setVisible(false);
//        jLabel10.setVisible(false);
//        jLabel11.setVisible(false);
//        jLabel12.setVisible(false);
//        jLabel13.setVisible(false);
//        
//        
//        
//         fill_combo();
//           update_table();
//           
//          
//           //TABLE RESET
//           int p1=table1.getRowCount();
//        for(int i=0;i<p1;i++)
//            {
//                String a1=null;
//                String a2=null;
//                Double a3=null;
//                Double a4=null;
//                Double a5=null;
//                Double a6=null;
//                Double a7=null;
//                Double a8=null;
//                Double a9=null;
//                Double a10=null;
//                String a11=null;
//        table1.setValueAt(a1, i, 0);
//        table1.setValueAt(a2, i, 1);
//        table1.setValueAt(a3, i, 2);
//        table1.setValueAt(a4, i, 3);
//        table1.setValueAt(a5, i, 4);
//        table1.setValueAt(a6, i, 5);
//        table1.setValueAt(a7, i, 6);
//        table1.setValueAt(a8, i, 7);
//        table1.setValueAt(a9, i, 8);
//        table1.setValueAt(a10, i,9);
//        table1.setValueAt(a11, i, 10);
//        }
//      }
//      else
//      {
//      jOptionPane1.showMessageDialog(this,"Select a valid Sale Invoice");
//      }
//        jTextField1.setText(null);
//        search_txt.setText(null);
//        fill_combo();
//        update_table();
//    }
//  }
        
        
        
        
         if(invoice_no_txt.getText().equals(""))
     {
           JOptionPane.showMessageDialog(this,"Select Invoice No!"); 
     }
         else
         {
             invoice();
             date();
             party();
             sale();
             godown();
             
             if(i==1&&j==1&&k==1&&l==1&&m==1&&x==0&&y==0)
                     try{

                
                Connection con2 = Database.getConnection();
                Connection con3 = Database.getConnection();
                Statement ps5 =con2.createStatement();
                //Integer sx = Integer.parseInt(jTextField1.getText().toString());
                
                
                //Updating Purchase Table 1
                PreparedStatement ps1=con2.prepareStatement("update sale_table1 set sale_inv='"+invoice_no_txt.getText()+"', sale_date='"+date_txt.getText()+"', sale_party_name='"+party_combo.getSelectedItem().toString()+"', sale_current_balance='"+curbalnc_txt.getText()+"', sale_ledger='"+sale_combo.getSelectedItem().toString()+"', sale_gd_name='"+godown_combo.getSelectedItem().toString()+"' where sale_inv='"+jTextField2.getText()+"'");
                ps1.executeUpdate();
                
                log_table.table_update("sale_table1",jLabel18.getText(),invoice_no_txt.getText());

                Statement ps6 =con2.createStatement();
                Statement ps7 =con2.createStatement();
               
                 //Deleting All Sale details from Sale Table 2
                PreparedStatement ps9=con2.prepareStatement("DELETE FROM sale_table2 WHERE sale_inv_no='"+jTextField2.getText()+"'");
                ps9.executeUpdate();
                
                
                   // Upadating Purchase Table 2
                    
                     for(int i=1;i<row;i++)
                {

                    text_field[i][4].setBackground(Color.white);
                    text_field[i][3].setBackground(Color.white);
                    text_field[i][2].setBackground(Color.WHITE);

                    String item=jComboBox1[i].getSelectedItem().toString();
                    String unit=jComboBox2[i].getSelectedItem().toString();
                    String quantity=text_field[i][2].getText();
                    String amount=text_field[i][4].getText();
                    String rate=text_field[i][3].getText();
                    String tax=text_field[i][5].getText();
                    String tax_amnt=text_field[i][6].getText();
                    String disc=text_field[i][7].getText();
                    String disc_amnt=text_field[i][8].getText();
                    String total=text_field[i][9].getText();
                    
                    double amnt=Double.parseDouble(amount);
                    double t_disc=Double.parseDouble(disc_amnt);
                    double clo= amnt - t_disc;
                    String closing_amnt=Double.toString(clo);
                    PreparedStatement ps10=con2.prepareStatement("insert into sale_table2 (sale_inv_no, sale_item, sale_quantity, sale_unit, sale_amount, sale_rate, sale_tax, sale_taxable_amnt, sale_disc, sale_disc_amnt, sale_total,date,party_ledger,type)values('"+invoice_no_txt.getText()+"','"+item+"','"+quantity+"','"+unit+"','"+amount+"','"+rate+"','"+tax+"','"+tax_amnt+"','"+disc+"','"+disc_amnt+"','"+total+"','"+date_txt.getText()+"','"+party_combo.getSelectedItem().toString()+"','SALE')");
                    ps10.executeBatch();
                    ps10.executeUpdate();
                    PreparedStatement gds=con2.prepareStatement("insert into godown_detail (gd_name_to, item, s_quantity, unit,invoice,type,date)values('"+godown_combo.getSelectedItem().toString()+"','"+item+"','"+quantity+"','"+unit+"','"+invoice_no_txt.getText()+"','SALE','"+date_txt.getText()+"')");

                gds.executeBatch();
                gds.executeUpdate();
                 Statement ps400 = con2.createStatement();
               ResultSet rs40 = ps400.executeQuery("select p_group from product where product_name='"+item+"'");

                if(rs40.next())
               {
                   name4=rs40.getString("p_group");
                    item_combox.addItem(name4);

                    PreparedStatement it=con2.prepareStatement("insert into `"+name4+"` (p_name, inv_sale,trans_id)values('"+item+"','"+quantity+"','"+invoice_no_txt.getText()+"')");

                    it.executeBatch();
                    it.executeUpdate();

                }                    


//imran
                    

//                    PreparedStatement ps11=con2.prepareStatement("insert into purchase_table2 (purchase_inv, purchase_item, purchase_quantity, purchase_unit, purchase_amount, purchase_rate, purchase_tax, purchase_taxable_amnt, purchase_disc, purchase_disc_amnt, purchase_total)values('"+invoice_no_txt.getText()+"','"+item+"','"+quantity+"','"+unit+"','"+amount+"','"+rate+"','"+tax+"','"+tax_amnt+"','"+disc+"','"+disc_amnt+"','"+total+"')");
//                    ps11.executeBatch();
//                    ps11.executeUpdate();
//
//                    PreparedStatement gds=con2.prepareStatement("insert into godown_detail (gd_name_to, item, p_quantity, unit,invoice)values('"+godown_combo.getSelectedItem().toString()+"','"+item+"','"+quantity+"','"+unit+"','"+invoice_no_txt.getText()+"')");
//                    gds.executeBatch();
//                    gds.executeUpdate();
//                    
//                    //Updating Purchase Table 3
//                    String gtt = gross_total.getText().toString();
//                    Double gt = Double.parseDouble(gtt);
//
//                    String isrch = jTextField3.getText().toString();
//                    Integer src3 = Integer.parseInt(isrch);
//                    System.out.println("Update details of Purchase ID for Purchase Table 3:"+src3);


                }
                
                 PreparedStatement ps8=con3.prepareStatement("update sale_table3 set sale_inv_no='"+invoice_no_txt.getText()+"', sale_g_total='"+gross_total+"', sale_ledger='"+sale_combo.getSelectedItem().toString()+"' where sale_invoice_no='"+jTextField2.getText()+"'");
                ps8.executeUpdate();
               invoice_no_txt.setText(null);
        date_txt.setText(null);
        party_combo.setSelectedIndex(0);
        curbalnc_txt.setText(null);
        sale_combo.setSelectedIndex(0);
        godown_combo.setSelectedIndex(0);
        gross_total.setText(null);
        challan_combox.setSelectedItem(null);
        sale_narration.setText(null);
        create_user.setText(null);
           create_date.setText(null);
           update_user.setText(null);
           update_date.setText(null);
        
        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        gross_total.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel9.setVisible(false);
        jLabel14.setVisible(false);
        jLabel10.setVisible(false);
        jLabel11.setVisible(false);
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
                    
                    
               jOptionPane1.showMessageDialog(this,"Sale Details Updated");
               con2.close();
               con3.close();
                 }catch (SQLException q){
                    System.out.println("Sql Exception" + q.toString());
                }

            
                  
         }
                gb.removeAll();
//        gb.revalidate();
//     gb.repaint();
          row=0;
    fill_gridpanel();
       gb.revalidate();
     gb.repaint();
    }//GEN-LAST:event_saveActionPerformed

    private void date_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_date_txtFocusLost
      if(date_txt.getText().length()==0)
        {
                 date_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);
        }
        else
        {
            String content = date_txt.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel14.setEnabled(false);  
            jLabel14.setVisible(false);
            j=1;
            if(!matchFound)

            {

                 date_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);

            }
        }
    }//GEN-LAST:event_date_txtFocusLost

    private void search_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_txtActionPerformed
      
    }//GEN-LAST:event_search_txtActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
//        DefaultTableModel y = (DefaultTableModel)table1.getModel();
//
//        int a=y.getRowCount()- 1;
//
//        y.removeRow(a);

       if (rowfinal > 1)
        {
            gb.remove(text_field[rowfinal-1][2]);
            gb.remove(text_field[rowfinal-1][3]);
            gb.remove(text_field[rowfinal-1][4]);
            gb.remove(text_field[rowfinal-1][5]);
            gb.remove(text_field[rowfinal-1][6]);
            gb.remove(text_field[rowfinal-1][7]);
            gb.remove(text_field[rowfinal-1][8]);
            gb.remove(text_field[rowfinal-1][9]);
            gb.remove(jComboBox1[rowfinal-1]);
            gb.remove(jComboBox2[rowfinal-1]);
            
            rowfinal--;
            
            gb.revalidate();
            gb.repaint();

        }
        else
        {
            System.out.println("No Row to delete");
        }    
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
//        DefaultTableModel y = (DefaultTableModel)table1.getModel();
//
//        Vector <String> r = new Vector <String>();
//        y.addRow(r);
        
      if(invoice_no_txt.getText().equals(""))
     {
           JOptionPane.showMessageDialog(this,"Select Invoice No!"); 
     }
      
      else
      {
          
      
        
        jComboBox1[rowfinal]= new JComboBox();

        jComboBox1[rowfinal].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
        gridBagConstraints.weightx=0.24;
        gridBagConstraints.weighty=0.0;
        gridBagConstraints.gridx=0;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipady = 7;

        fill_combo1(jComboBox1[rowfinal]);
       // jComboBox1[rowfinal].setSelectedItem(null);
        
        
        gb.add(jComboBox1[rowfinal],gridBagConstraints);

        jComboBox2[rowfinal]= new JComboBox();
        jComboBox2[rowfinal].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=11;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipady = 7;
        fill_combo2(jComboBox2[rowfinal]);
        gb.add(jComboBox2[rowfinal],gridBagConstraints);

        //END IN 5 12-2014

        text_field[rowfinal][2] = new JTextField("0.00");
    
        //text_field[rowfinal][2].setText(Double.toString(sqty));
        
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[rowfinal][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        //text_field[rowfinal][3].setFont(myfont);
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=22;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
         text_field[rowfinal][2].addFocusListener(this);

        //text_field[rowfinal][2].

        gb.add(text_field[rowfinal][2],gridBagConstraints);

        text_field[rowfinal][3] = new JTextField("0.00");
        text_field[rowfinal][3].setHorizontalAlignment(SwingConstants.RIGHT);

        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[rowfinal][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        //text_field[rowfinal][3].setFont(myfont);
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=33;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
         text_field[rowfinal][3].addFocusListener(this);

        gb.add(text_field[rowfinal][3],gridBagConstraints);

        text_field[rowfinal][3].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[rowfinal][4] = new JTextField("0.00");
        text_field[rowfinal][4].setHorizontalAlignment(SwingConstants.RIGHT);
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        //text_field[rowfinal][4].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        text_field[rowfinal][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=44;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
         text_field[rowfinal][4].addFocusListener(this);

        gb.add(text_field[rowfinal][4],gridBagConstraints);

        text_field[rowfinal][5] = new JTextField("0.00");
        text_field[rowfinal][5].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[rowfinal][5].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[rowfinal][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=55;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
         text_field[rowfinal][5].addFocusListener(this);

        gb.add(text_field[rowfinal][5],gridBagConstraints);

        text_field[rowfinal][5].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[rowfinal][6] = new JTextField("0.00");
        text_field[rowfinal][6].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[rowfinal][6].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[rowfinal][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.013;
        gridBagConstraints.gridx=66;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
         text_field[rowfinal][6].addFocusListener(this);

        gb.add(text_field[rowfinal][6],gridBagConstraints);

        text_field[rowfinal][6].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[rowfinal][7] = new JTextField("0.00");
        text_field[rowfinal][7].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[rowfinal][7].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[rowfinal][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=77;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
         text_field[rowfinal][7].addFocusListener(this);

        gb.add(text_field[rowfinal][7],gridBagConstraints);

        text_field[rowfinal][7].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[rowfinal][8] = new JTextField("0.00");
        text_field[rowfinal][8].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[rowfinal][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[rowfinal][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.013;
        gridBagConstraints.gridx=88;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
         text_field[rowfinal][8].addFocusListener(this);

        gb.add(text_field[rowfinal][8],gridBagConstraints);

        text_field[rowfinal][8].setHorizontalAlignment(SwingConstants.RIGHT);
        
        
        text_field[rowfinal][9] = new JTextField("0.00");
        text_field[rowfinal][9].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[rowfinal][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[rowfinal][9].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=99;
        gridBagConstraints.gridy=rowfinal;
        gridBagConstraints.gridwidth=10;
         text_field[rowfinal][9].addFocusListener(this);

        gb.add(text_field[rowfinal][9],gridBagConstraints);

        text_field[rowfinal][9].setHorizontalAlignment(SwingConstants.RIGHT);

        rowfinal++;
        
                  gb.revalidate();
                  gb.repaint();
                 
                  jPanel7.add(gb, BorderLayout.NORTH);
                  
                  }
            
    }//GEN-LAST:event_jButton8ActionPerformed

    private void product_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_product_tableMouseClicked
            //Deleting all rows from Table 1
//            DefaultTableModel y = (DefaultTableModel)table1.getModel();
//            int fr = y.getRowCount();
//            while (fr>=1)
//            {   
//            int a=y.getRowCount()- 1;
//            y.removeRow(a);
//            fr--;
//            }
//        
//        
//            int new1=product_table.getSelectedRow();
//            String table_click=(product_table.getModel().getValueAt(new1, 0).toString());
//            
//            try{
//         
//           
//           Connection con1 = Database.getConnection();
//           Statement ps1 =con1.createStatement();
//           Statement ps3 =con1.createStatement();                      
//           ResultSet rs1=ps1.executeQuery("SELECT * from sale_table1 where sale_inv_no='"+table_click+"' ");
//                      
//           while(rs1.next())
//                {
//                String  aa=rs1.getString("sale_id");
//                jTextField1.setText(aa);
//                
//                String a1=rs1.getString("sale_inv_no");
//                invoice_no_txt.setText(a1);
//                jTextField2.setText(a1);
//
//                String a2=rs1.getString("sale_date");
//                date_txt.setText("");
//                date_txt.setText(a2);
//                                
//                String a3=rs1.getString("sale_party_name");
//                party_combo.setSelectedItem(a3);
//                
//                String a4=rs1.getString("sale_current_balance");
//                curbalnc_txt.setText(a4);
//                
//                String a5=rs1.getString("sale_ledger");
//                sale_combo.setSelectedItem(a5);
//                
//                String a6=rs1.getString("sale_gd_name");
//                godown_combo.setSelectedItem(a6);
//                
//                String a7=rs1.getString("sale_challan_no");
//                challan_combox.setSelectedItem(a7);
//                
//                String narration=rs1.getString("sale_narration");
//                sale_narration.setText(narration);
//                
//                
//                // Code to Save & Edit Sale Table 3 with value from JTextField 3
//            String sch3 = jTextField2.getText().toString();
//            System.out.println(sch3);
//            Integer srch3 = Integer.parseInt(sch3);
//            System.out.println("Invoice No.:"+srch3);
//            
//            ResultSet rs3=ps3.executeQuery("SELECT * from sale_table3 where sale_inv_no='"+srch3+"' ");
//            while (rs3.next())
//            {
//                String ax = rs3.getString("sale_id");
//                jTextField3.setText(ax);
//            }
//
//                
//                
//                }
//           
//           Statement ps2 =con1.createStatement();
//           ResultSet rs2=ps2.executeQuery("SELECT * from sale_table2 where sale_inv_no='"+table_click+"' ");
//           //sale_item AS Item, sale_unit AS Unit, sale_quantity AS Quantity, sale_rate AS Rate, sale_amount AS Amount, sale_tax AS Amount, sale_taxable_amnt AS Taxable_Amt, sale_disc AS Discount, sale_disc_amnt AS Discount_Amt, sale_total AS Total
//           //table1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs2));
//           
//           int li_row=0;
//           int rw = 0;
//           Vector <String> r[] = (Vector <String> []) new Vector[1000];
//           
//           
//           table1.getColumnModel().getColumn(10).setMinWidth(0);
//           table1.getColumnModel().getColumn(10).setMaxWidth(0);
//           table1.getColumnModel().getColumn(10).setResizable(false);
//           
//           while(rs2.next())
//                 {
//                 y.addRow(r[rw]); 
//                    
//                 table1.setValueAt(rs2.getString("sale_item"), li_row, 0);
//                 table1.setValueAt(rs2.getString("sale_unit"), li_row, 1);
//                 
//                 Double sqty = Double.parseDouble(rs2.getString("sale_quantity"));
//                 table1.setValueAt(sqty, li_row, 2);
//                 
//                 Double srt = Double.parseDouble(rs2.getString("sale_rate"));
//                 table1.setValueAt(srt, li_row, 3);
//                 
//                 Double samnt = Double.parseDouble(rs2.getString("sale_amount"));
//                 table1.setValueAt(samnt, li_row, 4);
//                 
//                 Double stax = Double.parseDouble(rs2.getString("sale_tax"));
//                 table1.setValueAt(stax, li_row, 5);
//                 
//                 Double stxamnt = Double.parseDouble(rs2.getString("sale_taxable_amnt"));
//                 table1.setValueAt(stxamnt, li_row, 6);
//                 
//                 Double sdisc = Double.parseDouble(rs2.getString("sale_disc"));
//                 table1.setValueAt(sdisc, li_row, 7);
//                 
//                 Double sdamnt = Double.parseDouble(rs2.getString("sale_disc_amnt"));
//                 table1.setValueAt(sdamnt, li_row, 8);
//                 
//                 table1.setValueAt(rs2.getString("sale_total"), li_row, 9);
//                 
//                 Integer said = Integer.parseInt(rs2.getString("sale_id"));
//                 table1.setValueAt(said, li_row, 10);
//                 
//                 rw++;
//                 li_row++;
//                 }
//           
//           
//          //jComboBox1.removeAll();
//        }catch (SQLException q){
//        System.out.println("Sql Exception" + q.toString());
//        }
//        
//            
            
            
    }//GEN-LAST:event_product_tableMouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
      if(invoice_no_txt.getText().equals(""))
     {
           jopt1.showMessageDialog(this,"Select An Invoice!"); 
     }
      else{
        try{
         
           
           Connection conn1 = Database.getConnection();
           
            PreparedStatement del=conn1.prepareStatement("DELETE FROM sale_table2 WHERE sale_inv_no='"+jTextField2.getText()+"'");
             del.executeUpdate();
              PreparedStatement del1=conn1.prepareStatement("DELETE FROM godown_detail WHERE invoice='"+jTextField2.getText()+"'");
             del1.executeUpdate();
              PreparedStatement del2=conn1.prepareStatement("DELETE FROM sale_table1 WHERE sale_inv='"+jTextField2.getText()+"'");
             del2.executeUpdate();
             
             log_table.table_delete("sale_table1",jLabel18.getText());
            
              PreparedStatement del4=conn1.prepareStatement("DELETE FROM sale_table3 WHERE sale_inv_no='"+jTextField2.getText()+"'");
             del4.executeUpdate();
              PreparedStatement del5=conn1.prepareStatement("DELETE FROM company_main_table WHERE get_id='"+jTextField2.getText()+"'");
             del5.executeUpdate();
             
             
               Statement under = conn1.createStatement();
            ResultSet under1 = under.executeQuery("select sale_item,p_group from sale_table2,product where sale_table2.sale_inv_no='"+jTextField2.getText()+"' and sale_table2.sale_item=product_name");
       while(under1.next()){
           
           
            PreparedStatement del3=conn1.prepareStatement("DELETE FROM `"+under1.getString("p_group")+"` WHERE trans_id='"+jTextField2.getText()+"'");
             del3.executeUpdate();
           
            jOptionPane1.showMessageDialog(this,"Sale Details Deleted");
       }
             
            conn1.close();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        
         fill_combo();
           update_table();
           invoice_no_txt.setText(null);
        date_txt.setText(null);
        party_combo.setSelectedIndex(0);
        curbalnc_txt.setText(null);
        sale_combo.setSelectedIndex(0);
        godown_combo.setSelectedIndex(0);
        gross_total.setText(null);
        challan_combox.setSelectedItem(null);
        sale_narration.setText(null);
        
        create_user.setText(null);
           create_date.setText(null);
           update_user.setText(null);
           update_date.setText(null);
        
        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        gross_total.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel9.setVisible(false);
        jLabel14.setVisible(false);
        jLabel10.setVisible(false);
        jLabel11.setVisible(false);
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
        
        
               gb.removeAll();
//        gb.revalidate();
//     gb.repaint();
          row=0;
    fill_gridpanel();
       gb.revalidate();
     gb.repaint();
           
          
           //TABLE RESET
//           int p1=table1.getRowCount();
//        for(int i=0;i<p1;i++)
//            {
//                String a1=null;
//                String a2=null;
//                Double a3=null;
//                Double a4=null;
//                Double a5=null;
//                Double a6=null;
//                Double a7=null;
//                Double a8=null;
//                Double a9=null;
//                Double a10=null;
//                String a11=null;
//        table1.setValueAt(a1, i, 0);
//        table1.setValueAt(a2, i, 1);
//        table1.setValueAt(a3, i, 2);
//        table1.setValueAt(a4, i, 3);
//        table1.setValueAt(a5, i, 4);
//        table1.setValueAt(a6, i, 5);
//        table1.setValueAt(a7, i, 6);
//        table1.setValueAt(a8, i, 7);
//        table1.setValueAt(a9, i, 8);
//        table1.setValueAt(a10, i,9);
//        table1.setValueAt(a11, i, 10);
//        }
    }//GEN-LAST:event_jButton5ActionPerformed
    }
    private void invoice_no_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_invoice_no_txtFocusLost
      if(invoice_no_txt.getText().length()==0)
      {
          invoice_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel9.setEnabled(true);
          jLabel9.setForeground(Color.red);
          jLabel9.setVisible(true);
             
      }  
      else
      {
           invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel9.setEnabled(false);  
           jLabel9.setVisible(false);
           i=1;
          
      }
    }//GEN-LAST:event_invoice_no_txtFocusLost

    private void party_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_party_comboFocusLost
     if(party_combo.getSelectedItem().equals(""))
      {
          party_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel10.setEnabled(true);
          jLabel10.setForeground(Color.red);
          jLabel10.setVisible(true);
             
      }  
      else
      {
           party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel10.setEnabled(false);  
           jLabel10.setVisible(false);
           k=1;
      }
    }//GEN-LAST:event_party_comboFocusLost

    private void sale_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_sale_comboFocusLost
      if(sale_combo.getSelectedItem().equals(""))
      {
          sale_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel12.setEnabled(true);
          jLabel12.setForeground(Color.red);
          jLabel12.setVisible(true);
             
      }  
      else
      {
           sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel12.setEnabled(false);  
           jLabel12.setVisible(false);
           l=1;
      }
        
    }//GEN-LAST:event_sale_comboFocusLost

    private void godown_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_godown_comboFocusLost
      if(godown_combo.getSelectedItem().equals(""))
      {
          godown_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
             
      }  
      else
      {
           godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           m=1;
      }
    }//GEN-LAST:event_godown_comboFocusLost

    private void curbalnc_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_curbalnc_txtFocusLost
      if(curbalnc_txt.getText().length()==0)
        {
              curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              jLabel11.setEnabled(false);  
              jLabel11.setVisible(false);
              x=0;
        }
        else
        {
            String content = curbalnc_txt.getText();
            Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel11.setEnabled(false);  
            jLabel11.setVisible(false);
            x=0;
            if(!matchFound)
            {
                x=1;
                curbalnc_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel11.setEnabled(true);
                jLabel11.setForeground(Color.red);
                jLabel11.setVisible(true);

            }
        }
    }//GEN-LAST:event_curbalnc_txtFocusLost

    private void gross_totalFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_gross_totalFocusLost
      if(gross_total.getText().length()==0)
        {
              gross_total.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              jLabel15.setEnabled(false);  
              jLabel15.setVisible(false);
              y=0;
        }
        else
        {
            String content = gross_total.getText();
            Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            gross_total.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel15.setEnabled(false);  
            jLabel15.setVisible(false);
            y=0;
            if(!matchFound)
            {
                y=1;
                gross_total.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel15.setEnabled(true);
                jLabel15.setForeground(Color.red);
                jLabel15.setVisible(true);

            }
        }
    }//GEN-LAST:event_gross_totalFocusLost

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        invoice_no_txt.setText(null);
        date_txt.setText(null);
        party_combo.setSelectedIndex(0);
        curbalnc_txt.setText(null);
        sale_combo.setSelectedIndex(0);
        godown_combo.setSelectedIndex(0);
        gross_total.setText(null);
        challan_combox.setSelectedItem(null);
        sale_narration.setText(null);
        create_user.setText(null);
           create_date.setText(null);
           update_user.setText(null);
           update_date.setText(null);
        
        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        gross_total.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel9.setVisible(false);
        jLabel14.setVisible(false);
        jLabel10.setVisible(false);
        jLabel11.setVisible(false);
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
        
        
        
         fill_combo();
           update_table();
                  gb.removeAll();
//        gb.revalidate();
//     gb.repaint();
          row=0;
    fill_gridpanel();
       gb.revalidate();
     gb.repaint();
           
          
           //TABLE RESET
        //   int p1=table1.getRowCount();
       // for(int i=0;i<p1;i++)
     //       {
//                String a1=null;
//                String a2=null;
//                Double a3=null;
//                Double a4=null;
//                Double a5=null;
//                Double a6=null;
//                Double a7=null;
//                Double a8=null;
//                Double a9=null;
//                Double a10=null;
//                String a11=null;
//        table1.setValueAt(a1, i, 0);
//        table1.setValueAt(a2, i, 1);
//        table1.setValueAt(a3, i, 2);
//        table1.setValueAt(a4, i, 3);
//        table1.setValueAt(a5, i, 4);
//        table1.setValueAt(a6, i, 5);
//        table1.setValueAt(a7, i, 6);
//        table1.setValueAt(a8, i, 7);
//        table1.setValueAt(a9, i, 8);
//        table1.setValueAt(a10, i,9);
//        table1.setValueAt(a11, i, 10);
     //   }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void challan_comboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_challan_comboxActionPerformed
        // TODO add your handling code here:
//          DefaultTableModel y1 = (DefaultTableModel)table1.getModel();
//            int fr = y1.getRowCount();
//            while (fr>=1)
//            {   
//            int a=y1.getRowCount()- 1;
//            y1.removeRow(a);
//            fr--;
//            }
//         try{
//         
//            Connection con1 = Database.getConnection();
//            Statement ps1 =con1.createStatement();
//            Statement ps2 =con1.createStatement();
//            Statement ps3 =con1.createStatement();
//        
//             ResultSet rs2=ps2.executeQuery("SELECT * from sale_challan_2 where sale_challan_no='"+challan_combox.getSelectedItem()+"' ");
//           //sale_item AS Item, sale_unit AS Unit, sale_quantity AS Quantity, sale_rate AS Rate, sale_amount AS Amount, sale_tax AS Amount, sale_taxable_amnt AS Taxable_Amt, sale_disc AS Discount, sale_disc_amnt AS Discount_Amt, sale_total AS Total
//           //table1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs2));
//           
//           int li_row=0;
//           int rw = 0;
//           Vector <String> r[] = (Vector <String> []) new Vector[1000];
//           
//           
//          
//           
//           while(rs2.next())
//                 {
//                 y1.addRow(r[rw]); 
//                    
//                 table1.setValueAt(rs2.getString("sale_challan_item"), li_row, 0);
//                 table1.setValueAt(rs2.getString("sale_challan_unit"), li_row, 1);
//                 
//                 Double sqty = Double.parseDouble(rs2.getString("sale_challan_quantity"));
//                 table1.setValueAt(sqty, li_row, 2);
//               
//                 rw++;
//                 li_row++;
//                 }
//           
//           
//            
//       
//        }catch (SQLException q){
//        System.out.println("Sql Exception" + q.toString());
//        }
//        
        
         try{
         
                               
               
               Connection con1 = Database.getConnection();
                  Statement ps23 =con1.createStatement();
               ResultSet rs2=ps23.executeQuery("SELECT * from sale_challan_2 where sale_challan_no='"+challan_combox.getSelectedItem().toString()+"'  ");
           //sale_item AS Item, sale_unit AS Unit, sale_quantity AS Quantity, sale_rate AS Rate, sale_amount AS Amount, sale_tax AS Amount, sale_taxable_amnt AS Taxable_Amt, sale_disc AS Discount, sale_disc_amnt AS Discount_Amt, sale_total AS Total
           //table1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs2));
           
//           int li_row=0;
//           int rw = 0;
           
//           Vector <String> r[] = (Vector <String> []) new Vector[1000];
//           
//           
//           table1.getColumnModel().getColumn(10).setMinWidth(0);
//           table1.getColumnModel().getColumn(10).setMaxWidth(0);
//           table1.getColumnModel().getColumn(10).setResizable(false);
           
           
           
           
           //Code to redraw header when selection of specific invoice
          
            row = 0;
            gb.removeAll();
            gb.revalidate();
            gb.repaint();
            text_field[row][0] = new JTextField("Item");
            text_field[row][0].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.24;
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][0].setFont(myFont);
            
           
            gb.add(text_field[row][0],gridBagConstraints);
            
            text_field[row][0].setHorizontalAlignment(SwingConstants.CENTER);
            
            text_field[row][1] = new JTextField("Unit");
           
            text_field[row][1].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
           
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=11;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            text_field[row][1].setFont(myFont);
            
            gb.add(text_field[row][1],gridBagConstraints);
            text_field[row][1].setHorizontalAlignment(SwingConstants.CENTER);           

            text_field[row][2] = new JTextField("Quantity");            
            text_field[row][2].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][2].setFont(myFont);
           
            gb.add(text_field[row][2],gridBagConstraints);
            text_field[row][2].setHorizontalAlignment(SwingConstants.CENTER);
            
            //Santu added in 05-12-2014
            
            text_field[row][3] = new JTextField("Rate");            
            text_field[row][3].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=33;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][3].setFont(myFont);
            
            gb.add(text_field[row][3],gridBagConstraints);
            text_field[row][3].setHorizontalAlignment(SwingConstants.CENTER);
            
           //added on 05-12-2014
            
            text_field[row][4] = new JTextField("Amount");            
            text_field[row][4].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=44;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][4].setFont(myFont);
            
            gb.add(text_field[row][4],gridBagConstraints);
            text_field[row][4].setHorizontalAlignment(SwingConstants.CENTER);
            
            text_field[row][5] = new JTextField("Tax");            
            text_field[row][5].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=55;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][5].setFont(myFont);
            
            gb.add(text_field[row][5],gridBagConstraints);
            text_field[row][5].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[row][6] = new JTextField("Taxable Amount");            
            text_field[row][6].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.013;
            gridBagConstraints.gridx=66;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][6].setFont(myFont);
           
            gb.add(text_field[row][6],gridBagConstraints);
            text_field[row][6].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[row][7] = new JTextField("Discount");            
            text_field[row][7].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.033;
            gridBagConstraints.gridx=77;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][7].setFont(myFont);
          
            gb.add(text_field[row][7],gridBagConstraints);
            text_field[row][7].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[row][8] = new JTextField("Discountable Amount");            
            text_field[row][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.013;
            gridBagConstraints.gridx=88;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][8].setFont(myFont);
           
            gb.add(text_field[row][8],gridBagConstraints);
            text_field[row][8].setHorizontalAlignment(SwingConstants.CENTER);
            
//            
            text_field[row][9] = new JTextField("Total");            
            text_field[row][9].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.weighty=0.00;
            gridBagConstraints.gridx=99;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=10;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            text_field[row][9].setFont(myFont);
            
            gb.add(text_field[row][9],gridBagConstraints);
            text_field[row][9].setHorizontalAlignment(SwingConstants.CENTER);
           
            row++;
           
           
           while(rs2.next())
                 {
              
                   
                    
//                 table1.setValueAt(rs2.getString("purchase_item"), li_row, 0);
//                 table1.setValueAt(rs2.getString("purchase_unit"), li_row, 1);
//                 
                 //Double sqty = Double.parseDouble(rs2.getString("purchase_quantity"));
//                 table1.setValueAt(sqty, li_row, 2);
//                 
//                 Double srt = Double.parseDouble(rs2.getString("purchase_rate"));
//                 table1.setValueAt(srt, li_row, 3);
//                 
//                 Double samnt = Double.parseDouble(rs2.getString("purchase_amount"));
//                 table1.setValueAt(samnt, li_row, 4);
//                 
//                 Double stax = Double.parseDouble(rs2.getString("purchase_tax"));
//                 table1.setValueAt(stax, li_row, 5);
//                 
//                 Double stxamnt = Double.parseDouble(rs2.getString("purchase_taxable_amnt"));
//                 table1.setValueAt(stxamnt, li_row, 6);
//                 
//                 Double sdisc = Double.parseDouble(rs2.getString("purchase_disc"));
//                 table1.setValueAt(sdisc, li_row, 7);
//                 
//                 Double sdamnt = Double.parseDouble(rs2.getString("purchase_disc_amnt"));
//                 table1.setValueAt(sdamnt, li_row, 8);
//                 
//                 table1.setValueAt(rs2.getString("purchase_total"), li_row, 9);
//                 
//                 table1.setValueAt(rs2.getString("purchase_id"), li_row, 10);
//                 
//                 rw++;
//                 li_row++;
                 
                 
      
                     
                    
        //filling item table with gridbag rows and values
         
        jComboBox1[row]= new JComboBox();

        jComboBox1[row].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
        gridBagConstraints.weightx=0.24;
        gridBagConstraints.weighty=0.0;
        gridBagConstraints.gridx=0;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipady = 7;
        jComboBox1[row].setSelectedItem(null);

        fill_combo1(jComboBox1[row]);
        jComboBox1[row].setSelectedItem(rs2.getString("sale_challan_item"));
        
        
        gb.add(jComboBox1[row],gridBagConstraints);

        jComboBox2[row]= new JComboBox();
        jComboBox2[row].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=11;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipady = 7;
        jComboBox2[row].setSelectedItem(null);
        
        fill_combo2(jComboBox2[row]);
        jComboBox2[row].setSelectedItem(rs2.getString("sale_challan_unit"));
        
        gb.add(jComboBox2[row],gridBagConstraints);

        //END IN 5 12-2014

        text_field[row][2] = new JTextField("0.00");
    
        text_field[row][2].setText("");
        
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        //text_field[row][3].setFont(myfont);
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=22;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        text_field[row][2].addFocusListener(this);
      

        //text_field[row][2].
        text_field[row][2].setText(rs2.getString("sale_challan_quantity"));
        gb.add(text_field[row][2],gridBagConstraints);

        text_field[row][3] = new JTextField("0.00");
        text_field[row][3].setHorizontalAlignment(SwingConstants.RIGHT);

        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        //text_field[row][3].setFont(myfont);
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=33;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
       text_field[row][3].addFocusListener(this);
        
        text_field[row][3].setText("");
        gb.add(text_field[row][3],gridBagConstraints);

        text_field[row][3].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[row][4] = new JTextField("0.00");
        text_field[row][4].setHorizontalAlignment(SwingConstants.RIGHT);
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        //text_field[row][4].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        text_field[row][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=44;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        text_field[row][4].addFocusListener(this);
        
        text_field[row][4].setText(" ");
        gb.add(text_field[row][4],gridBagConstraints);

        text_field[row][5] = new JTextField("0.00");
        text_field[row][5].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][5].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=55;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        text_field[row][5].addFocusListener(this);
        
        text_field[row][5].setText("");
        gb.add(text_field[row][5],gridBagConstraints);

        text_field[row][5].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[row][6] = new JTextField("0.00");
        text_field[row][6].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][6].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.013;
        gridBagConstraints.gridx=66;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
       text_field[row][6].addFocusListener(this);
        
        text_field[row][6].setText("");
        gb.add(text_field[row][6],gridBagConstraints);

        text_field[row][6].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[row][7] = new JTextField("0.00");
        text_field[row][7].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][7].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.033;
        gridBagConstraints.gridx=77;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        text_field[row][7].addFocusListener(this);
        
        text_field[row][7].setText(" ");
        gb.add(text_field[row][7],gridBagConstraints);

        text_field[row][7].setHorizontalAlignment(SwingConstants.RIGHT);

        text_field[row][8] = new JTextField("0.00");
        text_field[row][8].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.013;
        gridBagConstraints.gridx=88;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        text_field[row][8].addFocusListener(this);
        
        text_field[row][8].setText(" ");
        gb.add(text_field[row][8],gridBagConstraints);

        text_field[row][8].setHorizontalAlignment(SwingConstants.RIGHT);
        
        
        text_field[row][9] = new JTextField("0.00");
        text_field[row][9].setHorizontalAlignment(SwingConstants.RIGHT);

        //text_field[row][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
        gridBagConstraints.fill=gridBagConstraints.VERTICAL;
        gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
        text_field[row][9].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
        gridBagConstraints.ipady = 9;
        gridBagConstraints.weightx=0.20;
        gridBagConstraints.gridx=99;
        gridBagConstraints.gridy=row;
        gridBagConstraints.gridwidth=10;
        text_field[row][9].addFocusListener(this);
        
        text_field[row][9].setText(" ");
        gb.add(text_field[row][9],gridBagConstraints);

        text_field[row][9].setHorizontalAlignment(SwingConstants.RIGHT);


        row++;
        
     
            
       //end of gridbag fill              
                     
            
                 
                  gb.revalidate();
                  gb.repaint();
                 
                  jPanel6.add(gb, BorderLayout.NORTH);
                  
                 }
           
            //rowfinal = row;    
           
        
    }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
    }//GEN-LAST:event_challan_comboxActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.jidesoft.swing.AutoCompletionComboBox challan_combox;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private numeric.textField.NumericTextField curbalnc_txt;
    private javax.swing.JTextField date_txt;
    private javax.swing.JComboBox godown_combo;
    private numeric.textField.NumericTextField gross_total;
    private javax.swing.JTextField invoice_no_txt;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JOptionPane jopt1;
    private javax.swing.JComboBox party_combo;
    private javax.swing.JTable product_table;
    private javax.swing.JComboBox sale_combo;
    private javax.swing.JTextArea sale_narration;
    private javax.swing.JButton save;
    private javax.swing.JTextField search_txt;
    private javax.swing.JTable table1;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    // End of variables declaration//GEN-END:variables
    JComboBox item_combox = new JComboBox();
    JComboBox unit_combox = new JComboBox();
    
        @Override
  public void focusGained(FocusEvent e) {
     
  // System.out.println("Imran Ji");
   calculation_total();
  }

  @Override
  public void focusLost(FocusEvent e) {
  //    System.out.println("Imran Ji");
      calculation_total();
  }
    
     

}
