/*
 *TreeCellEditor.java   Feb 23, 2008
 * Developer: sandarenu
 * Copyright (c) 2006-2008 Minimuthu Software Developers.
 * Sri Lanka.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * Minimuthu Software Developers. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Minimuthu.
 */

package final_project;
import java.awt.Component;
import java.util.EventObject;

import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;

/**
 * @author sandarenu
 *
 */
public class TreeCellEditor implements TableCellEditor
{

	public Component getTableCellEditorComponent(JTable arg0, Object arg1, boolean arg2, int arg3, int arg4)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public void addCellEditorListener(CellEditorListener arg0)
	{
		// TODO Auto-generated method stub
		
	}

	public void cancelCellEditing()
	{
		// TODO Auto-generated method stub
		
	}

	public Object getCellEditorValue()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isCellEditable(EventObject arg0)
	{
		// TODO Auto-generated method stub
		return false;
	}

	public void removeCellEditorListener(CellEditorListener arg0)
	{
		// TODO Auto-generated method stub
		
	}

	public boolean shouldSelectCell(EventObject arg0)
	{
		// TODO Auto-generated method stub
		return false;
	}

	public boolean stopCellEditing()
	{
		// TODO Auto-generated method stub
		return false;
	}

}
