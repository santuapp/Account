package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import org.jdesktop.xswingx.PromptSupport;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class journal_edit_panel extends javax.swing.JPanel {
     Font myFont = new Font("",Font.PLAIN,9);
     
      int i=0,j=0;     // For Mandatory
      int a=0;        // For Non Mandatory

    /**
     * Creates new form journal_edit_panel
     */
      
      public void set(){
    search_txt.requestFocusInWindow();
    search_txt.setFocusable(true);
}

public void user(String u_name){
    jLabel10.setText(u_name);
}
   

      static String w;
    public journal_edit_panel() {
        initComponents();
        j_id.setVisible(false);
          ledger_name.removeAllItems();
          textvalidation();
          create_table();
           initialise1();
        initialise();
        search();
        update_table();
        
        
        invoice_no_txt.setFocusable(true);
        invoice_no_txt.setEditable(false);
        ref_no.setEditable(false);
        
        
        PromptSupport.setPrompt("0.00", balance_txt);
       PromptSupport.setPrompt("dd/mm/yyyy", j_date);
       
        jLabel1.setFont(myFont);
        jLabel1.setEnabled(false);
        jLabel1.setVisible(false);
        
        jLabel3.setFont(myFont);
        jLabel3.setEnabled(false);
        jLabel3.setVisible(false);
        
        
        jLabel7.setFont(myFont);
        jLabel7.setEnabled(false);
        jLabel7.setVisible(false);
        
         jLabel10.setVisible(false);
         
         create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
        //Ref.No
        jLabel2.setVisible(false);
        ref_no.setVisible(false);
        
     
            table.setRowHeight(30);
       
          try{
        
           
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct l_name from ledger");
          while(rs.next())
          {
            
             // String name=rs.getString("l_name");
           //  reference_no.removeAllItems();
            ledger_name.addItem(rs.getString("l_name"));
             //reference_no.addItem(rs.getString("l_name"));
          }
         Statement ps1 =con.createStatement();
           ResultSet rs1=ps1.executeQuery("select distinct journal_inv from journal_creation");
          
            
             // String name=rs.getString("l_name");
           //  reference_no.removeAllItems();
                          table2.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs1));

             //reference_no.addItem(rs.getString("l_name"));
          
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
    }
    
      // Invoice No
    
     public void invoice(){
            if(invoice_no_txt.getText().length()==0)
      {
          invoice_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel1.setEnabled(true);
          jLabel1.setForeground(Color.red);
          jLabel1.setVisible(true);
             
      }  
      else
      {
           invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel1.setEnabled(false);  
           jLabel1.setVisible(false);
           i=1;
          
      }
        
    }
     
      // date
     
     public void date(){
             if(j_date.getText().length()==0)
       {
             j_date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel7.setEnabled(true);
             jLabel7.setForeground(Color.red);
             jLabel7.setVisible(true);
           
       }
       else
       {
           
       
                 String content = j_date.getText();
                 Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
                 Matcher m = p.matcher(content);
                 boolean matchFound = m.matches();
             //    System.out.println(matchFound);
                 j_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                 jLabel7.setEnabled(false);  
                 jLabel7.setVisible(false);
                 j=1;
          
          if(!matchFound)
          { 
             j_date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel7.setEnabled(true);
             jLabel7.setForeground(Color.red);
             jLabel7.setVisible(true);
          }
       }
     } 


    
    ////
    private void tableMouseClicked(java.awt.event.MouseEvent evt)
    {                                   
//jComboBox1.removeAll();
       //jComboBox1.setVisible(false);
//jTextField2.setVisible(true);
            int new1=table2.getSelectedRow();
            String table_click=(table2.getModel().getValueAt(new1, 0).toString());
            System.out.println(table_click);
        try{
         
           
           Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
          ResultSet rs=ps1.executeQuery("SELECT journal_id,journal_select as Choose ,ledger as Perticulars, DEBIT,CREDIT from journal_creation where journal_inv='"+table_click+"'");
         int li_row=0;
           while(rs.next())
                 {
                    
                 table.setValueAt(rs.getString("Choose"), li_row, 0);
                  table.setValueAt(rs.getString("Perticulars"), li_row, 1);
                  table.setValueAt(rs.getString("DEBIT"), li_row, 2);
                   table.setValueAt(rs.getString("CREDIT"), li_row, 3);
                    table.setValueAt(rs.getString("journal_id"), li_row, 4);
                   li_row++;
                 }
           table.getColumnModel().getColumn(4).setMinWidth(0);
             table.getColumnModel().getColumn(4).setMaxWidth(0);
                table.getColumnModel().getColumn(4).setResizable(false);
          //TableColoumn tc=table.getColumnModel().getColumn(0);
        //table.removeColumn(table.getColumnModel().getColumn(4));
         //table.setTableHeader(table.getColumnModel().getColumn("SELECT"));
         
                      ResultSet rs1=ps1.executeQuery("SELECT distinct journal_inv,journal_date,journal_ref_no,journal_balance,sum(debit) as tdebit,sum(credit) as tcredit from journal_creation where journal_inv='"+table_click+"'");
                       
                  while(rs1.next())
                 {
                     String  aa=rs1.getString("journal_inv");
                      invoice_no_txt.setText(aa);
                       String  ab=rs1.getString("journal_ref_no");
                   ref_no.setText(ab);
                   String  ac=rs1.getString("journal_balance");
                   balance_txt.setText(ac);
                   String  at=rs1.getString("tdebit");
                   debit_total.setText(at);
                   String  ay=rs1.getString("tcredit");
                   credit_total.setText(ay);
                   j_date.setText(rs1.getString("journal_date"));
                   
                     Statement ps4 =con1.createStatement();
                ResultSet rs2=ps4.executeQuery("SELECT * from user_activity_table where table_name='journal_creation' and value='"+table_click+"'");
                while(rs2.next())
            {
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                 
                  }
          
          //jComboBox1.removeAll();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        initialise1();

// TODO add your handling code here:
    } 
 
 
 public void search(){
        search_txt.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   String s1=search_txt.getText();

 
 
 String s3=s1;
     
                    try{
                  
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT journal_inv as JOURNAL_INVOICE from journal_creation where journal_inv like '"+s3+"%'"); 
          
              
                table2.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
           
                    }catch (SQLException e1){
        System.out.println("Sql Exception" + e1.toString());
        }
        
                
}
            });
    }
 
   public void update_table()
{ 
       
        try{
        
           
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT journal_inv  from journal_creation");
          table2.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
           
          System.out.println("Done");
          
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
       
        
        table2.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   
int keyvalue=e.getKeyCode();
if(keyvalue==KeyEvent.VK_ENTER)
                {
                   // jComboBox1.setVisible(false);
//jTextField2.setVisible(true);
                 int row=table2.getSelectedRow();
                 int col=table2.getSelectedColumn();
                
                if(table2.getValueAt(row, 0) != null){
                String s1= (String)table2.getValueAt(row, 0);
                
                
//JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());

System.out.println(" Value in the row clicked :"+ " " +row+"");
System.out.println(" Value in the col clicked :"+ " " +col+"");
System.out.println(" Value in the col,row clicked :"+ " " +s1+"");

          try{
         
           
           Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
         ResultSet rs=ps1.executeQuery("SELECT journal_id,journal_select as Choose ,ledger as Perticulars, DEBIT,CREDIT from journal_creation where journal_inv='"+s1+"'");
         int li_row=0;
           while(rs.next())
                 {
                    
                 table.setValueAt(rs.getString("Choose"), li_row, 0);
                  table.setValueAt(rs.getString("Perticulars"), li_row, 1);
                  table.setValueAt(rs.getString("DEBIT"), li_row, 2);
                   table.setValueAt(rs.getString("CREDIT"), li_row, 3);
                    table.setValueAt(rs.getString("journal_id"), li_row, 4);
                   li_row++;
                 }
           table.getColumnModel().getColumn(4).setMinWidth(0);
             table.getColumnModel().getColumn(4).setMaxWidth(0);
                table.getColumnModel().getColumn(4).setResizable(false);
                 initialise1();
          //TableColoumn tc=table.getColumnModel().getColumn(0);
        //table.removeColumn(table.getColumnModel().getColumn(4));
         //table.setTableHeader(table.getColumnModel().getColumn("SELECT"));
         
                      ResultSet rs1=ps1.executeQuery("SELECT distinct journal_inv,journal_date,journal_ref_no,journal_balance,sum(debit) as tdebit,sum(credit) as tcredit from journal_creation where journal_inv='"+s1+"'");
                       
                  while(rs1.next())
                 {
                   String  aa=rs1.getString("journal_inv");
                   invoice_no_txt.setText(aa);
                   String  ab=rs1.getString("journal_ref_no");
                   ref_no.setText(ab);
                   String  ac=rs1.getString("journal_balance");
                   balance_txt.setText(ac);
                   String  at=rs1.getString("tdebit");
                   debit_total.setText(at);
                   String  ay=rs1.getString("tcredit");
                   credit_total.setText(ay);
                   j_date.setText(rs1.getString("journal_date"));
                   
                    Statement ps4 =con1.createStatement();
                ResultSet rs2=ps4.executeQuery("SELECT * from user_activity_table where table_name='journal_creation' and value='"+s1+"'");
                while(rs2.next())
            {
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                 
                  }
       
          
         
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
       

                }  }



}

}

);
    Action delete = new AbstractAction()
{
    public void actionPerformed(ActionEvent e)
    {
        
    }
};
 
 
}
    
    ///////
    
    
    
    /**
     * 
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton4 = new javax.swing.JButton();
        ledger_name = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel9 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        savebutton = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        Clear_button = new javax.swing.JButton();
        j_id = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        invoice_no_txt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        ref_no = new javax.swing.JTextField();
        j_date = new javax.swing.JTextField();
        credit_total = new javax.swing.JTextField();
        debit_total = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        balance_txt = new numeric.textField.NumericTextField();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        journal_narration = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        search_txt = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        table2 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        create_date = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        update_date = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();

        jButton4.setText("jButton4");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        savebutton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        savebutton.setText("Save");
        savebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savebuttonActionPerformed(evt);
            }
        });

        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete_button.setText("Delete");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });

        Clear_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        Clear_button.setText("Clear");
        Clear_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Clear_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Clear_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(delete_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(savebutton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(savebutton)
                .addGap(21, 21, 21)
                .addComponent(delete_button)
                .addGap(21, 21, 21)
                .addComponent(Clear_button)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Invoice No.");

        invoice_no_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                invoice_no_txtFocusLost(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Reference No.");

        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Balance:");

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Date");

        table.setForeground(new java.awt.Color(0, 0, 255));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "To/By", "Particulars", "Debit", "Credit", "Title 5"
            }
        ));
        jScrollPane1.setViewportView(table);
        table.getColumn("To/By").setCellEditor(new DefaultCellEditor(combox1));

        j_date.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                j_dateFocusLost(evt);
            }
        });

        jLabel1.setText("Invoice No Can't Be Empty!");

        jLabel3.setText("Enter Valid Balance!");

        jLabel7.setText("Enter Valid Date!");

        balance_txt.setText("numericTextField1");
        balance_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                balance_txtFocusLost(evt);
            }
        });

        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Narration:");

        journal_narration.setColumns(20);
        journal_narration.setRows(5);
        jScrollPane4.setViewportView(journal_narration);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rows", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Action-remove-icon.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/add-2-icon.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton5))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addContainerGap())
        );

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Total:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 292, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(debit_total, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(credit_total, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jScrollPane1))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(invoice_no_txt, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                                            .addComponent(balance_txt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(212, 212, 212)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(ref_no, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                                        .addComponent(j_date))))
                            .addComponent(jScrollPane4))))
                .addGap(0, 0, 0))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {credit_total, debit_total});

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {balance_txt, invoice_no_txt, j_date, ref_no});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(invoice_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ref_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(7, 7, 7)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(jLabel5)
                        .addComponent(j_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(balance_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel7))
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(debit_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel11))
                    .addComponent(credit_total, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26))
        );

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        jPanel12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(search_txt, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(search_txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        table2.setForeground(new java.awt.Color(0, 0, 255));
        table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(table2);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Journal Edit Delete");

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.cyan));

        jLabel26.setForeground(new java.awt.Color(51, 153, 0));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel26.setText("Created By:");

        jLabel27.setForeground(new java.awt.Color(51, 153, 0));
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel27.setText("Created Date:");

        jLabel28.setForeground(new java.awt.Color(51, 153, 0));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel28.setText("Updated By:");

        jLabel29.setForeground(new java.awt.Color(51, 153, 0));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel29.setText("Update Date:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {create_date, create_user, update_date, update_user});

        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel10.setText("jLabel10");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel10))
                            .addComponent(j_id, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 936, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 11, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(j_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 22, Short.MAX_VALUE))))
        );

        jScrollPane2.setViewportView(jPanel9);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane2)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void savebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savebuttonActionPerformed
 if(invoice_no_txt.getText().equals(""))
     {
           jopt1.showMessageDialog(this,"Select Invoice No!"); 
     }

   
       
  else {
       invoice();
      date();  
         if(i==1&&j==1&&a==0)
    {       
        try{

            
            Connection con = Database.getConnection();
            PreparedStatement psd1=con.prepareStatement("delete from  journal_creation where journal_inv='"+invoice_no_txt.getText()+"'");

                psd1.executeUpdate();
              PreparedStatement psd2=con.prepareStatement("delete from  company_main_table where get_id='"+invoice_no_txt.getText()+"'");

             psd2.executeUpdate();  
            int p=table.getRowCount();
            for(int i=0;i<p;i++)
            {
                String select=table.getValueAt(i,0).toString();
                String ledger=table.getValueAt(i,1).toString();
                String debit=table.getValueAt(i,2).toString();
                String credit=table.getValueAt(i,3).toString();
                log_table.table_update("journal_creation",jLabel10.getText(),invoice_no_txt.getText());
                PreparedStatement ps1=con.prepareStatement("insert into journal_creation (journal_inv,ledger,debit,credit,journal_date,journal_ref_no,journal_balance,journal_select)values('"+invoice_no_txt.getText()+"','"+ledger+"','"+debit+"','"+credit+"','"+j_date.getText()+"','"+ref_no.getText()+"','"+balance_txt.getText()+"','"+select+"')");

                ps1.executeBatch();
                ps1.executeUpdate();
                PreparedStatement ps2=con.prepareStatement("insert into company_main_table (ledger,debit,credit,get_id,trans_date,type)values('"+ledger+"','"+debit+"','"+credit+"','"+invoice_no_txt.getText()+"','"+j_date.getText()+"','JOURNAL')");

                ps2.executeBatch();
                ps2.executeUpdate();
                 Statement pss =con.createStatement();
           ResultSet rss=pss.executeQuery("select  l_under from ledger where l_name='"+ledger+"'");
          while(rss.next())
          {
              String under=rss.getString("l_under");
               PreparedStatement psd3=con.prepareStatement("delete from   `"+under+"` where trans_id='"+invoice_no_txt.getText()+"'");

                psd3.executeUpdate();
             PreparedStatement psw=con.prepareStatement("insert into `"+under+"` (l_name,credit,debit,trans_id,date)values('"+ledger+"','"+debit+"',,'"+credit+"','"+invoice_no_txt.getText()+"','"+j_date.getText()+"')");
              psw.executeBatch();
             psw.executeUpdate();
              
          }
            }
            System.out.println("saved");

            jopt1.showMessageDialog(this,"Journal Updated");
            
              invoice_no_txt.setText(null);
            j_date.setText(null);
            ref_no.setText(null);
            balance_txt.setText(null);
            
            create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
            
            jLabel7.setVisible(false);
           
            jLabel4.setVisible(false);
            jLabel8.setVisible(false);
            
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            j_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            ref_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            
            
            debit_total.setText(null);
            credit_total.setText(null);
            
           //TABLE RESET
           int p2=table.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
                Double a4=null;
                String a5=null;
                
                
        table.setValueAt(a1, i, 0);
        table.setValueAt(a2, i, 1);
        table.setValueAt(a3, i, 2);
        table.setValueAt(a4, i, 3);
        table.setValueAt(a5, i, 4);
        
        }
        con.close();
        }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
        }
        
    }
 }
    }//GEN-LAST:event_savebuttonActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        DefaultTableModel y = (DefaultTableModel)table.getModel();

        Vector <String> r = new Vector <String>();
        y.addRow(r);

        initialise1();
        initialise();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        DefaultTableModel y = (DefaultTableModel)table.getModel();

        int a=y.getRowCount()- 1;

        y.removeRow(a);
        try{

            
            Connection con1 = Database.getConnection();
            Statement ps1 =con1.createStatement();
            Statement ps2 =con1.createStatement();
            PreparedStatement ps10=con1.prepareStatement("delete from  journal_creation where purchase_id='"+j_id.getText()+"'");

            ps10.executeUpdate();

            //jComboBox1.removeAll();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }//GEN-LAST:event_jButton6ActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
        int p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(p==0)
        {
            try{

               
                Connection con1 = Database.getConnection();

                System.out.println("Done");
                update_table();

                PreparedStatement ps1=con1.prepareStatement("delete from  journal_creation where journal_inv='"+invoice_no_txt.getText()+"'");

                ps1.executeUpdate();
                log_table.table_delete("journal_creation",jLabel10.getText());
                
                 jopt1.showMessageDialog(this,"Journal Deleted");
                 
                 con1.close();
            }catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
           

        }
         invoice_no_txt.setText(null);
            j_date.setText(null);
            ref_no.setText(null);
            balance_txt.setText(null);
            
            create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
            
            jLabel7.setVisible(false);
           
            jLabel4.setVisible(false);
            jLabel8.setVisible(false);
            
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            j_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            ref_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            
            
            debit_total.setText(null);
            credit_total.setText(null);
            
           //TABLE RESET
           int p2=table.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
                Double a4=null;
                String a5=null;
                
                
        table.setValueAt(a1, i, 0);
        table.setValueAt(a2, i, 1);
        table.setValueAt(a3, i, 2);
        table.setValueAt(a4, i, 3);
        table.setValueAt(a5, i, 4);
        
        }
        
        
    }//GEN-LAST:event_delete_buttonActionPerformed

    private void Clear_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Clear_buttonActionPerformed
            invoice_no_txt.setText(null);
            j_date.setText(null);
            ref_no.setText(null);
            balance_txt.setText(null);
            
            create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
            
            jLabel7.setVisible(false);
           
            jLabel4.setVisible(false);
            jLabel8.setVisible(false);
            
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            j_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            ref_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            
            
            debit_total.setText(null);
            credit_total.setText(null);
            
           //TABLE RESET
           int p2=table.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
                Double a4=null;
                String a5=null;
                
                
        table.setValueAt(a1, i, 0);
        table.setValueAt(a2, i, 1);
        table.setValueAt(a3, i, 2);
        table.setValueAt(a4, i, 3);
        table.setValueAt(a5, i, 4);
        
        }
    }//GEN-LAST:event_Clear_buttonActionPerformed

    private void balance_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_balance_txtFocusLost
     if(balance_txt.getText().length()==0)
                   {
                       balance_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                       jLabel3.setEnabled(true);
                       jLabel3.setForeground(Color.red);
                       jLabel3.setVisible(true);
                       
                   }
                   else
                   {
                       String content = balance_txt.getText();
                       Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
                       Matcher m1 = p.matcher(content);
                       boolean matchFound = m1.matches();
                       balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel3.setEnabled(false);  
                       jLabel3.setVisible(false);
                       a=1;
                       
                       
                       
                     if(!matchFound)
                    {
                       balance_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                       jLabel3.setEnabled(true);
                       jLabel3.setForeground(Color.red);
                       jLabel3.setVisible(true);
                       
                    }
                   }
    }//GEN-LAST:event_balance_txtFocusLost

    private void invoice_no_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_invoice_no_txtFocusLost
            if(invoice_no_txt.getText().length()==0)
      {
          invoice_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel1.setEnabled(true);
          jLabel1.setForeground(Color.red);
          jLabel1.setVisible(true);
             
      }  
      else
      {
           invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel1.setEnabled(false);  
           jLabel1.setVisible(false);
           i=1;
          
      }
    }//GEN-LAST:event_invoice_no_txtFocusLost

    private void j_dateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_j_dateFocusLost
           if(j_date.getText().length()==0)
       {
             j_date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel7.setEnabled(true);
             jLabel7.setForeground(Color.red);
             jLabel7.setVisible(true);
           
       }
       else
       {
           
       
                 String content = j_date.getText();
                 Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
                 Matcher m = p.matcher(content);
                 boolean matchFound = m.matches();
             //    System.out.println(matchFound);
                 j_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                 jLabel7.setEnabled(false);  
                 jLabel7.setVisible(false);
                 j=1;
          
          if(!matchFound)
          { 
             j_date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel7.setEnabled(true);
             jLabel7.setForeground(Color.red);
             jLabel7.setVisible(true);
          }
       }
    }//GEN-LAST:event_j_dateFocusLost
  public void initialise(){
   
       table.getModel().addTableModelListener(new TableModelListener()
        
                {
                  public void tableChanged (TableModelEvent e)
                {
		  double gtot=0.0d;
                   double gtot1=0.0d;
            int n1=table.getRowCount();
            System.out.println(n1);
            for (int i =0; i<=n1-1; i++)
            {
                if ((table.getValueAt(i, 2)) !=null)
            {
                    String s1 = (String)table.getValueAt(i, 2);
                    double d1=Double.parseDouble(s1);
                    System.out.println(s1);
                   
                   
                    gtot=gtot+d1;
                    System.out.println(gtot);
                  
            }
                String s4=Double.toString(gtot);
                    debit_total.setText(s4);
            }
             for (int i =0; i<=n1-1; i++)
            {
                if ((table.getValueAt(i, 3)) !=null)
            {
                    String s0 = (String)table.getValueAt(i, 3);
                    double d1=Double.parseDouble(s0);
                    System.out.println(s0);
                   
                   
                    gtot1=gtot1+d1;
                    System.out.println(gtot1);
                  
            }
                String s40=Double.toString(gtot1);
                    credit_total.setText(s40);
            }
            
                }
                }
          );

    }
      
    public void initialise1()
    {
  
     table.getModel().addTableModelListener(new TableModelListener(){
 public void tableChanged  (TableModelEvent e) {
                String b[] = { "Titan", "HMT" };
                String c[] = {"Nokia","Sony","Motorola","Samsung"};
                String d[] = {""};
                        int n=table.getRowCount();
 for (int j =0; j<=n-1; j++)
                    {
                        
                if (((table.getValueAt(j, 0)) !=null) && (table.getValueAt(j, 1)) ==null){
                        if (combox1.getSelectedItem().equals("Select")) {
                            //JComboBox combox2 = new JComboBox();
                            //JComboBox combox = new JComboBox();
                             JComboBox combox3 = new JComboBox(d);
                              table.getColumn("Particulars").setCellEditor(new DefaultCellEditor(combox3));
                               
                               //combox3.setEnabled(true);
                           
                               //combox.setEnabled(false);
                                //combox2.setEnabled(false);
                                //combox2.removeAllItems();
                                //combox.removeAllItems();
                        }
                    if (combox1.getSelectedItem().equals("By")) {
                        
                            //JComboBox combox = new JComboBox(b);
                          // table.setValueAt("s1", j, 2);
                           //  combox2.removeAllItems();
                                //combox2.setEnabled(true);
                            //combox2.removeAllItems();
                               
                               
                            // table.getColumn("Debit").setCellEditor(new DefaultCellEditor(combox));

                         // combox.removeAllItems();
                                //combox.setEnabled(true); 
                                  table.getColumn("Particulars").setCellEditor(new DefaultCellEditor(ledger_name));
                                
                                  
                        } 
                    else if (combox1.getSelectedItem().equals("To")) {
                            
                                
                               // JComboBox combox = new JComboBox(c);
                          // combox.removeAllItems();
                              //  table.setValueAt("0.00", j, 2);
                               //combox.setEnabled(true);
                      table.getColumn("Particulars").setCellEditor(new DefaultCellEditor(ledger_name));

                        }
                }   }  }
        
 });

               }
    
    
    
    
    public void create_table(){
        String wsdf="";
     //    System.out.println(w);
        try{
        
           
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
         Statement ps1 =con.createStatement();
          Statement ps2 =con.createStatement();
           Statement ps3 =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT journal_id,journal_select as Choose ,ledger as Perticulars, DEBIT,CREDIT from journal_creation where journal_inv='"+w+"'");
         int li_row=0;
           while(rs.next())
                 {
                    
                 table.setValueAt(rs.getString("Choose"), li_row, 0);
                  table.setValueAt(rs.getString("Perticulars"), li_row, 1);
                  table.setValueAt(rs.getString("DEBIT"), li_row, 2);
                   table.setValueAt(rs.getString("CREDIT"), li_row, 3);
                    table.setValueAt(rs.getString("journal_id"), li_row, 4);
                   li_row++;
                 }
           table.getColumnModel().getColumn(4).setMinWidth(0);
             table.getColumnModel().getColumn(4).setMaxWidth(0);
                table.getColumnModel().getColumn(4).setResizable(false);
          //TableColoumn tc=table.getColumnModel().getColumn(0);
        //table.removeColumn(table.getColumnModel().getColumn(4));
         //table.setTableHeader(table.getColumnModel().getColumn("SELECT"));
         
                      ResultSet rs1=ps1.executeQuery("SELECT distinct journal_inv,journal_ref_no,journal_balance,sum(debit) as tdebit,sum(credit) as tcredit from journal_creation where journal_inv='"+w+"'");
                       
                  while(rs1.next())
                 {
                     String  aa=rs1.getString("journal_inv");
                      invoice_no_txt.setText(aa);
                       String  ab=rs1.getString("journal_ref_no");
                   ref_no.setText(ab);
                   String  ac=rs1.getString("journal_balance");
                   balance_txt.setText(ac);
                   String  at=rs1.getString("tdebit");
                   debit_total.setText(at);
                   String  ay=rs1.getString("tcredit");
                   credit_total.setText(ay);
                   
                    Statement ps4 =con.createStatement();
                ResultSet rs2=ps4.executeQuery("SELECT * from user_activity_table where table_name='journal_creation' and value='"+w+"'");
                while(rs2.next())
            {
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                 
                  }
                   ResultSet rs2=ps2.executeQuery("SELECT DAYOFMONTH(journal_date) as DAY,MONTH(journal_date)as month,YEAR(journal_date) as year from journal_creation where journal_inv='"+w+"'");
                    while(rs2.next())
                    {
                        String  af=rs2.getString("DAY");
                 
                    }
                    
          System.out.println("Done");
            
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
    }
     public void  textvalidation(){
         invoice_no_txt.addKeyListener(new KeyAdapter(){
             private boolean SHIFT_PRESSED;
             private boolean SPACE_PRESSED;
             private boolean CAPS_LOCK_PRESSED;
            
             public void keyPressed(KeyEvent e){
           String  i=invoice_no_txt.getText();
            
                char ch = e.getKeyChar();
                if(Character.isLetterOrDigit(ch)){
                }
                else if(e.getKeyChar() == KeyEvent.VK_BACK_SPACE){
                }else if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
            this.SHIFT_PRESSED = true;
        }else if(e.getKeyCode() == KeyEvent.VK_SPACE) {
            this.SPACE_PRESSED = true;
        }else if(e.getKeyCode() == KeyEvent.VK_CAPS_LOCK) {
            this.CAPS_LOCK_PRESSED = true;
        }
                else{
                    //JOptionPane.showMessageDialog(null, "Special Character are not Allowed!");
                  invoice_no_txt.setText("");
                }
            
             }
        });
     }

    
    
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Clear_button;
    private numeric.textField.NumericTextField balance_txt;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private javax.swing.JTextField credit_total;
    private javax.swing.JTextField debit_total;
    private javax.swing.JButton delete_button;
    private javax.swing.JTextField invoice_no_txt;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField j_date;
    private javax.swing.JTextField j_id;
    private javax.swing.JTextArea journal_narration;
    private javax.swing.JComboBox ledger_name;
    private javax.swing.JTextField ref_no;
    private javax.swing.JButton savebutton;
    private javax.swing.JTextField search_txt;
    private javax.swing.JTable table;
    private javax.swing.JTable table2;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    // End of variables declaration//GEN-END:variables
JComboBox combox1 = new JComboBox(new String [] {"Select","By","To"});
private javax.swing.JOptionPane jopt1;
}
