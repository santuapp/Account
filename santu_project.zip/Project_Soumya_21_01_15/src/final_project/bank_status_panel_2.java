/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.DefaultRowSorter;
import javax.swing.KeyStroke;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Ardhendu
 */
public class bank_status_panel_2 extends javax.swing.JPanel {

    /**
     * Creates new form bank_status_panel_2
     */
     String head_trans;
    String id;
    double closing=0.0d;
     int flag=0;
    /**
     * Creates new form vendor_trans_detail_panel
     */
        public String s1="";
        public  int row,col;
    public bank_status_panel_2() {
        initComponents();
       
    }
    public void bank_deatils_2(String click)
        {
    flag=0;
     jLabel1.setText(click);
     head_trans = click;
          try{
        
           Connection con = Database.getConnection();
           Statement psq3 =con.createStatement();
             PreparedStatement ps09=con.prepareStatement("DELETE FROM bank_status");
                ps09.executeUpdate();
                  Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("SELECT distinct TRANS_Date AS DATE, ledger as PARTICULERS, SUM(Debit) AS DEBIT, SUM(Credit) AS CREDIT, get_id AS TRANSACTION_ID, TYPE FROM company_main_table where type='Opening' and ledger='"+click+"'");
          while(flag<=0)
          {
            if(rs.next())
            {
                String de=rs.getString("debit");
                String cre=rs.getString("credit");
                  
                PreparedStatement ps110=con.prepareStatement("insert into bank_status(  vtp_debit, vtp_credit,vtp_type) values ('"+de+"','"+cre+"','Opening')");
                ps110.executeUpdate();
            
                System.out.println(de+"      "+cre);
               flag++; 
            }
          }
               Statement psq =con.createStatement();
           ResultSet rsq=psq.executeQuery("SELECT distinct get_id FROM company_main_table where ledger='"+click+"' and get_id is not null");
           
           while(rsq.next())
           {
            id=rsq.getString("get_id");
             System.out.println(id+"A    ");
           
            Statement psa =con.createStatement();
            ResultSet rsa=psa.executeQuery("SELECT distinct TRANS_Date AS DATE, ledger as PARTICULERS, SUM(Debit) AS DEBIT, SUM(Credit) AS CREDIT, get_id AS TRANSACTION_ID, TYPE FROM company_main_table where get_id='"+id+"' and ledger!='"+click+"'");
            while(rsa.next())
            {
                
                  PreparedStatement ps102=con.prepareStatement("insert into bank_status (vtp_trans_date, vtp_ledger, vtp_debit, vtp_credit, vtp_get_id, vtp_type) values ('"+rsa.getString("DATE")+"','"+rsa.getString("PARTICULERS")+"','"+rsa.getString("credit")+"','"+rsa.getString("debit")+"','"+rsa.getString("TRANSACTION_ID")+"','"+rsa.getString("type")+"')");
                  ps102.executeBatch();
                  ps102.executeUpdate();
                    
                  System.out.println("insert into bank_status (vtp_trans_date, vtp_ledger, vtp_debit, vtp_credit, vtp_get_id, vtp_type) values ('"+rsa.getString("DATE")+"','"+rsa.getString("PARTICULERS")+"','"+rsa.getString("credit")+"','"+rsa.getString("debit")+"','"+rsa.getString("TRANSACTION_ID")+"','"+rsa.getString("type")+"')");
            }
        
           }
         
          Statement temp =con.createStatement();
            ResultSet tm=temp.executeQuery("SELECT vtp_trans_date as DATE, vtp_ledger AS PARTICULARS, vtp_debit AS DEPOSITE, vtp_credit as WITHDRAWN, vtp_get_id AS `TRANSSACTION ID`, vtp_type as TYPE FROM bank_status order by  (CASE VTP_TYPE WHEN 'Opening' Then 1 ELSE 100 END) ASC");
           
                  int li_row=0;
           int rw = 0;
           Vector <String> r[] = (Vector <String> []) new Vector[1000];
             DefaultTableModel y1 = (DefaultTableModel)table_1.getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            }
            closing=0.0d;
           while(tm.next())
                 {
                     double deposite=Double.parseDouble(tm.getString("DEPOSITE"));
                      double widthdrawn=Double.parseDouble(tm.getString("WITHDRAWN"));
                      closing=deposite + closing - widthdrawn ;
                      String clo=Double.toString(closing);
                         y1.addRow(r[rw]); 
                    
                 table_1.setValueAt(tm.getString("DATE"), li_row, 0);
                  table_1.setValueAt(tm.getString("PARTICULARS"), li_row, 1);
                  table_1.setValueAt(tm.getString("DEPOSITE"), li_row, 2);
                   table_1.setValueAt(tm.getString("WITHDRAWN"), li_row, 3);
                    table_1.setValueAt(tm.getString("TRANSSACTION ID"), li_row, 4);
                     table_1.setValueAt(tm.getString("TYPE"), li_row, 5);
                     table_1.setValueAt(clo, li_row, 6);
                     rw++;
                 li_row++;
                 }
            
         con.close();
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
       
          
          table_1.setPreferredScrollableViewportSize(table_1.getPreferredSize());
          table_1.setAutoCreateRowSorter(true);
          table_1.setRowHeight(25);
    
//         Action delete = new AbstractAction()
//{
//    public void actionPerformed(ActionEvent e)
//    {
//        
//    }
//};
//     ButtonColumn buttonColumn0 = new ButtonColumn(table_1, delete, 0);
//     ButtonColumn buttonColumn1 = new ButtonColumn(table_1, delete, 1);
//     ButtonColumn buttonColumn2 = new ButtonColumn(table_1, delete, 2);
//     ButtonColumn buttonColumn3 = new ButtonColumn(table_1, delete, 3);
//     ButtonColumn buttonColumn4 = new ButtonColumn(table_1, delete, 4);
//     ButtonColumn buttonColumn5 = new ButtonColumn(table_1, delete, 5);
//    buttonColumn0.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn1.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn2.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn3.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn4.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn5.setMnemonic(KeyEvent.VK_ENTER);
     table_1.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table_1.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {                                                                                  
            //action to be performed
        }

            
        });
        }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        table_1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        table_1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Date", "Particulars", "Deposite", "Withdrawn", "Transaction ID", "Vouchar Type", "Closing Balance"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(table_1);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("jLabel2");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    public javax.swing.JTable table_1;
    // End of variables declaration//GEN-END:variables
}
