package final_project;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class secondary_payment_edit_panel extends javax.swing.JPanel {

    /**
     * Creates new form secondary_payment_edit_panel
     */
    int p,p1;
    String a3,a6,table_click,under;
    public secondary_payment_edit_panel() {
        initComponents();
        pay_invoice_txt.setFocusable(true);
        pay_invoice_txt.setEditable(false);
        
        jLabel5.setVisible(false);
        ref_combo.setVisible(false);
        
        jLabel15.setVisible(false);
        
        create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
    }
    public void set(){
      pay_invoice_txt.requestFocusInWindow();
      pay_invoice_txt.setFocusable(true);
  }
  
  public void user(String u_name){
      jLabel15.setText(u_name);
  }
    
public void payment_panel(String pay)
{
    
    
    try{

           
            Connection con = Database.getConnection();

            Statement ps1 =con.createStatement();
            ResultSet rs1=ps1.executeQuery("select distinct l_name from ledger order by l_id");
            while(rs1.next())
            {
                String name=rs1.getString("l_name");
                ledger.addItem(name);
               pay_combo.addItem(name);
            }
        
    }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
        }
        
      
            try{
         
           
            Connection con1 = Database.getConnection();
            Statement ps1 =con1.createStatement();
            Statement ps2 =con1.createStatement();
           ResultSet rs1=ps1.executeQuery("SELECT * from payment where pay_invoice='"+pay+"' ");
            //jComboBox1.removeAll();
       
           while(rs1.next())
                {
                String  aa=rs1.getString("pay_invoice");
                pay_invoice_txt.setText(aa);
                                             
                String a1=rs1.getString("pay_c_name");
                customer_name_txt.setText(a1);

                String a2=rs1.getString("pay_date");
                pay_date.setText(a2);
                
                 a3=rs1.getString("pay_ledger");
                ledger.setSelectedItem(a3);
                
                
                String a4=rs1.getString("pay_ref_no");
               ref_combo.addItem(a4);
                ref_combo.setSelectedItem(a4);
                
                String a5=rs1.getString("pay_balance");
                balance_txt.setText(a5);

                 a6=rs1.getString("pay_ledger1");
                pay_combo.setSelectedItem(a6);
                                
                String a8=rs1.getString("pay_bank_name");
                bank_name_txt.setText(a8);
                
                String a9=rs1.getString("pay_branch_name");
                branch_name_txt.setText(a9);
                
                String a10=rs1.getString("pay_cheque_no");
                cheque_no_txt.setText(a10);
                
                String a11=rs1.getString("pay_total_amnt");
                total_amount_txt.setText(a11);
                
                String a12=rs1.getString("pay_amnt_words");
                amount_in_word_txt.setText(a12);
                
                String a13=rs1.getString("pay_for");
                payment_for_txt.setText(a13);
                
                 Statement ps4 =con1.createStatement();
                ResultSet rs2=ps4.executeQuery("SELECT * from user_activity_table where table_name='payment' and value='"+pay+"'");
                while(rs2.next())
            {
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                
                }
       
          
          //jComboBox1.removeAll();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane1 = new javax.swing.JOptionPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        customer_name_txt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        ref_combo = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        balance_txt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        pay_combo = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        bank_name_txt = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        branch_name_txt = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        cheque_no_txt = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        total_amount_txt = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        amount_in_word_txt = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        pay_date = new javax.swing.JTextField();
        ledger = new javax.swing.JComboBox();
        pay_invoice_txt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        payment_for_txt = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        save_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        create_date = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        update_date = new javax.swing.JTextField();

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Informations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 0, 255))); // NOI18N

        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Customer Name:");

        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Date:");

        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Ledger:");

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Reference No:");

        ref_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1" }));

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Balance:");

        balance_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                balance_txtFocusLost(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Payment Ledger:");

        pay_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));

        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Bank Name:");

        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Branch Name:");

        jLabel10.setForeground(new java.awt.Color(0, 0, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Cheque No:");

        jLabel11.setForeground(new java.awt.Color(0, 0, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Total Amount:");

        total_amount_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                total_amount_txtFocusLost(evt);
            }
        });

        jLabel12.setForeground(new java.awt.Color(0, 0, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Amount in Words:");

        jLabel13.setForeground(new java.awt.Color(0, 0, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Payment For:");

        ledger.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        ledger.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                ledgerFocusGained(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Invoice No.");

        payment_for_txt.setColumns(20);
        payment_for_txt.setRows(5);
        jScrollPane2.setViewportView(payment_for_txt);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(customer_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ref_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(balance_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bank_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(branch_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cheque_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(total_amount_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(amount_in_word_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pay_date, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pay_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ledger, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pay_invoice_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel1, jLabel10, jLabel11, jLabel12, jLabel13, jLabel2, jLabel3, jLabel4, jLabel5, jLabel6, jLabel7, jLabel8, jLabel9});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pay_invoice_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(19, 19, 19)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(customer_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(pay_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(ledger, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ref_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(balance_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pay_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bank_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(branch_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cheque_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(total_amount_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(amount_in_word_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        save_button.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        save_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save_button.setText("Save");
        save_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_buttonActionPerformed(evt);
            }
        });

        delete_button.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete_button.setText("Delete");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });

        clear.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        clear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        clear.setText("Clear");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(delete_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(save_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(save_button)
                .addGap(18, 18, 18)
                .addComponent(delete_button)
                .addGap(18, 18, 18)
                .addComponent(clear)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Secondary Payment Edit Delete");

        jLabel15.setText("jLabel15");

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), java.awt.Color.cyan)); // NOI18N

        jLabel26.setForeground(new java.awt.Color(51, 153, 0));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel26.setText("Created By:");

        jLabel27.setForeground(new java.awt.Color(51, 153, 0));
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel27.setText("Created Date:");

        jLabel28.setForeground(new java.awt.Color(51, 153, 0));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel28.setText("Updated By:");

        jLabel29.setForeground(new java.awt.Color(51, 153, 0));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel29.setText("Update Date:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(46, 46, 46)
                        .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(46, 46, 46)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel15)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel15)
                        .addGap(77, 77, 77)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void balance_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_balance_txtFocusLost
        String pin = balance_txt.getText();
        Pattern pattern = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]");
        Matcher matcher = pattern.matcher(pin);

        if (matcher.matches()) {
        }
        else
        {

            balance_txt.setText("");
            JOptionPane.showMessageDialog(null, "Enter Number!");
        }
    }//GEN-LAST:event_balance_txtFocusLost

    private void total_amount_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_total_amount_txtFocusLost
        String pin = total_amount_txt.getText();
        Pattern pattern = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
        Matcher matcher = pattern.matcher(pin);

        if (matcher.matches()) {
        }
        else
        {

            total_amount_txt.setText("");
            JOptionPane.showMessageDialog(null, "Enter Number!");
        }
    }//GEN-LAST:event_total_amount_txtFocusLost

    private void ledgerFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ledgerFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_ledgerFocusGained

    private void save_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_buttonActionPerformed

        String invoice = pay_invoice_txt.getText();
p1=JOptionPane.showConfirmDialog(null,"Do you really want to save?","Save",JOptionPane.YES_NO_OPTION);
        if(p1==0)
        {
        if (invoice!="")
        {
             try{

            
             Connection con2 = Database.getConnection();
             Statement ps5 =con2.createStatement(); 
             
             log_table.table_update("payment",jLabel15.getText(),customer_name_txt.getText());
             PreparedStatement ps1=con2.prepareStatement("update payment set pay_c_name='"+customer_name_txt.getText()+"',pay_date='"+pay_date.getText()+"',pay_ledger='"+ledger.getSelectedItem()+"',pay_ref_no='"+ref_combo.getSelectedItem()+"',pay_balance='"+balance_txt.getText()+"',pay_ledger1='"+pay_combo.getSelectedItem()+"',pay_bank_name='"+bank_name_txt.getText()+"',pay_branch_name='"+branch_name_txt.getText()+"',pay_cheque_no='"+cheque_no_txt.getText()+"',pay_total_amnt='"+total_amount_txt.getText()+"',pay_amnt_words='"+amount_in_word_txt.getText()+"',pay_for='"+payment_for_txt.getText()+"' where pay_invoice='"+pay_invoice_txt.getText()+"'");
             ps1.executeUpdate();
             PreparedStatement psm=con2.prepareStatement("update company_main_table set ledger='"+ledger.getSelectedItem().toString()+"',trans_date='"+pay_date.getText()+"',debit='"+total_amount_txt.getText()+"' where get_id='"+pay_invoice_txt.getText()+"' and credit='0'");
             psm.executeUpdate();
             PreparedStatement psg=con2.prepareStatement("update company_main_table set ledger='"+pay_combo.getSelectedItem().toString()+"',trans_date='"+pay_date.getText()+"',credit='"+total_amount_txt.getText()+"' where get_id='"+pay_invoice_txt.getText()+"' and debit='0'");
             psg.executeUpdate();
             /////
             
             
             Statement pssw =con2.createStatement();
             Statement pssw1 =con2.createStatement();
             Statement smt1 =con2.createStatement();
             Statement pssws =con2.createStatement();
             Statement pssw11 =con2.createStatement();
             Statement smt11 =con2.createStatement();
                 //Ledger
          ResultSet rssw1=pssw1.executeQuery("select  l_under from ledger where l_name='"+a3+"'");
          while(rssw1.next())
          {
               String under2=rssw1.getString("l_under");
               smt1.executeUpdate("delete from `"+under2+"` where l_name='"+a3+"' and trans_id='"+pay_invoice_txt.getText()+"'");
          }
          
           ResultSet rssw=pssw.executeQuery("select  l_under from ledger where l_name='"+ledger.getSelectedItem().toString()+"'");
          while(rssw.next())
          {
          String under=rssw.getString("l_under");
              
          PreparedStatement psw=con2.prepareStatement("insert into `"+under+"` (l_name,debit,credit,trans_id,date)values('"+ledger.getSelectedItem().toString()+"','"+total_amount_txt.getText()+"','0','"+table_click+"','"+pay_date.getText()+"')");
          psw.executeUpdate();
             
          }
          //payment_ledger
          ResultSet rssw11=pssw1.executeQuery("select  l_under from ledger where l_name='"+a6+"'");

          while(rssw11.next())
          {
               String under2=rssw11.getString("l_under");
               smt11.executeUpdate("delete from `"+under2+"` where l_name='"+a6+"' and trans_id='"+pay_invoice_txt.getText()+"'");
          }
          
           ResultSet rssw111=pssw11.executeQuery("select  l_under from ledger where l_name='"+pay_combo.getSelectedItem().toString()+"'");
          while(rssw.next())
          {
              String under=rssw.getString("l_under");
              
             PreparedStatement psw=con2.prepareStatement("insert into `"+under+"` (l_name,credit,debit,trans_id,date)values('"+pay_combo.getSelectedItem().toString()+"','"+total_amount_txt.getText()+"','0','"+table_click+"','"+pay_date.getText()+"')");
          psw.executeUpdate();
             
          } 
 
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
           
            jOptionPane1.showMessageDialog(this,"Payment Details Updated");
          
            
        customer_name_txt.setText(null);
        pay_date.setText(null);
        ledger.setSelectedItem(null);
        ref_combo.removeAllItems();
        balance_txt.setText(null);
        pay_combo.setSelectedItem(null);
        bank_name_txt.setText(null);
        branch_name_txt.setText(null);
        cheque_no_txt.setText(null);
        total_amount_txt.setText(null);
        amount_in_word_txt.setText(null);
        payment_for_txt.setText(null);
        
         create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
        
       
        customer_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pay_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ledger.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ref_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pay_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        branch_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        cheque_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        total_amount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        amount_in_word_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        payment_for_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        
            
        }
       
        }
        else{
            
        }

    }//GEN-LAST:event_save_buttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed

        p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(p==0)
        {
            System.out.println(p);
            try{

               
                Connection con1 = Database.getConnection();
                Statement smt11 =con1.createStatement();
                Statement smt12 =con1.createStatement();
                Statement pq =con1.createStatement();
                Statement pr =con1.createStatement();
                PreparedStatement ps1=con1.prepareStatement("delete from payment where pay_invoice='"+pay_invoice_txt.getText()+"'");

                ps1.executeUpdate();
                
                log_table.table_delete("payment",jLabel15.getText());

                //ledger delete
                ResultSet rp=pq.executeQuery("select  l_under from ledger where l_name='"+ledger.getSelectedItem().toString()+"'");
                while(rp.next())
                {
                    String under=rp.getString("l_under");
                    smt11.executeUpdate("delete from `"+under+"` where trans_id='"+pay_invoice_txt.getText()+"'");
                }
                //receipt _ledger delete
                ResultSet rw=pr.executeQuery("select  l_under from ledger where l_name='"+pay_combo.getSelectedItem().toString()+"'");
                while(rw.next())
                {
                    String unders=rw.getString("l_under");
                    smt12.executeUpdate("delete from `"+unders+"` where trans_id='"+pay_invoice_txt.getText()+"'");
                }
                System.out.println("Done");

            }catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
           

            jOptionPane1.showMessageDialog(this,"Payment Details Deleted");
        
        customer_name_txt.setText(null);
        pay_date.setText(null);
        ledger.setSelectedItem(null);
        ref_combo.removeAllItems();
        balance_txt.setText(null);
        pay_combo.setSelectedItem(null);
        bank_name_txt.setText(null);
        branch_name_txt.setText(null);
        cheque_no_txt.setText(null);
        total_amount_txt.setText(null);
        amount_in_word_txt.setText(null);
        payment_for_txt.setText(null);
        
         create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
        
       
        customer_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pay_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ledger.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ref_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pay_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        branch_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        cheque_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        total_amount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        amount_in_word_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        payment_for_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           

        }
    }//GEN-LAST:event_delete_buttonActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed

        
        customer_name_txt.setText(null);
        pay_date.setText(null);
        ledger.setSelectedItem(null);
        ref_combo.removeAllItems();
        balance_txt.setText(null);
        pay_combo.setSelectedItem(null);
        bank_name_txt.setText(null);
        branch_name_txt.setText(null);
        cheque_no_txt.setText(null);
        total_amount_txt.setText(null);
        amount_in_word_txt.setText(null);
        payment_for_txt.setText(null);
        
         create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
        
       
        customer_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pay_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ledger.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ref_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pay_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        branch_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        cheque_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        total_amount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        amount_in_word_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        payment_for_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        
        
    }//GEN-LAST:event_clearActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amount_in_word_txt;
    private javax.swing.JTextField balance_txt;
    private javax.swing.JTextField bank_name_txt;
    private javax.swing.JTextField branch_name_txt;
    private javax.swing.JTextField cheque_no_txt;
    private javax.swing.JButton clear;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private javax.swing.JTextField customer_name_txt;
    private javax.swing.JButton delete_button;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    public javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox ledger;
    private javax.swing.JComboBox pay_combo;
    private javax.swing.JTextField pay_date;
    private javax.swing.JTextField pay_invoice_txt;
    private javax.swing.JTextArea payment_for_txt;
    private javax.swing.JComboBox ref_combo;
    private javax.swing.JButton save_button;
    private javax.swing.JTextField total_amount_txt;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    // End of variables declaration//GEN-END:variables

}
