package final_project;

/**
 *
 * @author pc 5
 */
import java.text.DecimalFormat;
import java.text.Format;
import java.util.Locale;
import java.util.Scanner;
public class ConvertMoneyToNumberMain {
    public static String convertion(String a){
        String str2 = "";
        NumToWords n2w = new NumToWords();
//        Scanner input = new Scanner(System.in);
//        System.out.print("Enter Money Amount(Rs.Ps): ");
        String amt = a;
        DecimalFormat df = new DecimalFormat("0.00");
        df.setMaximumFractionDigits(2);
        Double amt2 = Double.parseDouble(amt);
        amt= df.format(amt2);
        Double amt5= Double.parseDouble(amt);
        int rupees = Integer.parseInt(amt.split("\\.")[0]);
        String str1 = n2w.convert(rupees);
        str1 += " Rupees ";
        int paise = Integer.parseInt(amt.split("\\.")[1]);        
        double paise2= paise+0.0001;
        if (paise2 == 0.0001) {
                str2 = "";
                }
            else
                {
                str2 += "and ";
                str2 += n2w.convert((int) paise);
                str2 += " Paise ";
                }
//            System.out.println(str1 + str2 + "Only");
            String total_in_words= str1+str2+"Only";
//            Format format = com.ibm.icu.text.NumberFormat.getCurrencyInstance(new Locale("en", "INR"));
//            System.out.println(format.format(amt5));
            return (total_in_words);
} 
    
//public static void main(String args[]) {
//        convertion();
//    }
}