package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import org.jdesktop.xswingx.PromptSupport;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class customer_edit_panel extends javax.swing.JPanel {
     Font myFont = new Font("",Font.PLAIN,9);
     int i=0,j=0,k=0;                    // for Mandatory
     int x=0,y=0,z=0,p=0,q=0;           // For Non Mandatory
     String user_activity_id="";
    /**
     * Creates new form customer_edit_panel
     */
      String country_name="";
    String country_id1="";
    String isd="";
    String state_name="";
    String state_id="";
    
    String city_name1="";
    String city_id="";
     
     
     public void set(){
         search_text.requestFocusInWindow();
         search_text.setFocusable(true);
     }
     
     public void user(String u_name){
         jLabel19.setText(u_name);
     }
     
    public customer_edit_panel() {
//         JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
       
         initComponents();
         set();
        name_txt.setFocusable(true);
       // name_txt.setEditable(false);
        
        create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
        
        jLabel2.setFont(myFont);
        jLabel2.setEnabled(false);
        jLabel2.setVisible(false);
        
        jLabel5.setFont(myFont);
        jLabel5.setEnabled(false);
        jLabel5.setVisible(false);
        
        jLabel18.setFont(myFont);
        jLabel18.setEnabled(false);
        jLabel18.setVisible(false);
        
        jLabel4.setFont(myFont);
        jLabel4.setEnabled(false);
        jLabel4.setVisible(false);
        
        jLabel6.setFont(myFont);
        jLabel6.setEnabled(false);
        jLabel6.setVisible(false);
        
        jLabel7.setFont(myFont);
        jLabel7.setEnabled(false);
        jLabel7.setVisible(false);
        
        jLabel8.setFont(myFont);
        jLabel8.setEnabled(false);
        jLabel8.setVisible(false);
        
        jLabel9.setFont(myFont);
        jLabel9.setEnabled(false);
        jLabel9.setVisible(false);
        
        jLabel10.setFont(myFont);
        jLabel10.setEnabled(false);
        jLabel10.setVisible(false);
        
        jLabel11.setFont(myFont);
        jLabel11.setEnabled(false);
        jLabel11.setVisible(false);
        
        jLabel12.setFont(myFont);
        jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        jLabel13.setFont(myFont);
        jLabel13.setEnabled(false);
        jLabel13.setVisible(false);
        
        jLabel14.setFont(myFont);
        jLabel14.setEnabled(false);
        jLabel14.setVisible(false);
        
        jLabel15.setFont(myFont);
        jLabel15.setEnabled(false);
        jLabel15.setVisible(false);
        
        jLabel16.setFont(myFont);
        jLabel16.setEnabled(false);
        jLabel16.setVisible(false);
        
        jLabel17.setFont(myFont);
        jLabel17.setEnabled(false);
        jLabel17.setVisible(false);
        
       
        jLabel19.setVisible(false);
        
        c_dob.setVisible(false);
        L_Name.setVisible(false);
        c_name.setVisible(false);
        under_name.setVisible(false);
        
        U_label.setEnabled(false);
        under_txt.setEnabled(false);
        
        PromptSupport.setPrompt("John Smith", name_txt);
        PromptSupport.setPrompt("dd/mm/yyyy", c_dob);
        PromptSupport.setPrompt("12, ABC Road", address_txt);
        PromptSupport.setPrompt("123456", pin_num);
        PromptSupport.setPrompt("abc@xyz.com", Email_Id_txt);
        PromptSupport.setPrompt("+911234567890", mobile_no_txt);
        PromptSupport.setPrompt("+91123456789", phone_no_txt);
        PromptSupport.setPrompt("12345678901", cst_no_txt);
        PromptSupport.setPrompt("12345678901", vat_no_txt);
        PromptSupport.setPrompt("AAAPL1234C", pan_no_txt);
       // company();
        update_table();
        search();
        
        country();
        state();
       // city();
        
        c_id.setVisible(false);
        
        company.setEnabled(false);
        table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }

            
        });
        
//        try{
//        
//          Connection con = Database.getConnection();
//        Statement ps =con.createStatement();
//           ResultSet rs=ps.executeQuery("select distinct g_name from acc_group group by acc_g_id");
//          while(rs.next())
//          {
//              String name=rs.getString("g_name");
//             
//              under_txt.addItem(name);
//             
//          }
//         
//        con.close();
//         
//        }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
        
        
        
//         try{
//        
//            Connection con = Database.getConnection();
//        Statement ps =con.createStatement();
//           ResultSet rs=ps.executeQuery("select distinct company_name,company_id from company_creation");
////            jComboBox1.addItem(d2); 
////           jComboBox1.setSelectedItem(d2);
//           while(rs.next())
//          {
//              String name=rs.getString("company_name");
//             int cc_id=Integer.parseInt(rs.getString("company_id"));
//              company.addItem(name);
//              System.out.println(cc_id);
//          }
//         // String name1="Others";
//          //jComboBox1.addItem(name1);
//            
//         con.close();
//        }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
        
        
    
    }

    
    class FocusGrabber implements Runnable {
  private JComponent component;

  public FocusGrabber(JComponent component) {
    this.component = component;
  }

  public void run() {
    component.grabFocus();
  }
}
  
    
    
     public void company(){
         try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct company_name from company_creation");
          
            while(rs.next())
            {
                  String company1=rs.getString("company_name");
//                country_id1=rs.getString("country_id");
//                isd=rs.getString("isd_code");

                company.addItem(company1);
               
            }
          // con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }
       ///c_name
     
     public void c_name(){
          if(name_txt.getText().length()==0)
        {
            i=0;
             name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel2.setEnabled(true);
             jLabel2.setForeground(Color.red);
             jLabel2.setVisible(true);
        }
        else
        {
            String content = name_txt.getText();
            Pattern p = Pattern.compile("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z][\\'\\,\\.\\- ]*)*$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            System.out.println(matchFound);
            name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel2.setEnabled(false);  
            jLabel2.setVisible(false);
            i=1;
            if(!matchFound)
            {
                i=0;

                name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel2.setEnabled(true);
                jLabel2.setForeground(Color.red);
                jLabel2.setVisible(true);
                
            }
        }
     }
     // under
     public void under(){
          if(under_txt.getSelectedItem().equals(""))
       {
          under_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel5.setEnabled(true);
          jLabel5.setForeground(Color.red);
          jLabel5.setVisible(true);
       }
       else
       {
           under_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel5.setEnabled(false);  
           jLabel5.setVisible(false);
           j=1;
       }
     }
     
       // phone no
     
     public void phone(){
         if(phone_no_txt.getText().length()==0)
        {
            k=0;
            phone_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel13.setEnabled(true);
            jLabel13.setForeground(Color.red);
            jLabel13.setVisible(true);
        }
        else
        {
            String content = phone_no_txt.getText();
            Pattern p = Pattern.compile("[+]\\d{3,16}");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            phone_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel13.setEnabled(false);  
            jLabel13.setVisible(false);
             k=1;
           
            if(!matchFound)

            {
                 k=0;
                 phone_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel13.setEnabled(true);
                 jLabel13.setForeground(Color.red);
                 jLabel13.setVisible(true);
                
                 
            }
        }
     }
    
   
    
     private void tableMouseClicked(java.awt.event.MouseEvent evt) 
           {                  
               
under_txt.removeAll();
      // v_under.setVisible(false);
//c_name.setVisible(false);
L_Name.setVisible(true);
c_dob.setVisible(true);
            int new1=table.getSelectedRow();
            String table_click=(table.getModel().getValueAt(new1, 0).toString());
        try{
         
           Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
         Statement ps2 =con1.createStatement();
                //   ResultSet rs2=ps2.executeQuery("SELECT DAYOFMONTH(v_dob) AS day,MONTH(v_dob) as month,YEAR(v_dob) as year from vendor where v_name='"+table_click+"'");
           ResultSet rs1=ps1.executeQuery("SELECT * from customer where c_name='"+table_click+"' ");
            //jComboBox1.removeAll();
       while(rs1.next())
                {
                      String  id=rs1.getString("c_id");
                        c_id.setText(id);
                  
                     String  aa=rs1.getString("c_name");
                      name_txt.setText(aa);
                      c_name.setText(aa);
                      
                     String a1=rs1.getString("c_under");
                   // c_name.setText(a1);
                    
                  under_txt.setSelectedItem(a1);
                  under_name.setText(a1);
                  
                   String a2=rs1.getString("c_dob");
                  c_dob.setText(a2);
                     
                    String a6=rs1.getString("c_pin");
                   pin_num.setText(a6);
                        
                 String a4=rs1.getString("c_eid");
                   Email_Id_txt.setText(a4);
                   
                    String a5=rs1.getString("c_gender");
                    String g1="Male";
                     String g2="Female";
                     if(a5.compareTo(g1)==0){
                      male_radiobutton.setSelected(true);
                    }
                     else if(a5.compareTo(g2)==0){
                        Female_radio.setSelected(true);
                       
                        
                    }
                     else{
                         Company_radio.setSelected(true);
                     }
                     
                    String a7=rs1.getString("c_address");
                    address_txt.setText(a7);
                    
                    String c_type=rs1.getString("c_company_name");
                    company.setSelectedItem(c_type);
                    
                     String a8=rs1.getString("c_city");
                     c_city.setText(a8);
                       
                     String a10=rs1.getString("c_country");
                     c_country.setSelectedItem(a10);
                     
                     String a9=rs1.getString("c_state");
                    c_state.setSelectedItem(a9);
                    
                     
                     
                     
                     String a13=rs1.getString("c_mb_no");
                    mobile_no_txt.setText(a13);
                    
                    String a14=rs1.getString("c_ph_no");
                  phone_no_txt.setText(a14);
                   
                    String a16=rs1.getString("c_vat_no");
                    vat_no_txt.setText(a16);
                    
                      String a18=rs1.getString("c_cst_no");
                    cst_no_txt.setText(a18);
                    
                    String a19=rs1.getString("c_pan");
                   pan_no_txt.setText(a19);
                
                    
                    String a30=rs1.getString("opening_balance");
                    opening_balance_num.setText(a30);
                    
                    String a303=rs1.getString("c_dob");
                    c_dob.setText(a303);
                    
                      Statement ps3 =con1.createStatement();
                ResultSet rs2=ps3.executeQuery("SELECT * from user_activity_table where table_name='customer' and value='"+c_name.getText()+"'");
                while(rs2.next())
            {
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                
                }
        
          con1.close();
          //jComboBox1.removeAll();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        
    }
    
    public void search(){
        search_text.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   String s1=search_text.getText();

 
 
 String s3=s1;
     
                    try{
                   Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT c_name as `CUSTOMER NAME` from customer where c_name like '"+s3+"%'"); 
          
              
                table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
                    con.close();
                    }
                    catch (SQLException e1){
        System.out.println("Sql Exception" + e1.toString());
        }
       
                
}
            });
    } 
public void update_table()
{ 
       
        try{
        
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT c_name as `CUSTOMER NAME` from customer ");
          table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
           
         con.close();
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
        
        table.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   
int keyvalue=e.getKeyCode();
if(keyvalue==KeyEvent.VK_ENTER)
                {
                   // jComboBox1.setVisible(false);
//jTextField2.setVisible(true);
                 int row=table.getSelectedRow();
                 int col=table.getSelectedColumn();
                
                if(table.getValueAt(row, 0) != null){
                String s1= (String)table.getValueAt(row, 0);
                
                
//JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());

System.out.println(" Value in the row clicked :"+ " " +row+"");
System.out.println(" Value in the col clicked :"+ " " +col+"");
System.out.println(" Value in the col,row clicked :"+ " " +s1+"");

          try{
         
           Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
          Statement ps2 =con1.createStatement();
           ResultSet rs1=ps1.executeQuery("SELECT * from customer where c_name='"+s1+"' ");
       while(rs1.next())
                {
                    
                           // jComboBox1.removeAll(); 
                    
                 
                      String  id=rs1.getString("c_id");
                  c_id.setText(id);
                  
                     String  aa=rs1.getString("c_name");
                      name_txt.setText(aa);
                      c_name.setText(aa);
                      
                     String a1=rs1.getString("c_under");
                   // c_name.setText(a1);
                    
                  under_txt.setSelectedItem(a1);
                  under_name.setText(a1);
                  
                   String a2=rs1.getString("c_dob");
                  c_dob.setText(a2);
                     
                    String a6=rs1.getString("c_pin");
                   pin_num.setText(a6);
                        
                 String a4=rs1.getString("c_eid");
                   Email_Id_txt.setText(a4);
                   
                    String a5=rs1.getString("c_gender");
                    String g1="Male";
                     String g2="Female";
                     if(a5.compareTo(g1)==0){
                      male_radiobutton.setSelected(true);
                    }
                     else if(a5.compareTo(g2)==0){
                        Female_radio.setSelected(true);
                       
                        
                    }
                     else{
                         Company_radio.setSelected(true);
                     }
                     
                    String a7=rs1.getString("c_address");
                    address_txt.setText(a7);
                    
                    String c_type=rs1.getString("c_company_name");
                    company.setSelectedItem(c_type);
                    
                     String a8=rs1.getString("c_city");
                     c_city.setText(a8);
                     
                     String a10=rs1.getString("c_country");
                     c_country.setSelectedItem(a10);  
                     
                     String a9=rs1.getString("c_state");
                    c_state.setSelectedItem(a9);
                    
                     
                     
                     
                     String a13=rs1.getString("c_mb_no");
                    mobile_no_txt.setText(a13);
                    
                    String a14=rs1.getString("c_ph_no");
                  phone_no_txt.setText(a14);
                   
                    String a16=rs1.getString("c_vat_no");
                    vat_no_txt.setText(a16);
                    
                      String a18=rs1.getString("c_cst_no");
                    cst_no_txt.setText(a18);
                    
                    String a19=rs1.getString("c_pan");
                   pan_no_txt.setText(a19);
                
                    
                    String a30=rs1.getString("opening_balance");
                    opening_balance_num.setText(a30);
                    
                    String a303=rs1.getString("c_dob");
                    c_dob.setText(a303);
                    
                      Statement ps3 =con1.createStatement();
                ResultSet rs2=ps3.executeQuery("SELECT * from user_activity_table where table_name='customer' and value='"+c_name.getText()+"'");
                while(rs2.next())
            {
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                }
          
         con1.close();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        

                }  }



}

}

);
    Action delete = new AbstractAction()
{
    public void actionPerformed(ActionEvent e)
    {
        
    }
};
 
 
}
    
public void country(){
         try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select * from country_name order by country_id");
          
            while(rs.next())
            {
                country_name=rs.getString("country_name");
                country_id1=rs.getString("country_id");
                isd=rs.getString("isd_code");

                c_country.addItem(country_name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }
    
    public void state(){
          try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct * from state_name order by state_id");
          
            while(rs.next())
            {
                String name=rs.getString("state_name");
                String id=rs.getString("state_id");

                c_state.addItem(name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
    }
    
    
     public void city(){
          try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct * from city_name order by city_id");
          
            while(rs.next())
            {
                String city_name1=rs.getString("city_name");
                String city_id1=rs.getString("city_id");

               // c_city.addItem(city_name1);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
    }
     
    
    
      
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        c_id = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        L_Name = new javax.swing.JLabel();
        name_txt = new javax.swing.JTextField();
        U_label = new javax.swing.JLabel();
        male_radiobutton = new javax.swing.JRadioButton();
        Female_radio = new javax.swing.JRadioButton();
        Company_radio = new javax.swing.JRadioButton();
        A_label = new javax.swing.JLabel();
        C_label = new javax.swing.JLabel();
        S_label = new javax.swing.JLabel();
        Co_label = new javax.swing.JLabel();
        P_label = new javax.swing.JLabel();
        E_label = new javax.swing.JLabel();
        Email_Id_txt = new javax.swing.JTextField();
        M_label = new javax.swing.JLabel();
        mobile_no_txt = new javax.swing.JTextField();
        Ph_label = new javax.swing.JLabel();
        phone_no_txt = new javax.swing.JTextField();
        V_label = new javax.swing.JLabel();
        vat_no_txt = new javax.swing.JTextField();
        Cst_label = new javax.swing.JLabel();
        cst_no_txt = new javax.swing.JTextField();
        Pan_label = new javax.swing.JLabel();
        pan_no_txt = new javax.swing.JTextField();
        Op_label = new javax.swing.JLabel();
        under_txt = new javax.swing.JComboBox();
        address_txt = new javax.swing.JTextField();
        c_dob = new javax.swing.JTextField();
        company = new javax.swing.JComboBox();
        opening_balance_num = new numeric.textField.NumericTextField();
        pin_num = new numeric.textField.NumericTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        c_city = new javax.swing.JTextField();
        c_state = new com.jidesoft.swing.AutoCompletionComboBox();
        c_country = new com.jidesoft.swing.AutoCompletionComboBox();
        jPanel3 = new javax.swing.JPanel();
        save_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        clear_button = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        search_text = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        c_name = new javax.swing.JTextField();
        under_name = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        create_date = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        update_date = new javax.swing.JTextField();

        c_id.setEnabled(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Customer Edit/Delete");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("*Name:");

        L_Name.setForeground(new java.awt.Color(0, 0, 255));
        L_Name.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        L_Name.setText("Date Of Birth:");

        name_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        name_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                name_txtFocusLost(evt);
            }
        });

        U_label.setForeground(new java.awt.Color(0, 0, 255));
        U_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        U_label.setText("*Under:");

        buttonGroup1.add(male_radiobutton);
        male_radiobutton.setForeground(new java.awt.Color(0, 0, 255));
        male_radiobutton.setText("Male");
        male_radiobutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                male_radiobuttonActionPerformed(evt);
            }
        });

        buttonGroup1.add(Female_radio);
        Female_radio.setForeground(new java.awt.Color(0, 0, 255));
        Female_radio.setText("Female");
        Female_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Female_radioActionPerformed(evt);
            }
        });

        buttonGroup1.add(Company_radio);
        Company_radio.setForeground(new java.awt.Color(0, 0, 255));
        Company_radio.setText("Company");
        Company_radio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Company_radioActionPerformed(evt);
            }
        });

        A_label.setForeground(new java.awt.Color(0, 0, 255));
        A_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        A_label.setText("Address:");

        C_label.setForeground(new java.awt.Color(0, 0, 255));
        C_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        C_label.setText("City:");

        S_label.setForeground(new java.awt.Color(0, 0, 255));
        S_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        S_label.setText("State:");

        Co_label.setForeground(new java.awt.Color(0, 0, 255));
        Co_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Co_label.setText("Country:");

        P_label.setForeground(new java.awt.Color(0, 0, 255));
        P_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        P_label.setText("Pin:");

        E_label.setForeground(new java.awt.Color(0, 0, 255));
        E_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        E_label.setText("Email Id:");

        Email_Id_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        Email_Id_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Email_Id_txtFocusLost(evt);
            }
        });

        M_label.setForeground(new java.awt.Color(0, 0, 255));
        M_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        M_label.setText("Mobile No:");

        mobile_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        mobile_no_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                mobile_no_txtFocusLost(evt);
            }
        });

        Ph_label.setForeground(new java.awt.Color(0, 0, 255));
        Ph_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Ph_label.setText("Phone No:");

        phone_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        phone_no_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                phone_no_txtFocusLost(evt);
            }
        });

        V_label.setForeground(new java.awt.Color(0, 0, 255));
        V_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        V_label.setText("VAT No:");

        vat_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        Cst_label.setForeground(new java.awt.Color(0, 0, 255));
        Cst_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Cst_label.setText("CST No:");

        cst_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        Pan_label.setForeground(new java.awt.Color(0, 0, 255));
        Pan_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Pan_label.setText("PAN No:");

        pan_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        Op_label.setForeground(new java.awt.Color(0, 0, 255));
        Op_label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Op_label.setText("Opening Balance:");

        under_txt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Sundry Debtors" }));
        under_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        under_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                under_txtFocusLost(evt);
            }
        });

        address_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        c_dob.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_dob.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                c_dobFocusLost(evt);
            }
        });

        company.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " ", "Sole Proprietorship", "Partnership", "Limited Liability Partnership", "Private Limited Company", "Public Limited Company", "HUF (Hindu Undivided Family)", "Cooperative", "Family Owned Business", "Unlimited Company", "Public Sector Unit (PSU)" }));
        company.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        opening_balance_num.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        opening_balance_num.setText("0.00");
        opening_balance_num.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                opening_balance_numFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                opening_balance_numFocusLost(evt);
            }
        });

        pin_num.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pin_num.setText("numericTextField1");
        pin_num.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                pin_numFocusLost(evt);
            }
        });

        jLabel2.setText("Enter Customer Name!");

        jLabel4.setText("Enter Valid Date Format!");

        jLabel5.setText("Select Under!");

        jLabel6.setText("Enter Your Address!");

        jLabel7.setText("Enter City Name!");

        jLabel8.setText("Enter State Name!");

        jLabel9.setText("Enter Country Name!");

        jLabel10.setText("Enter Pincode!");

        jLabel11.setText("Enter Valid Email ID!");

        jLabel12.setText("Enter Valid Mobile!");

        jLabel13.setText("Enter Valid Phone Number!");

        jLabel14.setText("Enter Valid VAT Number!");

        jLabel15.setText("Enter Valid CST Number!");

        jLabel16.setText("Enter Valid PAN Number!");

        jLabel17.setText("Enter Valid Opening Balance!");

        jLabel18.setText("Select Company Name!");

        c_state.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select" }));
        c_state.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_stateActionPerformed(evt);
            }
        });

        c_country.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select" }));
        c_country.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_countryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(L_Name)
                            .addComponent(jLabel3)
                            .addComponent(U_label)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(male_radiobutton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Female_radio)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(under_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(c_dob, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(name_txt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(A_label)
                            .addComponent(C_label)
                            .addComponent(S_label)
                            .addComponent(Co_label)
                            .addComponent(P_label)
                            .addComponent(E_label)
                            .addComponent(M_label)
                            .addComponent(Ph_label)
                            .addComponent(V_label)
                            .addComponent(Cst_label)
                            .addComponent(Pan_label)
                            .addComponent(Op_label))
                        .addGap(0, 37, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cst_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(vat_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phone_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mobile_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Email_Id_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pin_num, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(address_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pan_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(opening_balance_num, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(c_city, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c_state, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c_country, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(Company_radio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(company, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {A_label, C_label, Co_label, Cst_label, E_label, L_Name, M_label, Op_label, P_label, Pan_label, Ph_label, S_label, U_label, V_label, jLabel3});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(U_label)
                    .addComponent(under_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Company_radio)
                    .addComponent(company, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(male_radiobutton)
                    .addComponent(Female_radio)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(L_Name)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c_dob, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(A_label)
                    .addComponent(address_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Co_label)
                    .addComponent(c_country, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(S_label)
                    .addComponent(c_state, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(C_label)
                    .addComponent(c_city, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(P_label)
                    .addComponent(pin_num, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Email_Id_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(E_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mobile_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(M_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phone_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Ph_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(vat_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(V_label))
                .addGap(4, 4, 4)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cst_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Cst_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pan_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pan_label))
                .addGap(5, 5, 5)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Op_label)
                    .addComponent(opening_balance_num, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel17)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N
        jPanel3.setPreferredSize(new java.awt.Dimension(234, 188));

        save_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        save_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save_button.setText("Save");
        save_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_buttonActionPerformed(evt);
            }
        });

        delete_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete_button.setText("Delete");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });

        clear_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        clear_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        clear_button.setText("Clear");
        clear_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clear_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(delete_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(save_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(save_button)
                .addGap(18, 18, 18)
                .addComponent(delete_button)
                .addGap(18, 18, 18)
                .addComponent(clear_button)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), java.awt.Color.blue)); // NOI18N

        search_text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_textActionPerformed(evt);
            }
        });

        table.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        table.setForeground(new java.awt.Color(0, 0, 255));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(search_text, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(search_text, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jLabel19.setText("jLabel19");
        jLabel19.setEnabled(false);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 10), java.awt.Color.cyan)); // NOI18N

        jLabel20.setForeground(new java.awt.Color(51, 153, 0));
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel20.setText("Created By:");

        create_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_userActionPerformed(evt);
            }
        });

        jLabel21.setForeground(new java.awt.Color(51, 153, 0));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("Creation Date:");

        jLabel22.setForeground(new java.awt.Color(51, 153, 0));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel22.setText("Updated By:");

        jLabel23.setForeground(new java.awt.Color(51, 153, 0));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel23.setText("Updation Date:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(10, 10, 10)))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_date, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(c_id, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(under_name, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(c_name, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE))
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 583, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(c_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(c_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(under_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(jLabel19)
                                .addGap(34, 34, 34)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0))
        );

        jScrollPane2.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1603, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1819, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void save_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_buttonActionPerformed
//JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
    if(c_id.getText().equals(""))
     {
           jopt1.showMessageDialog(this,"Select Customer Name!"); 
     }
    else{
        c_name();
        under();
        phone();
        if(i==1&&j==1&&k==1&&x==0&&y==0&&z==0&&p==0&&q==0)
        {

                                      
    if(c_name.getText().equals(null))
     {
           jopt1.showMessageDialog(this,"Enter Valid Customer Name!"); 
     }
                           else{
           
                   
        try{

            Connection con2 = Database.getConnection();

            
             Statement ps5 =con2.createStatement(); 
                           ResultSet rs5=ps5.executeQuery("SELECT l_name,c_name from ledger,customer where l_name='"+name_txt.getText()+"' and l_name=c_name and c_id!='"+c_id.getText()+"'");

//                if(rs5.next())
//                    {
//                    jopt1.showMessageDialog(this,"Customer Already Exsist"); 
//                    }
//                else{
//                    PreparedStatement ps10=con2.prepareStatement("update user_activity_table set value='"+name_txt.getText()+"' where  value='"+c_name.getText()+"'");
//                ps10.executeUpdate();
                           
                   log_table.table_update("customer",name_txt.getText(),user_activity_id);
                PreparedStatement ps1=con2.prepareStatement("update customer set c_name='"+name_txt.getText()+"',c_under='"+under_txt.getSelectedItem().toString()+"',c_address='"+address_txt.getText()+"',c_country='"+c_country.getSelectedItem().toString()+"',c_state='"+c_state.getSelectedItem().toString()+"',c_city='"+c_city.getText()+"',c_pin='"+pin_num.getText()+"',c_eid='"+Email_Id_txt.getText()+"',c_mb_no='"+mobile_no_txt.getText()+"',c_ph_no='"+phone_no_txt.getText()+"',c_vat_no='"+vat_no_txt.getText()+"',c_cst_no='"+cst_no_txt.getText()+"',c_pan='"+pan_no_txt.getText()+"', opening_balance='"+opening_balance_num.getText()+"',c_gender='"+gender+"',c_company_name='"+company.getSelectedItem().toString()+"' where  c_id='"+c_id.getText()+"' and c_name='"+c_name.getText()+"'");
                ps1.executeUpdate();
                 PreparedStatement ps11=con2.prepareStatement("update ledger set l_name='"+name_txt.getText()+"',l_under='"+under_txt.getSelectedItem().toString()+"',l_address='"+address_txt.getText()+"',l_country='"+c_country.getSelectedItem().toString()+"',l_state='"+c_state.getSelectedItem().toString()+"',l_city='"+c_city.getText()+"', l_opning_balance='"+opening_balance_num.getText()+"' where  l_name='"+c_name.getText()+"'");
                ps11.executeUpdate();
                  PreparedStatement ps3=con2.prepareStatement("delete from  `"+under_name.getText()+"` where l_name='"+name_txt.getText()+"' ");

                ps3.executeUpdate();
                PreparedStatement ps4=con2.prepareStatement("insert into `"+under_txt.getSelectedItem().toString()+"`(l_name,debit)values('"+name_txt.getText()+"','"+opening_balance_num.getText()+"')");
                ps4.executeUpdate();
                
                try{
           Connection con1 = Database.getConnection();
           Statement ps6 =con1.createStatement(); 
           ResultSet rs6=ps6.executeQuery("SELECT city_name from city_name where city_name='"+c_city.getText()+"'");

if(rs6.next())
{
  //   jopt1.showMessageDialog(this,"City Already Exsist"); 
}
else{
    PreparedStatement ps2=con1.prepareStatement("insert into city_name (country_id,state_id,city_name)values('"+country_id1+"','"+state_id+"','"+c_city.getText()+"')");
            ps2.executeUpdate();
            
           // jopt1.showMessageDialog(this,"New City Saved"); 
}
            }
            catch(Exception e){
                
            }
                
                
                
                jopt1.showMessageDialog(this,"Customer Updated");
               
                male_radiobutton.setSelected(false);
                Female_radio.setSelected(false);
                Company_radio.setSelected(false);
                //jComboBox1.removeAll();
                // }
            /* else{
                PreparedStatement ps1=con2.prepareStatement("update ledger set l_name='"+under_txt.getText()+"',l_under='"+jComboBox1.getSelectedItem().toString()+"',l_address='"+state_txt.getText()+"',l_state='"+country_txt.getText()+"',l_acc_no='"+jTextField5.getText()+"',l_pan='"+jTextField5.getText()+"',l_sale_tax_no='"+jTextField6.getText()+"',l_branch='"+jTextField7.getText()+"',l_bsr_code='"+jTextField8.getText()+"',l_opning_balance='"+jTextField9.getText()+"',l_persentage='"+jTextField10.getText()+"' where  l_id='"+jTextField12.getText()+"'");
                ps1.executeUpdate();
                jopt1.showMessageDialog(this,"Ledger Updated");
                update_table();
                under_txt.setText(null);
                city_txt.setText(null);
                state_txt.setText(null);
                country_txt.setText(null);
                jTextField5.setText(null);
                jTextField6.setText(null);
                jTextField7.setText(null);
                jTextField8.setText(null);
                jTextField9.setText(null);
                jTextField10.setText(null);
                jTextField11.setText(null);
                jTextField12.setText(null);
                jComboBox1.removeAll();
            }*/
        
               // }
        con2.close(); 
                           
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
    }
         update_table();
        reset();
        search();
        set();
                                  
        }
    }
                     
                   
     

    }//GEN-LAST:event_save_buttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
if(c_id.getText().equals(""))
     {
           jopt1.showMessageDialog(this,"Select Customer Name!"); 
     }
else{
        int p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(p==0)
        {
            try{

               Connection con1 = Database.getConnection();
                Statement ps5 =con1.createStatement(); 
            ResultSet rs5=ps5.executeQuery("SELECT distinct flag from company_main_table where ledger='"+c_name.getText()+"' and type!='Opening'");

            if(rs5.next())
            {
               // String fl=rs5.getString("flag");
               
                 jopt1.showMessageDialog(this,"Customer can't be deleted "+""+"\n"+""+"Delete the transactions first"); 
                 
                 
            }
            
            else{
                log_table.table_delete("customer",jLabel19.getText());
                PreparedStatement ps1=con1.prepareStatement("delete from  customer where c_id='"+c_id.getText()+"'");

                ps1.executeUpdate();
             PreparedStatement ps11=con1.prepareStatement("delete from  ledger where l_name='"+c_name.getText()+"'");

                ps11.executeUpdate();
                PreparedStatement ps3=con1.prepareStatement("delete from  `"+c_name.getText()+"` where l_name='"+c_name.getText()+"' ");

                ps3.executeUpdate();
                System.out.println("Done");
                
                 
                con1.close();
            }
            }catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
            jopt1.showMessageDialog(this,"Customer Deleted");
             update_table();
        reset();
        search();
        set();
        
            male_radiobutton.setSelected(false);
            Female_radio.setSelected(false);
            Company_radio.setSelected(false);
            

        }
        else{
            update_table();
        reset();
        search();
        set();
            male_radiobutton.setSelected(false);
            Female_radio.setSelected(false);
            Company_radio.setSelected(false);
        }
}
        // TODO add your handling code here:
    }//GEN-LAST:event_delete_buttonActionPerformed

    private void Company_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Company_radioActionPerformed
      company.setEnabled(true);
      c_dob.setEnabled(false);
      c_dob.setVisible(false);
       L_Name.setVisible(false);
      gender=company.getSelectedItem().toString();
      jLabel4.setVisible(false);
    }//GEN-LAST:event_Company_radioActionPerformed

    private void male_radiobuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_male_radiobuttonActionPerformed
       gender="Male";
       company.setEnabled(false);
       c_dob.setEnabled(true);
       c_dob.setVisible(true);
       L_Name.setVisible(true);
    }//GEN-LAST:event_male_radiobuttonActionPerformed

    private void Female_radioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Female_radioActionPerformed
      
        gender="Female";
        company.setEnabled(false);
        c_dob.setEnabled(true);
        c_dob.setVisible(true);
        L_Name.setVisible(true);
    }//GEN-LAST:event_Female_radioActionPerformed

    private void Email_Id_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Email_Id_txtFocusLost
         if(Email_Id_txt.getText().length()==0)
        {
             Email_Id_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel11.setEnabled(false);  
             jLabel11.setVisible(false);
             z=0;
        }
        else
        {
            String email =Email_Id_txt.getText();
            String regEx1 = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
            Pattern p1 = Pattern.compile(regEx1);
            Matcher m1 = p1.matcher(email);
            Email_Id_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel11.setEnabled(false);  
            jLabel11.setVisible(false);
            z=0;

            if(m1.find()==false)
            {
                z=1;
                Email_Id_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel11.setEnabled(true);
                jLabel11.setForeground(Color.red);
                jLabel11.setVisible(true);

            }
        }
    }//GEN-LAST:event_Email_Id_txtFocusLost

    private void mobile_no_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_mobile_no_txtFocusLost
        if(mobile_no_txt.getText().length()==0)
        {
             mobile_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel12.setEnabled(false);  
             jLabel12.setVisible(false);
             p=0;
        }
        else
        {
            String pin =mobile_no_txt.getText();
            String regEx = "[+]\\d{10,12}";
            Pattern p1 = Pattern.compile(regEx);
            Matcher m = p1.matcher(pin);
            boolean matchFound = m.matches();
            mobile_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel12.setEnabled(false);  
            jLabel12.setVisible(false);
            p=0;
            if(!matchFound)
            {
                p=1;
                mobile_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel12.setEnabled(true);
                jLabel12.setForeground(Color.red);
                jLabel12.setVisible(true);
            }

        }
    }//GEN-LAST:event_mobile_no_txtFocusLost

    private void pin_numFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_pin_numFocusLost
        if(pin_num.getText().length()==0)
        {
              pin_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              jLabel10.setEnabled(false);  
              jLabel10.setVisible(false);
              y=0;
        }
        else
        {
            String pin = pin_num.getText();
            String regEx = "\\d{6}";
            Pattern p = Pattern.compile(regEx);
            Matcher m = p.matcher(pin);
            pin_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel10.setEnabled(false);  
            jLabel10.setVisible(false);
            y=0;
            if(m.find()==false)
            {
                y=1;
                pin_num.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel10.setEnabled(true);
                jLabel10.setForeground(Color.red);
                jLabel10.setVisible(true);

            }
        }
                
    }//GEN-LAST:event_pin_numFocusLost

    private void name_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_name_txtFocusLost
          if(name_txt.getText().length()==0)
        {
            i=0;
             name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel2.setEnabled(true);
             jLabel2.setForeground(Color.red);
             jLabel2.setVisible(true);
        }
        else
        {
            String content = name_txt.getText();
            Pattern p = Pattern.compile("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z][\\'\\,\\.\\- ]*)*$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            System.out.println(matchFound);
            name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel2.setEnabled(false);  
            jLabel2.setVisible(false);
            i=1;
            if(!matchFound)
            {
                i=0;

                name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel2.setEnabled(true);
                jLabel2.setForeground(Color.red);
                jLabel2.setVisible(true);
                
            }
        }
    }//GEN-LAST:event_name_txtFocusLost

    private void c_dobFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_c_dobFocusLost
              if(c_dob.getText().length()==0)
        {
             c_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel4.setEnabled(false);  
             jLabel4.setVisible(false);
             x=0;   
        }
        else
        {
            String content = c_dob.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            c_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel4.setEnabled(false);  
            jLabel4.setVisible(false);
            x=0;
            
            if(!matchFound)

            {
                 x=1;

                 c_dob.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel4.setEnabled(true);
                 jLabel4.setForeground(Color.red);
                 jLabel4.setVisible(true);

            }
        }
    }//GEN-LAST:event_c_dobFocusLost

    private void phone_no_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phone_no_txtFocusLost
        if(phone_no_txt.getText().length()==0)
        {
            k=0;
            phone_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel13.setEnabled(true);
            jLabel13.setForeground(Color.red);
            jLabel13.setVisible(true);
        }
        else
        {
            String content = phone_no_txt.getText();
            Pattern p = Pattern.compile("[+]\\d{3,16}");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            phone_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel13.setEnabled(false);  
            jLabel13.setVisible(false);
             k=1;
           
            if(!matchFound)

            {
                 k=0;
                 phone_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel13.setEnabled(true);
                 jLabel13.setForeground(Color.red);
                 jLabel13.setVisible(true);
                
                 
            }
        }
    }//GEN-LAST:event_phone_no_txtFocusLost

    public void reset(){
          name_txt.setText(null);
        under_txt.setSelectedIndex(0);
        company.setSelectedIndex(0);
        c_dob.setText(null);
        address_txt.setText(null);
        c_country.setSelectedIndex(0);
        c_state.removeAllItems();
        c_state.addItem("Select");
        c_city.setText(null);
        
        
        pin_num.setText(null); 
        Email_Id_txt.setText(null);
        mobile_no_txt.setText(null);
        phone_no_txt.setText(null);
        vat_no_txt.setText(null);
        search_text.setText(null);
        opening_balance_num.setText("0.00");
        pan_no_txt.setText(null);
        cst_no_txt.setText(null);   
        create_user.setText(null);
        create_date.setText(null);
        update_user.setText(null);
        update_date.setText(null);
        
        c_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        under_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        company.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        c_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        address_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
       
        pin_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        Email_Id_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        mobile_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        phone_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        vat_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        opening_balance_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pan_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        cst_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));   
                
          
       
        
        jLabel2.setVisible(false);               
        jLabel5.setVisible(false);                
        jLabel18.setVisible(false);        
        jLabel4.setVisible(false);        
        jLabel6.setVisible(false);        
        jLabel7.setVisible(false);        
        jLabel8.setVisible(false);        
        jLabel9.setVisible(false);        
        jLabel10.setVisible(false);                
        jLabel11.setVisible(false);                
        jLabel12.setVisible(false);                
        jLabel13.setVisible(false);               
        jLabel14.setVisible(false);                
        jLabel15.setVisible(false);                
        jLabel16.setVisible(false);                
        jLabel17.setVisible(false);
    }
    
    private void clear_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_buttonActionPerformed
        // TODO add your handling code here:
        update_table();
        reset();
        search();
        set();
            male_radiobutton.setSelected(false);
            Female_radio.setSelected(false);
            Company_radio.setSelected(false);
        
    }//GEN-LAST:event_clear_buttonActionPerformed

    private void under_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_under_txtFocusLost
          if(under_txt.getSelectedItem().equals(""))
       {
          under_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel5.setEnabled(true);
          jLabel5.setForeground(Color.red);
          jLabel5.setVisible(true);
       }
       else
       {
           under_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel5.setEnabled(false);  
           jLabel5.setVisible(false);
           j=1;
       }
    }//GEN-LAST:event_under_txtFocusLost

    private void opening_balance_numFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_opening_balance_numFocusLost
       if(opening_balance_num.getText().length()==0)
        {
            opening_balance_num.setText("0.00");
              opening_balance_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              jLabel17.setEnabled(false);  
              jLabel17.setVisible(false);
              q=0;
        }
        else
        {
            String content = opening_balance_num.getText();
            Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            opening_balance_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel17.setEnabled(false);  
            jLabel17.setVisible(false);
            q=0;
            if(!matchFound)
            {
                q=1;
                opening_balance_num.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel17.setEnabled(true);
                jLabel17.setForeground(Color.red);
                jLabel17.setVisible(true);

            }
        }
    }//GEN-LAST:event_opening_balance_numFocusLost

    private void create_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_userActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_userActionPerformed

    private void search_textActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_textActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_textActionPerformed

    private void c_stateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_stateActionPerformed
        // TODO add your handling code here:
//          String c_name=c_state.getSelectedItem().toString();
//          if(c_name==" "){
//             c_state.setSelectedIndex(0);
//         }
//          else{
//        try{
//            Connection con1 = Database.getConnection();
//            Statement ps =con1.createStatement();
//            ResultSet rs=ps.executeQuery("select distinct country_id,state_id from state_name where state_name='"+c_name+"'");
//          //c_state.removeAllItems();
//            while(rs.next())
//            {
//                
//                state_id=rs.getString("state_id");
//                //isd=rs.getString("isd_code");
//
//                c_state.addItem(state_name);
//               
//            }
////            Statement ps1 =con1.createStatement();
////            ResultSet rs1=ps1.executeQuery("select distinct country_id,state_id,city_name from city_name where country_id='"+country_id1+"' and state_id='"+state_id+"'");
////           // c_city.removeAllItems();
////            while(rs1.next())
////                
////            {
////                city_name1=rs1.getString("city_name");
////                //state_id=rs1.getString("state_id");
////                //System.out.print(state_id);
////                c_city.setSelectedItem(city_name1);
////            }
//            
//            con1.close();
//        }
//        catch(Exception e){
//            
//        }
//        System.out.println(country_id1);
//        //c_ph_no.setText("+"+isd);
//       // c_mb_no.setText("+"+isd);
//          }
    }//GEN-LAST:event_c_stateActionPerformed

    private void c_countryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_countryActionPerformed
        // TODO add your handling code here:
           String c_name=c_country.getSelectedItem().toString();

        try{
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct country_id,isd_code from country_name where country_name='"+c_name+"'");
          
            while(rs.next())
            {
                
                country_id1=rs.getString("country_id");
//                l_country.addItem(country_name);   
                isd=rs.getString("isd_code");
            }
            c_state.removeAllItems();
            Statement ps1 =con1.createStatement();
            ResultSet rs1=ps1.executeQuery("SELECT DISTINCT state_name FROM state_name WHERE country_id='"+country_id1+"' ORDER BY state_name");
            //System.out.println("State "+ rs1);
             c_state.addItem("Select");
             //l_state.requestFocus();
            
            while(rs1.next())
                
            {
               
                state_name=rs1.getString("state_name");
                c_state.addItem(state_name);
            }
            
            con1.close();
        }
        catch(Exception e){
            
        }
        System.out.println(country_id1);
        phone_no_txt.setText("+"+isd);
        mobile_no_txt.setText("+"+isd);
    }//GEN-LAST:event_c_countryActionPerformed

    private void opening_balance_numFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_opening_balance_numFocusGained
        // TODO add your handling code here:
        opening_balance_num.setText("");
    }//GEN-LAST:event_opening_balance_numFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel A_label;
    private javax.swing.JLabel C_label;
    private javax.swing.JLabel Co_label;
    private javax.swing.JRadioButton Company_radio;
    private javax.swing.JLabel Cst_label;
    private javax.swing.JLabel E_label;
    private javax.swing.JTextField Email_Id_txt;
    private javax.swing.JRadioButton Female_radio;
    private javax.swing.JLabel L_Name;
    private javax.swing.JLabel M_label;
    private javax.swing.JLabel Op_label;
    private javax.swing.JLabel P_label;
    private javax.swing.JLabel Pan_label;
    private javax.swing.JLabel Ph_label;
    private javax.swing.JLabel S_label;
    private javax.swing.JLabel U_label;
    private javax.swing.JLabel V_label;
    private javax.swing.JTextField address_txt;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField c_city;
    private com.jidesoft.swing.AutoCompletionComboBox c_country;
    private javax.swing.JTextField c_dob;
    private javax.swing.JTextField c_id;
    private javax.swing.JTextField c_name;
    private com.jidesoft.swing.AutoCompletionComboBox c_state;
    private javax.swing.JButton clear_button;
    private javax.swing.JComboBox company;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private javax.swing.JTextField cst_no_txt;
    private javax.swing.JButton delete_button;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton male_radiobutton;
    private javax.swing.JTextField mobile_no_txt;
    private javax.swing.JTextField name_txt;
    private numeric.textField.NumericTextField opening_balance_num;
    private javax.swing.JTextField pan_no_txt;
    private javax.swing.JTextField phone_no_txt;
    private numeric.textField.NumericTextField pin_num;
    private javax.swing.JButton save_button;
    private javax.swing.JTextField search_text;
    private javax.swing.JTable table;
    private javax.swing.JTextField under_name;
    private javax.swing.JComboBox under_txt;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    private javax.swing.JTextField vat_no_txt;
    // End of variables declaration//GEN-END:variables
private javax.swing.JOptionPane jopt1;
private String gender;
}
