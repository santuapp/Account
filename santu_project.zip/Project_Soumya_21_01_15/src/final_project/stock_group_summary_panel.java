/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc1
 */
package final_project;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
//import net.sf.jasperreports.components.table.ColumnGroup;

public class stock_group_summary_panel extends JPanel
{   
    String head_trans;
    JTable table = new JTable( /*dm, new GroupableTableColumnModel()*/);
    DefaultTableModel dm = new DefaultTableModel();
    
    stock_group_summary_panel()
    {
        this.setLayout(new BorderLayout());
       
       // this.setSize(600, 600);
        
        dm.setDataVector(new Object[][]{{},{}},
            new Object[]{"Particulars", "Quantity", "Rate", "Value"});
            
            // Setup table
         
            table.setColumnModel(new GroupableTableColumnModel());
            table.setTableHeader(new GroupableTableHeader((GroupableTableColumnModel)table.getColumnModel()));
            table.setModel(dm);
            
            // Setup Column Groups
            GroupableTableColumnModel cm = (GroupableTableColumnModel)table.getColumnModel();
             ColumnGroup g_name = new ColumnGroup("Closing Balance");
            g_name.add(cm.getColumn(1));
            g_name.add(cm.getColumn(2));
            g_name.add(cm.getColumn(3));
            GroupableTableHeader header = (GroupableTableHeader)table.getTableHeader();
            cm.addColumnGroup(g_name);
            
            // Finish off gui
            JScrollPane scroll = new JScrollPane(table);
            this.add(scroll);
           
    }   
     
    
    public void fill_stock_grp_sum_db(String click)
    {    
        head_trans = click;
         int fr = dm.getRowCount();
            while (fr>=1)
            {   
            int a = dm.getRowCount()- 1;
            dm.removeRow(a);
            fr--;
            }
        try
           {
              
           
           Connection con = Database.getConnection();
                             
           
                Statement ps = con.createStatement();
                ResultSet rs = ps.executeQuery("SELECT  p_name,(inv_open + inv_purchase - inv_sale),(inv_open_amount + inv_pur_amount - inv_sale_amount) / (inv_open + inv_purchase - inv_sale) , (inv_open_amount + inv_pur_amount - inv_sale_amount) FROM `"+click+"` ");
                ResultSetMetaData md1=rs.getMetaData();
                int col=md1.getColumnCount();
               
                while(rs.next())
                 {
                  Object row1[]=new Object[col];
                   for(int x=0;x<row1.length;x++)
                   {
                 
                        row1[x]=rs.getObject(x+1);
                  
                   }
                   dm.addRow(row1);
                 }
           
              
                     
           
          table.setModel(dm);
           dm.fireTableDataChanged();
           }
         
         
        catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
          
         
            //setSize( 800, 200 );
         //   this.setBorder(BorderFactory.createLineBorder(Color.orange, 0));
            System.out.println("Hello Max Size: "+this.isMaximumSizeSet());
            System.out.println("Hello Min Size: "+this.isMinimumSizeSet());
    
    }    




class GroupableTableCellRenderer extends DefaultTableCellRenderer {
    /**
     *
     * @param table
     * @param value
     * @param selected
     * @param focused
     * @param row
     * @param column
     * @return
     */
    public Component getTableCellRendererComponent(JTable table, Object value,
    boolean selected, boolean focused, int row, int column) {
        JTableHeader header = table.getTableHeader();
        if (header != null) {
         Border border=BorderFactory.createLineBorder(Color.BLUE);
         table.setBorder(border);
        }
      //  setHorizontalAlignment(SwingConstants.CENTER);
        setText(value != null ? value.toString() : " ");
        setBorder(UIManager.getBorder("TableHeader.cellBorder"));
        return this;
    }
}

public void print(){
     System.out.println(head_trans);
    HashMap param=new HashMap();
    param.put("group_summary_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\group_summary_printable_inventory.jasper", param);
    viewer1.setVisible(true);
    
}

}