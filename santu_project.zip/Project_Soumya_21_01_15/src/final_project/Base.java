/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author Daz
 */
public interface Base {

    void updateComboboxDept(DefaultComboBoxModel t);
    void updateComboboxSex(DefaultComboBoxModel t);
    void setDefaultSize();
}
