package final_project;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc144
 */
public class trial_balance_panel extends javax.swing.JPanel implements ContainerListener{
private final GridBagConstraints gridBagConstraints;
private final GridBagConstraints gbc;
    /**
     * Creates new form trial_balance_panel
     */
String head_trans="";
 int h=0,g=0;
 int row=0;
  final JButton[][] labels=new JButton[5000][4];
    public trial_balance_panel() {
        initComponents();
   
        jPanel1.setLayout(new BorderLayout());
      JPanel gb = new JPanel(new GridBagLayout());
      
        jPanel1.add(gb,BorderLayout.NORTH);
        
        Font myFont = new Font("Serif", Font.BOLD, 17);
        Font myFont2 = new Font("Serif", Font.BOLD, 13);
        Font myFont1 = new Font("Serif", Font.ITALIC, 14);
        
         addContainerListener(this);
         
//         GridbagLayout gridbag = new  GridbagLayout();
        
         gridBagConstraints = new java.awt.GridBagConstraints();
         gbc = new java.awt.GridBagConstraints();
       
         
         gridBagConstraints.anchor=gridBagConstraints.PAGE_START;
         
         
        // gridBagConstraints.insets=new Insets(0,0,0,0);
            
           
            String capital_acc_debit,capital_acc_credit,curr_lib_debit,curr_lib_credit,fix_asset,cur_asset,sundry_debtors,sundry_creditors,sales_account,purchase_account,dir_exp,dir_inc,indir_exp,cash,bank,indir_inc;
            Double cap_total=0.0d,cur_lib=0.0d,fixed_asset=0.0d,current_asset=0.0d,sundry_deb=0.0d,sundry_cre=0.0d,sales=0.0d,purchase=0.0d,direct_exp=0.0d,direct_inc=0.0d,indirect_exp=0.0d,cash_acc=0.0d,bank_acc=0.0d,indirect_inc=0.0d;
            int cap=0,lon=0,cur=0,fxd=0,ivt=0,crt=0,act=0,pur=0,dxp=0,din=0,iex=0,cas=0,bak=0,sun=0,sud=0,r=4,iid=0;
            
            int count = 1000;
            
            
                 try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("delete from trial_balance_demo");
           
            
          
            ps2.executeUpdate();
            
            
    //        System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
            
          
            
                
            
            
            // for panel 2
            int row2=0;
            
            // Panel 1 start.....y=2
            
            
            JLabel tohead=new JLabel("Particulars");
            tohead.setBorder(BorderFactory.createMatteBorder(1, 1, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            tohead.setHorizontalAlignment(SwingConstants.CENTER);
            tohead.setFont(myFont);
            gb.add(tohead,gridBagConstraints);
            
            JLabel blankhead4=new JLabel(" ");
            blankhead4.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.black));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            blankhead4.setFont(myFont);
            gb.add(blankhead4,gridBagConstraints);
            
            JLabel refhead=new JLabel("Closing Balance");
            refhead.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.4;
            refhead.setFont(myFont);
            gb.add(refhead,gridBagConstraints);
            
            // y=3
            
            JLabel tohead1=new JLabel(" ");
            tohead1.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            tohead1.setFont(myFont);
            gb.add(tohead1,gridBagConstraints);
            
            JLabel blankhead5=new JLabel(" ");
            blankhead5.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.black));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            blankhead5.setFont(myFont);
            gb.add(blankhead5,gridBagConstraints);
            
            JLabel tohead5=new JLabel("Debit");
            tohead5.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            tohead5.setHorizontalAlignment(SwingConstants.CENTER);
            tohead5.setFont(myFont);
            gb.add(tohead5,gridBagConstraints);
            
            JLabel blankhead6=new JLabel(" ");
            blankhead6.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.black));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            blankhead6.setFont(myFont);
            gb.add(blankhead6,gridBagConstraints);
            
            JLabel tohead6=new JLabel("Credit");
            tohead6.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=3;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            tohead6.setHorizontalAlignment(SwingConstants.CENTER);
            tohead6.setFont(myFont);
            gb.add(tohead6,gridBagConstraints);
            
             
            //y=4...start...
             //Heading Capital Account
            
//             try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//           Statement ps =con.createStatement();
//           ResultSet rs=ps.executeQuery("SELECT IFNULL(SUM(credit),0) - IFNULL(SUM(debit),0) AS total_capital FROM `Capital Account`");
//          
//            
//          while(rs.next())
//             {
         //   String grp="Capital Account";
//            first_panel fp=new first_panel();
//            fp.add_panel_2("Capital Account");
//                    String inv_tot1=fp.val;
//                 capital_acc_credit=inv_tot1;
//                
//                     cap_total=Double.parseDouble(capital_acc_credit);
//                    
//                   
//                         //cap_total=0.0d - cap_total;
//                          String cpaital=Double.toString(cap_total);
            
            System.out.println(row+"soumya");
            
            labels[row][0] = new JButton("Capital Account");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setFont(myFont);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
     //        labels[row][0].requestFocusInWindow();
                        
    
           
            labels[row][1] = new JButton(" "); 
           
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
              
            
            labels[row][3] = new JButton(" "); 
           
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0.2;
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
             // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
        
           
            
          
            
            r++;
          
                 
//             }
//          }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }
            //Content Array (Capital A/C  Name,debit Value,Credit Value) displaying
            try{
        
           
           Connection con = Database.getConnection();
        Statement ps1 =con.createStatement();
           ResultSet rs1=ps1.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Capital Account` group by l_name");
           while(rs1.next())
           {
               String cap_ledger=rs1.getString("l_name");
                 String cap_ledger_value_debit=rs1.getString("debit");
                 String cap_ledger_value_credit=rs1.getString("credit");
               if(cap_ledger!=null)
               {
               
            labels[row][0] = new JButton();   
                
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("  "+cap_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
                
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setFont(myFont1);
            labels[row][1].setText(cap_ledger_value_debit);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
             
             
            labels[row][3] = new JButton(); 
             
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setFont(myFont1);
            labels[row][3].setText(cap_ledger_value_credit);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
             // For Temp database-trail_balance_demo
            
               try
            {
                
           Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
             
        
            
            row++;
            
             r++;
             cap++;
                   } 
             } 
          }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
            
           
                 
              /*   
           
            //Heading Loan Liabilities
            
            JLabel tohead8=new JLabel("Loan Liabilities");
            tohead8.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(tohead8,gridBagConstraints);
            tohead8.setFont(myFont);
            tohead8.setHorizontalAlignment(SwingConstants.LEFT);
            
            JLabel tohead10=new JLabel("500000000 ");
            tohead10.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(tohead10,gridBagConstraints);
            tohead10.setFont(myFont);
            tohead10.setHorizontalAlignment(SwingConstants.RIGHT);
            
            JLabel tohead11=new JLabel("8500000.00");
            tohead11.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(tohead11,gridBagConstraints);
            tohead11.setFont(myFont);
            tohead11.setHorizontalAlignment(SwingConstants.RIGHT);
            
            r++;
           
            //Content Array (Loans Libilities  Name,debit Value,Credit Value) displaying
            
             while(rs1.next())
             {
                   loanlabel[lon]=new JLabel();
                   loandblabel[lon]=new JLabel();
                   loancrlabel[lon]=new JLabel(); 
                   
            loanlabel[lon].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(loanlabel[lon],gridBagConstraints);
            loanlabel[lon].setHorizontalAlignment(SwingConstants.LEFT);
            loanlabel[lon].setText("Loan name");
            
            loandblabel[lon].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(loandblabel[lon],gridBagConstraints);
            loandblabel[lon].setHorizontalAlignment(SwingConstants.CENTER); 
            loandblabel[lon].setText("Loan Debit value");
            
            loancrlabel[lon].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(loancrlabel[lon],gridBagConstraints);
            loancrlabel[lon].setHorizontalAlignment(SwingConstants.RIGHT);
            loancrlabel[lon].setText("Loan Credit value");
            
            r++;
            lon++;
            
             }
            */
           
             // Heading Current Liabilities
//              try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//           Statement ps2 =con.createStatement();
//           ResultSet rs2=ps2.executeQuery("SELECT IFNULL(SUM(credit),0) - IFNULL(SUM(debit),0) AS total_capital FROM `Current Liabilities`");
//          
//            
//            
//            
//          while(rs2.next())
//             {
//             first_panel fp1=new first_panel();
//            fp.add_panel_2("Current Liabilities");
//                    String inv_tot2=fp.val;
//                 curr_lib_debit=inv_tot2;
//               
//                     cur_lib=Double.parseDouble(curr_lib_debit);
//                    String curr_liabilities=Double.toString(cur_lib);
                     
            
            labels[row][0] = new JButton("Current Liabilities"); 
            
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText(" ");
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            
            labels[row][1] = new JButton(" ");
           
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setText(" ");
            labels[row][1].setHorizontalAlignment(SwingConstants.CENTER);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            
            
            labels[row][3] = new JButton(" ");
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            
            
               // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            r++;
//                     }
//            else{
//            
//            cur_lib=0 - cur_lib;
//            String curr_liabilities1=Double.toString(cur_lib);
//            
//            labels[row][0] = new JButton("Current Liabilities");
//           
//            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=17;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.6;
//            gb.add(labels[row][0],gridBagConstraints);
//            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
//            labels[row][0].setFont(myFont); 
//            
//           
//            labels[row][1] = new JButton(" ");
//            
//            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][1],gridBagConstraints);
//            labels[row][1].setText(curr_liabilities1);
//            labels[row][1].setFont(myFont);
//            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
//            
//            labels[row][2] = new JButton(" "); 
//           
//            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=25;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0;
//            gb.add(labels[row][2],gridBagConstraints);
//            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][2].setFont(myFont);
//            
//            labels[row][3] = new JButton(" ");
//            
//            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=27;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][3],gridBagConstraints);
//            //tohead14.setText(curr_liabilities);
//            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][3].setFont(myFont);
//            r++;
//                     }
//                } 
//             }
//          }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }      
            
              
              
        //Content Array (Current Libilities  Name,debit Value,Credit Value) displaying
               
              try{
        
           Connection con = Database.getConnection();
           Statement ps3 =con.createStatement();
           ResultSet rs3=ps3.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Current Liabilities` group by l_name");
          
              
            while(rs3.next())
            {
               String cur_lib_ledger=rs3.getString("l_name");
                 String cur_lib_ledger_value_debit=rs3.getString("debit");
                 String cup_lib_ledger_value_credit=rs3.getString("credit");
               if(cur_lib_ledger!=null)
               {
              
            labels[row][0] = new JButton();
              
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("  "+cur_lib_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(cur_lib_ledger_value_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(cup_lib_ledger_value_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
               // For Temp database-trail_balance_demo
            
               try
            {
                
            Class.forName("com.mysql.jdbc.Driver");
            String ConnUr2="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
            Connection con2 = (Connection) DriverManager.getConnection(ConnUr2);
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            catch(ClassNotFoundException ce)
            {
            System.out.println("ClassNotFoundException" + ce.toString());
            }    
            
            row++;
            
            r++;
            cur++;
            }
              }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
       
              
              
            

        //Heading Fixed Asset
          
//               try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//        Statement ps4 =con.createStatement();
//           ResultSet rs4=ps4.executeQuery("SELECT IFNULL(IFNULL(SUM(debit),0),0) - IFNULL(IFNULL(SUM(credit),0),0) AS total_capital FROM `Fixed Asset`");
//          
//            
//            
            
//       while(rs4.next())
//             {
//                 fix_asset=rs4.getString("total_capital");
//                 if(fix_asset!=null){
//                     fixed_asset=Double.parseDouble(fix_asset);
//                    String f_asset=Double.toString(fixed_asset);
//                     if(fixed_asset>0.0d){
            
            labels[row][0] = new JButton("Fixed Asset");             
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            
            labels[row][1] = new JButton(" ");   
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setText(" ");
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setFont(myFont);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            
            labels[row][3] = new JButton(" ");
           
            labels[row][3] .setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3] ,gridBagConstraints);
            labels[row][3] .setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setFont(myFont);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
               // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            r++;
//            }
//            
//            else{
//                   fixed_asset=0.0d - fixed_asset;  
//                       String f_asset1=Double.toString(fixed_asset);
//            
//            labels[row][0] = new JButton("Fixed Asset");
//            
//            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=17;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.6;
//            gb.add(labels[row][0],gridBagConstraints);
//            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
//            labels[row][0].setFont(myFont);
//            
//            labels[row][1] = new JButton(" ");
//            
//            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][1],gridBagConstraints);
//         
//            labels[row][1].setHorizontalAlignment(SwingConstants.CENTER);
//        //    tohead17.setFont(myFont);
//            
//            labels[row][2] = new JButton(" "); 
//           
//            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=25;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0;
//            gb.add(labels[row][2],gridBagConstraints);
//            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][2].setFont(myFont);
//            
//            labels[row][3] = new JButton();
//            
//            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=27;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][3],gridBagConstraints);
//            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][3].setText(f_asset1);
//            labels[row][3].setFont(myFont);
//                  
//            r++;
//               
//                     }
//               }
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }    
             //Content Array (Fixed Asset  Name,debit Value,Credit Value) displaying
               
                try{
        
           Connection con = Database.getConnection();
        Statement ps5 =con.createStatement();
           ResultSet rs5=ps5.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Fixed Asset`group by l_name ");
          
              
            while(rs5.next())
            {
               String fix_asset_ledger=rs5.getString("l_name");
                 String fix_asset_ledger_value_debit=rs5.getString("debit");
                 String fix_asset_ledger_value_credit=rs5.getString("credit");
               if(fix_asset_ledger!=null)
               {
            
            labels[row][0] = new JButton();
                   
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("  "+fix_asset_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(fix_asset_ledger_value_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(fix_asset_ledger_value_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
               // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            row++;
            
            r++;
            fxd++;
            
            }
               
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
          
            
          /*  // Heading Invest Asset
            
            JLabel tohead20=new JLabel("Investment");
            tohead20.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(tohead20,gridBagConstraints);
            tohead20.setHorizontalAlignment(SwingConstants.LEFT);
            
            JLabel tohead21=new JLabel();
            tohead21.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(tohead21,gridBagConstraints);
            tohead21.setHorizontalAlignment(SwingConstants.CENTER);
            tohead21.setFont(myFont);
            
            JLabel tohead22=new JLabel();
            tohead22.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(tohead22,gridBagConstraints);
            tohead22.setHorizontalAlignment(SwingConstants.RIGHT);
            tohead22.setFont(myFont);
            
            r++;
          
            //Content Array (Invest Asset  Name,debit Value,Credit Value) displaying
            
              while(rs1.next())
              {
               ivtasetlabel[ivt]=new JLabel();
               ivtasetdblabel[ivt]=new JLabel();
               ivtasetcrlabel[ivt]=new JLabel();
               
            ivtasetlabel[ivt].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(ivtasetlabel[ivt],gridBagConstraints);
            ivtasetlabel[ivt].setHorizontalAlignment(SwingConstants.LEFT);
            ivtasetlabel[ivt].setText("Invest Asset name");
            
            ivtasetdblabel[ivt].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(ivtasetdblabel[ivt],gridBagConstraints);
            ivtasetdblabel[ivt].setHorizontalAlignment(SwingConstants.CENTER); 
            ivtasetdblabel[ivt].setText("Invest Asset Debit value");
            
            ivtasetcrlabel[ivt].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(ivtasetcrlabel[ivt],gridBagConstraints);
            ivtasetcrlabel[ivt].setHorizontalAlignment(SwingConstants.RIGHT);
            ivtasetcrlabel[ivt].setText("Invest Asset Credit value");
            r++;
            ivt++;
              }
                   */        

            // Heading Current Asset
            
//           try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//           Statement ps6 =con.createStatement();
//           ResultSet rs6=ps6.executeQuery("SELECT IFNULL(IFNULL(SUM(debit),0),0) - IFNULL(IFNULL(SUM(credit),0),0) AS total_capital FROM `Current Asset`");
//             while(rs6.next())
//             {
//                 cur_asset=rs6.getString("total_capital");
//                 if(cur_asset!=null){
//                     current_asset=Double.parseDouble(cur_asset);
//                    String c_asset=Double.toString(current_asset);
//                     if(current_asset>0.0d){
                         
            labels[row][0] = new JButton("Current Asset");  
           
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
           
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setText(" ");
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setFont(myFont);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setFont(myFont);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
               // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
           
//            r++;
//             }
//            else{
            current_asset=0 - current_asset;    
            String c_asset1=Double.toString(current_asset);
            
            labels[row][0] = new JButton("Current Asset");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" "); 
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);          
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" "); 
          
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(c_asset1);
            labels[row][3].setFont(myFont);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
               // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
           
            
            r++;
//             }
//                     
//                 }
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }    
//            
//            //Content Array (Current Asset  Name,debit Value,Credit Value) displaying
//             try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//           Statement ps7 =con.createStatement();
//           ResultSet rs7=ps7.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Current Asset` group by l_name ");
//          
//              
//            while(rs7.next())
//            {
//                 String curr_asset_ledger=rs7.getString("l_name");
//                 String curr_asset_ledger_value_debit=rs7.getString("debit");
//                 String curr_asset_ledger_value_credit=rs7.getString("credit");
//               if(curr_asset_ledger!=null)
//               {
//            
//            labels[row][0] = new JButton();
//                
//            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=17;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.6;
//            gb.add(labels[row][0],gridBagConstraints);
//            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
//            labels[row][0].setText("  "+curr_asset_ledger);
//            labels[row][0].setFont(myFont1);
//            
//            
//            labels[row][1] = new JButton();
//            
//            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][1],gridBagConstraints);
//            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
//            labels[row][1].setText(curr_asset_ledger_value_debit);
//            labels[row][1].setFont(myFont1);
//            
//            
//            labels[row][2] = new JButton(" ");
//             
//            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=25;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
//            labels[row][2].setFont(myFont1);
//            gb.add(labels[row][2],gridBagConstraints);
//            
//            labels[row][3] = new JButton();
//            
//            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=27;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][3],gridBagConstraints);
//            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][3].setText(curr_asset_ledger_value_credit);
//            labels[row][3].setFont(myFont1);
//            
//            row++;
//            
//            r++;
//            crt++;
//            
//            }
//            
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }    
            
                  // Heading Sundry Debtors
               try{
        
           Connection con = Database.getConnection();
           Statement ps6 =con.createStatement();
           ResultSet rs6=ps6.executeQuery("SELECT IFNULL(IFNULL(SUM(debit),0),0) - IFNULL(IFNULL(SUM(credit),0),0) AS total_capital FROM `Sundry Debtors`");
          
            
            
            
       while(rs6.next())
             {
                 sundry_debtors=rs6.getString("total_capital");
                 if(sundry_debtors!=null){
                     sundry_deb=Double.parseDouble(sundry_debtors);
                    String s_deb=Double.toString(sundry_deb);
                     if(sundry_deb>0.0d)
                     {
                         
            labels[row][0] = new JButton();
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setText("    "+"Sundry Debtors");
            labels[row][0].setFont(myFont2);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setFont(myFont2);
            labels[row][1].setText(s_deb);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont2);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setFont(myFont2);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
               // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            
           
            
            
            r++;  
             }
              else{
                         sundry_deb=0 - sundry_deb;
                            String s_deb1=Double.toString(sundry_deb);
            
            labels[row][0] = new JButton();
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setText("    "+"Sundry Debtors");
            labels[row][0].setFont(myFont2);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setFont(myFont2);
            labels[row][1].setText(" ");
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont2);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setFont(myFont2);
            labels[row][3].setText(s_deb1);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
               // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            
            
            
            r++;  
             }       
                 }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
            
            //Content Array (Sundry Debtors Name,debit Value,Credit Value) displaying
            
            try{
        
           Connection con = Database.getConnection();
        Statement ps8 =con.createStatement();
           ResultSet rs8=ps8.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Sundry Debtors` group by l_name ");
          
              
            while(rs8.next())
            {
               String sundry_ledger=rs8.getString("l_name");
                 String sundry_debtors_value_debit=rs8.getString("debit");
                 String sundry_debtors_value_credit=rs8.getString("credit");
               if(sundry_ledger!=null)
               {
                
            labels[row][0] = new JButton();      
                 
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("      "+sundry_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(sundry_debtors_value_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(sundry_debtors_value_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
           Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            
           
            
            row++;
              
            r++;
            sud++;
               }
            }
            }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
           
             
            // Heading Sundry Creditors
              try{
        
           Connection con = Database.getConnection();
           Statement ps6 =con.createStatement();
           ResultSet rs6=ps6.executeQuery("SELECT IFNULL(SUM(credit),0) - IFNULL(SUM(debit),0) AS total_capital FROM `Sundry Creditors`");
          
         
       while(rs6.next())
             {
                 sundry_creditors=rs6.getString("total_capital");
                 if(sundry_creditors!=null){
                     sundry_cre=Double.parseDouble(sundry_creditors);
                    String s_cre=Double.toString(sundry_cre);
                     if(sundry_cre>0.0d){
            
            labels[row][0] = new JButton("    "+"Sundry Creditor");             
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setFont(myFont2);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            labels[row][1].setFont(myFont2);
            gb.add(labels[row][1],gridBagConstraints);         
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont2);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setText(s_cre);
            labels[row][3].setFont(myFont2);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            
            
            
            r++; 
            }
            else
            {
            sundry_cre = 0 -  sundry_cre; 
            String s_cre1=Double.toString(sundry_cre);
            
            labels[row][0] = new JButton("    "+"Sundry Creditor");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setFont(myFont2);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            labels[row][1].setText(s_cre1);
            labels[row][1].setFont(myFont2);
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont2);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
          //
            
            labels[row][3].setText(" ");
            labels[row][3].setFont(myFont2);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            
         
            
            r++;          
                      
                     }      
                 }
               }
               }
        catch (SQLException e)
        {
        System.out.println("Sql Exception" + e.toString());
        }
           
            
            //Content Array (Sundry Creditor Name,debit Value,Credit Value) displaying
            
              
              
              try{
        
           Connection con = Database.getConnection();
           Statement ps8 =con.createStatement();
           ResultSet rs8=ps8.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Sundry Creditors` group by l_name ");
           
              
            while(rs8.next())
            {
               String sundry_cre_ledger=rs8.getString("l_name");
                 String sundry_creditors_value_debit=rs8.getString("debit");
                 String sundry_creditors_value_credit=rs8.getString("credit");
               if(sundry_cre_ledger!=null)
               {
                      
            labels[row][0] = new JButton();
                   
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("      "+sundry_cre_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(sundry_creditors_value_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(sundry_creditors_value_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            
            
            
            row++;
            
            r++;
            sun++;
             
                }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
          
              
             // Heading Sales Accout
//              try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//        Statement ps60 =con.createStatement();
//           ResultSet rs60=ps60.executeQuery("SELECT IFNULL(SUM(credit),0) - IFNULL(SUM(debit),0) AS total_capital FROM `Sale`");
//          
//         while(rs60.next())
//            {
//            
//            sales_account=rs60.getString("total_capital");
//            
//            if( sales_account!=null)
//            {
//                sales=Double.parseDouble(sales_account);
//                String s_aacc=Double.toString(sales);
//                if(sales>0.0d)
//                     {
                         
            labels[row][0] = new JButton("Sales Account");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setFont(myFont);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1] .setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            labels[row][1] .setFont(myFont);
            gb.add(labels[row][1] ,gridBagConstraints);
            labels[row][1] .setHorizontalAlignment(SwingConstants.CENTER);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton("");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setText(" ");
            labels[row][3].setFont(myFont);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
                
            
          
            
            
            r++;
//            
//             }
//                     else{
//                         sales=0 - sales ;
//                            String s_aacc1=Double.toString(sales);
//                           
//            labels[row][0] = new JButton("Sales Account");
//            
//            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=15;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.6;
//            gb.add(labels[row][0],gridBagConstraints);
//            labels[row][0].setFont(myFont);
//            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
//            
//            labels[row][1] = new JButton(" ");
//            
//            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            labels[row][1].setText(" ");
//            labels[row][1].setFont(myFont);
//            gb.add(labels[row][1],gridBagConstraints);
//            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
//            
//            labels[row][2] = new JButton(" "); 
//           
//            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=25;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0;
//            gb.add(labels[row][2],gridBagConstraints);
//            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][2].setFont(myFont);
//            
//            labels[row][3] = new JButton(" ");
//            
//            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=27;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][3],gridBagConstraints);
//            labels[row][3].setText(s_aacc1);
//            labels[row][3].setFont(myFont);
//            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
//            
//            r++;
//                     }
//                 }
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }    
//          
            //Content Array (Sales Account  Name,debit Value,Credit Value) displaying
            
            try{
        
           Connection con = Database.getConnection();
        Statement ps80 =con.createStatement();
           ResultSet rs80=ps80.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Sale` group by l_name ");
          
              
            while(rs80.next())
            {
               String sales_ledger=rs80.getString("l_name");
                 String sale_value_debit=rs80.getString("debit");
                 String sale_value_credit=rs80.getString("credit");
               if(sales_ledger!=null)
               {
            
            labels[row][0] = new JButton();
                   
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("  "+sales_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(sale_value_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
                      
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(sale_value_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            
        
            row++;
            
            r++;
            act++;
             }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
            
               
           
            // Heading Purchase Accout
            
//            try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//        Statement ps60 =con.createStatement();
//           ResultSet rs60=ps60.executeQuery("SELECT IFNULL(IFNULL(SUM(debit),0),0) - IFNULL(IFNULL(SUM(credit),0),0) AS total_capital FROM `Purchase`");
//          
//         while(rs60.next())
//             {
//                 purchase_account=rs60.getString("total_capital");
//                 if( purchase_account!=null){
//                     purchase=Double.parseDouble(purchase_account);
//                    String p_acc=Double.toString(purchase);
//                     if(purchase>0.0d){
            
            
            labels[row][0] = new JButton("Purchase Account");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setFont(myFont);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1] .setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            labels[row][1] .setFont(myFont);
            gb.add(labels[row][1] ,gridBagConstraints);
            labels[row][1] .setHorizontalAlignment(SwingConstants.CENTER);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            
            
          
            
            
            r++;
//             }
//            else{
//            
//            purchase=0 - purchase;
//            String p_acc1=Double.toString(purchase);
//            
//            labels[row][0] = new JButton("Purchase Account");
//            
//            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=17;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.6;
//            gb.add(labels[row][0],gridBagConstraints);
//            labels[row][0].setFont(myFont);
//            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
//            
//            labels[row][1] = new JButton(" ");
//            
//            labels[row][1] .setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            labels[row][1] .setFont(myFont);
//            gb.add(labels[row][1] ,gridBagConstraints);
//            labels[row][1] .setHorizontalAlignment(SwingConstants.CENTER);
//            
//            
//            labels[row][2] = new JButton(" "); 
//           
//            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=25;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0;
//            gb.add(labels[row][2],gridBagConstraints);
//            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][2].setFont(myFont);
//            
//            labels[row][3] = new JButton(" ");
//            
//            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=27;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][3],gridBagConstraints);
//            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][3].setText(p_acc1);
//            labels[row][3].setFont(myFont);
//            
//            r++;
//             }
//                         
//                 }
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }     
//            

//Content Array (Purchase Account  Name,debit Value,Credit Value) displaying
            
              try{
        
           Connection con = Database.getConnection();
        Statement ps80 =con.createStatement();
           ResultSet rs80=ps80.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Purchase` group by l_name ");
          
              
            while(rs80.next())
            {
               String purchase_ledger=rs80.getString("l_name");
                 String purchase_value_debit=rs80.getString("debit");
                 String purchase_value_credit=rs80.getString("credit");
              
                 if(purchase_ledger!=null)
               {
            
            labels[row][0] = new JButton();
                  
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText( "  "+purchase_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(purchase_value_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
         
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(purchase_value_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
            
            
            
            row++;
            
            r++;
            pur++;
             
             }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
          
             
            // Heading Direct Expense
//               try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//        Statement ps60 =con.createStatement();
//           ResultSet rs60=ps60.executeQuery("SELECT IFNULL(IFNULL(SUM(debit),0),0) - IFNULL(IFNULL(SUM(credit),0),0) AS total_capital FROM `Direct Expense`");
//          
//         while(rs60.next())
//             {
//                 dir_exp=rs60.getString("total_capital");
//                 if(dir_exp!=null){
//                     direct_exp=Double.parseDouble(dir_exp);
//                    String d_exp=Double.toString(direct_exp);
//                     if(direct_exp>0.0d){
                         
            
            labels[row][0] = new JButton("Direct Expense");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setFont(myFont);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setText(" ");
            labels[row][1].setFont(myFont);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setFont(myFont);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            
            r++; 
//             }
//                     else
//                         {
//                          direct_exp=0 - direct_exp;   
//                            String d_exp1=Double.toString(direct_exp);
//                            
//            labels[row][0] = new JButton("Direct Expense");
//            
//            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=15;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.6;
//            gb.add(labels[row][0],gridBagConstraints);
//            labels[row][0].setFont(myFont);
//            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
//            
//            labels[row][1] = new JButton("");
//            
//            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][1],gridBagConstraints);
//           // tohead36.setText(d_exp);
//            labels[row][1].setFont(myFont);
//            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
//            
//            labels[row][2] = new JButton(" "); 
//           
//            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=25;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0;
//            gb.add(labels[row][2],gridBagConstraints);
//            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][2].setFont(myFont);
//            
//            labels[row][3] = new JButton(" ");
//            
//            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=27;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][3],gridBagConstraints);
//            labels[row][3].setText(d_exp1);
//            labels[row][3].setFont(myFont);
//            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
//            
//            r++; 
//             }
//              }
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }     
            //Content Array (Direct Expense  Name,debit Value,Credit Value) displaying
           
               
            try{
        
          Connection con = Database.getConnection();
        Statement ps800 =con.createStatement();
           ResultSet rs800=ps800.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Direct Expense` group by l_name ");
          
              
            while(rs800.next())
            {
               String dir_exp_ledger=rs800.getString("l_name");
                 String dir_exp_debit=rs800.getString("debit");
                 String dir_exp_credit=rs800.getString("credit");
             
           if(dir_exp_ledger!=null)
           {
            
            labels[row][0] = new JButton();   
               
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont1);
            labels[row][0].setText("  "+dir_exp_ledger);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            
            labels[row][1] = new JButton();
                    
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setFont(myFont1);
            labels[row][1].setText(dir_exp_debit);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
           
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][3].setFont(myFont1);
            labels[row][3].setText(dir_exp_credit);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
           Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
          
            row++;
            
            r++;
            dxp++;
            }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
            
              
             // Heading Direct Income
//             try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//        Statement ps60 =con.createStatement();
//           ResultSet rs60=ps60.executeQuery("SELECT IFNULL(SUM(credit),0) - IFNULL(SUM(debit),0) AS total_capital FROM `Direct Income`");
//          
//         while(rs60.next())
//             {
//                 dir_inc=rs60.getString("total_capital");
//                 if(dir_inc!=null){
//                     direct_inc=Double.parseDouble(dir_inc);
//                    String d_inc=Double.toString(direct_inc);
//                     if(direct_inc>0.0d)
//                     {
                         
            
            labels[row][0] = new JButton("Direct Income");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1] .setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            labels[row][1] .setFont(myFont);
            gb.add(labels[row][1] ,gridBagConstraints);
            labels[row][1] .setHorizontalAlignment(SwingConstants.CENTER);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" "); 
           
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][2].setFont(myFont);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
          
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(" ");
            labels[row][3].setFont(myFont);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            r++;  
//             }
//            }
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }     
            //Content Array (Direct Income  Name,debit Value,Credit Value) displaying
              
             try{
        
          Connection con = Database.getConnection();
           Statement ps800 =con.createStatement();
           ResultSet rs800=ps800.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Direct Income` group by l_name ");
          
              
            while(rs800.next())
            {
               String dir_inc_ledger=rs800.getString("l_name");
                 String dir_inc_debit=rs800.getString("debit");
                 String dir_inc_credit=rs800.getString("credit");
             if(dir_inc_ledger!=null)
             {
                               
            
            labels[row][0] = new JButton();
                 
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont1);
            labels[row][0].setText("  "+dir_inc_ledger);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setFont(myFont1);
            labels[row][1].setText(dir_inc_debit);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setFont(myFont1);
            labels[row][3].setText(dir_inc_credit);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
             
            
            
            row++;
            
            r++;
            din++;
            }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
            
             
              // Heading Indirect Expense
//             try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//        Statement ps60 =con.createStatement();
//           ResultSet rs60=ps60.executeQuery("SELECT IFNULL(IFNULL(SUM(debit),0),0) - IFNULL(IFNULL(SUM(credit),0),0) AS total_capital FROM `Indirect Expense`");
//          
//         while(rs60.next())
//             {
//                 indir_exp=rs60.getString("total_capital");
//                 if(indir_exp!=null){
//                     indirect_exp=Double.parseDouble(indir_exp);
//                    String ind_exp=Double.toString(indirect_exp);
//                     if(indirect_exp>0.0d){
            
            
            labels[row][0] = new JButton("Indirect Expense");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setText(" ");
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setFont(myFont);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setFont(myFont);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            
            r++;
//                     }
//             }
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }  
             
                //Content Array (Indirect Expense  Name,debit Value,Credit Value) displaying
            
              try{
        
           Connection con = Database.getConnection();
           Statement ps800 =con.createStatement();
           ResultSet rs800=ps800.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Indirect Expense` group by l_name ");
          
              
            while(rs800.next())
            {
                 String indir_exp_ledger=rs800.getString("l_name");
                 String indir_exp_debit=rs800.getString("debit");
                 String indir_exp_credit=rs800.getString("credit");
             
               if(indir_exp_ledger!=null)
               {
                 
            labels[row][0] = new JButton();
                 
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("  "+ indir_exp_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(indir_exp_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(indir_exp_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
           
            
            row++;
            
            r++;
            iex++;
               }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
           
          
              
              
               // Heading Indirect Income 
//               try{
//        
//           Class.forName("com.mysql.jdbc.Driver");
//           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
//           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
//           Statement ps60 =con.createStatement();
//           ResultSet rs60=ps60.executeQuery("SELECT IFNULL(SUM(credit),0) - IFNULL(SUM(debit),0) AS total_capital FROM `Indirect Income`");
//          
//         while(rs60.next())
//             {
//                 indir_inc=rs60.getString("total_capital");
//                 if(indir_inc!=null){
//                     indirect_inc=Double.parseDouble(indir_inc);
//                    String ind_inc=Double.toString(indirect_inc);
//                     if(indirect_inc>0.0d){
            
           
            labels[row][0] = new JButton("Indirect Income");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.CENTER);
            labels[row][1].setFont(myFont);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(" ");
            labels[row][3].setFont(myFont);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            
            r++;  
            
//            }
//                     
//            else
//            {
//            
//            labels[row][0] = new JButton("Indirect Income");
//            
//            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=15;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.6;
//            gb.add(labels[row][0],gridBagConstraints);
//            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
//            labels[row][0].setFont(myFont);
//            
//            labels[row][1] = new JButton(" ");
//            
//            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][1],gridBagConstraints);
//            labels[row][1].setText(ind_inc);
//            labels[row][1].setFont(myFont);
//            labels[row][1].setHorizontalAlignment(SwingConstants.CENTER);
//            
//            labels[row][2] = new JButton(" ");
//             
//            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
//            gridBagConstraints.weightx=0;
//            gridBagConstraints.gridx=25;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
//            labels[row][2].setFont(myFont);
//            gb.add(labels[row][2],gridBagConstraints);
//            
//            labels[row][3] = new JButton(" ");
//            
//            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=27;
//            gridBagConstraints.gridy=r;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            gb.add(labels[row][3],gridBagConstraints);
//            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row][3].setFont(myFont);
//            
//            r++;  
//                     }
//             }
//               }
//               }catch (SQLException e){
//        System.out.println("Sql Exception" + e.toString());
//        }
//        catch(ClassNotFoundException ce)
//        {
//            System.out.println("ClassNotFoundException" + ce.toString());
//        }     
//          
             
             
              //Content Array (Indirect Income  Name,debit Value,Credit Value) displaying
           
                 try{
        
           Connection con = Database.getConnection();
           Statement ps800 =con.createStatement();
           ResultSet rs800=ps800.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Indirect Income` group by l_name ");
          
              
            while(rs800.next())
            {
               String indir_inc_ledger=rs800.getString("l_name");
                 String indir_inc_debit=rs800.getString("debit");
                 String indir_inc_credit=rs800.getString("credit");
             if(indir_inc_ledger!=null)
             {
                           
            labels[row][0] = new JButton();    
                 
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("  "+indir_inc_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(indir_inc_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(indir_inc_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
           Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
             
            
            
            row++;
            
            r++;
            iid++;
             }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
          
         
              // Heading Cash
                
           try{
        
          Connection con = Database.getConnection();
           Statement ps60 =con.createStatement();
           ResultSet rs60=ps60.executeQuery("SELECT IFNULL(IFNULL(SUM(debit),0),0) - IFNULL(IFNULL(SUM(credit),0),0) AS total_capital FROM `Cash`");
          
         while(rs60.next())
             {
                cash=rs60.getString("total_capital");
                 if(cash!=null){
                     cash_acc=Double.parseDouble(cash);
                    String cash_account=Double.toString(cash_acc);
                     if(cash_acc>0.0d)
                     {
            
            
            labels[row][0] = new JButton("Cash");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.CENTER);
            labels[row][1].setText(cash_account);
            labels[row][1].setFont(myFont);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            
            r++;  
            }
            
            else
            {
                         cash_acc=0 - cash_acc;
                         String cash_account1=Double.toString(cash_acc);
            
            labels[row][0] = new JButton("Cash");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.CENTER);
            labels[row][1].setFont(myFont);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setFont(myFont);
            labels[row][3].setText(cash_account1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            
            r++;  
                     }
             }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
            
           
            //Content Array (Cash  Name,debit Value,Credit Value) displaying
            
              try{
        
          Connection con = Database.getConnection();
        Statement ps800 =con.createStatement();
           ResultSet rs800=ps800.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Cash` group by l_name ");
          
              
            while(rs800.next())
            {
                 String cash_ledger=rs800.getString("l_name");
                 String cash_debit=rs800.getString("debit");
                 String cash_credit=rs800.getString("credit");
             
             if(cash_ledger!=null)
             {
         
            labels[row][0] = new JButton();
                    
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("  " + cash_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(cash_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(cash_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            
            row++;
            
            r++;
            cas++;
               }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
            
             
              // Heading Bank
              try{
        
           Connection con = Database.getConnection();
        Statement ps60 =con.createStatement();
           ResultSet rs60=ps60.executeQuery("SELECT IFNULL(IFNULL(SUM(debit),0),0) - IFNULL(IFNULL(SUM(credit),0),0) AS total_capital FROM `Bank`");
          
         while(rs60.next())
             {
                bank=rs60.getString("total_capital");
                 if(bank!=null){
                     bank_acc=Double.parseDouble(bank);
                    String bank_account=Double.toString(bank_acc);
                     if(bank_acc>0.0d){
            
            
            labels[row][0] = new JButton("Bank");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][1].setText(bank_account);
            labels[row][1].setFont(myFont);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText("");
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
            Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
            
            
            r++;  
                     }
            
            else
            {
                bank_acc=0 - bank_acc;
                String bank_account1=Double.toString(bank_acc);
            
            labels[row][0] = new JButton("Bank");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setFont(myFont);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.CENTER);
         //   tohead48.setText(bank_account);
            labels[row][1].setFont(myFont);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(bank_account1);
            labels[row][3].setFont(myFont);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
           Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
               
            
            
            r++;   
                     }
                      }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
             
             
            //Content Array (Bank Name,debit Value,Credit Value) displaying
            
             try{
        
           Connection con = Database.getConnection();
           Statement ps800 = con.createStatement();
           ResultSet rs800=ps800.executeQuery("SELECT l_name,IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `Bank` group by l_name ");
          
              
            while(rs800.next())
            {
               String bank_ledger=rs800.getString("l_name");
               String bank_debit=rs800.getString("debit");
               String bank_credit=rs800.getString("credit");
             
             if(bank_ledger!=null)
             {
                 
            labels[row][0] = new JButton();
                 
            labels[row][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            gb.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            labels[row][0].setText("  "+ bank_ledger);
            labels[row][0].setFont(myFont1);
            labels[row][0].setBorderPainted(false);
            labels[row][0].setContentAreaFilled(false);
            
            labels[row][1] = new JButton();
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT); 
            labels[row][1].setText(bank_debit);
            labels[row][1].setFont(myFont1);
            labels[row][1].setBorderPainted(false);
            labels[row][1].setContentAreaFilled(false);
            
            labels[row][2] = new JButton(" ");
             
            labels[row][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL; 
            labels[row][2].setFont(myFont1);
            gb.add(labels[row][2],gridBagConstraints);
            labels[row][2].setBorderPainted(false);
            labels[row][2].setContentAreaFilled(false);
            
            labels[row][3] = new JButton();
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=r;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            gb.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
            labels[row][3].setText(bank_credit);
            labels[row][3].setFont(myFont1);
            labels[row][3].setBorderPainted(false);
            labels[row][3].setContentAreaFilled(false);
            
            
              // For Temp database-trail_balance_demo
            
               try
            {
                
           Connection con2 = Database.getConnection();
           
            PreparedStatement ps2=con2.prepareStatement("insert into trial_balance_demo(particular,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps2.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
              
            
            
            
            
            
            row++;
            
            
            
            r++;
            bak++;
            
            jPanel1.add(gb,BorderLayout.NORTH);
            
            
            
             }
               }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
           
             
           try{
        
           
           Connection con = Database.getConnection();
           Statement ps8001 = con.createStatement();
           ResultSet rs8001=ps8001.executeQuery("SELECT IFNULL(SUM(credit),0) as credit,IFNULL(SUM(debit),0) as debit FROM `company_main_table`  ");
          
              
            while(rs8001.next())
            {
             if(rs8001.getString("debit")!=null)
             {
               String t_debit=rs8001.getString("debit");
               String t_credit=rs8001.getString("credit");    
             
            JLabel tohead65=new JLabel("Total");
            tohead65.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=row2;
            gridBagConstraints.gridwidth=17;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.6;
            jPanel2.add(tohead65,gridBagConstraints);
            tohead65.setHorizontalAlignment(SwingConstants.LEFT);
            tohead65.setFont(myFont);
            
            JLabel tohead66=new JLabel(t_debit);
            tohead66.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.gridx=18;
            gridBagConstraints.gridy=row2;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            jPanel2.add(tohead66,gridBagConstraints);
            tohead66.setHorizontalAlignment(SwingConstants.RIGHT);
            tohead66.setFont(myFont);
            
            JLabel tohead70=new JLabel(" ");
            tohead70.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.gridx=25;
            gridBagConstraints.gridy=row2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0;
            jPanel2.add(tohead70,gridBagConstraints);
            tohead70.setHorizontalAlignment(SwingConstants.RIGHT);
            tohead70.setFont(myFont);
            
            
            JLabel tohead67=new JLabel(t_credit);
            tohead67.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.gridx=27;
            gridBagConstraints.gridy=row2;
            gridBagConstraints.gridwidth=6;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.2;
            jPanel2.add(tohead67,gridBagConstraints);
            tohead67.setHorizontalAlignment(SwingConstants.RIGHT);
            tohead67.setFont(myFont);
               
            
            
               
//            labels[row2][0] = new JButton("Total");
//            
//            labels[row2][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=0;
//            gridBagConstraints.gridy=row2;
//            gridBagConstraints.gridwidth=17;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.6;
//            jPanel2.add(labels[row2][0],gridBagConstraints);
//            labels[row2][0].setFont(myFont);
//            labels[row2][0].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row2][0].setBorderPainted(false);
//            labels[row2][0].setContentAreaFilled(false);
//     //        labels[row][0].requestFocusInWindow();
//                        
//    
//           
//            labels[row2][1] = new JButton("t_debit"); 
//           
//            labels[row2][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=18;
//            gridBagConstraints.gridy=row2;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0.2;
//            jPanel2.add(labels[row2][1],gridBagConstraints);
//            labels[row2][1].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row2][1].setBorderPainted(false);
//            labels[row2][1].setContentAreaFilled(false);
//            
//            
//            labels[row2][2] = new JButton(" "); 
//           
//            labels[row2][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
//            gridBagConstraints.gridx=25;
//            gridBagConstraints.gridy=row2;
//            gridBagConstraints.gridwidth=1;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            gridBagConstraints.weightx=0;
//            jPanel2.add(labels[row2][2],gridBagConstraints);
//            labels[row2][2].setHorizontalAlignment(SwingConstants.RIGHT);
//            labels[row2][2].setFont(myFont);
//            labels[row2][2].setBorderPainted(false);
//            labels[row2][2].setContentAreaFilled(false);
//              
//            
//            labels[row2][3] = new JButton("t_credit"); 
//           
//            labels[row2][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.green));
//            gridBagConstraints.weightx=0.2;
//            gridBagConstraints.gridx=27;
//            gridBagConstraints.gridy=row2;
//            gridBagConstraints.gridwidth=6;
//            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
//            jPanel2.add(labels[row2][3],gridBagConstraints);
//            labels[row2][3].setBorderPainted(false);
//            labels[row2][3].setContentAreaFilled(false); 
            
            
            
            
            
            row2++; 
             }
              }
               }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
            
          // Convering Buttons to Labels
            
            for (int i = 0; i < row; i++) 
                {
                   // loop for column buttons 0-8
                    for (JButton item : labels[i]) 
                   {
                       item.setBorderPainted(false);
                       item.setContentAreaFilled(false);
                       item.setFocusPainted(false);
                       item.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
                   }
                }
           
           // Initial Focus on First Row
            
           labels[0][0].requestFocus();
           labels[0][0].setContentAreaFilled(true);
           labels[0][1].setContentAreaFilled(true);
           labels[0][2].setContentAreaFilled(true);
           labels[0][3].setContentAreaFilled(true);
           
           labels[0][0].setBackground(Color.cyan);
           labels[0][1].setBackground(Color.cyan);
           labels[0][2].setBackground(Color.cyan);
           labels[0][3].setBackground(Color.cyan);
            
        //Embedding Key Movement traversal
        // i loop for rows
        // j loop for columns
          
        for (int i = 0; i < row; i++) 
        {
          for (int j = 0; j < labels[i].length; j++) {
            final int rowfin = row;
            final int curRow = i;
            final int curCol = j;
            //labels[i][j].setBorderPainted(true);
            labels[i][j].addKeyListener(enter);
            labels[i][j].addKeyListener(new KeyAdapter() {
               @Override
               public void keyPressed(KeyEvent e) {
                  switch (e.getKeyCode()) {
                  case KeyEvent.VK_UP:
                     if (curRow > 0)
                     {
                        labels[curRow][curCol].setContentAreaFilled(false);
                        labels[curRow][curCol+1].setContentAreaFilled(false);
                        labels[curRow][curCol+2].setContentAreaFilled(false);
                        labels[curRow][curCol+3].setContentAreaFilled(false);
                         
                        labels[curRow - 1][curCol].requestFocus();
                        labels[curRow - 1][curCol].setContentAreaFilled(true);
                        labels[curRow - 1][curCol+1].setContentAreaFilled(true);
                        labels[curRow - 1][curCol+2].setContentAreaFilled(true);
                        labels[curRow - 1][curCol+3].setContentAreaFilled(true);
                        
                        labels[curRow - 1][curCol].setBackground(Color.cyan);
                        labels[curRow - 1][curCol+1].setBackground(Color.cyan);
                        labels[curRow - 1][curCol+2].setBackground(Color.cyan);
                        labels[curRow - 1][curCol+3].setBackground(Color.cyan);
                     }
                     break;
                  case KeyEvent.VK_DOWN:
                     if (curRow < rowfin - 1)
                     {
                        labels[curRow][curCol].setContentAreaFilled(false);
                        labels[curRow][curCol+1].setContentAreaFilled(false);
                        labels[curRow][curCol+2].setContentAreaFilled(false);
                        labels[curRow][curCol+3].setContentAreaFilled(false);    
                                                                    
                        labels[curRow + 1][curCol].requestFocus();
                        labels[curRow + 1][curCol].setContentAreaFilled(true);
                        labels[curRow + 1][curCol+1].setContentAreaFilled(true);
                        labels[curRow + 1][curCol+2].setContentAreaFilled(true);
                        labels[curRow + 1][curCol+3].setContentAreaFilled(true);
                        
                        labels[curRow + 1][curCol].setBackground(Color.cyan);
                        labels[curRow + 1][curCol+1].setBackground(Color.cyan);
                        labels[curRow + 1][curCol+2].setBackground(Color.cyan);
                        labels[curRow + 1][curCol+3].setBackground(Color.cyan);
                     }
                       break;
                  
                  case KeyEvent.VK_LEFT:
                     
                     break;
                  
                  case KeyEvent.VK_RIGHT:
                     
                     break;
                  
                  default:
                      System.out.println();
                     break;
                  
                  }
               }
            });
         }
      }
                     }    
    

    public KeyListener enter = new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
         if (e.getKeyChar() == KeyEvent.VK_ENTER) {
            ((JButton) e.getComponent()).doClick();
         }
      }
   };

    
    public void print(){
    System.out.println(head_trans);
    HashMap param=new HashMap();
    param.put("trial_balance_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\trial_balance_printable_report.jasper", param);
    viewer1.setVisible(true);
}
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        jPanel1.setLayout(new java.awt.GridBagLayout());
        jScrollPane1.setViewportView(jPanel1);

        jPanel2.setLayout(new java.awt.GridBagLayout());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    @Override
    public void componentAdded(ContainerEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void componentRemoved(ContainerEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
