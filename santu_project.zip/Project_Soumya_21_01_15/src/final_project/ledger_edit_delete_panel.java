package final_project;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import net.proteanit.sql.DbUtils;
import org.jdesktop.xswingx.PromptSupport;
//import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author virtual vista
 */
public class ledger_edit_delete_panel extends javax.swing.JPanel {
    Font myFont = new Font("",Font.PLAIN,9);
     int i=0,j=0;    // For Mandatory
     int x=0,y=0,z=0; // For Non Mandatory
     String user_activity_id="";

     
       String country_name="";
    String country_id1="";
    String isd="";
    String state_name="";
    String state_id="";
    
    String city_name1="";
    String city_id="";
    /**
     * Creates new form ledger_edit_delete_panel
     */
     
      public void user(String user1){
       jLabel17.setText(user1);
   }
      public void set(){
          jTextField13.requestFocusInWindow();
          jTextField13.setFocusable(true);
      }
     
    public ledger_edit_delete_panel() 
    {
//         JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
        initComponents();
        
        country();
        state();
        //city();
        set();
        reset();
        
        //name_txt.setEditable(false);
        
        under_name.setVisible(false);
        jTextField12.setVisible(false);
        name.setVisible(false);
        name_txt.setFocusable(true);
        create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        jLabel17.setVisible(false);
        
        
        try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct g_name from acc_group order by acc_g_id");
          
            while(rs.next())
            {
                String name=rs.getString("g_name");

                under.addItem(name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        jLabel2.setFont(myFont);
        jLabel2.setEnabled(false);
        jLabel2.setVisible(false);
        
        jLabel3.setFont(myFont);
        jLabel3.setEnabled(false);
        jLabel3.setVisible(false);
        
        jLabel4.setFont(myFont);
        jLabel4.setEnabled(false);
        jLabel4.setVisible(false);
        
       // jLabel5.setFont(myFont);
       // jLabel5.setEnabled(false);
       // jLabel5.setVisible(false);
        
        jLabel6.setFont(myFont);
        jLabel6.setEnabled(false);
        jLabel6.setVisible(false);
        
        jLabel7.setFont(myFont);
        jLabel7.setEnabled(false);
        jLabel7.setVisible(false);
        
        jLabel8.setFont(myFont);
        jLabel8.setEnabled(false);
        jLabel8.setVisible(false);
        
        jLabel9.setFont(myFont);
        jLabel9.setEnabled(false);
        jLabel9.setVisible(false);
        
        jLabel10.setFont(myFont);
        jLabel10.setEnabled(false);
        jLabel10.setVisible(false);
        
        jLabel11.setFont(myFont);
        jLabel11.setEnabled(false);
        jLabel11.setVisible(false);
        
        jLabel12.setFont(myFont);
        jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        PromptSupport.setPrompt("12, ABC Road", address_txt);
        PromptSupport.setPrompt("AAAPL1234C", pan_it_no_txt);
        PromptSupport.setPrompt("12345678901", sale_tax_no_txt);
        PromptSupport.setPrompt("ABCD1234567", bsr_ifsc_code_txt);
        PromptSupport.setPrompt("1234567", account_no_txt);
       // PromptSupport.setPrompt("STATE", state_txt);
        PromptSupport.setPrompt("BRANCH", branch_name_txt);
        PromptSupport.setPrompt("0.00", ope_bal_num);
        PromptSupport.setPrompt("0.00", per_num);
        PromptSupport.setPrompt("LEDGER", name_txt);
        update_table();
        search();
       
     jTextField12.setVisible(false);
        //name.setVisible(false);
        name1.setVisible(false);
        
        under_name.setVisible(false);
         table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }

            
        });
      
    }
    
    
     public void country(){
         try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select * from country_name order by country_id");
          
            while(rs.next())
            {
                country_name=rs.getString("country_name");
                country_id1=rs.getString("country_id");
                isd=rs.getString("isd_code");

                l_country.addItem(country_name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }
    
    public void state(){
          try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct * from state_name order by state_id");
          
            while(rs.next())
            {
                String name=rs.getString("state_name");
                String id=rs.getString("state_id");

                l_state.addItem(name);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
    }
    
    
     public void city(){
          try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct * from city_name order by city_id");
          
            while(rs.next())
            {
                String city_name1=rs.getString("city_name");
                String city_id1=rs.getString("city_id");

               // l_city.addItem(city_name1);
               
            }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        
    }
    
    
      // name
    
    
    public void name(){
            if(name_txt.getText().length()==0)
      {
          name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel2.setEnabled(true);
          jLabel2.setForeground(Color.red);
          jLabel2.setVisible(true);
             
      }  
      else
      {
           name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel2.setEnabled(false);  
           jLabel2.setVisible(false);
           i=1;
          
      }
        
    }
    
    
    // under
    
    
     public void under(){
           if(under.getSelectedItem().equals(""))
      {
          under.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel3.setEnabled(true);
          jLabel3.setForeground(Color.red);
          jLabel3.setVisible(true);
             
      }  
      else
      {
           under.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel3.setEnabled(false);  
           jLabel3.setVisible(false);
           j=1;
      }
        
    }
            
        
               
            
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
     public void search(){
        jTextField13.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
                String s1=jTextField13.getText();
                String s3=s1;
     
                try
                    {
                        
                    
                    Connection con = Database.getConnection();
                    Statement ps =con.createStatement();
                    ResultSet rs=ps.executeQuery("SELECT l_name as `LEDGER NAME` from ledger where l_name like '"+s3+"%'"); 


                    table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
                    con.close();
                    }
                    catch (SQLException e1)
                    {
                    System.out.println("Sql Exception" + e1.toString());
                    }
                    
                
        }
            });
    }
    
    
    public void update_table()
{
       
        try{
        
           
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT l_name as `LEDGER NAME` from ledger ");
          table.setModel(DbUtils.resultSetToTableModel(rs));
           con.close();
          
          
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
        
        table.addKeyListener(new java.awt.event.KeyAdapter()

            {

public void keyReleased(java.awt.event.KeyEvent e)

{
   
int keyvalue=e.getKeyCode();
if(keyvalue==KeyEvent.VK_ENTER)
                {
                    

                 int row=table.getSelectedRow();
                 int col=table.getSelectedColumn();
                
                if(table.getValueAt(row, 0) != null){
                String s1= (String)table.getValueAt(row, 0);
                
                
//JOptionPane.showMessageDialog(null,"Value in the cell clicked :"+ "" +table.getValueAt(0,(table.getSelectedColumn())).toString());

            System.out.println(" Value in the row clicked :"+ " " +row+"");
            System.out.println(" Value in the col clicked :"+ " " +col+"");
            System.out.println(" Value in the col,row clicked :"+ " " +s1+"");

          try{
         
           
           Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
           ResultSet rs1=ps1.executeQuery("SELECT * from ledger where l_name='"+s1+"' ");
       while(rs1.next())
                {
                              
                   
                   String  aa=rs1.getString("l_id");
                jTextField12.setText(aa);
                
                String a1=rs1.getString("l_name");
                name_txt.setText(a1);
                name.setText(a1);

               
                under.setSelectedItem(rs1.getString("l_under"));
                under_name.setText(rs1.getString("l_under"));
                
                String a3=rs1.getString("l_address");
                address_txt.setText(a3);
                
                
                
                String country=rs1.getString("l_country");
                l_country.setSelectedItem(country);
                
                String a4=rs1.getString("l_state");
                l_state.setSelectedItem(a4);
                
                
                String city=rs1.getString("l_city");
                l_city.setText(city);
                
                String pin=rs1.getString("l_pin");
                l_pin.setText(pin);
                
                String a5=rs1.getString("l_acc_no");
                account_no_txt.setText(a5);
                
                String a7=rs1.getString("l_pan");
                pan_it_no_txt.setText(a7);
                
                String a8=rs1.getString("l_sale_tax_no");
                sale_tax_no_txt.setText(a8);
                
                String a9=rs1.getString("l_branch");
                branch_name_txt.setText(a9);
                
                String a10=rs1.getString("l_bsr_code");
                bsr_ifsc_code_txt.setText(a10);
                
                String a11=rs1.getString("l_opning_balance");
                ope_bal_num.setText(a11);
                
                String a12=rs1.getString("l_persentage");
                per_num.setText(a12);
                    
                 Statement ps2 =con1.createStatement();
                ResultSet rs2=ps2.executeQuery("SELECT * from user_activity_table where table_name='ledger' and value='"+name.getText()+"'");
                    //System.out.println("SOUMYA 27_01_15"+rs2);
                while(rs2.next())
            {
                
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                
                }
          
         con1.close();
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        

                } 
                
                }



}
//
//                 @Override
//                public void keyPressed(java.awt.event.KeyEvent e) {
//                     table.getCellEditor().stopCellEditing();
//                   // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//                }

               

                @Override
                public void keyTyped(java.awt.event.KeyEvent e) {
                   table.getCellEditor().stopCellEditing();
//  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

               

}

);
    Action delete = new AbstractAction()
{
    public void actionPerformed(ActionEvent e)
    {
        
    }
};
 
 
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jTextField12 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        l_name = new javax.swing.JLabel();
        l_under = new javax.swing.JLabel();
        address = new javax.swing.JLabel();
        l_acc_no = new javax.swing.JLabel();
        l_pan = new javax.swing.JLabel();
        sale_tax = new javax.swing.JLabel();
        l_branch = new javax.swing.JLabel();
        l_bsr = new javax.swing.JLabel();
        l_opening_balance = new javax.swing.JLabel();
        l_persentage = new javax.swing.JLabel();
        name_txt = new javax.swing.JTextField();
        address_txt = new javax.swing.JTextField();
        account_no_txt = new javax.swing.JTextField();
        pan_it_no_txt = new javax.swing.JTextField();
        sale_tax_no_txt = new javax.swing.JTextField();
        branch_name_txt = new javax.swing.JTextField();
        bsr_ifsc_code_txt = new javax.swing.JTextField();
        under = new javax.swing.JComboBox();
        ope_bal_num = new numeric.textField.NumericTextField();
        per_num = new numeric.textField.NumericTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel29 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        l_pin = new javax.swing.JTextField();
        l_city = new javax.swing.JTextField();
        l_state = new com.jidesoft.swing.AutoCompletionComboBox();
        l_country = new com.jidesoft.swing.AutoCompletionComboBox();
        jPanel3 = new javax.swing.JPanel();
        save_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        clear_button = new javax.swing.JButton();
        name = new javax.swing.JTextField();
        under_name = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        create_date = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        update_date = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jTextField13 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        name1 = new javax.swing.JTextField();

        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Ledger Edit/Delete");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 13), java.awt.Color.blue)); // NOI18N

        l_name.setForeground(new java.awt.Color(0, 0, 255));
        l_name.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        l_name.setText("*Name:");

        l_under.setForeground(new java.awt.Color(0, 0, 255));
        l_under.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        l_under.setText("*Under:");

        address.setForeground(new java.awt.Color(0, 0, 255));
        address.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        address.setText("Address:");

        l_acc_no.setForeground(new java.awt.Color(0, 0, 255));
        l_acc_no.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        l_acc_no.setText("Account No:");

        l_pan.setForeground(new java.awt.Color(0, 0, 255));
        l_pan.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        l_pan.setText("PAN/IT No.");

        sale_tax.setForeground(new java.awt.Color(0, 0, 255));
        sale_tax.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        sale_tax.setText("Sale Tax No.");

        l_branch.setForeground(new java.awt.Color(0, 0, 255));
        l_branch.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        l_branch.setText("Branch Name:");

        l_bsr.setForeground(new java.awt.Color(0, 0, 255));
        l_bsr.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        l_bsr.setText("BSR/IFSC Code:");

        l_opening_balance.setForeground(new java.awt.Color(0, 0, 255));
        l_opening_balance.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        l_opening_balance.setText("Opening Balance:");

        l_persentage.setForeground(new java.awt.Color(0, 0, 255));
        l_persentage.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        l_persentage.setText("Percentage:");

        name_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        name_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                name_txtFocusLost(evt);
            }
        });

        address_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        address_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                address_txtActionPerformed(evt);
            }
        });

        account_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        pan_it_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        sale_tax_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_tax_no_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sale_tax_no_txtActionPerformed(evt);
            }
        });

        branch_name_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        bsr_ifsc_code_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        bsr_ifsc_code_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                bsr_ifsc_code_txtFocusLost(evt);
            }
        });

        under.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        under.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        under.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                underFocusLost(evt);
            }
        });
        under.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                underActionPerformed(evt);
            }
        });

        ope_bal_num.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ope_bal_num.setText("numericTextField1");
        ope_bal_num.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                ope_bal_numFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                ope_bal_numFocusLost(evt);
            }
        });

        per_num.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        per_num.setText("numericTextField1");
        per_num.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                per_numFocusLost(evt);
            }
        });

        jLabel2.setText("Ledger Name Can Not be Empty!");

        jLabel3.setText("Select Under!");

        jLabel4.setText("Please Provide Your Address!");

        jLabel6.setText("Enter Valid Account Number!");

        jLabel7.setText("Enter Valid PAN/IT Number!");

        jLabel8.setText("Enter Valid Sales Tax Number!");

        jLabel9.setText("Enter Valid Branch Name!");

        jLabel10.setText("Enter Valid BSR/IFSC Code!");

        jLabel11.setText("Enter Valid Opening Balance!");

        jLabel12.setText("Enter Valid Percentage!");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Dr", "Cr" }));

        jLabel29.setForeground(new java.awt.Color(0, 0, 255));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel29.setText("Country:");

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("State:");

        jLabel31.setForeground(new java.awt.Color(0, 0, 255));
        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31.setText("City:");

        jLabel30.setForeground(new java.awt.Color(0, 0, 255));
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel30.setText("Pincode:");

        l_country.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "select" }));
        l_country.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l_countryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(l_pin, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(l_opening_balance, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 99, Short.MAX_VALUE)
                                .addComponent(l_bsr, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(l_branch, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(sale_tax, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(l_pan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(l_acc_no, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(l_persentage, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(address, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                                .addComponent(l_under, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(l_name, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(l_city, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(l_state, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(l_country, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(26, 26, 26))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(ope_bal_num, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(address_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(account_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pan_it_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(sale_tax_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(branch_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bsr_ifsc_code_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(per_num, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(under, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_name)
                    .addComponent(name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_under)
                    .addComponent(under, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(address)
                    .addComponent(address_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(l_country, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(l_state, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(l_city, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_pin, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_acc_no)
                    .addComponent(account_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_pan)
                    .addComponent(pan_it_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sale_tax)
                    .addComponent(sale_tax_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_branch)
                    .addComponent(branch_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_bsr)
                    .addComponent(bsr_ifsc_code_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_opening_balance)
                    .addComponent(ope_bal_num, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(per_num, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(l_persentage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 13), java.awt.Color.blue)); // NOI18N

        save_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save_button.setText("Save");
        save_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_buttonActionPerformed(evt);
            }
        });

        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete_button.setText("Delete");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });

        clear_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        clear_button.setText("Clear");
        clear_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(clear_button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(delete_button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
                    .addComponent(save_button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(save_button)
                .addGap(18, 18, 18)
                .addComponent(delete_button)
                .addGap(18, 18, 18)
                .addComponent(clear_button)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Informations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 13), java.awt.Color.cyan)); // NOI18N

        jLabel13.setForeground(new java.awt.Color(51, 153, 0));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Created By:");

        jLabel14.setForeground(new java.awt.Color(51, 153, 0));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Creation Date:");

        create_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_userActionPerformed(evt);
            }
        });

        jLabel15.setForeground(new java.awt.Color(51, 153, 0));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Updated By:");

        jLabel16.setForeground(new java.awt.Color(51, 153, 0));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Updation By:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(update_user, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(create_date, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(create_user, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel17.setText("jLabel17");

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 13), java.awt.Color.blue)); // NOI18N

        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jScrollPane2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        table.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        table.setForeground(new java.awt.Color(0, 0, 250));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, "", null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ));
        table.setGridColor(new java.awt.Color(138, 138, 138));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(under_name, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(73, 73, 73)
                        .addComponent(jLabel1)
                        .addGap(34, 34, 34))
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(jLabel17))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jPanel5, jPanel6});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(under_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel17))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(name1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 746, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void save_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_buttonActionPerformed
//JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
           
            
     if(name.getText().equals(""))
     {
           jopt1.showMessageDialog(this,"Select Ledger Name!"); 
     }

   
       
  else {
       name();
      under();  
         if(i==1&&j==1&&x==0&&y==0&&z==0)
    {       
       try{

            
            Connection con2 = Database.getConnection();
            Statement ps5 =con2.createStatement(); 
            ResultSet rs5=ps5.executeQuery("SELECT l_name from ledger where l_name='"+name_txt.getText()+"' and l_id!='"+jTextField12.getText()+"'");

//            if(rs5.next())
//            {
//                 jopt1.showMessageDialog(this,"Ledger Already Exsist"); 
//            }
//            else
//            {
            
//                PreparedStatement ps10=con2.prepareStatement("update user_activity_table set value='"+name_txt.getText()+"' where  value='"+name.getText()+"'");
//                ps10.executeUpdate();
            
                log_table.table_update("ledger",name_txt.getText(),user_activity_id);
                PreparedStatement ps1=con2.prepareStatement("update ledger set l_name='"+name_txt.getText()+"',l_under='"+under.getSelectedItem().toString()+"',l_address='"+address_txt.getText()+"',l_state='"+l_state.getSelectedItem().toString()+"',l_country='"+l_country.getSelectedItem().toString()+"',l_city='"+l_city.getText()+"',l_pin='"+l_pin.getText()+"',l_acc_no='"+account_no_txt.getText()+"',l_pan='"+pan_it_no_txt.getText()+"',l_sale_tax_no='"+sale_tax_no_txt.getText()+"',l_branch='"+branch_name_txt.getText()+"',l_bsr_code='"+bsr_ifsc_code_txt.getText()+"',l_opning_balance='"+ope_bal_num.getText()+"',l_persentage='"+per_num.getText()+"' where  l_id='"+jTextField12.getText()+"'");
                ps1.executeUpdate();
                 
                
                
                
                 if(jComboBox1.getSelectedItem().equals("Dr"))
                    {
                        
                         PreparedStatement ps4=con2.prepareStatement("insert into `"+under.getSelectedItem().toString()+"` select * from `"+under_name.getText()+"` where `"+under_name.getText()+"`.l_name='"+name.getText()+"'");
                         ps4.executeUpdate();
                    }
                 else
                    {
                         PreparedStatement ps4=con2.prepareStatement("insert into `"+under.getSelectedItem().toString()+"` (l_name,debit,credit,trans_id,date) select l_name,debit,credit,trans_id,date  from `"+under_name.getText()+"` where `"+under_name.getText()+"`.l_name='"+name.getText()+"'");
                         ps4.executeUpdate();
                    }
                 PreparedStatement ps3=con2.prepareStatement("delete from  `"+under_name.getText()+"` where l_name='"+name.getText()+"'");

                ps3.executeUpdate();
                
                 try{
           Connection con1 = Database.getConnection();
           Statement ps6 =con1.createStatement(); 
           ResultSet rs6=ps6.executeQuery("SELECT city_name from city_name where city_name='"+l_city.getText()+"'");

if(rs6.next())
{
  //   jopt1.showMessageDialog(this,"City Already Exsist"); 
}
else{
    PreparedStatement ps=con1.prepareStatement("insert into city_name (country_id,state_id,city_name)values('"+country_id1+"','"+state_id+"','"+l_city.getText()+"')");
            ps.executeUpdate();
            
            //jopt1.showMessageDialog(this,"New City Saved"); 
}
            }
            catch(Exception e){
                
            }
                
                
               
               // under.removeAll();
          //  }
        con2.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
        jopt1.showMessageDialog(this,"Ledger Updated");
                update_table();
                search();
               reset();
               set();
    }
     }
    }//GEN-LAST:event_save_buttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
       jTextField13.setText("");
       if(name.getText().equals(""))
     {
           jopt1.showMessageDialog(this,"Select Ledger Name!"); 
     }
       else{
        int p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(p==0)
        {
            
            
            try{

               //Connection con = Database.getConnection();
                
                Connection con1 = Database.getConnection();
                 Statement ps5 =con1.createStatement(); 
            ResultSet rs5=ps5.executeQuery("SELECT distinct flag from company_main_table where ledger='"+name.getText()+"' and type!='Opening'");

            if(rs5.next())
            {
                String fl=rs5.getString("flag");
               
                 jopt1.showMessageDialog(this,"Ledger can't be deleted "+""+"\n"+""+"Delete the transactions first"); 
                 
                 
            }
            
            else{
                PreparedStatement ps1=con1.prepareStatement("delete from  ledger where l_id='"+jTextField12.getText()+"'");

                ps1.executeUpdate();
                PreparedStatement ps3=con1.prepareStatement("delete from  `"+under.getSelectedItem().toString()+"` where l_name='"+name.getText()+"' ");

                ps3.executeUpdate();
                  PreparedStatement ps30=con1.prepareStatement("delete from  company_main_table where ledger='"+name.getText()+"' ");

                ps30.executeUpdate();
                System.out.println("Done");
                
                log_table.table_delete("ledger",jLabel17.getText());
                con1.close();
                }
            
            }catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
             JOptionPane.showMessageDialog(null,"Ledger Deleted");
            set();
          reset();
            under.removeAll();
         update_table();

        }
        else{
           reset();
            under.removeAll();
        }
       }
    }//GEN-LAST:event_delete_buttonActionPerformed

    public void reset(){
          name_txt.setText(null);
        under.setSelectedIndex(0);
        address_txt.setText(null);
        l_country.setSelectedIndex(0);
        l_state.removeAllItems();
        l_city.setText(null);
        l_pin.setText(null);
        account_no_txt.setText(null);
        pan_it_no_txt.setText(null);
        sale_tax_no_txt.setText(null);
        branch_name_txt.setText(null);
        bsr_ifsc_code_txt.setText(null);
        ope_bal_num.setText(null);
        per_num.setText(null);
        jTextField13.setText(null);
        under_name.setText(null);
        jTextField12.setText(null);
        name.setText(null);
        name1.setText(null);
        
        
        name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        under.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        address_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
       // state_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        account_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        pan_it_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_tax_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        branch_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        bsr_ifsc_code_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ope_bal_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        per_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
              
        
         
        
        jLabel2.setVisible(false);  
        jLabel3.setVisible(false);              
        jLabel4.setVisible(false);               
        //jLabel5.setVisible(false);               
        jLabel6.setVisible(false);               
        jLabel7.setVisible(false);               
        jLabel8.setVisible(false);               
        jLabel9.setVisible(false);             
        jLabel10.setVisible(false);               
        jLabel11.setVisible(false);               
        jLabel12.setVisible(false);
        
        
        create_user.setText(null);
        create_date.setText(null);
        update_user.setText(null);
        update_date.setText(null);
        
        
    }
    
    private void clear_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_buttonActionPerformed

     reset();
     set();
        // TODO add your handling code here:
    }//GEN-LAST:event_clear_buttonActionPerformed

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
    under.setSelectedItem("");
       
//       l_country.setSelectedIndex(0);
//       l_state.setSelectedIndex(0);
      
//     country();
//     state();
//     city();
        int new1=table.getSelectedRow();
        String table_click=(table.getModel().getValueAt(new1, 0).toString());
        try{

          
            Connection con1 = Database.getConnection();
            Statement ps1 =con1.createStatement();
            ResultSet rs1=ps1.executeQuery("SELECT * from ledger where l_name='"+table_click+"' ");
            under.removeAll();
            while(rs1.next())
            {

                
                
                String  aa=rs1.getString("l_id");
                jTextField12.setText(aa);
                 
                String a1=rs1.getString("l_name");
                name_txt.setText(a1);
                name.setText(a1);
               // name.setText(a1);
            
                under.setSelectedItem(rs1.getString("l_under"));
                under_name.setText(rs1.getString("l_under"));
                
                String a3=rs1.getString("l_address");
                address_txt.setText(a3);
                
                
                
                String country=rs1.getString("l_country");
                l_country.setSelectedItem(country);
                
                String a4=rs1.getString("l_state");
                l_state.setSelectedItem(a4);
                
                String city=rs1.getString("l_city");
                l_city.setText(city);
                
                String pin=rs1.getString("l_pin");
                l_pin.setText(pin);
                
                String a5=rs1.getString("l_acc_no");
                account_no_txt.setText(a5);
                
                String a7=rs1.getString("l_pan");
                pan_it_no_txt.setText(a7);
                
                String a8=rs1.getString("l_sale_tax_no");
                sale_tax_no_txt.setText(a8);
                
                String a9=rs1.getString("l_branch");
                branch_name_txt.setText(a9);
                
                String a10=rs1.getString("l_bsr_code");
                bsr_ifsc_code_txt.setText(a10);
                
                String a11=rs1.getString("l_opning_balance");
                ope_bal_num.setText(a11);
                
                String a12=rs1.getString("l_persentage");
                per_num.setText(a12);
                Statement ps2 =con1.createStatement();
                ResultSet rs2=ps2.executeQuery("SELECT * from user_activity_table where table_name='ledger' and value='"+name.getText()+"'");
                while(rs2.next())
            {
                user_activity_id=rs2.getString("id");
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
            }

            under.removeAll();
            con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
       

        // TODO add your handling code here:
    }//GEN-LAST:event_tableMouseClicked

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void sale_tax_no_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sale_tax_no_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sale_tax_no_txtActionPerformed

    private void address_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_address_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_address_txtActionPerformed

    private void bsr_ifsc_code_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_bsr_ifsc_code_txtFocusLost
         
                        
                        
                         if(bsr_ifsc_code_txt.getText().length()==0)
                            {
                               bsr_ifsc_code_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                               jLabel10.setEnabled(false);  
                               jLabel10.setVisible(false);
                               x=0;
                                
                            }
                            else
                            {
                        String email =bsr_ifsc_code_txt.getText();
                        String regEx1 = "^[a-zA-Z0-9]+$";
                        Pattern p1 = Pattern.compile(regEx1);
                        Matcher m1 = p1.matcher(email);
                        bsr_ifsc_code_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                        jLabel10.setEnabled(false);  
                        jLabel10.setVisible(false);
                        x=0;
                       
                      if(m1.find()==false)
                    {
                        x=1;
                       bsr_ifsc_code_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                       jLabel10.setEnabled(true);
                       jLabel10.setForeground(Color.red);
                       jLabel10.setVisible(true);
                     
                    }
                            }
                         
    }//GEN-LAST:event_bsr_ifsc_code_txtFocusLost

    private void ope_bal_numFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ope_bal_numFocusLost
            if(ope_bal_num.getText().length()==0)
                            {
                                ope_bal_num.setText("0.00");
                               ope_bal_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                               jLabel10.setEnabled(false);  
                               jLabel10.setVisible(false);
                               y=0;
                                
                            }
                            else
                            {
                       String content = ope_bal_num.getText();
                       Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
                       Matcher m = p.matcher(content);
                       boolean matchFound = m.matches();
                       ope_bal_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel10.setEnabled(false);  
                       jLabel10.setVisible(false);
                       y=0;
                     if(!matchFound)
                    {
                        y=1;
                       ope_bal_num.setBorder(BorderFactory.createLineBorder(Color.red));
                       jLabel10.setEnabled(true);
                       jLabel10.setForeground(Color.red);
                       jLabel10.setVisible(true);
                     
                    }
                            }
    }//GEN-LAST:event_ope_bal_numFocusLost

    private void per_numFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_per_numFocusLost
               
                      if(per_num.getText().length()==0)
                            {
                               per_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                               jLabel12.setEnabled(false);  
                               jLabel12.setVisible(false);
                               z=0;
                                
                            }
                            else
                            {
                       String content = per_num.getText();
                       Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
                       Matcher m = p.matcher(content);
                       boolean matchFound = m.matches();
                       per_num.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel12.setEnabled(false);  
                       jLabel12.setVisible(false);
                       z=0;
                     if(!matchFound)
                    {
                        z=1;
                       per_num.setBorder(BorderFactory.createLineBorder(Color.red));
                       jLabel12.setEnabled(true);
                       jLabel12.setForeground(Color.red);
                       jLabel12.setVisible(true);
                     
                    }
                     
                            }
    }//GEN-LAST:event_per_numFocusLost

    private void underActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_underActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_underActionPerformed

    private void name_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_name_txtFocusLost
    if(name_txt.getText().length()==0)
      {
          name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel2.setEnabled(true);
          jLabel2.setForeground(Color.red);
          jLabel2.setVisible(true);
             
      }  
      else
      {
           name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel2.setEnabled(false);  
           jLabel2.setVisible(false);
           i=1;
          
      }
    }//GEN-LAST:event_name_txtFocusLost

    private void underFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_underFocusLost
            if(under.getSelectedItem().equals(""))
      {
          under.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel3.setEnabled(true);
          jLabel3.setForeground(Color.red);
          jLabel3.setVisible(true);
             
      }  
      else
      {
           under.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel3.setEnabled(false);  
           jLabel3.setVisible(false);
           j=1;
      }
    }//GEN-LAST:event_underFocusLost

    private void create_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_userActionPerformed
         // TODO add your handling code here:
    }//GEN-LAST:event_create_userActionPerformed

    private void l_countryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l_countryActionPerformed
        // TODO add your handling code here:
          
        
          
          String c_name=l_country.getSelectedItem().toString();
          
          if(c_name.equals("select")){
              
               l_state.setSelectedItem("");
          }
          
          else{
              
         
        try{
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct country_id from country_name where country_name='"+c_name+"'");
          
                while(rs.next())
                {

                    country_id1=rs.getString("country_id");
    //                l_country.addItem(country_name);               
                }
                l_state.removeAllItems();
                Statement ps1 =con1.createStatement();
                ResultSet rs1=ps1.executeQuery("SELECT DISTINCT state_name FROM state_name WHERE country_id='"+country_id1+"' ORDER BY state_name");
                System.out.println("State "+ rs1);
                l_state.addItem("Select");
                while(rs1.next())                
                {         
                    state_name=rs1.getString("state_name");
                    l_state.addItem(state_name);
                }            
            con1.close();
        }
        catch(Exception e){
            
        }
      }
    }//GEN-LAST:event_l_countryActionPerformed

    private void ope_bal_numFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ope_bal_numFocusGained
        // TODO add your handling code here:
        ope_bal_num.setText("");
    }//GEN-LAST:event_ope_bal_numFocusGained

    public void fill_combo_ref(){
        try{

            
            Connection con1 = Database.getConnection();
            Statement ps =con1.createStatement();
            ResultSet rs=ps.executeQuery("select distinct g_name from acc_group order by acc_g_id");
                while(rs.next())
                {
                    String name=rs.getString("g_name");
                    under.addItem(name);

                }
           con1.close();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField account_no_txt;
    private javax.swing.JLabel address;
    private javax.swing.JTextField address_txt;
    private javax.swing.JTextField branch_name_txt;
    private javax.swing.JTextField bsr_ifsc_code_txt;
    private javax.swing.JButton clear_button;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private javax.swing.JButton delete_button;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JLabel l_acc_no;
    private javax.swing.JLabel l_branch;
    private javax.swing.JLabel l_bsr;
    private javax.swing.JTextField l_city;
    private com.jidesoft.swing.AutoCompletionComboBox l_country;
    private javax.swing.JLabel l_name;
    private javax.swing.JLabel l_opening_balance;
    private javax.swing.JLabel l_pan;
    private javax.swing.JLabel l_persentage;
    private javax.swing.JTextField l_pin;
    private com.jidesoft.swing.AutoCompletionComboBox l_state;
    private javax.swing.JLabel l_under;
    private javax.swing.JTextField name;
    private javax.swing.JTextField name1;
    private javax.swing.JTextField name_txt;
    private numeric.textField.NumericTextField ope_bal_num;
    private javax.swing.JTextField pan_it_no_txt;
    private numeric.textField.NumericTextField per_num;
    private javax.swing.JLabel sale_tax;
    private javax.swing.JTextField sale_tax_no_txt;
    private javax.swing.JButton save_button;
    private javax.swing.JTable table;
    private javax.swing.JComboBox under;
    private javax.swing.JTextField under_name;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    // End of variables declaration//GEN-END:variables
private javax.swing.JOptionPane jopt1;
}
