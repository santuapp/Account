package final_project;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class outstanding_receivable extends javax.swing.JPanel {
String head_trans="";
    /**
     * Creates new form outstanding_receivable
     */
    public outstanding_receivable() {
        initComponents();
        
        table.setRowHeight(30);
        table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }
        });
        TableColumnModel cmodel = table.getColumnModel(); 
        TextAreaRenderer textAreaRenderer = new TextAreaRenderer(); 
        cmodel.getColumn(0).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(1).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(2).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(3).setCellRenderer(textAreaRenderer);
       
        addRows(table);
        
        
       

         
        
        
          
        
        
    }
    
   
    
    
    
      private void addRows(JTable table)
    
    { 
           DefaultTableModel y1 = (DefaultTableModel)table .getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            }
        
       try{
        
           
            Connection con = Database.getConnection();
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("select rec_date as Date,rec_ledger1 as Particulars,rec_invoice as Transaction_ID ,rec_total_amnt as AMOUNT from receipt order by receipt_id");
           int li_row=0;
           int rw = 0;
           Vector <String> r[] = (Vector <String> []) new Vector[1000];
           
           
        
           
           while(rs.next())
                 {
                 y1.addRow(r[rw]); 
                    
                 table.setValueAt(rs.getString("Date"), li_row, 0);
                 table.setValueAt(rs.getString("Particulars"), li_row, 1);
                 table.setValueAt(rs.getString("Transaction_ID"), li_row, 2);
                 table.setValueAt(rs.getString("AMOUNT"), li_row, 3);
                 
                  
       
                 
                 rw++;
                 li_row++;
                 }
           

   
            System.out.println("Done");
          
         
            }catch (SQLException e)
                {
                System.out.println("Sql Exception" + e.toString());
                }
       
 }
      
      public void rcv(){
             try{
        
            Class.forName("com.mysql.jdbc.Driver");
            String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
            Connection con = (Connection) DriverManager.getConnection(ConnUrl);
            
            // Adding Items to Party Ledger
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("select rec_date as Date,rec_ledger1 as Particulars,rec_invoice as Transaction_ID ,rec_total_amnt as AMOUNT from receipt order by receipt_id");
            
                  table.setModel(DbUtils.resultSetToTableModel(rs));
               }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            catch(ClassNotFoundException ce)
            {
                System.out.println("ClassNotFoundException" + ce.toString());
            } 
             
             
               
        table.setRowHeight(30);
        table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }
        });
        TableColumnModel cmodel = table.getColumnModel(); 
        TextAreaRenderer textAreaRenderer = new TextAreaRenderer(); 
        cmodel.getColumn(0).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(1).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(2).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(3).setCellRenderer(textAreaRenderer);
       
        addRows(table);
        
      }
    
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();

        setLayout(new java.awt.BorderLayout());

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Receipt Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(0, 0, 255))); // NOI18N

        table.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        table.setForeground(new java.awt.Color(0, 0, 255));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "Particulars", "Transaction_ID", "AMOUNT"
            }
        ));
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 388, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents
 public void print(){
    System.out.println(head_trans);
    HashMap param=new HashMap();
    param.put("receipt_main_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\receipt_details.jasper", param);
    viewer1.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
