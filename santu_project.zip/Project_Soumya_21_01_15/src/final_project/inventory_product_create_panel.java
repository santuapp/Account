package final_project;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import org.jdesktop.xswingx.PromptSupport;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author virtual vista
 */
public class inventory_product_create_panel extends javax.swing.JPanel {
Font myFont = new Font("",Font.PLAIN,9);

int i=0,j=0,k=0;   // For Mandatory
int x=0,y=0,z=0;       // For Non Mandatory
    /**
     * Creates new form inventory_product_create_panel
     */

public void set(){
    item_name_txt.requestFocusInWindow();
    item_name_txt.setFocusable(true);
}

public void user(String u_name){
    jLabel22.setText(u_name);
}
    public inventory_product_create_panel() 
    {
//         JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE);
        initComponents();
        set();
        PromptSupport.setPrompt("0.00", discount_txt);
        PromptSupport.setPrompt("0.00", tax_txt);
        PromptSupport.setPrompt("0.00", quantity_txt);
        PromptSupport.setPrompt("0.00", rate_txt);
        PromptSupport.setPrompt("0.00", value_txt);
        
        refresh_form();
        
        item_name_txt.setFocusable(true);
        item_name_txt.getCaret().setVisible(true);
        
        jLabel12.setFont(myFont);
        jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        jLabel13.setFont(myFont);
        jLabel13.setEnabled(false);
        jLabel13.setVisible(false);
        
        jLabel14.setFont(myFont);
        jLabel14.setEnabled(false);
        jLabel14.setVisible(false);
        
        jLabel15.setFont(myFont);
        jLabel15.setEnabled(false);
        jLabel15.setVisible(false);
        
        jLabel16.setFont(myFont);
        jLabel16.setEnabled(false);
        jLabel16.setVisible(false);
        
        jLabel17.setFont(myFont);
        jLabel17.setEnabled(false);
        jLabel17.setVisible(false);
        
        jLabel18.setFont(myFont);
        jLabel18.setEnabled(false);
        jLabel18.setVisible(false);
        
        jLabel19.setFont(myFont);
        jLabel19.setEnabled(false);
        jLabel19.setVisible(false);
        
        
        jLabel20.setFont(myFont);
        jLabel20.setEnabled(false);
        jLabel20.setVisible(false);
        
        jLabel21.setFont(myFont);
        jLabel21.setEnabled(false);
        jLabel21.setVisible(false);
        
        jLabel22.setVisible(false);
                
       //Discount & Tax
        jLabel7.setVisible(false);
        discount_txt.setVisible(false);
        jLabel16.setVisible(false);
        jLabel8.setVisible(false);
        tax_txt.setVisible(false);
        jLabel17.setVisible(false);
        
        
    }
        class FocusGrabber implements Runnable {
  private JComponent component;

  public FocusGrabber(JComponent component) {
    this.component = component;
  }

  public void run() {
    component.grabFocus();
  }
}
        // VaLIDATION..........................
        
    // item name
        
        public void item(){
            if(item_name_txt.getText().length()==0)
      {
          i=0;
          item_name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel12.setEnabled(true);
          jLabel12.setForeground(Color.red);
          jLabel12.setVisible(true);
             
      }  
      else
      {
           item_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel12.setEnabled(false);  
           jLabel12.setVisible(false);
           i=1;
      }    
            
            
        }
        
    // group
        
        public void group(){
              if(group.getSelectedItem().equals(""))
       {
           j=0;
          group.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
       }
       else
       {
           group.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           j=1;
       }
        }
        
      // unit
        
        public void unit(){
                     if(unit.getSelectedItem().equals(""))
       {
           k=0;
          unit.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel14.setEnabled(true);
          jLabel14.setForeground(Color.red);
          jLabel14.setVisible(true);
       }
       else
       {
           unit.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel14.setEnabled(false);  
           jLabel14.setVisible(false);
           k=1;
       }
        }
        
      // quantity
        
//        public void quantity(){
//              if(quantity_txt.getText().length()==0)
//        {
//            quantity_txt.setBorder(BorderFactory.createLineBorder(Color.red));
//            jLabel18.setEnabled(true);
//            jLabel18.setForeground(Color.red);
//            jLabel18.setVisible(true);
//        }
//        else
//        {
//             String content = quantity_txt.getText();
//             Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
//             Matcher m = p.matcher(content);
//             boolean matchFound = m.matches();
//             quantity_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//             jLabel18.setEnabled(false);  
//             jLabel18.setVisible(false);
//             l=1;
//           
//            if(!matchFound)
//
//            {
//                 quantity_txt.setBorder(BorderFactory.createLineBorder(Color.red));
//                 jLabel18.setEnabled(true);
//                 jLabel18.setForeground(Color.red);
//                 jLabel18.setVisible(true);
//                 
//            }
//        }
//        }
        
        // rate
        
//        public void rate(){
//                 if(rate_txt.getText().length()==0)
//      
//      {
//          rate_txt.setBorder(BorderFactory.createLineBorder(Color.red));
//          jLabel19.setEnabled(true);
//          jLabel19.setForeground(Color.red);
//          jLabel19.setVisible(true);
//             
//      }  
//      else
//      {
//           rate_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
//           jLabel19.setEnabled(false);  
//           jLabel19.setVisible(false);
//           m=1;
//        }
//                 
//        }

    public void refresh_form()
    {
        item_name_txt.setText(null);
//        group.removeAll();
//        unit.removeAll();
        quantity_txt.setText(null);
        rate_txt.setText(null);
        discount_txt.setText(null);
        tax_txt.setText(null);
        product_code_txt.setText(null);
        per_txt.setText(null);
        value_txt.setText(null);
        
        
        try{
        
            Connection con = Database.getConnection();
            
            // Adding Items to Group
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("select distinct inv_g_name from inv_group order by inv_g_id");
            
               while(rs.next())
              {
                  String name=rs.getString("inv_g_name");
                  group.addItem(name);
              }
               
            //              String name1="Others";
            //              group.addItem(name1);
            
            //Adding Items to Unit
            Statement ps2 =con.createStatement();
            ResultSet rs2=ps2.executeQuery("select distinct u_name from unit order by u_id");
            
               while(rs2.next())
              {
                  String name2=rs2.getString("u_name");
                  unit.addItem(name2);
              }
               con.close();            
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
        
    }
    
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane1 = new javax.swing.JOptionPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        reset_button = new javax.swing.JButton();
        submit_button = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        per_txt = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        quantity_txt = new numeric.textField.NumericTextField();
        rate_txt = new numeric.textField.NumericTextField();
        value_txt = new numeric.textField.NumericTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        item_name_txt = new javax.swing.JTextField();
        product_code_txt = new javax.swing.JTextField();
        discount_txt = new javax.swing.JTextField();
        tax_txt = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        group = new com.jidesoft.swing.AutoCompletionComboBox();
        unit = new com.jidesoft.swing.AutoCompletionComboBox();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Product Creation Master");

        reset_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        reset_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        reset_button.setText("Reset");
        reset_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reset_buttonActionPerformed(evt);
            }
        });

        submit_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        submit_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/folder-access-icon.png"))); // NOI18N
        submit_button.setText("Submit");
        submit_button.setPreferredSize(new java.awt.Dimension(61, 23));
        submit_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submit_buttonActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 153), 1, true), "Opening Balance", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Aharoni", 1, 12), new java.awt.Color(51, 102, 255))); // NOI18N

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Quantity:");

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Rate:");
        jLabel6.setToolTipText("");

        per_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        per_txt.setEnabled(false);
        per_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                per_txtFocusGained(evt);
            }
        });

        jLabel10.setForeground(new java.awt.Color(0, 0, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Per:");

        jLabel11.setForeground(new java.awt.Color(0, 0, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Value:");

        quantity_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        quantity_txt.setText("0");
        quantity_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                quantity_txtFocusLost(evt);
            }
        });

        rate_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        rate_txt.setText("0.0");
        rate_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                rate_txtFocusLost(evt);
            }
        });

        value_txt.setEditable(false);
        value_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        value_txt.setText("0.0");
        value_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                value_txtFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                value_txtFocusLost(evt);
            }
        });

        jLabel18.setText("Enter Quantity!");

        jLabel19.setText("Enter Rate!");

        jLabel20.setText("Enter Per!");

        jLabel21.setText("Enter Valid Value!");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(quantity_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rate_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(per_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(value_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 4, Short.MAX_VALUE)))
                .addGap(11, 11, 11))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel10, jLabel11, jLabel5, jLabel6});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quantity_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(rate_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(per_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(value_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel21)
                .addContainerGap())
        );

        jLabel22.setText("jLabel22");

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("*Item Name:");

        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("*Group:");

        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("*Unit:");

        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Product Code:");

        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Discount (%):");

        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Tax (%):");

        item_name_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                item_name_txtFocusLost(evt);
            }
        });

        discount_txt.setText("0");
        discount_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                discount_txtFocusLost(evt);
            }
        });

        tax_txt.setText("0");
        tax_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tax_txtFocusLost(evt);
            }
        });

        jLabel12.setText("Enter Valid Item Name!");

        jLabel13.setText("Select Group!");

        jLabel14.setText("Select Unit!");

        jLabel15.setText("Enter Product Code!");

        jLabel16.setText("Enter Disc. Percentage!");

        jLabel17.setText("Enter Tax Percentage!");

        group.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        group.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                groupFocusLost(evt);
            }
        });

        unit.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        unit.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                unitFocusLost(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(item_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(product_code_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(discount_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tax_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(group, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(unit, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(item_name_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addGap(9, 9, 9)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(group, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(unit, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(product_code_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(discount_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tax_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel17)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(194, 194, 194)
                        .addComponent(reset_button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(submit_button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel22))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(148, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jLabel22)
                .addGap(42, 42, 42)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submit_button, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reset_button))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 774, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void submit_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submit_buttonActionPerformed
// Validation Start.....
        
//JOptionPane.showMessageDialog(this,"\n" +
//"Class not found com.myproject.server.MyTest\n" +
//"java.lang.ClassNotFoundException: com.myproject.server.MyTest\n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:366) \n" +
//"    at java.net.URLClassLoader$1.run(URLClassLoader.java:355) \n" +
//"    at java.security.AccessController.doPrivileged(Native Method) \n" +
//"    at java.net.URLClassLoader.findClass(URLClassLoader.java:354) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:423) \n" +
//"    at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:308) \n" +
//"    at java.lang.ClassLoader.loadClass(ClassLoader.java:356) \n" +
//"","Warning", JOptionPane.WARNING_MESSAGE); 
        
        
        item();
        group();
        unit();
        //quantity();
   //     rate();
        
       
              if(i==1&&j==1&&k==1&&x==0&&y==0&&z==0)
                     {
                         
      
         
        try{

           Connection con = Database.getConnection();
           
           log_table.table_create("product", item_name_txt.getText());
           log_table.table_insert("product", item_name_txt.getText());

            PreparedStatement ps=con.prepareStatement("insert into product (product_name, p_group, p_unit, p_quantity, p_rate, p_discount, p_tax, product_code, p_value)values('"+item_name_txt.getText()+"','"+group.getSelectedItem().toString()+"','"+unit.getSelectedItem().toString()+"','"+quantity_txt.getText()+"','"+rate_txt.getText()+"','"+discount_txt.getText()+"','"+tax_txt.getText()+"','"+product_code_txt.getText()+"','"+value_txt.getText()+"')");
            ps.executeUpdate();
            
           PreparedStatement ps2=con.prepareStatement("insert into `"+group.getSelectedItem().toString()+"`(p_name,inv_open,inv_open_amount)values('"+item_name_txt.getText()+"','"+quantity_txt.getText()+"','"+value_txt.getText()+"')");
           ps2.executeUpdate();
            
            System.out.println("saved");
            refresh_form();
            jOptionPane1.showMessageDialog(this,"Product Created");
            
          reset();
          set();
         
         refresh_form();
           con.close(); 

        }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
        }
        

                     
                  
              
         }




    }//GEN-LAST:event_submit_buttonActionPerformed

    
    public void reset(){
         item_name_txt.setText(null);
        group.setSelectedIndex(0);
        unit.setSelectedIndex(0);
        product_code_txt.setText(null);
        discount_txt.setText(null);
        tax_txt.setText(null);
        quantity_txt.setText(null);
        rate_txt.setText(null);
        per_txt.setText(null);
        value_txt.setText(null);
        
        
        item_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        group.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        unit.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        product_code_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        discount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        tax_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        quantity_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        rate_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        per_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        value_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        
         
        
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
        jLabel14.setVisible(false);
        jLabel15.setVisible(false);
        jLabel16.setVisible(false);
        jLabel17.setVisible(false);
        jLabel18.setVisible(false);             
        jLabel19.setVisible(false);                    
        jLabel20.setVisible(false);       
        jLabel21.setVisible(false);
    }
    private void reset_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reset_buttonActionPerformed
       reset();
       set();
       
        
    }//GEN-LAST:event_reset_buttonActionPerformed

    private void rate_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_rate_txtFocusLost
      // Selecting Unit of Product
 //       rate();
        String xuname = null;
        String xu = unit.getSelectedItem().toString();
        try{
        
            Connection con3 = Database.getConnection();
            
            Statement ps3 =con3.createStatement();
            ResultSet rs3=ps3.executeQuery("select distinct u_value from unit where u_name='"+xu+"'");
                                                                    
               while(rs3.next())
              {
                  
                  xuname=rs3.getString("u_value");
                  
              }
               con3.close();    
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
           
        
        //Setting unit in short of Product
         per_txt.setText(xuname);           
        
        
        String rte  = rate_txt.getText();
        Pattern pattern = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
        Matcher matcher = pattern.matcher(rte);
        
        if (matcher.matches()) {
         
        }
        else
        {

            rate_txt.setText("0.0");
          //  quantity_txt.setText("0");
            JOptionPane.showMessageDialog(null, "Enter Number!");
        }
        //Calculating
       
        
//        if (!"0".equals(quant))
//        {
             String quant = quantity_txt.getText();
            //per_txt.setText("");
            Integer qty=Integer.parseInt(quant);
            Float rt = Float.parseFloat(rte);
            Float val =(qty*rt);
            value_txt.setText(val.toString());
      //  }
//        else
//        {
//          //  rate_txt.setText("0.00");
//           // per_txt.setText(xuname);
//            //String qty="1";
//            Float qt=Float.parseFloat(quantity_txt.getText());
//            Float rt = Float.parseFloat(rate_txt.getText());
//            Float val = (qt*rt);
//            value_txt.setText(val.toString());
//            
//        }
        
        
    }//GEN-LAST:event_rate_txtFocusLost

    private void quantity_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_quantity_txtFocusLost
              if(quantity_txt.getText().length()==0)
        {
            quantity_txt.setText("0");
            quantity_txt.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel18.setEnabled(true);
            jLabel18.setForeground(Color.red);
            jLabel18.setVisible(true);
        }
        else
        {
             String content = quantity_txt.getText();
             Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
             Matcher m = p.matcher(content);
             boolean matchFound = m.matches();
             quantity_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
             jLabel18.setEnabled(false);  
             jLabel18.setVisible(false);
           
           
//            if(!matchFound)
//
//            {
//                 quantity_txt.setBorder(BorderFactory.createLineBorder(Color.red));
//                 jLabel18.setEnabled(true);
//                 jLabel18.setForeground(Color.red);
//                 jLabel18.setVisible(true);
//                 
//            }
        }
    }//GEN-LAST:event_quantity_txtFocusLost

    private void value_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_value_txtFocusLost
    
          if(value_txt.getText().length()==0)
                   {
                       value_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel21.setEnabled(false);  
                       jLabel21.setVisible(false);
                       z=0;
                       
                   }
                   else
                   {
                       String content = value_txt.getText();
                       Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
                       Matcher m = p.matcher(content);
                       boolean matchFound = m.matches();
                       value_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel21.setEnabled(false);  
                       jLabel21.setVisible(false);
                       z=0;
                     if(!matchFound)
                    {
                        z=1;
                       tax_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                       jLabel17.setEnabled(true);
                       jLabel17.setForeground(Color.red);
                       jLabel17.setVisible(true);
                       
                    }
                   }
    }//GEN-LAST:event_value_txtFocusLost

    private void item_name_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_item_name_txtFocusLost
        // TODO add your handling code here:
         if(item_name_txt.getText().length()==0)
      {
          i=0;
          item_name_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel12.setEnabled(true);
          jLabel12.setForeground(Color.red);
          jLabel12.setVisible(true);
             
      }  
      else
      {
           item_name_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel12.setEnabled(false);  
           jLabel12.setVisible(false);
           i=1;
      }    
    }//GEN-LAST:event_item_name_txtFocusLost

    private void discount_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_discount_txtFocusLost
        // TODO add your handling code here:
           if(discount_txt.getText().length()==0)
            {
                   discount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                   jLabel16.setEnabled(false);  
                   jLabel16.setVisible(false);
                   x=0;
            }
            else
              {
                       String content = discount_txt.getText();
                       Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
                       Matcher m = p.matcher(content);
                       boolean matchFound = m.matches();
                       discount_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel16.setEnabled(false);  
                       jLabel16.setVisible(false);
                       x=0;
                     if(!matchFound)
                    {
                        x=1;
                      discount_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                      jLabel16.setEnabled(true);
                      jLabel16.setForeground(Color.red);
                      jLabel16.setVisible(true);
                     
                    }
               }
    }//GEN-LAST:event_discount_txtFocusLost

    private void tax_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tax_txtFocusLost
        // TODO add your handling code here:
              
         if(tax_txt.getText().length()==0)
            {
                      tax_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                      jLabel17.setEnabled(false);  
                      jLabel17.setVisible(false); 
                      y=0;
            } 
            else
              { 
                       String content = tax_txt.getText();
                       Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
                       Matcher m = p.matcher(content);
                       boolean matchFound = m.matches();
                       tax_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                       jLabel17.setEnabled(false);  
                       jLabel17.setVisible(false);
                       y=0;
                     if(!matchFound)
                    {
                        y=1;
                       tax_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                       jLabel17.setEnabled(true);
                       jLabel17.setForeground(Color.red);
                       jLabel17.setVisible(true);
                     
                    }
               }
    }//GEN-LAST:event_tax_txtFocusLost

    private void per_txtFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_per_txtFocusGained
        // TODO add your handling code here:
  
    }//GEN-LAST:event_per_txtFocusGained

    private void groupFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_groupFocusLost
            if(group.getSelectedItem().equals(""))
       {
           j=0;
          group.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
       }
       else
       {
           group.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           j=1;
       }
    }//GEN-LAST:event_groupFocusLost

    private void unitFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_unitFocusLost
                   if(unit.getSelectedItem().equals(""))
       {
           k=0;
          unit.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel14.setEnabled(true);
          jLabel14.setForeground(Color.red);
          jLabel14.setVisible(true);
       }
       else
       {
           unit.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel14.setEnabled(false);  
           jLabel14.setVisible(false);
           k=1;
       }
    }//GEN-LAST:event_unitFocusLost

    private void value_txtFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_value_txtFocusGained
        
    }//GEN-LAST:event_value_txtFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField discount_txt;
    private com.jidesoft.swing.AutoCompletionComboBox group;
    private javax.swing.JTextField item_name_txt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField per_txt;
    private javax.swing.JTextField product_code_txt;
    private numeric.textField.NumericTextField quantity_txt;
    private numeric.textField.NumericTextField rate_txt;
    private javax.swing.JButton reset_button;
    private javax.swing.JButton submit_button;
    private javax.swing.JTextField tax_txt;
    private com.jidesoft.swing.AutoCompletionComboBox unit;
    private numeric.textField.NumericTextField value_txt;
    // End of variables declaration//GEN-END:variables
}
