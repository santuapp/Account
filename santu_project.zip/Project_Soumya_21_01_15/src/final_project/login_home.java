/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import static java.awt.SystemColor.menu;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;


/**
 *
 * @author virtual vista
 */
public class login_home extends javax.swing.JFrame {
public JPanel[] panelArray = new JPanel[100];
int i = 0;
int c_id;

String name="admin";
String name2="";
//int flag=0;
                  
//Main_panel d5=new Main_panel();
    /**
     * Creates new form home_demo
     */



    public login_home() {
        initComponents();
        esc_close();
        
        
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        Login_form lf=new Login_form();
       // System.out.println(lf.flag);
        name2=jLabel2.getText();
        
        setIcon();
        
        
        
       // setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        jPanel3.setFocusable(true);
        
        
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        user_menu.setVisible(false);
        create_comany_menu.setVisible(false);
        select_company_menu.setVisible(false);
        select_company_user_menu.setVisible(false);
        
        
        
        tutorial_panel tp=new tutorial_panel();   
             panelArray[i]=tp;
             //panelArray[i].setBounds(0, 0, 0,0);
            
             panelArray[i].setVisible(true);
             
             //jPanel4.removeAll();
             jPanel3.setLayout(new BorderLayout());
             jPanel3.add(panelArray[i]);
           
             System.out.println("Tutorial Panel added: "+i);
             
        jPanel3.validate();
        jPanel3.setVisible(true);
        
        
         final JButton create_menu_buttons[]={create_company,alter_company, select_company,create_user,admin_logout};
    {
       
         for (int p=0;p<5;p++)
            {
                
               final int p1=p;
               String st=create_menu_buttons[p1].getText();
              
                
               create_menu_buttons[p1].addKeyListener(new KeyAdapter() {
               @Override
               public void keyPressed(KeyEvent e) {
                  
                  
                     switch (e.getKeyCode()) {
                     case KeyEvent.VK_UP:
                     if (p1 > 0){
                     create_menu_buttons[p1-1].requestFocus();
                     create_menu_buttons[p1-1].setContentAreaFilled(true);
                     create_menu_buttons[p1-1].setBorderPainted(true);
                     create_menu_buttons[p1].setContentAreaFilled(false);
                     create_menu_buttons[p1].setBorderPainted(false);
                     create_menu_buttons[p1-1].setBackground(Color.cyan);
                      
                     }
                      if (p1 == 0){
                     create_menu_buttons[4].requestFocus();
                     create_menu_buttons[4].setContentAreaFilled(true);
                     create_menu_buttons[4].setBorderPainted(true);
                     create_menu_buttons[0].setContentAreaFilled(false);
                     create_menu_buttons[0].setBorderPainted(false);
                     create_menu_buttons[4].setBackground(Color.cyan);
                      
                     }
                       // button_array[p1-1].setBorder(BorderFactory.createLineBorder(2, 1, 2, 1, Color.orange));
                     break;
                     case KeyEvent.VK_DOWN:
                     if (p1 <5){
                     create_menu_buttons[p1+1].requestFocus();
                     create_menu_buttons[p1+1].setContentAreaFilled(true);
                     create_menu_buttons[p1+1].setBorderPainted(true);
                     create_menu_buttons[p1].setContentAreaFilled(false);
                     create_menu_buttons[p1].setBorderPainted(false);
                     create_menu_buttons[p1+1].setBackground(Color.cyan);
                     } // button_array[p1+1].setBorder(BorderFactory.createMatteBorder(2, 1, 2, 1, Color.orange));
                     
                    if (p1 == 4){
                     create_menu_buttons[0].requestFocus();
                     create_menu_buttons[0].setContentAreaFilled(true);
                     create_menu_buttons[0].setBorderPainted(true);
                     create_menu_buttons[4].setContentAreaFilled(false);
                     create_menu_buttons[4].setBorderPainted(false);
                     create_menu_buttons[0].setBackground(Color.cyan);
                      
                     }
                     break;
                          case KeyEvent.VK_ENTER:
                     if (p1==0){
                         esc_close();
                       System.out.println("Panel to Delete: "+i);
       
        jPanel4.setVisible(false);
        panelArray[i].setVisible(false);
           
        jPanel3.validate();
        jPanel3.setVisible(true);
        
        
        i++;    
        System.out.println("Panel to add: "+i);
        
      company_registraion_panel crp=new company_registraion_panel();
            panelArray[i]=crp;
           
        
           jPanel3.setLayout(new BorderLayout());
           jPanel3.add(panelArray[i]);
           panelArray[i].setVisible(true);
       
        jPanel3.revalidate();
        jPanel3.setVisible(true);
                     
    
                     }
                     if (p1==1){
                         esc_close();
                   System.out.println("Panel to Delete: "+i);
       
        jPanel4.setVisible(false);
        panelArray[i].setVisible(false);
           
        jPanel3.validate();
        jPanel3.setVisible(true);
        
        
        i++;    
        System.out.println("Panel to add: "+i);
        
      company_regisration_edit_delete_panel cedp=new company_regisration_edit_delete_panel();
            panelArray[i]=cedp;
           
          
        
           jPanel3.setLayout(new BorderLayout());
           jPanel3.add(panelArray[i]);
           panelArray[i].setVisible(true);
       
        jPanel3.revalidate();
        jPanel3.setVisible(true);
    
                     }
                         if (p1==2){
                   
                   select_company_menu.setVisible(true);
        create_comany_menu.setVisible(false);
    
                     }
                         
                         if (p1==3){
                    
    
                     }
                            if (p1==4){
                    
                        Login_form lf=new Login_form();
        lf.setVisible(true);
        dispose();
    
                     }




// button_array[p1+1].setBorder(BorderFactory.createMatteBorder(2, 1, 2, 1, Color.orange));
                     
//                    if (p1 == 4){
//                     button_array[0].requestFocus();
//                     button_array[0].setContentAreaFilled(true);
//                     button_array[0].setBorderPainted(true);
//                     button_array[4].setContentAreaFilled(false);
//                     button_array[4].setBorderPainted(false);
//                     button_array[0].setBackground(Color.cyan);
//                      
//                     }
                     break;
                      
                  default:
                     break;
                  }
               }
            });
                
               
            
       
            }
         
          final JButton user_buttons[]={user_select_company,user_logout};
       
         for (int p=0;p<2;p++)
            {
                
   
               
              final int p1=p;
                String st=user_buttons[p1].getText();
              
                
               user_buttons[p1].addKeyListener(new KeyAdapter() {
               @Override
               public void keyPressed(KeyEvent e) {
                  
                  
                  switch (e.getKeyCode()) {
                  case KeyEvent.VK_UP:
                     if (p1==1)
                     {  
                         System.out.println("Ardhen");
                         user_buttons[p1].setContentAreaFilled(false);
                    user_buttons[p1].setBorderPainted(false);
//                        user_buttons[p1-1].requestFocus();
//                     user_buttons[p1-1].setContentAreaFilled(true);
//                    user_buttons[p1-1].setBorderPainted(true);
//                     
//                     user_buttons[p1-1].setBackground(Color.cyan);
                       // button_array[p1-1].setBorder(BorderFactory.createLineBorder(2, 1, 2, 1, Color.orange));
                     }
                     break;
                  case KeyEvent.VK_DOWN:
                     if (p1 ==0)
                     {
                      user_buttons[p1+1].requestFocus();
                     user_buttons[p1+1].setContentAreaFilled(true);
                     user_buttons[p1+1].setBorderPainted(true);
                     
                      user_buttons[p1].setContentAreaFilled(false);
                     user_buttons[p1].setBorderPainted(false);
                      user_buttons[p1+1].setBackground(Color.cyan);
                     }
                      // button_array[p1+1].setBorder(BorderFactory.createMatteBorder(2, 1, 2, 1, Color.orange));
                     break;

                     
                      
                  default:
                     break;
                  }
               }
            });
                
       
            }
         
          final JButton select_company_buttons[]={select_select_company};
       
         for (int p=0;p<1;p++)
            {
                
               final int p1=p;
               String st=user_buttons[p1].getText();
              
                
               user_buttons[p1].addKeyListener(new KeyAdapter() {
               @Override
               public void keyPressed(KeyEvent e) {
                  
                  
                     switch (e.getKeyCode()) {
                     case KeyEvent.VK_UP:
                     if (p1 > 0){
                     user_buttons[p1-1].requestFocus();
                     user_buttons[p1-1].setContentAreaFilled(true);
                     user_buttons[p1-1].setBorderPainted(true);
                     user_buttons[p1].setContentAreaFilled(false);
                     user_buttons[p1].setBorderPainted(false);
                     user_buttons[p1-1].setBackground(Color.cyan);
                      
                     }
                      if (p1 == 0){
                     user_buttons[0].requestFocus();
                     user_buttons[0].setContentAreaFilled(true);
                     user_buttons[0].setBorderPainted(true);
                     user_buttons[0].setContentAreaFilled(false);
                     user_buttons[0].setBorderPainted(false);
                     user_buttons[0].setBackground(Color.cyan);
                      
                     }
                       // button_array[p1-1].setBorder(BorderFactory.createLineBorder(2, 1, 2, 1, Color.orange));
                     break;
                     case KeyEvent.VK_DOWN:
                     if (p1 <2){
                     user_buttons[p1+1].requestFocus();
                     user_buttons[p1+1].setContentAreaFilled(true);
                     user_buttons[p1+1].setBorderPainted(true);
                     user_buttons[p1].setContentAreaFilled(false);
                     user_buttons[p1].setBorderPainted(false);
                     user_buttons[p1+1].setBackground(Color.cyan);
                     } // button_array[p1+1].setBorder(BorderFactory.createMatteBorder(2, 1, 2, 1, Color.orange));
                     
                    if (p1 == 0){
                     user_buttons[0].requestFocus();
                     user_buttons[0].setContentAreaFilled(true);
                     user_buttons[0].setBorderPainted(true);
                     user_buttons[0].setContentAreaFilled(false);
                     user_buttons[0].setBorderPainted(false);
                     user_buttons[0].setBackground(Color.cyan);
                      
                     }
                     break;
                          case KeyEvent.VK_ENTER:
                     if (p1==0){
                       
                     company_select_form lsf=new company_select_form();
                     lsf.setVisible(true);
                      dispose();
                     }
                     if (p1==1){
                  
    
                     }
                        
                     
                          




// button_array[p1+1].setBorder(BorderFactory.createMatteBorder(2, 1, 2, 1, Color.orange));
                     
//                    if (p1 == 4){
//                     button_array[0].requestFocus();
//                     button_array[0].setContentAreaFilled(true);
//                     button_array[0].setBorderPainted(true);
//                     button_array[4].setContentAreaFilled(false);
//                     button_array[4].setBorderPainted(false);
//                     button_array[0].setBackground(Color.cyan);
//                      
//                     }
                     break;
                      
                  default:
                     break;
                  }
               }
            });
                
               
            
       
            }
         
         
         
         
         
         

       
    }
          try{
        
          Connection con = Database.getConnection();
          Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct company_name,company_id from company_creation");
//            jComboBox1.addItem(d2); 
//           jComboBox1.setSelectedItem(d2);
           while(rs.next())
          {
              String name=rs.getString("company_name");
              c_id=Integer.parseInt(rs.getString("company_id"));
              jComboBox1.addItem(name);
              jComboBox2.addItem(name);
              System.out.println(c_id);
          }
         // String name1="Others";
          //jComboBox1.addItem(name1);
            
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
        
    }
    
    
    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png"))); //To change body of generated methods, choose Tools | Templates.
    }
    
   
    
//user set on JLabel2 for user login information 
    public void user(String u)
    {
        jLabel2.setText(u);
    }
    
    
 public void esc_close()
{
  KeyStroke escape1111 = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
    Action action1111 = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
        int p=JOptionPane.showConfirmDialog(null,"Do you really want to Close?","Close",JOptionPane.YES_NO_OPTION);
    if(p==0){
     System.out.println();
       
        if (i>0)
        {    
        System.out.println("Panel to Delete: "+i);
        
        panelArray[i].setVisible(false);
           
        jPanel3.validate();
        jPanel3.setVisible(true);
         
       
        
        i--;
        System.out.println("Next Panel:"+i);


        jPanel3.setLayout(new BorderLayout());
   
        //jPanel4.add(panelArray[i]);
        panelArray[i].setVisible(true);
     
        
         
            jPanel3.repaint();
         jPanel3.revalidate();
         jPanel3.setVisible(true);
         jPanel4.setVisible(true);
         create_comany_menu.setVisible(true);      
                     
     
        }  
         if(i==0)
        {
 try
     {
         create_comany_menu.setVisible(true);
                create_comany_menu.requestFocusInWindow();
       
        
                        create_company.requestFocus();
                        
                     create_company.setContentAreaFilled(true);
                     create_company.setBorderPainted(true);
                //    menu_account_master.setContentAreaFilled(false);
                 //   menu_account_master.setBorderPainted(false);
                     create_company.setBackground(Color.cyan);      
     }
     catch(Exception we)
     {
     }
           if(name.compareTo(name2)==0){
               jPanel4.setVisible(true);
              
       
       
                            
               
           }
//           else
//            {
//                user_menu.setVisible(true);
//            }
            
      
       
        }


    }
   
    }
    };
        
getRootPane().getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape1111, "escape1111");
getRootPane().getActionMap().put("escape1111", action1111);
}
         
            
        
    
   /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        create_comany_menu = new javax.swing.JInternalFrame();
        create_company = new javax.swing.JButton();
        select_company = new javax.swing.JButton();
        create_user = new javax.swing.JButton();
        admin_logout = new javax.swing.JButton();
        alter_company = new javax.swing.JButton();
        user_menu = new javax.swing.JInternalFrame();
        user_select_company = new javax.swing.JButton();
        user_logout = new javax.swing.JButton();
        select_company_menu = new javax.swing.JInternalFrame();
        select_select_company = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox();
        select_company_user_menu = new javax.swing.JInternalFrame();
        select_select_company1 = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Welcome to BITS Accounting");
        setMaximumSize(new java.awt.Dimension(1024, 768));
        setPreferredSize(new java.awt.Dimension(800, 600));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Company Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 13), java.awt.Color.blue)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("Date:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("DD/MM/YYYY");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setText("Financial Year:");

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 0, 255));
        jLabel25.setText("DD/MM/YYYY");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("Company Name:");

        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Welcome");

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setText("jLabel2");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jLabel6)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 159, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        create_comany_menu.setTitle("Admin Menu");
        create_comany_menu.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/logo.png"))); // NOI18N
        create_comany_menu.setVisible(true);
        create_comany_menu.getContentPane().setLayout(new java.awt.GridBagLayout());

        create_company.setForeground(new java.awt.Color(0, 0, 255));
        create_company.setText("Create Company");
        create_company.setBorderPainted(false);
        create_company.setContentAreaFilled(false);
        create_company.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_companyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 54;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 0, 20, 0);
        create_comany_menu.getContentPane().add(create_company, gridBagConstraints);

        select_company.setForeground(new java.awt.Color(0, 0, 255));
        select_company.setText("Select Company");
        select_company.setBorderPainted(false);
        select_company.setContentAreaFilled(false);
        select_company.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                select_companyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 58;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 0, 20, 0);
        create_comany_menu.getContentPane().add(select_company, gridBagConstraints);

        create_user.setForeground(new java.awt.Color(0, 0, 255));
        create_user.setText("Create User");
        create_user.setBorderPainted(false);
        create_user.setContentAreaFilled(false);
        create_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_userActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.ipadx = 76;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 0, 20, 0);
        create_comany_menu.getContentPane().add(create_user, gridBagConstraints);

        admin_logout.setForeground(new java.awt.Color(0, 0, 255));
        admin_logout.setText("Logout");
        admin_logout.setBorderPainted(false);
        admin_logout.setContentAreaFilled(false);
        admin_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admin_logoutActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.ipadx = 102;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 0, 20, 0);
        create_comany_menu.getContentPane().add(admin_logout, gridBagConstraints);

        alter_company.setForeground(new java.awt.Color(0, 0, 255));
        alter_company.setText("Alter Company");
        alter_company.setBorderPainted(false);
        alter_company.setContentAreaFilled(false);
        alter_company.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alter_companyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 64;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 0, 20, 0);
        create_comany_menu.getContentPane().add(alter_company, gridBagConstraints);

        user_menu.setTitle("User Menu");
        user_menu.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/logo.png"))); // NOI18N
        user_menu.setVisible(true);
        user_menu.getContentPane().setLayout(new java.awt.GridBagLayout());

        user_select_company.setForeground(new java.awt.Color(0, 0, 255));
        user_select_company.setText("Select Company");
        user_select_company.setBorderPainted(false);
        user_select_company.setContentAreaFilled(false);
        user_select_company.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_select_companyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 58;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 0, 20, 0);
        user_menu.getContentPane().add(user_select_company, gridBagConstraints);

        user_logout.setForeground(new java.awt.Color(0, 0, 255));
        user_logout.setText("Logout");
        user_logout.setBorderPainted(false);
        user_logout.setContentAreaFilled(false);
        user_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_logoutActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 102;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 0, 20, 0);
        user_menu.getContentPane().add(user_logout, gridBagConstraints);

        select_company_menu.setTitle("Select Company");
        select_company_menu.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/logo.png"))); // NOI18N
        select_company_menu.setVisible(true);

        select_select_company.setForeground(new java.awt.Color(0, 0, 255));
        select_select_company.setText("Go To Gateway");
        select_select_company.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                select_select_companyActionPerformed(evt);
            }
        });

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout select_company_menuLayout = new javax.swing.GroupLayout(select_company_menu.getContentPane());
        select_company_menu.getContentPane().setLayout(select_company_menuLayout);
        select_company_menuLayout.setHorizontalGroup(
            select_company_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(select_select_company, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
            .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        select_company_menuLayout.setVerticalGroup(
            select_company_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(select_company_menuLayout.createSequentialGroup()
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(select_select_company)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        select_company_user_menu.setTitle("Select Company");
        select_company_user_menu.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/logo.png"))); // NOI18N
        select_company_user_menu.setVisible(true);

        select_select_company1.setForeground(new java.awt.Color(0, 0, 255));
        select_select_company1.setText("Go To Gateway");
        select_select_company1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                select_select_company1ActionPerformed(evt);
            }
        });

        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout select_company_user_menuLayout = new javax.swing.GroupLayout(select_company_user_menu.getContentPane());
        select_company_user_menu.getContentPane().setLayout(select_company_user_menuLayout);
        select_company_user_menuLayout.setHorizontalGroup(
            select_company_user_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(select_select_company1, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
            .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        select_company_user_menuLayout.setVerticalGroup(
            select_company_user_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(select_company_user_menuLayout.createSequentialGroup()
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(select_select_company1)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(select_company_user_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(select_company_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(user_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(create_comany_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {create_comany_menu, select_company_menu, select_company_user_menu, user_menu});

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(user_menu)
                    .addComponent(select_company_user_menu, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(select_company_menu)
                    .addComponent(create_comany_menu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        //System.out.println("User is "+jLabel2.getText().toString()+user_name.getText());

        KeyStroke escape20 = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action action20 = new AbstractAction() {
            public void actionPerformed(ActionEvent eyy) {

                select_company_menu.setVisible(false);

                create_comany_menu.setVisible(true);
                try
                {
                    create_comany_menu.setSelected(true);
                }
                catch(Exception e)
                {
                }
            }
        };

        select_company_menu.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape20, "escape");
        select_company_menu.getActionMap().put("escape", action20);
        //System.out.println("User is "+jLabel2.getText().toString()+user_name.getText());

        KeyStroke escape21 = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action action21 = new AbstractAction() {
            public void actionPerformed(ActionEvent eyy) {

                select_company_user_menu.setVisible(false);

                user_menu.setVisible(true);
                try
                {
                    user_menu.setSelected(true);
                }
                catch(Exception e)
                {
                }
            }
        };

        select_company_user_menu.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(escape21, "escape");
        select_company_user_menu.getActionMap().put("escape", action21);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void admin_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_admin_logoutActionPerformed
        // TODO add your handling code here:
        Login_form lf=new Login_form();
        lf.setVisible(true);
        this.dispose();
        
        
    }//GEN-LAST:event_admin_logoutActionPerformed

    private void user_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_logoutActionPerformed
        // TODO add your handling code here:
         Login_form lf=new Login_form();
        lf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_user_logoutActionPerformed

    private void create_companyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_companyActionPerformed
        // TODO add your handling code here:
        esc_close();
        System.out.println("Panel to Delete: "+i);
       
        jPanel4.setVisible(false);
        panelArray[i].setVisible(false);
           
        jPanel3.validate();
        jPanel3.setVisible(true);
        
        
        i++;    
        System.out.println("Panel to add: "+i);
        
      company_registraion_panel crp=new company_registraion_panel();
            panelArray[i]=crp;
           
          
//           jPanel4.revalidate();
//           System.out.println("Visible hidden");
//          
           jPanel3.setLayout(new BorderLayout());
           jPanel3.add(panelArray[i]);
           panelArray[i].setVisible(true);
       crp.set();
        jPanel3.revalidate();
        jPanel3.setVisible(true);
    }//GEN-LAST:event_create_companyActionPerformed

    private void alter_companyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alter_companyActionPerformed
        // TODO add your handling code here:
    alter_company.setContentAreaFilled(false);
    alter_company.setBorderPainted(false);
    
        esc_close();
         System.out.println("Panel to Delete: "+i);
       
        jPanel4.setVisible(false);
        panelArray[i].setVisible(false);
           
        jPanel3.validate();
        jPanel3.setVisible(true);
        
        
        i++;    
        System.out.println("Panel to add: "+i);
        
      company_regisration_edit_delete_panel cedp=new company_regisration_edit_delete_panel();
            panelArray[i]=cedp;
           
          
//           jPanel4.revalidate();
//           System.out.println("Visible hidden");
//          
           jPanel3.setLayout(new BorderLayout());
           jPanel3.add(panelArray[i]);
           panelArray[i].setVisible(true);
       cedp.set();
        jPanel3.revalidate();
        jPanel3.setVisible(true);
    }//GEN-LAST:event_alter_companyActionPerformed

    private void select_companyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_select_companyActionPerformed
        // TODO add your handling code here:
        esc_close();
        select_company_menu.setVisible(true);
        create_comany_menu.setVisible(false);
         try
        {
            select_company_menu.setSelected(true);

        }
        catch(Exception Ae)
        {
        }
    }//GEN-LAST:event_select_companyActionPerformed

    private void user_select_companyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_select_companyActionPerformed
        // TODO add your handling code here:
       
        select_company_user_menu.setVisible(true);
        user_menu.setVisible(false);
    }//GEN-LAST:event_user_select_companyActionPerformed

    private void select_select_companyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_select_select_companyActionPerformed
        // TODO add your handling code here:
        company_select_form csf=new company_select_form();
        csf.setVisible(true);
        csf.user(jLabel2.getText());
        dispose();
        int c=jComboBox1.getSelectedIndex();
//        System.out.println(c);
//        if(c==0)
//        {
//      d5.setVisible(true);
//      this.dispose();
//        }
    }//GEN-LAST:event_select_select_companyActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void create_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_userActionPerformed
create_user.setContentAreaFilled(false);
    create_user.setBorderPainted(false);
        user_create_panel ucp= new user_create_panel();
        
        // TODO add your handling code here:
               
        esc_close();
        System.out.println("Panel to Delete: "+i);
       
        jPanel4.setVisible(false);
        panelArray[i].setVisible(false);
           
        jPanel3.validate();
        jPanel3.setVisible(true);
        
        
        i++;    
        System.out.println("Panel to add: "+i);
        
        
        panelArray[i]=ucp;
        
        jPanel3.setLayout(new BorderLayout());
        jPanel3.add(panelArray[i]);
        panelArray[i].setVisible(true);
        jPanel3.revalidate();
        jPanel3.setVisible(true);
    }//GEN-LAST:event_create_userActionPerformed

    private void select_select_company1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_select_select_company1ActionPerformed
        // TODO add your handling code here:
        company_select_form csf=new company_select_form();
        csf.setVisible(true);
        csf.user(jLabel2.getText());
        dispose();
        int c=jComboBox1.getSelectedIndex();
    }//GEN-LAST:event_select_select_company1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login_home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login_home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login_home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login_home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login_home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton admin_logout;
    private javax.swing.JButton alter_company;
    public javax.swing.JInternalFrame create_comany_menu;
    private javax.swing.JButton create_company;
    private javax.swing.JButton create_user;
    public javax.swing.JComboBox jComboBox1;
    public javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JButton select_company;
    public javax.swing.JInternalFrame select_company_menu;
    public javax.swing.JInternalFrame select_company_user_menu;
    private javax.swing.JButton select_select_company;
    private javax.swing.JButton select_select_company1;
    private javax.swing.JButton user_logout;
    public javax.swing.JInternalFrame user_menu;
    public javax.swing.JButton user_select_company;
    // End of variables declaration//GEN-END:variables
}
