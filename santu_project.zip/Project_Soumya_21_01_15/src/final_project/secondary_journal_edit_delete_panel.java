/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

//import static final_project.journal_edit_panel.w;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author virtual vista
 */
public class secondary_journal_edit_delete_panel extends javax.swing.JPanel {
    Font myFont =new Font("",Font.PLAIN,9);
    /**
     * Creates new form secondary_journal_edit_delete_panel
     */
    
    public secondary_journal_edit_delete_panel() {
        initComponents();
        textvalidation();
         // create_table();
           initialise1();
        initialise();
      
        invoice_no_txt.setFocusable(true);
        
        jLabel1.setFont(myFont);
        jLabel1.setEnabled(false);
        jLabel1.setVisible(false);
        
        jLabel3.setFont(myFont);
        jLabel3.setEnabled(false);
        jLabel3.setVisible(false);
        
        jLabel7.setFont(myFont);
        jLabel7.setEnabled(false);
        jLabel7.setVisible(false);
        
        jLabel8.setFont(myFont);
        jLabel8.setEnabled(false);
        jLabel8.setVisible(false);
        
        jLabel2.setVisible(false);
        ref_no.setVisible(false);
        jLabel3.setVisible(false);
        
         jLabel11.setVisible(false);
        
        
          create_user.setEditable(false);
        create_date.setEditable(false);
        update_user.setEditable(false);
        update_date.setEditable(false);
        
        
          try{
        
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct l_name from ledger");
          while(rs.next())
          {
            
             // String name=rs.getString("l_name");
           //  reference_no.removeAllItems();
            ledger_name.addItem(rs.getString("l_name"));
             //reference_no.addItem(rs.getString("l_name"));
          }
       
          
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
       
    }

    
      public void set(){
    invoice_no_txt.requestFocusInWindow();
    invoice_no_txt.setFocusable(true);
}

public void user(String u_name){
    jLabel11.setText(u_name);
}
    
    
    
      public void update_table(String s1)
{ 
       
       
          

          try{
         
           
           Connection con1 = Database.getConnection();
        Statement ps1 =con1.createStatement();
         ResultSet rs=ps1.executeQuery("SELECT journal_id,journal_select as Choose ,ledger as Perticulars, DEBIT,CREDIT from journal_creation where journal_inv='"+s1+"'");
         int li_row=0;
           while(rs.next())
                 {
                    
                 table.setValueAt(rs.getString("Choose"), li_row, 0);
                  table.setValueAt(rs.getString("Perticulars"), li_row, 1);
                  table.setValueAt(rs.getString("DEBIT"), li_row, 2);
                   table.setValueAt(rs.getString("CREDIT"), li_row, 3);
                    table.setValueAt(rs.getString("journal_id"), li_row, 4);
                   li_row++;
                 }
           table.getColumnModel().getColumn(4).setMinWidth(0);
             table.getColumnModel().getColumn(4).setMaxWidth(0);
                table.getColumnModel().getColumn(4).setResizable(false);
          //TableColoumn tc=table.getColumnModel().getColumn(0);
        //table.removeColumn(table.getColumnModel().getColumn(4));
         //table.setTableHeader(table.getColumnModel().getColumn("SELECT"));
         
                      ResultSet rs1=ps1.executeQuery("SELECT distinct journal_inv,journal_date,journal_ref_no,journal_balance,sum(debit) as tdebit,sum(credit) as tcredit from journal_creation where journal_inv='"+s1+"'");
                       
                  while(rs1.next())
                 {
                   String  aa=rs1.getString("journal_inv");
                   invoice_no_txt.setText(aa);
                   String  ab=rs1.getString("journal_ref_no");
                   ref_no.setText(ab);
                   String  ac=rs1.getString("journal_balance");
                   balance_txt.setText(ac);
                   String  at=rs1.getString("tdebit");
                   debit_total.setText(at);
                   String  ay=rs1.getString("tcredit");
                   credit_total.setText(ay);
                   j_date.setText(rs1.getString("journal_date"));
                   
                     Statement ps4 =con1.createStatement();
                ResultSet rs2=ps4.executeQuery("SELECT * from user_activity_table where table_name='journal_creation' and value='"+s1+"'");
                while(rs2.next())
            {
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                 
                  }
       
          
         
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
       
create_table(s1);
                }  




 
 

       public void create_table(String s2){
        String wsdf="";
        
     //    System.out.println(w);
        try{
        
           
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
         Statement ps1 =con.createStatement();
          Statement ps2 =con.createStatement();
           Statement ps3 =con.createStatement();
           ResultSet rs=ps.executeQuery("SELECT journal_id,journal_select as Choose ,ledger as Perticulars, DEBIT,CREDIT from journal_creation where journal_inv='"+s2+"'");
         int li_row=0;
           while(rs.next())
                 {
                    
                 table.setValueAt(rs.getString("Choose"), li_row, 0);
                  table.setValueAt(rs.getString("Perticulars"), li_row, 1);
                  table.setValueAt(rs.getString("DEBIT"), li_row, 2);
                   table.setValueAt(rs.getString("CREDIT"), li_row, 3);
                    table.setValueAt(rs.getString("journal_id"), li_row, 4);
                   li_row++;
                 }
           table.getColumnModel().getColumn(4).setMinWidth(0);
             table.getColumnModel().getColumn(4).setMaxWidth(0);
                table.getColumnModel().getColumn(4).setResizable(false);
          //TableColoumn tc=table.getColumnModel().getColumn(0);
        //table.removeColumn(table.getColumnModel().getColumn(4));
         //table.setTableHeader(table.getColumnModel().getColumn("SELECT"));
         
                      ResultSet rs1=ps1.executeQuery("SELECT distinct journal_inv,journal_ref_no,journal_balance,sum(debit) as tdebit,sum(credit) as tcredit from journal_creation where journal_inv='"+s2+"'");
                       
                  while(rs1.next())
                 {
                     String  aa=rs1.getString("journal_inv");
                      invoice_no_txt.setText(aa);
                       String  ab=rs1.getString("journal_ref_no");
                   ref_no.setText(ab);
                   String  ac=rs1.getString("journal_balance");
                   balance_txt.setText(ac);
                   String  at=rs1.getString("tdebit");
                   debit_total.setText(at);
                   String  ay=rs1.getString("tcredit");
                   credit_total.setText(ay);
                   
                     Statement ps4 =con.createStatement();
                ResultSet rs2=ps4.executeQuery("SELECT * from user_activity_table where table_name='journal_creation' and value='"+s2+"'");
                while(rs2.next())
            {
                String create_user1=rs2.getString("create_user");
                create_user.setText(create_user1);
                
                String create_date1=rs2.getString("create_date");
                create_date.setText(create_date1);
                
                String update_user1=rs2.getString("update_user");
                update_user.setText(update_user1);
                
                String update_date1=rs2.getString("update_date");
                update_date.setText(update_date1);
                
            }
                 
                  }
                  
                    
          System.out.println("Done");
            
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
    }
     public void  textvalidation(){
         invoice_no_txt.addKeyListener(new KeyAdapter(){
             private boolean SHIFT_PRESSED;
             private boolean SPACE_PRESSED;
             private boolean CAPS_LOCK_PRESSED;
            
             public void keyPressed(KeyEvent e){
           String  i=invoice_no_txt.getText();
            
                char ch = e.getKeyChar();
                if(Character.isLetterOrDigit(ch)){
                }
                else if(e.getKeyChar() == KeyEvent.VK_BACK_SPACE){
                }else if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
            this.SHIFT_PRESSED = true;
        }else if(e.getKeyCode() == KeyEvent.VK_SPACE) {
            this.SPACE_PRESSED = true;
        }else if(e.getKeyCode() == KeyEvent.VK_CAPS_LOCK) {
            this.CAPS_LOCK_PRESSED = true;
        }
                else{
                    JOptionPane.showMessageDialog(null, "Special Character are not Allowed!");
                  invoice_no_txt.setText("");
                }
            
             }
        });
     }

    public void initialise(){
   
       table.getModel().addTableModelListener(new TableModelListener()
        
                {
                  public void tableChanged (TableModelEvent e)
                {
		  double gtot=0.0d;
                   double gtot1=0.0d;
            int n1=table.getRowCount();
            System.out.println(n1);
            for (int i =0; i<=n1-1; i++)
            {
                if ((table.getValueAt(i, 2)) !=null)
            {
                    String s1 = (String)table.getValueAt(i, 2);
                    double d1=Double.parseDouble(s1);
                    System.out.println(s1);
                   
                   
                    gtot=gtot+d1;
                    System.out.println(gtot);
                  
            }
                String s4=Double.toString(gtot);
                    debit_total.setText(s4);
            }
             for (int i =0; i<=n1-1; i++)
            {
                if ((table.getValueAt(i, 3)) !=null)
            {
                    String s0 = (String)table.getValueAt(i, 3);
                    double d1=Double.parseDouble(s0);
                    System.out.println(s0);
                   
                   
                    gtot1=gtot1+d1;
                    System.out.println(gtot1);
                  
            }
                String s40=Double.toString(gtot1);
                    credit_total.setText(s40);
            }
            
                }
                }
          );

    }
      
    public void initialise1()
    {
  
     table.getModel().addTableModelListener(new TableModelListener(){
 public void tableChanged  (TableModelEvent e) {
                String b[] = { "Titan", "HMT" };
                String c[] = {"Nokia","Sony","Motorola","Samsung"};
                String d[] = {""};
                        int n=table.getRowCount();
 for (int j =0; j<=n-1; j++)
                    {
                        
                if (((table.getValueAt(j, 0)) !=null) && (table.getValueAt(j, 1)) ==null){
                        if (combox1.getSelectedItem().equals("Select")) {
                            //JComboBox combox2 = new JComboBox();
                            //JComboBox combox = new JComboBox();
                             JComboBox combox3 = new JComboBox(d);
                              table.getColumn("Perticulars").setCellEditor(new DefaultCellEditor(combox3));
                               
                               //combox3.setEnabled(true);
                           
                               //combox.setEnabled(false);
                                //combox2.setEnabled(false);
                                //combox2.removeAllItems();
                                //combox.removeAllItems();
                        }
                    if (combox1.getSelectedItem().equals("By")) {
                        
                            //JComboBox combox = new JComboBox(b);
                          // table.setValueAt("s1", j, 2);
                           //  combox2.removeAllItems();
                                //combox2.setEnabled(true);
                            //combox2.removeAllItems();
                               
                               
                            // table.getColumn("Debit").setCellEditor(new DefaultCellEditor(combox));

                         // combox.removeAllItems();
                                //combox.setEnabled(true); 
                                  table.getColumn("Perticulars").setCellEditor(new DefaultCellEditor(ledger_name));
                                
                                  
                        } 
                    else if (combox1.getSelectedItem().equals("To")) {
                            
                                
                               // JComboBox combox = new JComboBox(c);
                          // combox.removeAllItems();
                              //  table.setValueAt("0.00", j, 2);
                               //combox.setEnabled(true);
                      table.getColumn("Perticulars").setCellEditor(new DefaultCellEditor(ledger_name));

                        }
                }   }  }
        
 });

               }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ledger_name = new javax.swing.JComboBox();
        jButton4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        savebutton = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        Clear_button = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        invoice_no_txt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        balance_txt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        ref_no = new javax.swing.JTextField();
        j_date = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        credit_total = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        debit_total = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        sec_journal_narration = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        create_user = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        create_date = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        update_user = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        update_date = new javax.swing.JTextField();

        jButton4.setText("jButton4");

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Commands", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(0, 0, 255))); // NOI18N

        savebutton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        savebutton.setText("Save");
        savebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savebuttonActionPerformed(evt);
            }
        });

        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Recycle-Bin-full-icon.png"))); // NOI18N
        delete_button.setText("Delete");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });

        Clear_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        Clear_button.setText("Clear");
        Clear_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Clear_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Clear_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(delete_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(savebutton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(savebutton)
                .addGap(21, 21, 21)
                .addComponent(delete_button)
                .addGap(18, 18, 18)
                .addComponent(Clear_button)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 255))); // NOI18N

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Invoice No.");

        invoice_no_txt.setEditable(false);

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Reference No.");

        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Balance:");

        balance_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                balance_txtFocusLost(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Date");

        jLabel1.setText("Enter Invoice No.!");

        jLabel3.setText("Enter Valid Reference No.!");

        jLabel7.setText("Enter Balance!");

        jLabel8.setText("Enter Valid Date!");

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Choose", "Perticulars", "Debit", "Credit", "Title 5"
            }
        ));
        jScrollPane1.setViewportView(table);

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rows", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), java.awt.Color.blue)); // NOI18N

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Action-remove-icon.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/add-2-icon.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 601, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(debit_total, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(credit_total, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(0, 1, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(debit_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(credit_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel10.setForeground(new java.awt.Color(0, 0, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Narration:");

        sec_journal_narration.setColumns(20);
        sec_journal_narration.setRows(5);
        jScrollPane2.setViewportView(sec_journal_narration);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                                    .addComponent(invoice_no_txt)
                                    .addComponent(balance_txt))
                                .addGap(137, 137, 137)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(ref_no)
                                    .addComponent(j_date)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(invoice_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ref_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addGap(12, 12, 12)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(balance_txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(j_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addGap(11, 11, 11)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(26, 26, 26))
        );

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setText("Secondary Journal Edit Delete");

        jLabel11.setText("jLabel11");

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 10), java.awt.Color.cyan)); // NOI18N

        jLabel26.setForeground(new java.awt.Color(51, 153, 0));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel26.setText("Created By:");

        jLabel27.setForeground(new java.awt.Color(51, 153, 0));
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel27.setText("Created Date:");

        jLabel28.setForeground(new java.awt.Color(51, 153, 0));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel28.setText("Updated By:");

        jLabel29.setForeground(new java.awt.Color(51, 153, 0));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel29.setText("Update Date:");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(46, 46, 46)
                        .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(46, 46, 46)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(create_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(create_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(update_user, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(update_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(406, 406, 406)
                        .addComponent(jLabel9)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel9)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(139, 139, 139)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(jLabel11)
                        .addGap(136, 136, 136)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(354, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void savebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savebuttonActionPerformed

        try{

            
            Connection con = Database.getConnection();

            int p=table.getRowCount();
            for(int i=0;i<p;i++)
            {
                String select=table.getValueAt(i,0).toString();
                String ledger=table.getValueAt(i,1).toString();
                String debit=table.getValueAt(i,2).toString();
                String credit=table.getValueAt(i,3).toString();
                log_table.table_update("journal_creation",jLabel11.getText(),invoice_no_txt.getText());
                PreparedStatement ps1=con.prepareStatement("update journal_creation set journal_inv='"+invoice_no_txt.getText()+"',ledger='"+ledger+"',debit='"+debit+"',credit='"+credit+"',journal_date='"+j_date.getText()+"',journal_ref_no='"+ref_no.getText()+"',journal_balance='"+balance_txt.getText()+"',journal_select='"+select+"'");

                ps1.executeBatch();
                ps1.executeUpdate();
                PreparedStatement ps2=con.prepareStatement("update company_main_table set get_id='"+invoice_no_txt.getText()+"',ledger='"+ledger+"',debit='"+debit+"',credit='"+credit+"',trans_date='"+j_date.getText()+"'");

                ps2.executeBatch();
                ps2.executeUpdate();
            }
            System.out.println("saved");

           jopt1.showMessageDialog(this,"Journal Updated");
           
            invoice_no_txt.setText(null);
            j_date.setText(null);
            ref_no.setText(null);
            balance_txt.setText(null);
            
               create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
            
            jLabel7.setVisible(false);
           
            jLabel4.setVisible(false);
            jLabel8.setVisible(false);
            
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            j_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            ref_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            
            
            debit_total.setText(null);
            credit_total.setText(null);
            
           //TABLE RESET
           int p2=table.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
                Double a4=null;
                String a5=null;
                
                
        table.setValueAt(a1, i, 0);
        table.setValueAt(a2, i, 1);
        table.setValueAt(a3, i, 2);
        table.setValueAt(a4, i, 3);
        table.setValueAt(a5, i, 4);
        
        }
           

        }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
        }
        
    }//GEN-LAST:event_savebuttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
        int p=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(p==0)
        {
            try{

                
                Connection con1 = Database.getConnection();

                PreparedStatement ps1=con1.prepareStatement("delete from  journal_creation where journal_inv='"+invoice_no_txt.getText()+"'");

                ps1.executeUpdate();
                System.out.println("Done");
               // update_table();
                
                log_table.table_delete("journal_creation",jLabel11.getText());

            }catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
            

        }
      //  j_id.setText("");
        invoice_no_txt.setText(null);
            j_date.setText(null);
            ref_no.setText(null);
            balance_txt.setText(null);
            
               create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
            
            jLabel7.setVisible(false);
           
            jLabel4.setVisible(false);
            jLabel8.setVisible(false);
            
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            j_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            ref_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            
            
            debit_total.setText(null);
            credit_total.setText(null);
            
           //TABLE RESET
           int p2=table.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
                Double a4=null;
                String a5=null;
                
                
        table.setValueAt(a1, i, 0);
        table.setValueAt(a2, i, 1);
        table.setValueAt(a3, i, 2);
        table.setValueAt(a4, i, 3);
        table.setValueAt(a5, i, 4);
        
        }

    }//GEN-LAST:event_delete_buttonActionPerformed

    private void Clear_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Clear_buttonActionPerformed
 invoice_no_txt.setText(null);
            j_date.setText(null);
            ref_no.setText(null);
            balance_txt.setText(null);
            
               create_user.setText(null);
        create_date.setText(null);
        update_date.setText(null);
        update_user.setText(null);
            
            jLabel7.setVisible(false);
           
            jLabel4.setVisible(false);
            jLabel8.setVisible(false);
            
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            j_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            ref_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            balance_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            
            
            debit_total.setText(null);
            credit_total.setText(null);
            
           //TABLE RESET
           int p2=table.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
                Double a4=null;
                String a5=null;
                
                
        table.setValueAt(a1, i, 0);
        table.setValueAt(a2, i, 1);
        table.setValueAt(a3, i, 2);
        table.setValueAt(a4, i, 3);
        table.setValueAt(a5, i, 4);
        
        }
    }//GEN-LAST:event_Clear_buttonActionPerformed

    private void balance_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_balance_txtFocusLost
        String pin = balance_txt.getText();
        Pattern pattern = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
        Matcher matcher = pattern.matcher(pin);

        if (matcher.matches()) {
        }
        else
        {

            balance_txt.setText("");
            JOptionPane.showMessageDialog(null, "Enter Number!");
        }
    }//GEN-LAST:event_balance_txtFocusLost

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        DefaultTableModel y = (DefaultTableModel)table.getModel();

        Vector <String> r = new Vector <String>();
        y.addRow(r);

     //   initialise1();
      //  initialise();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        DefaultTableModel y = (DefaultTableModel)table.getModel();

        int a=y.getRowCount()- 1;

        y.removeRow(a);
        try{

           
            Connection con1 = Database.getConnection();
            Statement ps1 =con1.createStatement();
            Statement ps2 =con1.createStatement();
      //      PreparedStatement ps10=con1.prepareStatement("delete from  journal_creation where purchase_id='"+j_id.getText()+"'");

          //  ps10.executeUpdate();

            //jComboBox1.removeAll();
        }catch (SQLException q){
            System.out.println("Sql Exception" + q.toString());
        }
        
    }//GEN-LAST:event_jButton6ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Clear_button;
    private javax.swing.JTextField balance_txt;
    private javax.swing.JTextField create_date;
    private javax.swing.JTextField create_user;
    private javax.swing.JTextField credit_total;
    private javax.swing.JTextField debit_total;
    private javax.swing.JButton delete_button;
    private javax.swing.JTextField invoice_no_txt;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField j_date;
    private javax.swing.JComboBox ledger_name;
    private javax.swing.JTextField ref_no;
    private javax.swing.JButton savebutton;
    private javax.swing.JTextArea sec_journal_narration;
    private javax.swing.JTable table;
    private javax.swing.JTextField update_date;
    private javax.swing.JTextField update_user;
    // End of variables declaration//GEN-END:variables
JComboBox combox1 = new JComboBox(new String [] {"Select","By","To"});
private javax.swing.JOptionPane jopt1;
}
