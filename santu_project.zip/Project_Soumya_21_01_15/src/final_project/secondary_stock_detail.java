/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Ardhendu
 */
public class secondary_stock_detail extends javax.swing.JPanel {

    /**
     * Creates new form secondary_stock_detail
     */
       Font myFont = new Font("",Font.PLAIN,9);
    
     int i=0,j=0;
      int pt;
    public secondary_stock_detail() {
        initComponents();
        no.setFocusable(true);
        no.setEditable(false);
         table_1.setRowHeight(35);
        try{
        
          
           Connection con =Database.getConnection();
         Statement ps2 =con.createStatement();
            ResultSet rs2=ps2.executeQuery("select distinct gd_name from godown order by gd_id");
            
               while(rs2.next())
              {
                  String name2=rs2.getString("gd_name");
                  from.addItem(name2);
                  to.addItem(name2);
              }
       
          
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
         try{
        
           
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct product_name from product");
          while(rs.next())
          {
             
            item_combo.addItem(rs.getString("product_name"));
            
          }
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
         try{
        
          
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct u_name from unit");
          while(rs.next())
          {
             
            unit_combo.addItem(rs.getString("u_name"));
            
          }
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
         
        jLabel1.setFont(myFont);
        jLabel1.setEnabled(false);
        jLabel1.setVisible(false);
        
        jLabel2.setFont(myFont);
        jLabel2.setEnabled(false);
        jLabel2.setVisible(false);
         
         
    }
    
    // Form
    
    public void from(){
           if(from.getSelectedItem().equals(""))
      {
          from.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel1.setEnabled(true);
          jLabel1.setForeground(Color.red);
          jLabel1.setVisible(true);
             
      }  
      else
      {
           from.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel1.setEnabled(false);  
           jLabel1.setVisible(false);
           i=1;
      }
        
    }
    
      // Form
    
    public void to(){
           if(to.getSelectedItem().equals(""))
      {
          to.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel2.setEnabled(true);
          jLabel2.setForeground(Color.red);
          jLabel2.setVisible(true);
             
      }  
      else
      {
           to.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel2.setEnabled(false);  
           jLabel2.setVisible(false);
           j=1;
      }
    }
    
    
   public void update_table(String s1)
    { 
       
         
       
       

          try{
         
            
            Connection con1 = Database.getConnection();
            Statement ps1 =con1.createStatement();
            Statement ps2 =con1.createStatement();
            Statement ps3 =con1.createStatement();
            ResultSet rs1 =ps1.executeQuery("SELECT * from godown_detail where invoice='"+s1+"' ");
            while(rs1.next())
                {
                
              
                
                String a1=rs1.getString("invoice");
                no.setText(a1);
              

                String a2=rs1.getString("date");
               
                date.setText(a2);
                                
                String a3=rs1.getString("gd_name_from");
                from.setSelectedItem(a3);
                
                
                
                String a5=rs1.getString("gd_name_to");
                to.setSelectedItem(a5);
                
               
                                                
                
            
            // Code to Save & Edit Sale Table 3 with value from JTextField 3
         
            
          

                }
            //Code to fill Item Table
           DefaultTableModel y1 = (DefaultTableModel)table_1.getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            }
        
            
            
           ResultSet rs2=ps2.executeQuery("SELECT * from godown_detail where invoice='"+s1+"' ");
        
//sale_item AS Item, sale_unit AS Unit, sale_quantity AS Quantity, sale_rate AS Rate, sale_amount AS Amount, sale_tax AS Amount, sale_taxable_amnt AS Taxable_Amt, sale_disc AS Discount, sale_disc_amnt AS Discount_Amt, sale_total AS Total
           
           //table1.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs2));
           
           int li_row=0;
           int rw = 0;
           Vector <String> r[] = (Vector <String> []) new Vector[1000];
           
           
          
           
           while(rs2.next())
                 {
                 y1.addRow(r[rw]); 
                    
                 table_1.setValueAt(rs2.getString("item"), li_row, 0);
                 table_1.setValueAt(rs2.getString("t_quantity"), li_row, 1);
                 
                
                 table_1.setValueAt(rs2.getString("unit"), li_row, 2);
                 
                
                 
                 rw++;
                 li_row++;
                 }
           
           
            
       
        }catch (SQLException q){
        System.out.println("Sql Exception" + q.toString());
        }
        

                 

        

     
      


        }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane1 = new javax.swing.JOptionPane();
        item_combo = new javax.swing.JComboBox();
        unit_combo = new javax.swing.JComboBox();
        quantity = new numeric.textField.NumericTextField();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        table_1 = new javax.swing.JTable();
        transfer_button = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        from = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        to = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        no = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();

        item_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        unit_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        quantity.setText("numericTextField1");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Stock Transfer", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(0, 0, 255))); // NOI18N
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        table_1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Material Name", "Quantity", "Unit"
            }
        ));
        jScrollPane3.setViewportView(table_1);
        table_1.getColumn("Quantity").setCellEditor(new DefaultCellEditor(quantity));
        table_1.getColumn("Material Name").setCellEditor(new DefaultCellEditor(item_combo));
        table_1.getColumn("Unit").setCellEditor(new DefaultCellEditor(unit_combo));

        transfer_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        transfer_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        transfer_button.setText("SAVE");
        transfer_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transfer_buttonActionPerformed(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rows", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(0, 51, 255))); // NOI18N

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/add-2-icon.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Action-remove-icon.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 468, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(100, 100, 100))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(264, 264, 264)
                .addComponent(transfer_button)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(transfer_button)
                .addGap(6, 6, 6))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Godowns", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), java.awt.Color.blue)); // NOI18N

        from.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        from.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fromFocusLost(evt);
            }
        });

        jLabel1.setText("Select One!");

        to.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        to.setSelectedIndex(-1);
        to.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toActionPerformed(evt);
            }
        });
        to.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                toFocusLost(evt);
            }
        });

        jLabel5.setForeground(java.awt.Color.blue);
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("To:");

        jLabel2.setText("Select One!");

        jLabel3.setForeground(java.awt.Color.blue);
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("From:");

        jLabel4.setForeground(java.awt.Color.blue);
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("No.");

        jLabel6.setForeground(java.awt.Color.blue);
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Date:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(from, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                    .addComponent(no, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 83, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addGap(32, 32, 32)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                                .addComponent(to, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(date, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel5Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel3, jLabel4, jLabel5, jLabel6});

        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(to, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(from, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 580, Short.MAX_VALUE)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 592, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 386, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 8, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void transfer_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transfer_buttonActionPerformed
        from();
        to();

        if(i==1&&j==1)
        {
           
            try{

                
                Connection con = Database.getConnection();
                
                PreparedStatement ps1=con.prepareStatement("delete from  godown_detail where invoice='"+no.getText()+"'");

                ps1.executeUpdate();
                pt=table_1.getRowCount();
                for(int i=0;i<pt;i++)
                {
                    String item=table_1.getValueAt(i,0).toString();
                    String quantity=table_1.getValueAt(i,1).toString();
                    String unit=table_1.getValueAt(i,2).toString();
                    PreparedStatement gds=con.prepareStatement("insert into godown_detail (gd_name_from, item, t_quantity, unit,invoice,type,gd_name_to,date)values('"+from.getSelectedItem().toString()+"','"+item+"','"+quantity+"','"+unit+"','"+no.getText()+"','STOCK TRANSFER','"+to.getSelectedItem().toString()+"','"+date.getText()+"')");

                    gds.executeBatch();
                    gds.executeUpdate();

                }
              
                DefaultTableModel y1 = (DefaultTableModel)table_1.getModel();
                int fr = y1.getRowCount();
                while (fr>=1)
                {
                    int a=y1.getRowCount()- 1;
                    y1.removeRow(a);
                    fr--;
                }
                no.setText("");
                date.setText("");
                to.setSelectedIndex(-1);
                from.setSelectedIndex(-1);
            }catch (SQLException e){
                System.out.println("Sql Exception" + e.toString());
            }
            
              jOptionPane1.showMessageDialog(this,"Stock Transfer Changed Successfully");
        }
    }//GEN-LAST:event_transfer_buttonActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        DefaultTableModel y = (DefaultTableModel)table_1.getModel();

        Vector <String> r = new Vector <String>();
        y.addRow(r);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        DefaultTableModel y = (DefaultTableModel)table_1.getModel();

        int a=y.getRowCount()- 1;
//        System.out.println(a);
//         System.out.println(pt);
        if(a==pt)
        {
        

        } 
        else{
            y.removeRow(a);
        }
            
    }//GEN-LAST:event_jButton3ActionPerformed

    private void fromFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fromFocusLost
        if(from.getSelectedItem().equals(""))
        {
            from.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel1.setEnabled(true);
            jLabel1.setForeground(Color.red);
            jLabel1.setVisible(true);

        }
        else
        {
            from.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel1.setEnabled(false);
            jLabel1.setVisible(false);
            i=1;
        }
    }//GEN-LAST:event_fromFocusLost

    private void toActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_toActionPerformed

    private void toFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_toFocusLost
        if(to.getSelectedItem().equals(""))
        {
            to.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel2.setEnabled(true);
            jLabel2.setForeground(Color.red);
            jLabel2.setVisible(true);

        }
        else
        {
            to.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel2.setEnabled(false);
            jLabel2.setVisible(false);
            j=1;
        }
    }//GEN-LAST:event_toFocusLost


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField date;
    private javax.swing.JComboBox from;
    private javax.swing.JComboBox item_combo;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField no;
    private numeric.textField.NumericTextField quantity;
    private javax.swing.JTable table_1;
    private javax.swing.JComboBox to;
    private javax.swing.JButton transfer_button;
    private javax.swing.JComboBox unit_combo;
    // End of variables declaration//GEN-END:variables
}
