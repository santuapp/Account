/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import org.jdesktop.xswingx.PromptSupport;

/**
 *
 * @author virtual vista
 */
public class challan_purchase extends javax.swing.JPanel {
     Font myFont = new Font("",Font.PLAIN,9);
     int i=0,j=0,k=0,l=0,m=0;   // For Mandatory
     int x=0,y=0;              // For Non Mandatory

    String pur_item,quantity_name,quan,name4;
    Double quantity_value,quantity_value1,quantity_value3;

    /**
     * Creates new form challan_purchase
     */
    
    public void set(){
        invoice_no_txt.requestFocusInWindow();
        invoice_no_txt.setFocusable(true);
    }
    
    public void user(String u_name){
        jLabel2.setText(u_name);
    }
    
    public challan_purchase() {
        initComponents();
            
        PromptSupport.setPrompt("dd/mm/yyyy", date);
        PromptSupport.setPrompt("0.00", curbalnc_txt);
       
        
        fill_combo();
     //   initialise();
       // cell_caculate();
        invoice_no_txt.setFocusable(true);
        invoice_no_txt.getCaret().setVisible(true);        
        
        jLabel3.setFont(myFont);
        jLabel3.setEnabled(false);
        jLabel3.setVisible(false);
        
        jLabel10.setFont(myFont);
        jLabel10.setEnabled(false);
        jLabel10.setVisible(false);
        
        jLabel11.setFont(myFont);
        jLabel11.setEnabled(false);
        jLabel11.setVisible(false);
        
        jLabel12.setFont(myFont);
        jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        jLabel13.setFont(myFont);
        jLabel13.setEnabled(false);
        jLabel13.setVisible(false);
        
        jLabel14.setFont(myFont);
        jLabel14.setEnabled(false);
        jLabel14.setVisible(false);
        
       jLabel2.setVisible(false);
        
        TableCellRenderer r = table1.getTableHeader().getDefaultRenderer();
        JLabel headerlabel = (JLabel)r;
        headerlabel.setHorizontalAlignment(JLabel.CENTER);
        
        jButton5.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jButton4.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
     // Invoice No
    
    public void invoice(){
   if(invoice_no_txt.getText().length()==0)
      {
          invoice_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel3.setEnabled(true);
          jLabel3.setForeground(Color.red);
          jLabel3.setVisible(true);
             
      }  
      else
      {
           invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel3.setEnabled(false);  
           jLabel3.setVisible(false);
           i=1;
          
      }
    }
    
    // date
    
    public void date(){
     if(date.getText().length()==0)
        {
                 date.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);
        }
        else
        {
            String content = date.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel14.setEnabled(false);  
            jLabel14.setVisible(false);
            j=1;
            if(!matchFound)

            {

                 date.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel14.setEnabled(true);
                 jLabel14.setForeground(Color.red);
                 jLabel14.setVisible(true);

            }
        }
    }
    
    // Party Name
    
    public void party(){
    if(party_combo.getSelectedItem().equals(""))
      {
          party_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel10.setEnabled(true);
          jLabel10.setForeground(Color.red);
          jLabel10.setVisible(true);
             
      }  
      else
      {
           party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel10.setEnabled(false);  
           jLabel10.setVisible(false);
           k=1;
      }
    }
    
    // Sale Ledger
    
    public void purchase(){
     if(sale_combo.getSelectedItem().equals(""))
      {
          sale_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel12.setEnabled(true);
          jLabel12.setForeground(Color.red);
          jLabel12.setVisible(true);
             
      }  
      else
      {
           sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel12.setEnabled(false);  
           jLabel12.setVisible(false);
           l=1;
      }
        
    }
    
    // Godown
    
    public void godown(){
     if(godown_combo.getSelectedItem().equals(""))
      {
          godown_combo.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
             
      }  
      else
      {
           godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           m=1;
      }
        
    }
      public void fill_combo()
    {
      try{
        
           Connection con = Database.getConnection();
            
            // Adding Items to Party Ledger
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("select distinct l_name from ledger order by l_id");
            
               while(rs.next())
              {
                  String name=rs.getString("l_name");
                  party_combo.addItem(name);
                  sale_combo.addItem(name);
              }
               
            //              String name1="Others";
            //              group.addItem(name1);
            
            //Adding Items to Purchase Ledger
            Statement ps2 =con.createStatement();
            ResultSet rs2=ps2.executeQuery("select distinct gd_name from godown order by gd_id");
            
               while(rs2.next())
              {
                  String name2=rs2.getString("gd_name");
                  godown_combo.addItem(name2);
              }
               
            //Adding Items to Unit in Table
            Statement ps3 = con.createStatement();
            ResultSet rs3=ps3.executeQuery("select distinct u_name from unit order by u_id");
            
            
               while(rs3.next())
              {
                  String name3=rs3.getString("u_name");
                  unit_combox.addItem(name3);
              }   
               
            //Adding Products to Item in Table
            Statement ps4 = con.createStatement();
            ResultSet rs4 = ps4.executeQuery("select distinct product_name from product order by p_id");
            
            
               while(rs4.next())
              {
                  String name4=rs4.getString("product_name");
                  item_combox.addItem(name4);
              }    
               
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
          
    
    }
    
               public void initialise()
         {
            table1.setRowHeight(25);
            table1.getModel().addTableModelListener(new TableModelListener()
        
                {
                  public void tableChanged (TableModelEvent e)
                {
		  double gtot=0.0d;
            int n1=table1.getRowCount();
            System.out.println(n1);
            for (int i =0; i<=n1-1; i++)
            {
                if ((table1.getValueAt(i, 9)) !=null)
            {
                    String s1 = (String)table1.getValueAt(i, 9);
                    double d1=Double.parseDouble(s1);
                    System.out.println(s1);
                   
                   
                    gtot=gtot+d1;
                    System.out.println(gtot);
                  
            }
                String s4=Double.toString(gtot);
                  
            }
            
                }
                }
          );

         }

     public void cell_caculate()
     {
          
      table1.getModel().addTableModelListener(new TableModelListener()
        
                {
                  public void tableChanged (TableModelEvent e)
                {
                  int n=table1.getRowCount();
                  System.out.println(n);
                  for (int j = 0; j<=n-1; j++)
                    {
                        if (((table1.getValueAt(j, 2)) !=null) && (table1.getValueAt(j, 3)) !=null)
                        {
//                            String q1 = table1.getValueAt(j, 2).toString();
//                            
//                            double q = Double.parseDouble(q1);
                            double q = (double) table1.getValueAt(j, 2);
                            System.out.println(q);
                            //double q1 = Double.parseDouble(q);
                            double r = (double) table1.getValueAt(j, 3);
                            System.out.println(r);
                            // double r1 = Double.parseDouble(r);
                            double gtotal=0.0d;
                            double gtotal1=0.0d;
                            double tax_amnt=0.0d;
                            double disc_amnt=0.0d;
                            double tot =  (q*r);
                          // String tot1 = Double.toString(tot);
                            System.out.println(tot);
                            //System.out.flush();
                           if (table1.getValueAt(j, 4) == null)
                                {
                               table1.setValueAt(tot, j, 4);
                                }
                           if (table1.getValueAt(j, 5) != null)
                                {
                                double tax = (Double)table1.getValueAt(j, 5);
                                tax_amnt= (tot*tax)/100;
                                
                                if(table1.getValueAt(j, 6) == null)
                                    {
                                     System.out.println(tax_amnt);
                                     table1.setValueAt(tax_amnt, j, 6);
                                    }
                                }
                           if (table1.getValueAt(j, 7) != null) 
                                {
                                double disc = (Double)table1.getValueAt(j, 7);
                                disc_amnt= (tot*disc)/100;
                                
                                if(table1.getValueAt(j, 8) == null)
                                {
                                  System.out.println(disc_amnt);
                                  table1.setValueAt(disc_amnt, j, 8);
                                }
                                  
                                }
                           
          
                           if (table1.getValueAt(j, 8) != null&&table1.getValueAt(j, 6) != null&&table1.getValueAt(j, 4) != null&&table1.getValueAt(j, 9) == null)
                           {
                                    
                                 gtotal= tax_amnt  + tot - disc_amnt;
                                 
                                 System.out.println(gtotal);
                                 String gt=Double.toString(gtotal);
                                     
                                 //System.out.println(gtotal1);
                                 table1.setValueAt(gt, j, 9);
                                  
                            }
                         }
                    }
                }
               }
            );
     }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane1 = new javax.swing.JOptionPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        invoice_no_txt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        party_combo = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        curbalnc_txt = new numeric.textField.NumericTextField();
        jLabel11 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel7 = new javax.swing.JLabel();
        sale_combo = new javax.swing.JComboBox();
        jLabel12 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        godown_combo = new javax.swing.JComboBox();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        challan_purchase_narration = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("PURCHASE CHALLAN");

        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Challan No:");

        invoice_no_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        invoice_no_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                invoice_no_txtFocusLost(evt);
            }
        });

        jLabel3.setText("Enter Invoice No.!");

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Party's Name:");

        party_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        party_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                party_comboActionPerformed(evt);
            }
        });
        party_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                party_comboFocusLost(evt);
            }
        });

        jLabel10.setText("Enter Party Name!");

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Current Balance:");

        curbalnc_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setText("numericTextField1");
        curbalnc_txt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                curbalnc_txtFocusLost(evt);
            }
        });

        jLabel11.setText("Enter Current Balance!");

        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Purchase Ledger:");

        sale_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        sale_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sale_comboActionPerformed(evt);
            }
        });
        sale_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                sale_comboFocusLost(evt);
            }
        });

        jLabel12.setText("Select Ledger!");

        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Godown Name:");

        godown_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        godown_combo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                godown_comboActionPerformed(evt);
            }
        });
        godown_combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                godown_comboFocusLost(evt);
            }
        });

        jLabel13.setText("Select Godown!");

        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("Date:");

        date.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dateActionPerformed(evt);
            }
        });
        date.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                dateFocusLost(evt);
            }
        });

        jLabel14.setText("Enter Valid Date Format!");

        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Narration:");

        challan_purchase_narration.setColumns(20);
        challan_purchase_narration.setRows(5);
        jScrollPane3.setViewportView(challan_purchase_narration);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jSeparator2)
                .addGap(292, 292, 292))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jSeparator1)
                .addGap(293, 293, 293))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(party_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sale_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(curbalnc_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(invoice_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(82, 82, 82)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(godown_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 459, Short.MAX_VALUE))))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel1, jLabel5, jLabel6, jLabel7, jLabel8, jLabel9});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(invoice_no_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(party_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addComponent(jLabel10)
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(curbalnc_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(sale_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(godown_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/folder-access-icon.png"))); // NOI18N
        jButton4.setText("Submit");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        jButton5.setText("Reset");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Item", "Unit", "Quantity"
            }
        ));
        jScrollPane2.setViewportView(table1);
        table1.getColumn("Item").setCellEditor(new DefaultCellEditor(item_combox));
        table1.getColumn("Unit").setCellEditor(new DefaultCellEditor(unit_combox));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rows", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Action-remove-icon.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/add-2-icon.png"))); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton7))
        );

        jLabel2.setText("jLabel2");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 759, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(232, 232, 232)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(13, 13, 13)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 619, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(28, 28, 28)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jScrollPane1.setViewportView(jPanel4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 719, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void invoice_no_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_invoice_no_txtFocusLost
        if(invoice_no_txt.getText().length()==0)
        {
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel3.setEnabled(true);
            jLabel3.setForeground(Color.red);
            jLabel3.setVisible(true);

        }
        else
        {
            invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel3.setEnabled(false);
            jLabel3.setVisible(false);
            i=1;

        }
    }//GEN-LAST:event_invoice_no_txtFocusLost

    private void party_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_party_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_party_comboActionPerformed

    private void party_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_party_comboFocusLost
        if(party_combo.getSelectedItem().equals(""))
        {
            party_combo.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel10.setEnabled(true);
            jLabel10.setForeground(Color.red);
            jLabel10.setVisible(true);

        }
        else
        {
            party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel10.setEnabled(false);
            jLabel10.setVisible(false);
            k=1;
        }
    }//GEN-LAST:event_party_comboFocusLost

    private void dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dateActionPerformed

    private void dateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dateFocusLost
        if(date.getText().length()==0)
        {
            date.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel14.setEnabled(true);
            jLabel14.setForeground(Color.red);
            jLabel14.setVisible(true);
        }
        else
        {
            String content = date.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel14.setEnabled(false);
            jLabel14.setVisible(false);
            j=1;
            if(!matchFound)

            {

                date.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel14.setEnabled(true);
                jLabel14.setForeground(Color.red);
                jLabel14.setVisible(true);

            }
        }
    }//GEN-LAST:event_dateFocusLost

    private void sale_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sale_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sale_comboActionPerformed

    private void sale_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_sale_comboFocusLost
        if(sale_combo.getSelectedItem().equals(""))
        {
            sale_combo.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel12.setEnabled(true);
            jLabel12.setForeground(Color.red);
            jLabel12.setVisible(true);

        }
        else
        {
            sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel12.setEnabled(false);
            jLabel12.setVisible(false);
            l=1;
        }
    }//GEN-LAST:event_sale_comboFocusLost

    private void godown_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_godown_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_godown_comboActionPerformed

    private void godown_comboFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_godown_comboFocusLost
        if(godown_combo.getSelectedItem().equals(""))
        {
            godown_combo.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel13.setEnabled(true);
            jLabel13.setForeground(Color.red);
            jLabel13.setVisible(true);

        }
        else
        {
            godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel13.setEnabled(false);
            jLabel13.setVisible(false);
            m=1;
        }
    }//GEN-LAST:event_godown_comboFocusLost

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        DefaultTableModel y = (DefaultTableModel)table1.getModel();

        int a=y.getRowCount()- 1;

        y.removeRow(a);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        //String dt = date_txt.getText()+"/"+month_txt.getText()+"/"+year_txt.getText();
        invoice();
    date();
    party();
    purchase();
    godown();
     if(i==1&&j==1&&k==1&&l==1&&m==1&&x==0)
     {      
         try
         {

            Connection con = Database.getConnection();
            String ex=invoice_no_txt.getText();
            PreparedStatement exist=con.prepareStatement("Select purchase_challan_no from purchase_challan_1 where purchase_challan_no='"+ex+"'");
             ResultSet rs40=exist.executeQuery();
             System.out.println(rs40);
            if(rs40.next())
                {
                
                String  pcn=rs40.getString("purchase_challan_no");
                //jTextField1.setText(aa);
                System.out.println(pcn);
               
                    jOptionPane1.showMessageDialog(this,"Purchase Challan Already Exist");
                   
                }
                else
                {
                    
                    log_table.table_create("purchase_challan_1",  invoice_no_txt.getText());
                log_table.table_insert("purchase_challan_1",  invoice_no_txt.getText());
                    PreparedStatement ps=con.prepareStatement("insert into purchase_challan_1 (purchase_challan_no, purchase_challan_date, purchase_challan_party_name, purchase_challan_current_balance, purchase_challan_sale_ledger, purchase_challan_godown_name,purchase_challan_narration)values('"+invoice_no_txt.getText()+"','"+date.getText()+"','"+party_combo.getSelectedItem().toString()+"','"+curbalnc_txt.getText()+"','"+sale_combo.getSelectedItem().toString()+"','"+godown_combo.getSelectedItem().toString()+"','"+challan_purchase_narration.getText()+"')");
            ps.executeUpdate();

            System.out.println("Done Insertion in Sale Table 1");
          
            int p=table1.getRowCount();
            System.out.println(p);
            for(int i=0;i<p;i++)
            {
                String item=table1.getValueAt(i,0).toString();
                String unit=table1.getValueAt(i,1).toString();
                String quantity=table1.getValueAt(i,2).toString();
//             

              PreparedStatement ps1=con.prepareStatement("insert into purchase_challan_2 (purchase_challan_no, purchase_challan_item, purchase_challan_unit, purchase_challan_quantity)values('"+invoice_no_txt.getText()+"','"+item+"','"+unit+"','"+quantity+"')");
//
                ps1.executeBatch();
                ps1.executeUpdate();
                System.out.println(item);
                System.out.println(unit);
                System.out.println(quantity);

               
               

            }

            System.out.println("saved");

            jOptionPane1.showMessageDialog(this,"Purchase Challan Created");
            
        invoice_no_txt.setText(null);
        party_combo.setSelectedIndex(0);
        curbalnc_txt.setText(null);
        sale_combo.setSelectedIndex(0);
        godown_combo.setSelectedIndex(0);
        date.setText(null);
        challan_purchase_narration.setText(null);

        
        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel3.setVisible(false);
        jLabel14.setVisible(false);
        jLabel10.setVisible(false);
        jLabel11.setVisible(false);
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
        
        
         //TABLE RESET
           int p2=table1.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
           
        
                
                
                
        table1.setValueAt(a1, i, 0);
        table1.setValueAt(a2, i, 1);
        table1.setValueAt(a3, i, 2);
        
            }
                }
                
                
          ///////////////  
//            
            
con.close();
        }
        
        catch (SQLException e)
        {
            System.out.println("Sql Exception" + e.toString());
        }
     }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        invoice_no_txt.setText(null);
        party_combo.setSelectedIndex(0);
        curbalnc_txt.setText(null);
        sale_combo.setSelectedIndex(0);
        godown_combo.setSelectedIndex(0);
        date.setText(null);
        challan_purchase_narration.setText(null);

        
        invoice_no_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        party_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        sale_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        godown_combo.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jLabel3.setVisible(false);
        jLabel14.setVisible(false);
        jLabel10.setVisible(false);
        jLabel11.setVisible(false);
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
        
         //TABLE RESET
           int p2=table1.getRowCount();
        for(int i=0;i<p2;i++)
            {
                String a1=null;
                String a2=null;
                Double a3=null;
           
        
                
                
                
        table1.setValueAt(a1, i, 0);
        table1.setValueAt(a2, i, 1);
        table1.setValueAt(a3, i, 2);
        
            }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void curbalnc_txtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_curbalnc_txtFocusLost
        if(curbalnc_txt.getText().length()==0)
        {
            curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel11.setEnabled(false);
            jLabel11.setVisible(false);
            x=0;
        }
        else
        {
            String content = curbalnc_txt.getText();
            Pattern p = Pattern.compile("[-+]?[0-9]*\\.[0-9]?[0-9]|[-+]?[0-9]*");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            curbalnc_txt.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel11.setEnabled(false);
            jLabel11.setVisible(false);
            x=0;
            if(!matchFound)
            {
                x=1;
                curbalnc_txt.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel11.setEnabled(true);
                jLabel11.setForeground(Color.red);
                jLabel11.setVisible(true);

            }
        }
    }//GEN-LAST:event_curbalnc_txtFocusLost

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        DefaultTableModel y = (DefaultTableModel)table1.getModel();

        Vector <String> r = new Vector <String>();
        y.addRow(r);
        int i=table1.getRowCount();
        System.out.println("no."+i);
    }//GEN-LAST:event_jButton7ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea challan_purchase_narration;
    private numeric.textField.NumericTextField curbalnc_txt;
    private javax.swing.JTextField date;
    private javax.swing.JComboBox godown_combo;
    private javax.swing.JTextField invoice_no_txt;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JComboBox party_combo;
    private javax.swing.JComboBox sale_combo;
    private javax.swing.JTable table1;
    // End of variables declaration//GEN-END:variables
JComboBox item_combox = new JComboBox();
    JComboBox unit_combox = new JComboBox();
}
