/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.DefaultRowSorter;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author Ardhendu
 */
public class sale_register_panel extends javax.swing.JPanel {

    /**
     * Creates new form sale_register_panel
     */
       String head_trans;
    String id;
    /**
     * Creates new form vendor_trans_detail_panel
     */
        public String s1="";
        public  int row,col;
    public sale_register_panel() {
        initComponents();
        
        table_1.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }
        });
        TableColumnModel cmodel = table_1.getColumnModel(); 
        TextAreaRenderer textAreaRenderer = new TextAreaRenderer(); 
        cmodel.getColumn(0).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(1).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(2).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(3).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(4).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(5).setCellRenderer(textAreaRenderer);

        addRows(table_1);
       add_panel();
       
       
    }
    
    
     private void addRows(JTable table)
    
    { 
           DefaultTableModel y1 = (DefaultTableModel)table .getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            }
        
       try{
        
            
            Connection con = Database.getConnection();
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("SELECT vtp_trans_date as DATE, vtp_ledger AS PARTICULARS, vtp_debit AS DEBIT, vtp_credit as CREDIT, vtp_get_id AS `TRANSSACTION ID`, vtp_type as TYPE FROM sale_register");
           int li_row=0;
           int rw = 0;
           Vector <String> r[] = (Vector <String> []) new Vector[1000];
           
           
        
           
           while(rs.next())
                 {
                 y1.addRow(r[rw]); 
                    
                 table.setValueAt(rs.getString("DATE"), li_row, 0);
                 table.setValueAt(rs.getString("PARTICULARS"), li_row, 1);
                 table.setValueAt(rs.getString("DEBIT"), li_row, 2);
                 table.setValueAt(rs.getString("CREDIT"), li_row, 3);
                 table.setValueAt(rs.getString("TRANSSACTION ID"), li_row, 4);
                 table.setValueAt(rs.getString("TYPE"), li_row, 5);
                  
       
                 
                 rw++;
                 li_row++;
                 }
           

   
            System.out.println("Done");
          
         
            }catch (SQLException e)
                {
                System.out.println("Sql Exception" + e.toString());
                }
        
 }

     public void  add_panel()
 {
     table_1.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table_1.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }
        });
   //  trans_label.setText("Details of:"+click);
    // head_trans = click;
     
          try{
        
           
           Connection con = Database.getConnection();
           Statement psq3 =con.createStatement();
             PreparedStatement ps09=con.prepareStatement("DELETE FROM sale_register");
                ps09.executeUpdate();
               Statement psq =con.createStatement();
           ResultSet rsq=psq.executeQuery("SELECT distinct get_id FROM company_main_table where type='SALE' and debit='0' and get_id is not null");
           
           while(rsq.next())
           {
            id=rsq.getString("get_id");
             System.out.println(id+"A    ");
//            Statement ps =con.createStatement();
//            ResultSet rs=ps.executeQuery("SELECT distinct TRANS_Date AS DATE, ledger as PARTICULERS, SUM(Debit) AS DEBIT, SUM(Credit) AS CREDIT, get_id AS TRANSACTION_ID, TYPE FROM company_main_table where type='Opening' and ledger='"+click+"'");
//            if(rs.next())
//            {
//                String de=rs.getString("debit");
//                String cre=rs.getString("credit");
//                PreparedStatement ps110=con.prepareStatement("insert into sale_register ( vtp_ledger, vtp_debit, vtp_credit,vtp_type) values ('"+click+"','"+de+"','"+cre+"','Opening')");
//                ps110.executeUpdate();
//                System.out.println(de+"      "+cre);
//            }
            Statement psa =con.createStatement();
            ResultSet rsa=psa.executeQuery("SELECT distinct TRANS_Date AS DATE, ledger as PARTICULERS, SUM(Debit) AS DEBIT, SUM(Credit) AS CREDIT, get_id AS TRANSACTION_ID, TYPE FROM company_main_table where get_id='"+id+"' and debit='0'");
            while(rsa.next())
            {
                
                  PreparedStatement ps102=con.prepareStatement("insert into sale_register (vtp_trans_date, vtp_ledger, vtp_debit, vtp_credit, vtp_get_id, vtp_type) values ('"+rsa.getString("DATE")+"','"+rsa.getString("PARTICULERS")+"','"+rsa.getString("debit")+"','"+rsa.getString("credit")+"','"+rsa.getString("TRANSACTION_ID")+"','"+rsa.getString("type")+"')");
                     ps102.executeBatch();
                  ps102.executeUpdate();
                    
                  System.out.println("insert into sale_register (vtp_trans_date, vtp_ledger, vtp_debit, vtp_credit, vtp_get_id, vtp_type) values ('"+rsa.getString("DATE")+"','"+rsa.getString("PARTICULERS")+"','"+rsa.getString("debit")+"','"+rsa.getString("credit")+"','"+rsa.getString("TRANSACTION_ID")+"','"+rsa.getString("type")+"')");
            }
         
           }
         
           
          Statement temp =con.createStatement();
            ResultSet tm=temp.executeQuery("SELECT vtp_trans_date as DATE, vtp_ledger AS PARTICULARS, vtp_debit AS DEBIT, vtp_credit as CREDIT, vtp_get_id AS `TRANSSACTION ID`, vtp_type as TYPE FROM sale_register ");
           
                  int li_row=0;
           int rw = 0;
           Vector <String> r[] = (Vector <String> []) new Vector[1000];
             DefaultTableModel y1 = (DefaultTableModel)table_1.getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            }
           while(tm.next())
                 {
                      
                         y1.addRow(r[rw]); 
                    
                 table_1.setValueAt(tm.getString("DATE"), li_row, 0);
                  table_1.setValueAt(tm.getString("PARTICULARS"), li_row, 1);
                  table_1.setValueAt(tm.getString("DEBIT"), li_row, 2);
                   table_1.setValueAt(tm.getString("CREDIT"), li_row, 3);
                    table_1.setValueAt(tm.getString("TRANSSACTION ID"), li_row, 4);
                     table_1.setValueAt(tm.getString("TYPE"), li_row, 5);
                     rw++;
                 li_row++;
                 }
            
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
          table_1.setPreferredScrollableViewportSize(table_1.getPreferredSize());
          table_1.setAutoCreateRowSorter(true);
          table_1.setRowHeight(25);
    	DefaultRowSorter sorter = ((DefaultRowSorter)table_1.getRowSorter());
    	ArrayList list = new ArrayList();
    	list.add( new RowSorter.SortKey(2, SortOrder.ASCENDING) );
    	sorter.setSortKeys(list);
    	sorter.sort();
//         Action delete = new AbstractAction()
//{
//    public void actionPerformed(ActionEvent e)
//    {
//        
//    }
//};
//     ButtonColumn buttonColumn0 = new ButtonColumn(table_1, delete, 0);
//     ButtonColumn buttonColumn1 = new ButtonColumn(table_1, delete, 1);
//     ButtonColumn buttonColumn2 = new ButtonColumn(table_1, delete, 2);
//     ButtonColumn buttonColumn3 = new ButtonColumn(table_1, delete, 3);
//     ButtonColumn buttonColumn4 = new ButtonColumn(table_1, delete, 4);
//     ButtonColumn buttonColumn5 = new ButtonColumn(table_1, delete, 5);
//    buttonColumn0.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn1.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn2.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn3.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn4.setMnemonic(KeyEvent.VK_ENTER);
//    buttonColumn5.setMnemonic(KeyEvent.VK_ENTER);

    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_1 = new javax.swing.JTable();

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sale Register", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 255))); // NOI18N
        jPanel1.setForeground(new java.awt.Color(0, 0, 255));

        table_1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Date", "Particulars", "Debit", "Credit", "Transaction ID", "Type"
            }
        ));
        jScrollPane1.setViewportView(table_1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 388, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 287, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
public void print(){
     System.out.println(head_trans);
        HashMap param=new HashMap();
        param.put("sale_register_id", head_trans);
        String url = System.getProperty("user.dir");
        System.out.println(url);
        MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\sale_register_printable.jasper", param);
        viewer1.setVisible(true);
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable table_1;
    // End of variables declaration//GEN-END:variables
}
