package final_project;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class balance_sheet_panel extends javax.swing.JPanel implements ContainerListener {

    private final GridBagConstraints gridBagConstraints;
    private final GridBagConstraints gbc;
    Connection con;
    ResultSet rs;
    Double total_asset=0.0d,total_lib=0.0d;
     int row = 0,h=0,g=0;
     int rows = 0;
    final int count = 5000;
    final JButton[][] labels=new JButton[count][10];
    final JButton[][] labels1=new JButton[count][10];
    String enter_value="";
    String head_trans="";

//To draw line in Main Frame
    public void paint(Graphics g)  
    {  
     super.paint(g);  
     int a=(getSize().width/2)-2;
     //draw line in JFrame from top left corner until bottom right corner  
     g.drawLine(a,12,a,getSize().height-13); 
     repaint();
    }
    
    /**
     * Creates new form balance_sheet_panel
     */
      profit_loss_report_panel plrp=new profit_loss_report_panel();
    public balance_sheet_panel() {
        
        initComponents();
        
        
         try
            {
                
            
            Connection con = Database.getConnection();
        
            PreparedStatement ps3=con.prepareStatement("delete from balance_sheet_temp_1");
           
             PreparedStatement ps4=con.prepareStatement("delete from balance_sheet_temp_2");
          
            ps3.executeUpdate();
            ps4.executeUpdate();
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
            
        GridBagLayout gridbag = new GridBagLayout();
        
        
        
        gridBagConstraints = new java.awt.GridBagConstraints();
        gbc = new java.awt.GridBagConstraints();
        
            addContainerListener(this);
            
            gridBagConstraints.anchor=gridBagConstraints.PAGE_START;
        
            
            int cap=0, fap=0, lon=0, inv=0, lib=0, ast=0, prlos=0, l1=0, l2=0, r=0, row1=0, r1=0, row2=0;
            // r to control row icrement
            
            
       
             //Table headers printing

            labels[row][0] = new JButton("Liabilities");

            labels[row][0].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
            
                 
            


            labels[row][1] = new JButton("as at");

            labels[row][1].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.10;
            gridBagConstraints.gridx=17;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            jPanel1.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
         


            labels[row][2] = new JButton("  ");

            labels[row][2].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=23;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=2;
            gridBagConstraints.fill=gridBagConstraints.NONE;
            jPanel1.add(labels[row][2],gridBagConstraints);
           

            labels[row][3] = new JButton("31-Mar-2015");

            labels[row][3].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.10;
            gridBagConstraints.gridx=26;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            jPanel1.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.LEFT);
           

            labels[row][4] = new JButton(" ");

            labels[row][4].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=2;
            gridBagConstraints.fill=gridBagConstraints.NONE;
            jPanel1.add(labels[row][4],gridBagConstraints);
            
               
            
            labels[row][5] = new JButton("Assets");
            
            labels[row][5].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=35;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][5],gridBagConstraints);
            labels[row][5].setHorizontalAlignment(SwingConstants.LEFT);
           
            
            labels[row][6] = new JButton("as at");
            
            labels[row][6].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.10;
            gridBagConstraints.gridx=52;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            jPanel1.add(labels[row][6],gridBagConstraints);
            labels[row][6].setHorizontalAlignment(SwingConstants.RIGHT);
            
            
            
            labels[row][7] = new JButton("  ");
            
            labels[row][7].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=58;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=2;
            gridBagConstraints.fill=gridBagConstraints.NONE;
            jPanel1.add(labels[row][7],gridBagConstraints);
           
            
            
            labels[row][8] = new JButton("31-Mar-2015");
            
            labels[row][8].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.black));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.10;
            gridBagConstraints.gridx=61;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            jPanel1.add(labels[row][8],gridBagConstraints);
            labels[row][8].setHorizontalAlignment(SwingConstants.LEFT);
           
            
            row++;
            r=row;
            
            //Blank Row Printing
            
            labels[row][0] = new JButton("  ");

            labels[row][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][0],gridBagConstraints);
            labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
           

            labels[row][1] = new JButton(" ");

            labels[row][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.pink));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.10;
            gridBagConstraints.gridx=17;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            jPanel1.add(labels[row][1],gridBagConstraints);
            labels[row][1].setHorizontalAlignment(SwingConstants.RIGHT);
            


            labels[row][2] = new JButton(" ");

            labels[row][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=23;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=2;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][2],gridBagConstraints);
          


            labels[row][3] = new JButton(" ");

            labels[row][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.10;
            gridBagConstraints.gridx=26;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            jPanel1.add(labels[row][3],gridBagConstraints);
            labels[row][3].setHorizontalAlignment(SwingConstants.LEFT);
           


            labels[row][4] = new JButton(" ");

            labels[row][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=2;
            gridBagConstraints.fill=gridBagConstraints.NONE;
            jPanel1.add(labels[row][4],gridBagConstraints);
            

               
            
            labels[row][5] = new JButton("  ");
            
            labels[row][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.yellow));
            gridBagConstraints.weightx=0.20;
            gridBagConstraints.gridx=35;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=15;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][5],gridBagConstraints);
            labels[row][5].setHorizontalAlignment(SwingConstants.LEFT);
           
            
            
            labels[row][6] = new JButton(" ");
            
            labels[row][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.10;
            gridBagConstraints.gridx=52;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            jPanel1.add(labels[row][6],gridBagConstraints);
            labels[row][6].setHorizontalAlignment(SwingConstants.RIGHT);
            
            
            
            labels[row][7] = new JButton(" ");
            
            labels[row][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=58;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=2;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][7],gridBagConstraints);
           
            
            
            labels[row][8] = new JButton(" ");
            
            labels[row][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.cyan));
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            gridBagConstraints.weightx=0.10;
            gridBagConstraints.gridx=61;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            jPanel1.add(labels[row][8],gridBagConstraints);
            labels[row][8].setHorizontalAlignment(SwingConstants.LEFT);
           
            
            row++;
            r=row1=row;
            
           
          // Database connection 
            
        try
            {
        
               
               con = Database.getConnection();
          
            
       
            
            //Liabilities Filling
            
        
                 Statement ps =con.createStatement();
                 ResultSet rs=ps.executeQuery("select g_name  from `acc_group` where g_under='Liabilities' and acc_g_id >4");
                
//                 Statement ps2 =con.createStatement();
//                 ResultSet rs2=ps2.executeQuery("select sum(amount) as fixed from `Fixed Asset`");
//                
            //outer loop for Liabilities headers print
            
            
            while(rs.next())
                {
                    String group_name=rs.getString("g_name");
            
                    labels[row][0] = new JButton(group_name);

                    labels[row][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.cyan));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=0;
                    gridBagConstraints.gridy=row;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[row][0],gridBagConstraints);
                    labels[row][0].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[row][0].setContentAreaFilled(false);
                    labels[row][0].setBorderPainted(false);


                    labels[row][1] = new JButton(" ");

                    labels[row][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.pink));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=17;
                    gridBagConstraints.gridy=row;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[row][1],gridBagConstraints);
                    labels[row][1].setContentAreaFilled(false);
                    labels[row][1].setBorderPainted(false);

                    first_panel fp=new first_panel();
                    fp.add_panel_2(group_name);
                    String inv_tot=fp.val;
                    //loop for Liabilities headers print
                    
//                    Statement ps1 =con.createStatement();
//                    ResultSet rs1=ps1.executeQuery("select IFNULL (sum(credit),0.0)  - IFNULL(sum(debit),0.0) as grp_amount from `"+group_name+"`");
//
//                 while(rs1.next())
//                 {
                    
                     
                     double lib_1=Double.parseDouble(inv_tot);
                     total_lib+=lib_1;
                          labels[row][2] = new JButton(" ");

                    labels[row][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=23;
                    gridBagConstraints.gridy=row;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[row][2],gridBagConstraints);
                    labels[row][2].setContentAreaFilled(false);
                    labels[row][2].setBorderPainted(false);
                    
                    labels[row][3] = new JButton(Double.toString(lib_1));

                    labels[row][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=26;
                    gridBagConstraints.gridy=row;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[row][3],gridBagConstraints);
                    labels[row][3].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[row][3].setContentAreaFilled(false);
                    labels[row][3].setBorderPainted(false);


                    labels[row][4] = new JButton(" ");

                    labels[row][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=32;
                    gridBagConstraints.gridy=row;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.NONE;
                    jPanel1.add(labels[row][4],gridBagConstraints);
                    labels[row][4].setContentAreaFilled(false);
                    labels[row][4].setBorderPainted(false);
                    
                         
                   
                     
                     
                     
               //       For Temp database-balance_sheet_temp_1
           
            try
            {
                
            
            Connection con = Database.getConnection();
        
            PreparedStatement ps4=con.prepareStatement("insert into balance_sheet_temp_1(particulars,debit,credit)values('"+labels[row][0].getText()+"','"+labels[row][1].getText()+"','"+labels[row][3].getText()+"')");
           
            
          
            ps4.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
                  
          
//                 }
                
                    row++;
                    r=row; 
                    
                   
                    
                       
          
                    
                    
                    
                 //Liabilities sub-Subgroup Header Print
                    
                     Statement ps2 =con.createStatement();
                     ResultSet rs2=ps2.executeQuery("select g_name as grp_name from acc_group where g_under='"+group_name+"'");

                 while(rs2.next())
                 {
                    String sub_group_name=rs2.getString("grp_name");
                    
                    labels[r][0] = new JButton("  "+sub_group_name);
            
                    labels[r][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.cyan));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=0;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r][0],gridBagConstraints);
                    //set text from DB
                    labels[r][0].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[r][0].setContentAreaFilled(false);
                    labels[r][0].setBorderPainted(false);

                    
                 // Liabilities Sub-sub group amount
                    Statement ps3 =con.createStatement();
                    ResultSet rs3=ps3.executeQuery("select IFNULL(sum(credit),0.0)  - IFNULL(sum(debit),0.0) as sub_grp_amount from `"+sub_group_name+"`");

                 while(rs3.next())
                 {
                   
                    String sub_group_amount=rs3.getString("sub_grp_amount");
                    labels[r][1] = new JButton(sub_group_amount);

                    labels[r][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.pink));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=17;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r][1],gridBagConstraints);
                    //set text from DB
                    labels[r][1].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r][1].setContentAreaFilled(false);
                    labels[r][1].setBorderPainted(false);
                 
                   

                 }
                       labels[r][2] = new JButton(" ");
                     labels[r][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=23;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r][2],gridBagConstraints);
                    labels[r][2].setContentAreaFilled(false);
                    labels[r][2].setBorderPainted(false);

                    labels[r][3] = new JButton(" ");

                    labels[r][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=26;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r][3],gridBagConstraints);
                    labels[r][3].setContentAreaFilled(false);
                    labels[r][3].setBorderPainted(false);


                    labels[r][4] = new JButton(" ");

                    labels[r][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=32;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.NONE;
                    jPanel1.add(labels[r][4],gridBagConstraints);
                    labels[r][4].setContentAreaFilled(false);
                    labels[r][4].setBorderPainted(false);

                   
                    
                          // For Temp database-balance_sheet_temp_1
           
            try
            {
                
            
            Connection con = Database.getConnection();
        
            PreparedStatement ps4=con.prepareStatement("insert into balance_sheet_temp_1(particulars,debit,credit)values('"+labels[r][0].getText()+"','"+labels[r][1].getText()+"','"+labels[r][3].getText()+"')");
           
            
          
            ps4.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
                    
                    r++;
                 
                 }
                    //printing  blank row after sub-subgroup printing
                 
                    labels[r][0] = new JButton(" ");
            
                    labels[r][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.cyan));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=0;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r][0],gridBagConstraints);
                    //set text from DB
                    labels[r][0].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[r][0].setContentAreaFilled(false);
                    labels[r][0].setBorderPainted(false);

                    
                    labels[r][1] = new JButton(" ");

                    labels[r][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.pink));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=17;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r][1],gridBagConstraints);
                    //set text from DB
                    labels[r][1].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r][1].setContentAreaFilled(false);
                    labels[r][1].setBorderPainted(false);

                    
                    labels[r][2] = new JButton(" ");

                    labels[r][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=23;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r][2],gridBagConstraints);
                    labels[r][2].setContentAreaFilled(false);
                    labels[r][2].setBorderPainted(false);



                    labels[r][3] = new JButton(" ");

                    labels[r][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=26;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r][3],gridBagConstraints);
                    labels[r][3].setContentAreaFilled(false);
                    labels[r][3].setBorderPainted(false);



                    labels[r][4] = new JButton(" ");

                    labels[r][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=32;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.NONE;
                    jPanel1.add(labels[r][4],gridBagConstraints);
                    labels[r][4].setContentAreaFilled(false);
                    labels[r][4].setBorderPainted(false);

                    
         
                    
                    row=r; 
                    //row increase
                    row++;
                 
                    
                }
            }
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
         
       
         double profit_value=(plrp.net_profit);
         String pro=Double.toString(profit_value);
       
         double loss_value=(plrp.net_loss);
         String loss=Double.toString(loss_value);
         if(profit_value>loss_value){
             total_lib+=profit_value;
                     labels[r][0] = new JButton("Add:Profit");
            
                    labels[r][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.cyan));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=0;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r][0],gridBagConstraints);
                    //set text from DB
                    labels[r][0].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[r][0].setContentAreaFilled(false);
                    labels[r][0].setBorderPainted(false);

                    
                    labels[r][1] = new JButton(" ");

                    labels[r][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.pink));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=17;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r][1],gridBagConstraints);
                    //set text from DB
                    labels[r][1].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r][1].setContentAreaFilled(false);
                    labels[r][1].setBorderPainted(false);

                    
                    labels[r][2] = new JButton(" ");

                    labels[r][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=23;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r][2],gridBagConstraints);
                    labels[r][2].setContentAreaFilled(false);
                    labels[r][2].setBorderPainted(false);



                    labels[r][3] = new JButton(pro);

                    labels[r][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=26;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r][3],gridBagConstraints);
                     labels[r][3].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r][3].setContentAreaFilled(false);
                    labels[r][3].setBorderPainted(false);



                    labels[r][4] = new JButton(" ");

                    labels[r][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=32;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.NONE;
                    jPanel1.add(labels[r][4],gridBagConstraints);
                    labels[r][4].setContentAreaFilled(false);
                    labels[r][4].setBorderPainted(false);
           
            
         }
         else{
              total_lib-=loss_value;
              labels[r][0] = new JButton("Less:Loss");
            
                    labels[r][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.cyan));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=0;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r][0],gridBagConstraints);
                    //set text from DB
                    labels[r][0].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[r][0].setContentAreaFilled(false);
                    labels[r][0].setBorderPainted(false);

                    
                    labels[r][1] = new JButton(" ");

                    labels[r][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.pink));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=17;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r][1],gridBagConstraints);
                    //set text from DB
                    labels[r][1].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r][1].setContentAreaFilled(false);
                    labels[r][1].setBorderPainted(false);

                    
                    labels[r][2] = new JButton(" ");

                    labels[r][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=23;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r][2],gridBagConstraints);
                    labels[r][2].setContentAreaFilled(false);
                    labels[r][2].setBorderPainted(false);



                    labels[r][3] = new JButton(loss);

                    labels[r][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=26;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r][3],gridBagConstraints);
                     labels[r][3].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r][3].setContentAreaFilled(false);
                    labels[r][3].setBorderPainted(false);



                    labels[r][4] = new JButton(" ");

                    labels[r][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=32;
                    gridBagConstraints.gridy=r;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.NONE;
                    jPanel1.add(labels[r][4],gridBagConstraints);
                    labels[r][4].setContentAreaFilled(false);
                    labels[r][4].setBorderPainted(false);
         }
          try
            {
                
            
            Connection con = Database.getConnection();
        
            PreparedStatement ps4=con.prepareStatement("insert into balance_sheet_temp_1(particulars,debit,credit)values('"+labels[r][0].getText()+"','"+labels[r][1].getText()+"','"+labels[r][3].getText()+"')");
           
            
          
            ps4.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
                    
            row=r; 
                    //row increase
                    row++;
                 
         //asset Printing
         
           try
            {
                 Statement ps01 =con.createStatement();
                 ResultSet rs01=ps01.executeQuery("select g_name  from `acc_group` where g_under='Asset' and acc_g_id >4");
                
//                 Statement ps2 =con.createStatement();
//                 ResultSet rs2=ps2.executeQuery("select sum(amount) as fixed from `Fixed Asset`");
//                
            //outer loop for Asset  headers print
            
            
            while(rs01.next())
                {
                    
                    String group_name=rs01.getString("g_name");
                    
                    labels[row1][5] = new JButton(group_name);
                    
                    labels[row1][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.yellow));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=35;
                    gridBagConstraints.gridy=row1;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[row1][5],gridBagConstraints);
                    labels[row1][5].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[row1][5].setContentAreaFilled(false);
                    labels[row1][5].setBorderPainted(false);



                    labels[row1][6] = new JButton(" ");            

                    labels[row1][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=52;
                    gridBagConstraints.gridy=row1;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[row1][6],gridBagConstraints);
                    labels[row1][6].setContentAreaFilled(false);
                    labels[row1][6].setBorderPainted(false);
                    
                    first_panel fp=new first_panel();
                    fp.add_panel_2(group_name);
                    String inv_tot1=fp.val;
  
                    //loop for Asset headers print
                    
//                    Statement ps02 =con.createStatement();
//                    ResultSet rs02=ps02.executeQuery("select IFNULL(sum(debit),0)  - IFNULL(sum(credit),0) as grp_amount from `"+group_name+"`");
//
//                    while(rs02.next())
//                        
//                    {
                            double aset_1=Double.parseDouble(inv_tot1);
                     total_asset+=aset_1;
                    // String asset_total=rs02.getString("grp_amount");
//                     double total1=Double.parseDouble(asset_total);
                    // total_asset=total_asset + total1;
                       
                    labels[row1][7] = new JButton(" ");

                    labels[row1][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=58;
                    gridBagConstraints.gridy=row1;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[row1][7],gridBagConstraints);
                    labels[row1][7].setContentAreaFilled(false);
                    labels[row1][7].setBorderPainted(false);


                    labels[row1][8] = new JButton(Double.toString(aset_1));

                    labels[row1][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=61;
                    gridBagConstraints.gridy=row1;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[row1][8],gridBagConstraints);
                    
                    labels[row1][8].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[row1][8].setContentAreaFilled(false);
                    labels[row1][8].setBorderPainted(false);
                        
                    
                  //  }
                    
                    
                    
                                 
               //       For Temp database-balance_sheet_temp_2
           
            try
            {
                
            
            Connection con = Database.getConnection();
        
            PreparedStatement ps4=con.prepareStatement("insert into balance_sheet_temp_2(particulars,debit,credit)values('"+labels[row1][5].getText()+"','"+labels[row1][6].getText()+"','"+labels[row1][8].getText()+"')");
           
            
          
            ps4.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
            
                    
                     row1++;
                  
                     r1=row1; 
                    
                    
                 //Asset sub-Subgroup Header Print
                    
                     Statement ps03 =con.createStatement();
                     ResultSet rs03=ps03.executeQuery("select g_name as grp_name from acc_group where g_under='"+group_name+"'");

                while(rs03.next())
                {
                    String sub_group_name=rs03.getString("grp_name");
                      
                    labels[r1][5] = new JButton("  "+sub_group_name);

                    labels[r1][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.yellow));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=35;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r1][5],gridBagConstraints);
                    //set text from DB
                    labels[r1][5].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[r1][5].setContentAreaFilled(false);
                    labels[r1][5].setBorderPainted(false);

                   /// Asset Sub-sub group amount
                    Statement ps04 =con.createStatement();
                    ResultSet rs04=ps04.executeQuery("select IFNULL(sum(credit),0)  - IFNULL(sum(debit),0) as sub_grp_amount from `"+sub_group_name+"`");

                 while(rs04.next())
                 {
                    labels[r1][6] = new JButton(rs04.getString("sub_grp_amount"));            

                    labels[r1][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=52;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r1][6],gridBagConstraints);
                    //Set text from DB
                    labels[r1][6].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r1][6].setContentAreaFilled(false);
                    labels[r1][6].setBorderPainted(false);

                 }
                    labels[r1][7] = new JButton(" ");

                    labels[r1][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=58;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r1][7],gridBagConstraints);
                    labels[r1][7].setContentAreaFilled(false);
                    labels[r1][7].setBorderPainted(false);


                    labels[r1][8] = new JButton(" ");

                    labels[r1][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=61;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r1][8],gridBagConstraints);
                    labels[r1][8].setContentAreaFilled(false);
                    labels[r1][8].setBorderPainted(false);
                    
                    
                                   //       For Temp database-balance_sheet_temp_2
           
            try
            {
                
            
            Connection con = Database.getConnection();
        
            PreparedStatement ps4=con.prepareStatement("insert into balance_sheet_temp_2(particulars,debit,credit)values('"+labels[r1][5].getText()+"','"+labels[r1][6].getText()+"','"+labels[r1][8].getText()+"')");
            ps4.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
            
                    
              
                    
                    r1++;
                    
                    //printing blank row
                    
                    labels[r1][5] = new JButton(" ");

                    labels[r1][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.yellow));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=35;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r1][5],gridBagConstraints);
                    //set text from DB
                    labels[r1][5].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[r1][5].setContentAreaFilled(false);
                    labels[r1][5].setBorderPainted(false);
                    
                    labels[r1][6] = new JButton(" ");            

                    labels[r1][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=52;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r1][6],gridBagConstraints);
                    //Set text from DB
                    labels[r1][6].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r1][6].setContentAreaFilled(false);
                    labels[r1][6].setBorderPainted(false);
                    
                    
                    
                    labels[r1][7] = new JButton(" ");

                    labels[r1][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=58;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r1][7],gridBagConstraints);
                    labels[r1][7].setContentAreaFilled(false);
                    labels[r1][7].setBorderPainted(false);


                    labels[r1][8] = new JButton(" ");

                    labels[r1][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=61;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r1][8],gridBagConstraints);
                    labels[r1][8].setContentAreaFilled(false);
                    labels[r1][8].setBorderPainted(false);
                    
                    
                    
          
                  
                    }
                    row1=r1; 
                 //row increase
                    row1++;
                
                }
           
                    
                    
                    
        }
        catch (SQLException e)
        {
        System.out.println("Sql Exception" + e.toString());
        }
  double closing_value=(plrp.closing_total);
  total_asset+=closing_value;
            String clo=Double.toString(closing_value);
            labels[r1][5] = new JButton("Closing");

                    labels[r1][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.yellow));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=35;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r1][5],gridBagConstraints);
                    //set text from DB
                    labels[r1][5].setHorizontalAlignment(SwingConstants.LEFT);
                    labels[r1][5].setContentAreaFilled(false);
                    labels[r1][5].setBorderPainted(false);
                    
                    labels[r1][6] = new JButton(" ");            

                    labels[r1][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=52;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r1][6],gridBagConstraints);
                    //Set text from DB
                    labels[r1][6].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r1][6].setContentAreaFilled(false);
                    labels[r1][6].setBorderPainted(false);
                    
                    
                    
                    labels[r1][7] = new JButton(" ");

                    labels[r1][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=58;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel1.add(labels[r1][7],gridBagConstraints);
                    labels[r1][7].setContentAreaFilled(false);
                    labels[r1][7].setBorderPainted(false);


                    labels[r1][8] = new JButton(clo);

                    labels[r1][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.magenta));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=61;
                    gridBagConstraints.gridy=r1;
                    gridBagConstraints.gridwidth=5;
                    jPanel1.add(labels[r1][8],gridBagConstraints);
                     labels[r1][8].setHorizontalAlignment(SwingConstants.RIGHT);
                    labels[r1][8].setContentAreaFilled(false);
                    labels[r1][8].setBorderPainted(false);
                    
                      //       For Temp database-balance_sheet_temp_2
            try
            {
                
            
            Connection con = Database.getConnection();
        
            PreparedStatement ps4=con.prepareStatement("insert into balance_sheet_temp_2(particulars,debit,credit)values('"+labels[r1][5].getText()+"','"+labels[r1][6].getText()+"','"+labels[r1][8].getText()+"')");
           
            
          
            ps4.executeUpdate();
            
            
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
            
                    
           // Printing empty rows to make both sides equal
           
           if (row > row1)
           {
               
            int fr = row1 - 1;
               
            for (int rw = fr; rw <= row-1; rw++)
            {   
                labels[rw][5] = new JButton(" ");

                labels[rw][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.yellow));
                gridBagConstraints.weightx=0.20;
                gridBagConstraints.gridx=35;
                gridBagConstraints.gridy=rw;
                gridBagConstraints.gridwidth=15;
                gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                jPanel1.add(labels[rw][5],gridBagConstraints);
                labels[rw][5].setHorizontalAlignment(SwingConstants.LEFT);


                labels[rw][6] = new JButton(" ");

                labels[rw][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red));
                gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                gridBagConstraints.weightx=0.10;
                gridBagConstraints.gridx=52;
                gridBagConstraints.gridy=rw;
                gridBagConstraints.gridwidth=5;
                jPanel1.add(labels[rw][6],gridBagConstraints);
                labels[rw][6].setHorizontalAlignment(SwingConstants.RIGHT);


                labels[rw][7] = new JButton(" ");

                labels[rw][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
                gridBagConstraints.weightx=0;
                gridBagConstraints.gridx=58;
                gridBagConstraints.gridy=rw;
                gridBagConstraints.gridwidth=2;
                gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                jPanel1.add(labels[rw][7],gridBagConstraints);


                labels[rw][8] = new JButton(" ");

                labels[rw][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.cyan));
                gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                gridBagConstraints.weightx=0.10;
                gridBagConstraints.gridx=61;
                gridBagConstraints.gridy=rw;
                gridBagConstraints.gridwidth=5;
                jPanel1.add(labels[rw][8],gridBagConstraints);
                labels[rw][8].setHorizontalAlignment(SwingConstants.LEFT);
            }
           
           }
           
           

                    //Grand Total printing

                    labels1[row2][0] = new JButton("Total");

                    labels1[row2][0].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.BLACK));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=0;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel2.add(labels1[row2][0],gridBagConstraints);
                    labels1[row2][0].setHorizontalAlignment(SwingConstants.LEFT);


                    labels1[row2][1] = new JButton(" ");

                    labels1[row2][1].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=17;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=5;
                    jPanel2.add(labels1[row2][1],gridBagConstraints);


                    labels1[row2][2] = new JButton("  ");

                    labels1[row2][2].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.BLACK));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=23;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel2.add(labels1[row2][2],gridBagConstraints);

                  //  String asset=Double.toString(total_asset);
                    labels1[row2][3] = new JButton(total_lib.toString());

                    labels1[row2][3].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.BLACK));
                    gridBagConstraints.fill=gridBagConstraints.NONE;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=26;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=5;
                    jPanel2.add(labels1[row2][3],gridBagConstraints);
                    labels1[row2][3].setHorizontalAlignment(SwingConstants.RIGHT);


                    labels1[row2][4] = new JButton(" ");

                    labels1[row2][4].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.BLACK));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=32;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel2.add(labels1[row2][4],gridBagConstraints);


                    labels1[row2][5] = new JButton("Total");

                    labels1[row2][5].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.BLACK));
                    gridBagConstraints.weightx=0.20;
                    gridBagConstraints.gridx=35;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=15;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel2.add(labels1[row2][5],gridBagConstraints);
                    labels1[row2][5].setHorizontalAlignment(SwingConstants.LEFT);


                    labels1[row2][6] = new JButton(" ");            

                    labels1[row2][6].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.BLACK));
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=52;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=5;
                    jPanel2.add(labels1[row2][6],gridBagConstraints);


                    labels1[row2][7] = new JButton("  ");

                    labels1[row2][7].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.BLACK));
                    gridBagConstraints.weightx=0;
                    gridBagConstraints.gridx=58;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=2;
                    gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
                    jPanel2.add(labels1[row2][7],gridBagConstraints);


                    labels1[row2][8] = new JButton(total_asset.toString());

                    labels1[row2][8].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.BLACK));
                    gridBagConstraints.fill=gridBagConstraints.NONE;
                    gridBagConstraints.weightx=0.10;
                    gridBagConstraints.gridx=61;
                    gridBagConstraints.gridy=row2;
                    gridBagConstraints.gridwidth=5;
                    jPanel2.add(labels1[row2][8],gridBagConstraints);
                    labels1[row2][8].setHorizontalAlignment(SwingConstants.RIGHT);
                    
                    jPanel2.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.BLACK));
                    
                     try
            {
                
            
            Connection con = Database.getConnection();
        
            PreparedStatement ps4=con.prepareStatement("insert into balance_sheet_temp_2(particulars,debit,credit)values('"+labels[row2][5].getText()+"','"+labels[row2][6].getText()+"','"+labels[row2][8].getText()+"')");
           
            
          
            ps4.executeUpdate();
            
             PreparedStatement ps40=con.prepareStatement("insert into balance_sheet_temp_1(particulars,debit,credit)values('"+labels[row2][0].getText()+"','"+labels[row2][1].getText()+"','"+labels[row2][3].getText()+"')");
           
            
          
            ps40.executeUpdate();
            System.out.println("saved");
            
          
            
            }
            
            catch (SQLException e)
            {
            System.out.println("Sql Exception" + e.toString());
            }
                    
                    
                   row2++;

                   //Converting Buttons to Labels excluding Row 0 (reserved for heading)
               
                for (int l=0; l < 9; l++)
                {
                    //labels [l][0].setBorderPainted(false);
                    labels[0][l].setContentAreaFilled(false);
                     labels1[0][l].setContentAreaFilled(false);
                    labels[1][l].setContentAreaFilled(false);
                   //   labels1[0][l].setBorderPainted(false);
                }
            
                //Converting Right side Liabilities Buttons to Labels
                //Label 4 is not converted, Reserved to draw midway vertical line
                
                for (int i = 1; i < row; i++) 
                {
                   // loop for column buttons 0-8
                    for (int j=0; j<4; j++) 
                   {
                       labels[i][j].setBorderPainted(false);
                       labels[i][j].setContentAreaFilled(false);
                       labels[i][j].setFocusPainted(false);
                       labels[i][j].setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
                   }
                }
                
                //Converting Left side Assets Buttons to Labels
                //Label 4 is not converted, Reserved to draw midway vertical line
                
//                for (int i = 1; i < row; i++) 
//                {
//                   // loop for column buttons 0-8
//                    for (int j=5; j<9; j++) 
//                   {
//                       labels[i][j].setBorderPainted(false);
//                       labels[i][j].setContentAreaFilled(false);
//                       labels[i][j].setFocusPainted(false);
//                       labels[i][j].setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
//                   }
//                }
           
                //Converting Label 4 (resvd. for Line) into Black Line
                
                for (int i = 1; i<row; i++)
                {
                    labels[i][4].setContentAreaFilled(false);
                    labels[i][4].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
                }
                    
                
           // Setting Focus to highlight the first row     
                
          labels[2][0].requestFocus();
           labels[2][0].setContentAreaFilled(true);
           labels[2][1].setContentAreaFilled(true);
           labels[2][2].setContentAreaFilled(true);
           labels[2][3].setContentAreaFilled(true);
           
           labels[2][0].setBackground(Color.CYAN);
           labels[2][1].setBackground(Color.CYAN);
           labels[2][2].setBackground(Color.CYAN);
           labels[2][3].setBackground(Color.CYAN);
              
        // Embedding Key Movement traversal
        // i loop for rows
        // j loop for columns
            
//        for (int i = 2; i < row; i++) 
//        {
//          for (int j = 0; j < 9; j++) {
//            final int rowfin = row;
//            final int curRow = i;
//            final int curCol = j;
//            labels[i][j].setBorderPainted(true);
//            //labels[i][j].addKeyListener(enter);
//            labels[i][j].addKeyListener(new KeyAdapter() {
//               @Override
//               public void keyPressed(KeyEvent e) {
//                  switch (e.getKeyCode()) {
//                  case KeyEvent.VK_UP:
//                     if (curRow > 2)
//                     {
//                        if (!" ".equals(labels[curRow - 1][curCol].getText()))
//                        {
//                        labels[curRow - 1][curCol].requestFocus();
//                        labels[curRow - 1][curCol].setContentAreaFilled(true);
//                        labels[curRow - 1][curCol+1].setContentAreaFilled(true);
//                        labels[curRow - 1][curCol+2].setContentAreaFilled(true);
//                        labels[curRow - 1][curCol+3].setContentAreaFilled(true);
//                        
//                        labels[curRow - 1][curCol].setBackground(Color.cyan);
//                        labels[curRow - 1][curCol+1].setBackground(Color.cyan);
//                        labels[curRow - 1][curCol+2].setBackground(Color.cyan);
//                        labels[curRow - 1][curCol+3].setBackground(Color.cyan);
//                        
//                                         
//                        labels[curRow][curCol].setContentAreaFilled(false);
//                        labels[curRow][curCol+1].setContentAreaFilled(false);
//                        labels[curRow][curCol+2].setContentAreaFilled(false);
//                        labels[curRow][curCol+3].setContentAreaFilled(false);
//                        }
//                     else 
//                        {
//                            int cr = curRow;
//                            do
//                            {
//                             cr--;   
//                            }
//                            while (" ".equals(labels[cr][curCol].getText()));
//                            
//                        labels[curRow][curCol].setContentAreaFilled(false);
//                        labels[curRow][curCol+1].setContentAreaFilled(false);
//                        labels[curRow][curCol+2].setContentAreaFilled(false);
//                        labels[curRow][curCol+3].setContentAreaFilled(false);
//                        
//                        labels[cr][curCol].requestFocus();
//                        
//                        labels[cr][curCol].setContentAreaFilled(true);
//                        labels[cr][curCol+1].setContentAreaFilled(true);
//                        labels[cr][curCol+2].setContentAreaFilled(true);
//                        labels[cr][curCol+3].setContentAreaFilled(true);
//                        
//                        labels[cr][curCol].setBackground(Color.cyan);
//                        labels[cr][curCol+1].setBackground(Color.cyan);
//                        labels[cr][curCol+2].setBackground(Color.cyan);
//                        labels[cr][curCol+3].setBackground(Color.cyan);
//                        }
//                     }
//                     break;
//                  case KeyEvent.VK_DOWN:
//                     if (curRow < rowfin - 1)
//                     {
//                        if (!" ".equals(labels[curRow + 1][curCol].getText()))
//                        {    
//                        labels[curRow + 1][curCol].requestFocus();
//                        labels[curRow + 1][curCol].setContentAreaFilled(true);
//                        labels[curRow + 1][curCol+1].setContentAreaFilled(true);
//                        labels[curRow + 1][curCol+2].setContentAreaFilled(true);
//                        labels[curRow + 1][curCol+3].setContentAreaFilled(true);
//                        
//                        labels[curRow + 1][curCol].setBackground(Color.cyan);
//                        labels[curRow + 1][curCol+1].setBackground(Color.cyan);
//                        labels[curRow + 1][curCol+2].setBackground(Color.cyan);
//                        labels[curRow + 1][curCol+3].setBackground(Color.cyan);
//                            
//                                if (curRow != 0)//to keep the heading intact with border
//                                {    
//                                labels[curRow][curCol].setContentAreaFilled(false);
//                                labels[curRow][curCol+1].setContentAreaFilled(false);
//                                labels[curRow][curCol+2].setContentAreaFilled(false);
//                                labels[curRow][curCol+3].setContentAreaFilled(false);
//                                }
//                        }
//                        else 
//                        {
//                            int cr = curRow;
//                            do
//                            {
//                             cr++;   
//                            }
//                            while ((labels[cr][curCol].getText()) == " ");
//                            
//                        labels[curRow][curCol].setContentAreaFilled(false);
//                        labels[curRow][curCol+1].setContentAreaFilled(false);
//                        labels[curRow][curCol+2].setContentAreaFilled(false);
//                        labels[curRow][curCol+3].setContentAreaFilled(false);
//                        
//                        labels[cr][curCol].requestFocus();
//                        labels[cr][curCol].setContentAreaFilled(true);
//                        labels[cr][curCol+1].setContentAreaFilled(true);
//                        labels[cr][curCol+2].setContentAreaFilled(true);
//                        labels[cr][curCol+3].setContentAreaFilled(true);
//                        
//                        labels[cr][curCol].setBackground(Color.cyan);
//                        labels[cr][curCol+1].setBackground(Color.cyan);
//                        labels[cr][curCol+2].setBackground(Color.cyan);
//                        labels[cr][curCol+3].setBackground(Color.cyan);
//                        }
//                     }
//                       break;
//                  case KeyEvent.VK_LEFT:
//                     if (curCol > 0)
//                     {
//                        if (!" ".equals(labels[curRow][curCol - 5].getText()))
//                        {
//                        labels[curRow][curCol - 5].requestFocus();
//                        labels[curRow][curCol - 5].setContentAreaFilled(true);
//                        labels[curRow][curCol - 4].setContentAreaFilled(true);
//                        labels[curRow][curCol - 3].setContentAreaFilled(true);
//                        labels[curRow][curCol - 2].setContentAreaFilled(true);
//                        
//                        labels[curRow][curCol - 5].setBackground(Color.cyan);
//                        labels[curRow][curCol - 4].setBackground(Color.cyan);
//                        labels[curRow][curCol - 3].setBackground(Color.cyan);
//                        labels[curRow][curCol - 2].setBackground(Color.cyan);
//                        
//                        labels[curRow][curCol].setContentAreaFilled(false);
//                        labels[curRow][curCol + 1].setContentAreaFilled(false);
//                        labels[curRow][curCol + 2].setContentAreaFilled(false);
//                        labels[curRow][curCol + 3].setContentAreaFilled(false);
//                        }
//                    }
//                     break;
//                  case KeyEvent.VK_RIGHT:
//                     if (curCol < 4 && curRow > 0)
//                     {
//                        if (!" ".equals(labels[curRow][curCol + 5].getText()))
//                        {
//                        labels[curRow][curCol + 5].requestFocus();
//                        labels[curRow][curCol + 5].setContentAreaFilled(true);
//                        labels[curRow][curCol + 6].setContentAreaFilled(true);
//                        labels[curRow][curCol + 7].setContentAreaFilled(true);
//                        labels[curRow][curCol + 8].setContentAreaFilled(true);
//                        
//                        labels[curRow][curCol + 5].setBackground(Color.cyan);
//                        labels[curRow][curCol + 6].setBackground(Color.cyan);
//                        labels[curRow][curCol + 7].setBackground(Color.cyan);
//                        labels[curRow][curCol + 8].setBackground(Color.cyan);
//                        
//                        labels[curRow][curCol].setContentAreaFilled(false);
//                        labels[curRow][curCol + 1].setContentAreaFilled(false);
//                        labels[curRow][curCol + 2].setContentAreaFilled(false);
//                        labels[curRow][curCol + 3].setContentAreaFilled(false);
//                        }
//                     }
//                     break;
//                      
//                        case KeyEvent.VK_ENTER:
//                     if (curCol < 9 && curRow > 0)
//                     {
//                        if (!" ".equals(labels[curRow][curCol].getText()))
//                        {
////                        labels[curRow][curCol + 5].requestFocus();
////                        labels[curRow][curCol + 5].setContentAreaFilled(true);
////                        labels[curRow][curCol + 6].setContentAreaFilled(true);
////                        labels[curRow][curCol + 7].setContentAreaFilled(true);
////                        labels[curRow][curCol + 8].setContentAreaFilled(true);
////                        
////                        labels[curRow][curCol + 5].setBackground(Color.cyan);
////                        labels[curRow][curCol + 6].setBackground(Color.cyan);
////                        labels[curRow][curCol + 7].setBackground(Color.cyan);
////                        labels[curRow][curCol + 8].setBackground(Color.cyan);
////                        
////                        labels[curRow][curCol].setContentAreaFilled(false);
////                        labels[curRow][curCol + 1].setContentAreaFilled(false);
////                        labels[curRow][curCol + 2].setContentAreaFilled(false);
////                        labels[curRow][curCol + 3].setContentAreaFilled(false);
//                            enter_value=labels[curRow][curCol].getText();
//                       // System.out.println(labels[curRow][curCol].getText());
//                        }
//                     }
//                     break;
//                      
//                      
//                      
//                  default:
//                      System.out.println();
//                     break;
//                  }
//               }
//            });
//         }
//      }
//    
//    
    
                
            
                   
    }
    
    
    public void print(){
    System.out.println("Ardhendu");
    HashMap param=new HashMap();
    param.put("balance_sheet_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\balance_sheet_hori.jasper", param);
    viewer1.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        jPanel1.setLayout(new java.awt.GridBagLayout());

        jPanel2.setLayout(new java.awt.GridBagLayout());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables

    @Override
    public void componentAdded(ContainerEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void componentRemoved(ContainerEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
