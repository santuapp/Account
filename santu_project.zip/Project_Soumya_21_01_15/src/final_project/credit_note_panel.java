/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import org.jdesktop.xswingx.PromptSupport;
//import static org.joda.time.format.ISODateTimeFormat.date;

/**
 *
 * @author pc144
 */
public class credit_note_panel extends javax.swing.JPanel {
Font myFont = new Font("",Font.PLAIN,9);
     
      int i=0,j=0,k=0;     // For Mandatory
      int a=0;        // For Non Mandatory
    /**
     * Creates new form credit_note_panel
     */
       public void set(){
        credit_note_inv.requestFocusInWindow();
        credit_note_inv.setFocusable(true);
    }
    
    public void user(String u_name){
        jLabel10.setText(u_name);
    }
      
    public credit_note_panel() {
        initComponents();
        initialise();
        initialise1();
        
        credit_note_inv.setFocusable(true);
        credit_note_inv.getCaret().setVisible(true);
        
        PromptSupport.setPrompt("dd/mm/yyyy", credit_note_date);
        
        jLabel7.setFont(myFont);
        jLabel7.setEnabled(false);
        jLabel7.setVisible(false);
        
       
        
        jLabel9.setFont(myFont);
        jLabel9.setEnabled(false);
        jLabel9.setVisible(false);
        
        jLabel4.setFont(myFont);
        jLabel4.setEnabled(false);
        jLabel4.setVisible(false);
        
        jLabel10.setVisible(false);
        
        jButton1.setCursor(new Cursor(Cursor.HAND_CURSOR)); 
      
        table.setRowHeight(30);
        
          try{
        
           Connection con = Database.getConnection();
             Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct l_name from ledger");
          while(rs.next())
          {
             // String name=rs.getString("l_name");
           //  reference_no.removeAllItems();
            ledger_name.addItem(rs.getString("l_name"));
            // reference_no.addItem(rs.getString("l_name"));
          }
            Statement ps1 =con.createStatement();
           ResultSet rs1=ps1.executeQuery("select distinct sale_inv_no from sale_table1");
          while(rs1.next())
          {
             // String name=rs.getString("l_name");
           //  reference_no.removeAllItems();
           // ledger_name.addItem(rs.getString("l_name"));
             reference_no.addItem(rs1.getString("sale_inv_no"));
          }
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
    }

    
     public void invoice(){
            if(credit_note_inv.getText().length()==0)
      {
          credit_note_inv.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel7.setEnabled(true);
          jLabel7.setForeground(Color.red);
          jLabel7.setVisible(true);
             
      }  
      else
      {
           credit_note_inv.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel7.setEnabled(false);  
           jLabel7.setVisible(false);
           i=1;
          
      }
        
    }
     
      // date
     
     public void date(){
             if(credit_note_date.getText().length()==0)
       {
             credit_note_date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel9.setEnabled(true);
             jLabel9.setForeground(Color.red);
             jLabel9.setVisible(true);
           
       }
       else
       {
           
       
                 String content = credit_note_date.getText();
                 Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
                 Matcher m = p.matcher(content);
                 boolean matchFound = m.matches();
             //    System.out.println(matchFound);
                 credit_note_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                 jLabel9.setEnabled(false);  
                 jLabel9.setVisible(false);
                 j=1;
          
          if(!matchFound)
          { 
             credit_note_date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel9.setEnabled(true);
             jLabel9.setForeground(Color.red);
             jLabel9.setVisible(true);
          }
       }
     } 
     
     // under
     
       public void under(){
           if(reference_no.getSelectedItem().equals(""))
      {
          reference_no.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel4.setEnabled(true);
          jLabel4.setForeground(Color.red);
          jLabel4.setVisible(true);
             
      }  
      else
      {
           reference_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel4.setEnabled(false);  
           jLabel4.setVisible(false);
           k=1;
      }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
     public void initialise()
            
    {
   
       table.getModel().addTableModelListener(new TableModelListener()
        
                {
                  public void tableChanged (TableModelEvent e)
                {
		  double gtot=0.0d;
                   double gtot1=0.0d;
            int n1=table.getRowCount();
            System.out.println(n1);
            for (int i =0; i<=n1-1; i++)
            {
                if ((table.getValueAt(i, 2)) !=null)
            {
                    String s1 = (String)table.getValueAt(i, 2);
                    double d1=Double.parseDouble(s1);
                    System.out.println(s1);
                   
                   
                    gtot=gtot+d1;
                    System.out.println(gtot);
                  
            }
                String s4=Double.toString(gtot);
                    debit_total.setText(s4);
            }
             for (int i =0; i<=n1-1; i++)
            {
                if ((table.getValueAt(i, 3)) !=null)
            {
                    String s0 = (String)table.getValueAt(i, 3);
                    double d1=Double.parseDouble(s0);
                    System.out.println(s0);
                   
                   
                    gtot1=gtot1+d1;
                    System.out.println(gtot1);
                  
            }
                String s40=Double.toString(gtot1);
                    credit_total.setText(s40);
            }
            
                }
                }
          );

    }
      
    public void initialise1()
    {
  
     table.getModel().addTableModelListener(new TableModelListener(){
 public void tableChanged  (TableModelEvent e) {
                String b[] = { "Titan", "HMT" };
                String c[] = {"Nokia","Sony","Motorola","Samsung"};
                String d[] = {""};
                        int n=table.getRowCount();
 for (int j =0; j<=n-1; j++)
                    {
                       
                if (((table.getValueAt(j, 0)) !=null) && (table.getValueAt(j, 1)) ==null){
                        if (combox1.getSelectedItem().equals("Select")) {
                            //JComboBox combox2 = new JComboBox();
                            //JComboBox combox = new JComboBox();
                             JComboBox combox3 = new JComboBox(d);
                              table.getColumn("Particulars").setCellEditor(new DefaultCellEditor(combox3));
                               
                               //combox3.setEnabled(true);
                           
                               //combox.setEnabled(false);
                                //combox2.setEnabled(false);
                                //combox2.removeAllItems();
                                //combox.removeAllItems();
                        }
                    if (combox1.getSelectedItem().equals("By")) {
                        
                            //JComboBox combox = new JComboBox(b);
                          // table.setValueAt("s1", j, 2);
                           //  combox2.removeAllItems();
                                //combox2.setEnabled(true);
                            //combox2.removeAllItems();
                               
                               
                            // table.getColumn("Debit").setCellEditor(new DefaultCellEditor(combox));

                         // combox.removeAllItems();
                                //combox.setEnabled(true); 
                                  table.getColumn("Particulars").setCellEditor(new DefaultCellEditor(ledger_name));
                                
                                  
                        } 
                    else if (combox1.getSelectedItem().equals("To")) {
                            
                                
                               // JComboBox combox = new JComboBox(c);
                          // combox.removeAllItems();
                              //  table.setValueAt("0.00", j, 2);
                               //combox.setEnabled(true);
                      table.getColumn("Particulars").setCellEditor(new DefaultCellEditor(ledger_name));

                        }
                }   }  }
        
 });

               }
    
   public void table_validation()
   { 
          
     table.getModel().addTableModelListener(new TableModelListener(){
    public void tableChanged  (TableModelEvent e)
    {
         DefaultTableModel y = (DefaultTableModel)table.getModel();
         int sd=y.getRowCount();
         for (int i =0; i<=(sd - 1); i++)
            {
                for(int j=0;j<=3;j++){
      if (((table.getValueAt(i, j)) ==null))
             {
                  JOptionPane.showMessageDialog(null, "Enter Number!");
             }
                }
    }
    }
        });
//   table.addKeyListener(new java.awt.event.KeyAdapter()
//
//            {
//    
//   
//    
//    
//        });
       
       
       
       
       
       
       
        }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jopt1 = new javax.swing.JOptionPane();
        jopt2 = new javax.swing.JOptionPane();
        ledger_name = new javax.swing.JComboBox();
        jOptionPane1 = new javax.swing.JOptionPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        reference_no = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        credit_note_date = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        credit_note_inv = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        credit_note_narration = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        debit_total = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        credit_total = new javax.swing.JTextField();
        reset = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();

        ledger_name.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Credit Note Creation");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Informtion", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        reference_no.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        reference_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        reference_no.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                reference_noFocusLost(evt);
            }
        });

        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Sale Invoice No.:");

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Date:");

        credit_note_date.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        credit_note_date.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                credit_note_dateFocusLost(evt);
            }
        });

        jLabel9.setText("Enter Valid Date!");

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Invoice No.:");

        credit_note_inv.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        credit_note_inv.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                credit_note_invFocusLost(evt);
            }
        });

        jLabel7.setText("Invoice No Can't Be Empty!");

        jLabel4.setText("Select One!");

        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Narration:");

        credit_note_narration.setColumns(20);
        credit_note_narration.setRows(5);
        jScrollPane2.setViewportView(credit_note_narration);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(credit_note_inv, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(338, 338, 338)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(credit_note_date, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(reference_no, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel1, jLabel6});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(credit_note_inv, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(credit_note_date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reference_no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "To/By", "Particulars", "Debit", "Credit"
            }
        ));
        jScrollPane1.setViewportView(table);
        table.getColumn("To/By").setCellEditor(new DefaultCellEditor(combox1));

        debit_total.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/folder-access-icon.png"))); // NOI18N
        jButton1.setText("Submit");
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Total:");

        credit_total.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        reset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        reset.setText("Reset");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rows", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Action-remove-icon.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/add-2-icon.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(314, 314, 314)
                        .addComponent(reset)
                        .addGap(47, 47, 47)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(debit_total, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(credit_total, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1))
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(debit_total, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(credit_total, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(reset))
                .addContainerGap())
        );

        jLabel10.setText("jLabel10");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(10, 10, 10))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        DefaultTableModel y = (DefaultTableModel)table.getModel();

        int a=y.getRowCount()- 1;

        y.removeRow(a);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    invoice();
    
     date();
     under();
      if(i==1&&j==1&&k==1)
      {
             
        DefaultTableModel y = (DefaultTableModel)table.getModel();
  int row =y.getRowCount();
  if(row==0)
  {
   jopt1.showMessageDialog(this,"Fill Credit Note Information");
   
  }
  
  else{
       table_validation(); 
  }
  
  try{

            
            Connection con = Database.getConnection();
            Statement ps5 =con.createStatement();
            ResultSet rs5=ps5.executeQuery("SELECT credit_note_inv from credit_note where credit_note_inv='"+credit_note_inv.getText()+"'");

 if(rs5.next())
            {
                jopt1.showMessageDialog(this,"Credit Note Already Exsist");
            }
            else
            {
            int p=table.getRowCount();
            for(int i=0;i<p;i++)
            {
                String select=table.getValueAt(i,0).toString();
                String perticulars=table.getValueAt(i,1).toString();
                String debit=table.getValueAt(i,2).toString();
                String credit=table.getValueAt(i,3).toString();

           
                
                log_table.table_create("credit_note", credit_note_inv.getText());
                log_table.table_insert("credit_note",  credit_note_inv.getText());
               PreparedStatement ps1=con.prepareStatement("insert into credit_note (credit_note_inv,credit_note_date,sale_inv,credit_note_select,credit_note_perticulars,debit,credit)values('"+credit_note_inv.getText()+"','"+credit_note_date.getText()+"','"+reference_no.getSelectedItem().toString()+"','"+select+"','"+perticulars+"','"+debit+"','"+credit+"')");

               ps1.executeBatch();
               ps1.executeUpdate();
              PreparedStatement ps2=con.prepareStatement("insert into company_main_table (ledger,debit,credit,get_id,trans_date,type)values('"+perticulars+"','"+debit+"','"+credit+"','"+credit_note_inv.getText()+"','"+credit_note_date.getText()+"','CREDIT NOTE')");
              ps2.executeBatch();
              ps2.executeUpdate();
                Statement pss =con.createStatement();
                ResultSet rss=pss.executeQuery("select  l_under from ledger where l_name='"+perticulars+"'");
             while(rss.next())
                  {
                      String under=rss.getString("l_under");
                 PreparedStatement psw=con.prepareStatement("insert into `"+under+"` (l_name,debit,credit,trans_id,date)values('"+perticulars+"','"+debit+"','"+credit+"','"+credit_note_inv.getText()+"','"+credit_note_date.getText()+"')");
                psw.executeUpdate();

                  }
         
                
              
               
            }
            System.out.println("saved");

            jopt1.showMessageDialog(this,"Credit Note Created");

        }
 con.close();
        }catch (SQLException e){
            System.out.println("Sql Exception" + e.toString());
        }
       

        
            credit_note_inv.setText(null);
            credit_note_date.setText(null);
            reference_no.setSelectedItem(null);
            
            jLabel7.setVisible(false);
            jLabel9.setVisible(false);
            jLabel4.setVisible(false);
            
            credit_note_inv.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            credit_note_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            reference_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            
            
            
           int p1=table.getRowCount();
          for(int i=0;i<p1;i++)
            {
                String select1=null;
                String perticulars1=null;
                String debit1=null;
                String credit1=null;
        table.setValueAt(select1, i, 0);
        table.setValueAt(perticulars1, i, 1);
        table.setValueAt(debit1, i, 2);
        table.setValueAt(credit1, i, 3);
            }
        debit_total.setText(null);
        credit_total.setText(null);
      }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void credit_note_dateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_credit_note_dateFocusLost
        if(credit_note_date.getText().length()==0)
        {
            credit_note_date.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel9.setEnabled(true);
            jLabel9.setForeground(Color.red);
            jLabel9.setVisible(true);

        }
        else
        {

            String content = credit_note_date.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            //    System.out.println(matchFound);
            credit_note_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel9.setEnabled(false);
            jLabel9.setVisible(false);
            j=1;

            if(!matchFound)
            {
                credit_note_date.setBorder(BorderFactory.createLineBorder(Color.red));
                jLabel9.setEnabled(true);
                jLabel9.setForeground(Color.red);
                jLabel9.setVisible(true);
            }
        }
    }//GEN-LAST:event_credit_note_dateFocusLost

    private void credit_note_invFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_credit_note_invFocusLost
        if(credit_note_inv.getText().length()==0)
        {
            credit_note_inv.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel7.setEnabled(true);
            jLabel7.setForeground(Color.red);
            jLabel7.setVisible(true);

        }
        else
        {
            credit_note_inv.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel7.setEnabled(false);
            jLabel7.setVisible(false);
            i=1;

        }
    }//GEN-LAST:event_credit_note_invFocusLost

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        DefaultTableModel y = (DefaultTableModel)table.getModel();

        Vector <String> r = new Vector <String>();
        y.addRow(r);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void reference_noFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_reference_noFocusLost
           if(reference_no.getSelectedItem().equals(""))
      {
          reference_no.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel4.setEnabled(true);
          jLabel4.setForeground(Color.red);
          jLabel4.setVisible(true);
             
      }  
      else
      {
           reference_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel4.setEnabled(false);  
           jLabel4.setVisible(false);
           k=1;
      }
    }//GEN-LAST:event_reference_noFocusLost

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        // TODO add your handling code here:
            credit_note_inv.setText("");
            credit_note_date.setText("");
            reference_no.setSelectedItem("");
            
            jLabel7.setVisible(false);
            jLabel9.setVisible(false);
            jLabel4.setVisible(false);
            
            credit_note_inv.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            credit_note_date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            reference_no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            
            
            
           int p1=table.getRowCount();
          for(int i=0;i<p1;i++)
            {
                String select1=null;
                String perticulars1=null;
                String debit1=null;
                String credit1=null;
        table.setValueAt(select1, i, 0);
        table.setValueAt(perticulars1, i, 1);
        table.setValueAt(debit1, i, 2);
        table.setValueAt(credit1, i, 3);
            }
        debit_total.setText(null);
        credit_total.setText(null);
        
        
            
    }//GEN-LAST:event_resetActionPerformed

JComboBox combox1 = new JComboBox(new String [] {"Select","By","To"});
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField credit_note_date;
    private javax.swing.JTextField credit_note_inv;
    private javax.swing.JTextArea credit_note_narration;
    private javax.swing.JTextField credit_total;
    private javax.swing.JTextField debit_total;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JOptionPane jopt1;
    private javax.swing.JOptionPane jopt2;
    private javax.swing.JComboBox ledger_name;
    private javax.swing.JComboBox reference_no;
    private javax.swing.JButton reset;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
