package final_project;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author virtual vista
 */
public class Bank_Status_1 extends javax.swing.JFrame implements ContainerListener{
private final GridBagConstraints gridBagConstraints;
    /**
     * Creates new form Bank_Status_1
     */
static String aa;
double opening_balance=0.0d,t_debit=0.0d,t_credit=0.0d,total_balance=0.0d,total_closing=0.0d,closing_balance=0.0d,db=0.0d,cr=0.0d;
        String opening="",total_debit="",total_credit="",total_debit_value="",total_credit_value="",closing="",date="",balance="",totaldebit="",totalcredit="";
    public Bank_Status_1(String hh) 
    {
        hh=aa;
        initComponents();
        gridBagConstraints = new java.awt.GridBagConstraints();
         gridBagConstraints.insets=new Insets(0,0,0,0);
            
            addContainerListener(this);
            
            int bak=0,r=4;
            int count = 10000;
            final JButton[][] labels=new JButton[count][13];
            
            JLabel[] datelabel=new JLabel[count];
            JLabel[] dategaplabel=new JLabel[count];
            JLabel[] partilrlabel=new JLabel[count];
            JLabel[] partilrgaplabel=new JLabel[count];
            JLabel[] voucherlabel=new JLabel[count];
            JLabel[] vouchergaplabel=new JLabel[count];
            JLabel[] chequelabel=new JLabel[count];
            JLabel[] chequegaplabel=new JLabel[count];
            JLabel[] depositlabel=new JLabel[count];
            JLabel[] depositgaplabel=new JLabel[count];
            JLabel[] withdwlabel=new JLabel[count];
            JLabel[] withdwgaplabel=new JLabel[count];
            JLabel[] closinglabel=new JLabel[count];
            
            
            
            // Panel 1 start.....y=2
            
            JLabel tohead=new JLabel("Date");
            tohead.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            tohead.setHorizontalAlignment(SwingConstants.CENTER);
            gridBagConstraints.weightx=0.083;
            jPanel1.add(tohead,gridBagConstraints);
            
            JLabel blankhead4=new JLabel(" ");
            blankhead4.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead4,gridBagConstraints);
            
            JLabel refhead=new JLabel("Particular");
            refhead.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.5;
            jPanel1.add(refhead,gridBagConstraints);
            
            JLabel blankhead5=new JLabel(" ");
            blankhead5.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead5,gridBagConstraints);
            
            JLabel refhead1=new JLabel("Voucher Type");
            refhead1.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead1.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead1,gridBagConstraints);
            
            JLabel blankhead6=new JLabel(" ");
            blankhead6.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead6,gridBagConstraints);
            
            JLabel refhead2=new JLabel("Cheque No");
            refhead2.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=24;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead2.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead2,gridBagConstraints);
            
            JLabel blankhead7=new JLabel(" ");
            blankhead7.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead7,gridBagConstraints);
            
            JLabel refhead3=new JLabel("Deposit");
            refhead3.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead3.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead3,gridBagConstraints);
            
            JLabel blankhead8=new JLabel(" ");
            blankhead8.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=38;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead8,gridBagConstraints);
            
            JLabel refhead4=new JLabel("Withdrawal");
            refhead4.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=40;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead4.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead4,gridBagConstraints);
            
            JLabel blankhead9=new JLabel(" ");
            blankhead9.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=46;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(blankhead9,gridBagConstraints);
            
            JLabel refhead5=new JLabel("Closing Balance");
            refhead5.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=48;
            gridBagConstraints.gridy=2;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            refhead5.setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(refhead5,gridBagConstraints);
            
            //y=3...........
            
            int row=3;
            
            labels[row][0]=new JButton(" ");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][0].setHorizontalAlignment(SwingConstants.CENTER);
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][0],gridBagConstraints);
            
            labels[row][1]=new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][1],gridBagConstraints);
            
            labels[row][2]=new JButton("Opening");
            
            labels[row][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][2].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.5;
            jPanel1.add(labels[row][2],gridBagConstraints);
            
            labels[row][3]=new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][3],gridBagConstraints);
            
            labels[row][4]=new JButton("Voucher Type");
            
            labels[row][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][4].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][4],gridBagConstraints);
            
            
            labels[row][5]=new JButton(" ");
            
            labels[row][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][5],gridBagConstraints);
            
            labels[row][6]=new JButton("Cheque No");
            
            labels[row][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=24;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][6].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][6],gridBagConstraints);
            
            
            
            
            labels[row][7]=new JButton(" ");
            
            labels[row][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][7],gridBagConstraints);
            
            
            labels[row][8]=new JButton("Deposit");
            
            
            labels[row][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][8].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][8],gridBagConstraints);
            
            
            
            labels[row][9]=new JButton(" ");
            
            labels[row][9].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=38;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][9],gridBagConstraints);
            
            
            labels[row][10]=new JButton("Withdrawal");
            
            
            labels[row][10].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=40;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][10].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][10],gridBagConstraints);
            
            
            
            labels[row][11]=new JButton(" ");
            
            labels[row][11].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=46;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][11],gridBagConstraints);
            
            
            labels[row][12]=new JButton("Closing Balance");
            
            
            labels[row][12].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=48;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][12].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][12],gridBagConstraints);
            
            row++;
            
            // y=4 start....
            
            //Content Array (date,gap,particular,gap,voucher,gap,cheque,gap,deposit,gap,withdw,gap,closing) displaying
            
        //     while(rs1.next())
              try{
        
           Class.forName("com.mysql.jdbc.Driver");
           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
        Statement ps =con.createStatement();
          Statement ps2 =con.createStatement();
             ResultSet rs4=ps.executeQuery("select bank_date from bank_status where bank_name='"+aa+"'");
               while(rs4.next()){
                   date=rs4.getString("bank_date");
             if(date!=null){
          ResultSet rs3=ps2.executeQuery("select  ledger,sum(debit) as debit,cheque_no from bank_status  where  bank_name='"+aa+"' and bank_date='"+date+"' group by bank_name,bank_date");
           while(rs3.next()){
               totaldebit=rs3.getString("debit");
                  if( totaldebit!=null){
            labels[row][0]=new JButton(" ");
            
            labels[row][0].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black));
            gridBagConstraints.gridx=0;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][0].setHorizontalAlignment(SwingConstants.CENTER);
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][0],gridBagConstraints);
            
            labels[row][1]=new JButton(" ");
            
            labels[row][1].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=6;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][1],gridBagConstraints);
            
            labels[row][2]=new JButton("Opening");
            
            labels[row][2].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=8;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][2].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.5;
            jPanel1.add(labels[row][2],gridBagConstraints);
            
            labels[row][3]=new JButton(" ");
            
            labels[row][3].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=14;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][3],gridBagConstraints);
            
            labels[row][4]=new JButton("Voucher Type");
            
            labels[row][4].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=16;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][4].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][4],gridBagConstraints);
            
            
            labels[row][5]=new JButton(" ");
            
            labels[row][5].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=22;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][5],gridBagConstraints);
            
            labels[row][6]=new JButton("Cheque No");
            
            labels[row][6].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=24;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][6].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][6],gridBagConstraints);
            
            
            
            
            labels[row][7]=new JButton(" ");
            
            labels[row][7].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=30;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][7],gridBagConstraints);
            
            
            labels[row][8]=new JButton("Deposit");
            
            
            labels[row][8].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=32;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][8].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][8],gridBagConstraints);
            
            
            
            labels[row][9]=new JButton(" ");
            
            labels[row][9].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=38;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][9],gridBagConstraints);
            
            
            labels[row][10]=new JButton("Withdrawal");
            
            
            labels[row][10].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=40;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][10].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][10],gridBagConstraints);
            
            
            
            labels[row][11]=new JButton(" ");
            
            labels[row][11].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.green));
            gridBagConstraints.weightx=0;
            gridBagConstraints.gridx=46;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=1;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            jPanel1.add(labels[row][11],gridBagConstraints);
            
            
            labels[row][12]=new JButton("Closing Balance");
            
            
            labels[row][12].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
            gridBagConstraints.gridx=48;
            gridBagConstraints.gridy=row;
            gridBagConstraints.gridwidth=5;
            gridBagConstraints.fill=gridBagConstraints.HORIZONTAL;
            labels[row][12].setHorizontalAlignment(SwingConstants.CENTER);
            //gridBagConstraints.anchor=gridBagConstraints.EAST;
            gridBagConstraints.weightx=0.083;
            jPanel1.add(labels[row][12],gridBagConstraints);
            
            row++;
             
               }  
           }
             }
               }
            
          System.out.println(r);
 }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        catch(ClassNotFoundException ce)
        {
            System.out.println("ClassNotFoundException" + ce.toString());
        }
            
            
           
            
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

        jPanel1.setLayout(new java.awt.GridBagLayout());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 728, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(249, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bank_Status_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Bank_Status_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Bank_Status_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Bank_Status_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

    @Override
    public void componentAdded(ContainerEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void componentRemoved(ContainerEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
