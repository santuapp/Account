/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package final_project;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author pc2
 */
public class group_summary_panel_2 extends javax.swing.JPanel {

    /**
     * Creates new form group_summary_panel_2
     */
      public String s1="";
     public  int row,col;
     String head_grp;
 String head_trans;
 String var_global="";
    public group_summary_panel_2() {
        initComponents();
        table_3.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table_3.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }

            
        });
       
        
    }
public void print()
    
    {
        
           
       //  jLabel1.setEnabled(true);
    Integer row = table_3.getRowCount();
    
    //Inserting data into table for printing
    try{

                

                Connection con = Database.getConnection();
                

                //Deleting All Sale details from Sale Table 2
                PreparedStatement ps9=con.prepareStatement("DELETE FROM group_sum_fp_temp");
                ps9.executeUpdate();

                //Inserting data into table for printing
                for(int i=0;i<row;i++)
                {
                    String fp_part=table_3.getValueAt(i,0).toString();
                    String fp_dr=table_3.getValueAt(i,1).toString();
                    String fp_cr=table_3.getValueAt(i,2).toString();
                    
                    PreparedStatement ps10=con.prepareStatement("insert into group_sum_fp_temp (fp_particulars, fp_debit, fp_credit)values('"+fp_part+"','"+fp_dr+"','"+fp_cr+"')");

                    ps10.executeBatch();
                    ps10.executeUpdate();
                   
                }
                
               con.close();
            }catch (SQLException q){
                System.out.println("Sql Exception" + q.toString());
            }
           
          System.out.println(head_trans);
    HashMap param=new HashMap();
    param.put("group_main_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\group_summary_printable.jasper", param);
    viewer1.setVisible(true);   
    }
    
public void  add_panel_2(String click){
     h_label.setText(click);
        head_trans = click;
          var_global= click.trim();

  TableColumnModel cmodel = table_3.getColumnModel(); 
        TextAreaRenderer textAreaRenderer = new TextAreaRenderer(); 
        cmodel.getColumn(0).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(1).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(2).setCellRenderer(textAreaRenderer);
        addRows(table_3);
        
 
      
    }

 private void addRows(JTable table)
    
    { 
           DefaultTableModel y1 = (DefaultTableModel)table .getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            
            
        }
         int li_row=0;
           int rw = 0,rw1=0;
       try{
        
            Connection con = Database.getConnection();
            Statement ps1 =con.createStatement();
            ResultSet rs1=ps1.executeQuery("SELECT g_name from acc_group where g_under='"+h_label.getText()+"'");
             Vector <String> r[] = (Vector <String> []) new Vector[1000];
           while(rs1.next())
                 {
                      y1.addRow(r[rw]); 
                         table_3.setValueAt(rs1.getString("g_name"), li_row, 0);
                        
            Statement ps =con.createStatement();
            
            ResultSet rs=ps.executeQuery("SELECT SUM(debit) AS DEBIT,SUM(credit) AS CREDIT  FROM `"+rs1.getString("g_name")+"` ");
        
           while(rs.next())
                 {
                    
               
                 table_3.setValueAt(rs.getString("DEBIT"), li_row, 1);
                 table_3.setValueAt(rs.getString("CREDIT"), li_row, 2);
                
                  
       
                 
               
                 }
           
                 rw++;
                 li_row++;
   
            System.out.println("Done");
                 }
         
           con.close();
            }catch (SQLException e)
                {
                System.out.println("Sql Exceptions" + e.toString());
                }
       
 }
 
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        h_label = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_3 = new javax.swing.JTable();

        h_label.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        h_label.setForeground(new java.awt.Color(0, 0, 255));
        h_label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        h_label.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        table_3.setForeground(new java.awt.Color(0, 0, 250));
        table_3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PARTICULERS", "DEBIT", "CREDIT"
            }
        ));
        jScrollPane1.setViewportView(table_3);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
            .addComponent(h_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(h_label, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel h_label;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable table_3;
    // End of variables declaration//GEN-END:variables
}
