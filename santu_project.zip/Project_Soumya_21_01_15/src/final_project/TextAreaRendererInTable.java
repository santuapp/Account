/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

/**
 *
 * @author pc 5
 */
import java.awt.Color;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*; 
import javax.swing.border.LineBorder;
import javax.swing.table.*; 
 
public class TextAreaRendererInTable extends JFrame { 
  JTable table = new JTable(500, 1); 

    public void showTable() { 
        
 
        TableColumnModel cmodel = table.getColumnModel(); 
        TextAreaRenderer textAreaRenderer = new TextAreaRenderer(); 
 
         TableCellEditor fce = new FiveCharacterEditor();  
            table.setDefaultEditor(Object.class, fce); 
            cmodel.getColumn(0).setCellRenderer(textAreaRenderer); 
//        cmodel.getColumn(0).setCellRenderer(new DefaultTableCellRenderer()); 
//        cmodel.getColumn(1).setCellRenderer(textAreaRenderer); 
//        cmodel.getColumn(2).setCellRenderer(textAreaRenderer); 
 
        addRows(table); 
        
         
        
        getContentPane().add(new JScrollPane(table)); 
        setSize(500, 40); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        setLocationRelativeTo(null); 
        setTitle("Renderer In Table"); 
        setVisible(true); 
 
    }
            class FiveCharacterEditor extends DefaultCellEditor  
        {  
            FiveCharacterEditor()  
            {  
                super( new JTextField() );  
            }  
      
            public boolean stopCellEditing()  
            {  
                JTable table = (JTable)getComponent().getParent();  
      
                try  
                {  
                    String editingValue = (String)getCellEditorValue();  
      
                    if(editingValue.length() != 50)  
                    {  
                        JTextField textField = (JTextField)getComponent();  
                        textField.setBorder(new LineBorder(Color.red));  
                        textField.selectAll();  
                        textField.requestFocusInWindow();  
                        
                        JOptionPane.showMessageDialog( null,"Please enter string with 5 letters.","Alert!",JOptionPane.ERROR_MESSAGE);  
                        return false;  
                    }  
                }  
                catch(ClassCastException exception)  
                {  
                    return false;  
                }  
      
                return super.stopCellEditing();  
            }  
      
            public Component getTableCellEditorComponent(  
                JTable table, Object value, boolean isSelected, int row, int column)  
            {  
                Component c = super.getTableCellEditorComponent(  
                    table, value, isSelected, row, column);  
                ((JComponent)c).setBorder(new LineBorder(Color.black));  
      
                return c;  
            }  
      
        }  
    
  

    private void addRows(JTable table) { 
        try{
            int i=0;
           Class.forName("com.mysql.jdbc.Driver");
           String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
           Connection con = (Connection) DriverManager.getConnection(ConnUrl);
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct l_name from ledger");
          while(rs.next())
          {
              table.setValueAt(rs.getString("l_name"), i, 0);
              i++;
          }
        }
          catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        catch(ClassNotFoundException ce)
        {
            System.out.println("ClassNotFoundException" + ce.toString());
        } 
          
//        String props = "Ardhendu Chatterjee"; 
//        for (int i = 0; i < 5; i++) { 
//            table.setValueAt(props + "-" + props, i, 0); 
//            table.setValueAt(props, i, 1); 
//            table.setValueAt(props + "*" + props + "*" + props, i, 2); 
        } 
     
 
    public static void main(String[] args) { 
        TextAreaRendererInTable te = new TextAreaRendererInTable();
        te.showTable();
//        new TextAreaRendererInTable().showTable(); 
    } 
} 
