/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import org.jdesktop.xswingx.PromptSupport;

/**
 *
 * @author pc41
 */
public class user_create_panel extends javax.swing.JPanel {
    
     Font myFont = new Font("",Font.PLAIN,9);
     int i=0,j=0,k=0,m=0,n=0,p=0;     // For Mandatory

    /**
     * Creates new form user_create_panel
     */
    public user_create_panel() {
        initComponents();
        
        // For Validaton Label Remove

        jLabel8.setFont(myFont);
        jLabel8.setEnabled(false);
        jLabel8.setVisible(false);
        
        jLabel9.setFont(myFont);
         jLabel9.setEnabled(false);
        jLabel9.setVisible(false);
        
        jLabel10.setFont(myFont);
         jLabel10.setEnabled(false);
        jLabel10.setVisible(false);
        
        jLabel11.setFont(myFont);
         jLabel11.setEnabled(false);
        jLabel11.setVisible(false);
        
        jLabel12.setFont(myFont);
         jLabel12.setEnabled(false);
        jLabel12.setVisible(false);
        
        jLabel13.setFont(myFont);
         jLabel13.setEnabled(false);
        jLabel13.setVisible(false);
        
        
        PromptSupport.setPrompt("dd/mm/yyyy", user_dob);
        PromptSupport.setPrompt("abc@XY1", user_pass);
        
    }
    
    
     // user id
    
      public void id(){
            if(user_id.getText().length()==0)
      {
          user_id.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel8.setEnabled(true);
          jLabel8.setForeground(Color.red);
          jLabel8.setVisible(true);
             
      }  
      else
      {
           user_id.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel8.setEnabled(false);  
           jLabel8.setVisible(false);
           i=1;
          
      }
    }
    
    
     // password
     
     public void pass(){
       
          if(user_pass.getPassword().length==0)
         {
          user_pass.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel9.setEnabled(true);
          jLabel9.setForeground(Color.red);
          jLabel9.setVisible(true);
             
         }
         else
         {
       char[] pass=  user_pass.getPassword();
       String s1= new String(pass);
       System.out.println(s1);
       String s2 = "((?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%!]).{6,40})|(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{6,40}";
       Pattern p1 = Pattern.compile(s2);
       Matcher m1 = p1.matcher(s1);
       user_pass.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
       jLabel9.setEnabled(false);  
       jLabel9.setVisible(false);
       j=1;
  
             if(m1.find()==false) 
           {
            user_pass.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel9.setEnabled(true);
            jLabel9.setForeground(Color.red);
            jLabel9.setVisible(true);
            
            } 
         }
     }
     
     // Confirm Pass
     
     public void retype_pass(){
           char[] pass=  user_pass.getPassword();
           String s1= new String(pass);    
           char[] pas=user_conf_pass.getPassword();
           String s2= new String(pas);
           user_conf_pass.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel10.setEnabled(false);  
           jLabel10.setVisible(false);
            k=1;
           
                               
           if(s1.compareTo(s2) != 0)
           { 
                            
            user_conf_pass.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel10.setEnabled(true);
            jLabel10.setForeground(Color.red);
            jLabel10.setVisible(true);
            
    //        user_conf_pass.requestFocus();
     //       user_conf_pass.setText("");
           }
     }
     
   
    
    
    
    
    // name
    
    public void name(){
        
             if(user_name.getText().length()==0)
      {
          user_name.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel11.setEnabled(true);
          jLabel11.setForeground(Color.red);
          jLabel11.setVisible(true);
             
      }  
      else
      {
           user_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel11.setEnabled(false);  
           jLabel11.setVisible(false);
           m=1;
          
      }
        
    }
    
    
    // Date of Birth
    
    
    public void dob(){
               if(user_dob.getText().length()==0)
        {
              user_dob.setBorder(BorderFactory.createLineBorder(Color.red));
              jLabel12.setEnabled(true);
              jLabel12.setForeground(Color.red);
              jLabel12.setVisible(true);
        }
        else
        {
            String content = user_dob.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            user_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel12.setEnabled(false);  
            jLabel12.setVisible(false);
            n=1;
            if(!matchFound)

            {
              

                 user_dob.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel12.setEnabled(true);
                 jLabel12.setForeground(Color.red);
                 jLabel12.setVisible(true);

            }
        }
    }
    
    
    // user Type
    
    
       public void type(){
           if(user_type.getSelectedItem().equals(""))
      {
          user_type.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
             
      }  
      else
      {
           user_type.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           p=1;
      }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        user_id = new javax.swing.JTextField();
        user_name = new javax.swing.JTextField();
        user_dob = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        user_type = new javax.swing.JComboBox();
        user_pass = new javax.swing.JPasswordField();
        user_conf_pass = new javax.swing.JPasswordField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        reset = new javax.swing.JButton();
        save = new javax.swing.JButton();

        setLayout(new java.awt.GridBagLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("User Create Panel");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "User Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(0, 0, 255))); // NOI18N

        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("User ID:");

        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Password:");

        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Confirm Password:");

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("User Name:");

        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Date of Birth:");

        user_id.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        user_id.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                user_idFocusLost(evt);
            }
        });

        user_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        user_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                user_nameFocusLost(evt);
            }
        });
        user_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_nameActionPerformed(evt);
            }
        });

        user_dob.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        user_dob.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                user_dobFocusLost(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("User Type:");

        user_type.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "user", "admin" }));
        user_type.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        user_type.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                user_typeFocusLost(evt);
            }
        });

        user_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        user_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                user_passFocusLost(evt);
            }
        });

        user_conf_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        user_conf_pass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                user_conf_passFocusLost(evt);
            }
        });

        jLabel8.setText("Enter User Id!");

        jLabel9.setText("Enter Valid Password!");

        jLabel10.setText("Enter Valid Confirm Password!");

        jLabel11.setText("Enter Name!");

        jLabel12.setText("Enter Valid Date of Birth!");

        jLabel13.setText("Enter User Type!");

        reset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Button-Refresh-icon.png"))); // NOI18N
        reset.setText("RESET");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Save-icon.png"))); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel12)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(user_id)
                        .addComponent(user_name)
                        .addComponent(user_dob)
                        .addComponent(user_type, 0, 170, Short.MAX_VALUE)
                        .addComponent(user_pass)
                        .addComponent(user_conf_pass)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(reset)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(save)
                .addGap(22, 22, 22))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(user_id, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(user_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(user_conf_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(user_name, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(user_dob, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addGap(7, 7, 7)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(user_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addGap(2, 2, 2)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reset)
                    .addComponent(save)))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(jLabel1))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel1)
                .addGap(6, 6, 6)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 73, 65);
        add(jPanel1, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
    id();
    pass();
    retype_pass();
    name();
    dob();
    type();
   
    if(i==1&&j==1&&k==1&&m==1&&n==1&&p==1)
    {
        try {
            Connection con = Database.getConnection();
            PreparedStatement ps10=con.prepareStatement("insert into user (user_id,user_pass,user_name,user_dob,user_type)values('"+user_id.getText()+"','"+user_pass.getText()+"','"+user_name.getText()+"','"+user_dob.getText()+"','"+user_type.getSelectedItem().toString()+"')");
            ps10.executeBatch();
            ps10.executeUpdate();
            user_id.setText(null);
            user_pass.setText(null);
            user_conf_pass.setText(null);
            user_name.setText(null);
            user_dob.setText(null);
            JOptionPane.showMessageDialog(this,"User Created");
                     
        } catch (SQLException ex) {
            Logger.getLogger(user_create_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }//GEN-LAST:event_saveActionPerformed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        // TODO add your handling code here:
        user_id.setText(null);
        user_pass.setText(null);
        user_conf_pass.setText(null);
        user_name.setText(null);
        user_dob.setText(null);
    }//GEN-LAST:event_resetActionPerformed

    private void user_idFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_user_idFocusLost
         if(user_id.getText().length()==0)
      {
          user_id.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel8.setEnabled(true);
          jLabel8.setForeground(Color.red);
          jLabel8.setVisible(true);
             
      }  
      else
      {
           user_id.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel8.setEnabled(false);  
           jLabel8.setVisible(false);
           i=1;
          
      }
    }//GEN-LAST:event_user_idFocusLost

    private void user_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_user_passFocusLost
       if(user_pass.getPassword().length==0)
         {
          user_pass.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel9.setEnabled(true);
          jLabel9.setForeground(Color.red);
          jLabel9.setVisible(true);
             
         }
         else
         {
       char[] pass=  user_pass.getPassword();
       String s1= new String(pass);
       System.out.println(s1);
       String s2 = "((?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%!]).{6,40})|(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{6,40}";
       Pattern p1 = Pattern.compile(s2);
       Matcher m1 = p1.matcher(s1);
       user_pass.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
       jLabel9.setEnabled(false);  
       jLabel9.setVisible(false);
       j=1;
  
             if(m1.find()==false) 
           {
            user_pass.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel9.setEnabled(true);
            jLabel9.setForeground(Color.red);
            jLabel9.setVisible(true);
            
            } 
         }
    }//GEN-LAST:event_user_passFocusLost

    private void user_conf_passFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_user_conf_passFocusLost
      char[] pass=  user_pass.getPassword();
           String s1= new String(pass);    
           char[] pas=user_conf_pass.getPassword();
           String s2= new String(pas);
           user_conf_pass.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel10.setEnabled(false);  
           jLabel10.setVisible(false);
            k=1;
           
                               
           if(s1.compareTo(s2) != 0)
           { 
                            
            user_conf_pass.setBorder(BorderFactory.createLineBorder(Color.red));
            jLabel10.setEnabled(true);
            jLabel10.setForeground(Color.red);
            jLabel10.setVisible(true);
            
        //    user_conf_pass.requestFocus();
        //    user_conf_pass.setText("");
           }
    }//GEN-LAST:event_user_conf_passFocusLost

    private void user_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_user_nameFocusLost
          if(user_name.getText().length()==0)
      {
          user_name.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel11.setEnabled(true);
          jLabel11.setForeground(Color.red);
          jLabel11.setVisible(true);
             
      }  
      else
      {
           user_name.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel11.setEnabled(false);  
           jLabel11.setVisible(false);
           m=1;
          
      }
    }//GEN-LAST:event_user_nameFocusLost

    private void user_dobFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_user_dobFocusLost
          if(user_dob.getText().length()==0)
        {
              user_dob.setBorder(BorderFactory.createLineBorder(Color.red));
              jLabel12.setEnabled(true);
              jLabel12.setForeground(Color.red);
              jLabel12.setVisible(true);
        }
        else
        {
            String content = user_dob.getText();
            Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
            Matcher m = p.matcher(content);
            boolean matchFound = m.matches();
            user_dob.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
            jLabel12.setEnabled(false);  
            jLabel12.setVisible(false);
            n=1;
            if(!matchFound)

            {
              

                 user_dob.setBorder(BorderFactory.createLineBorder(Color.red));
                 jLabel12.setEnabled(true);
                 jLabel12.setForeground(Color.red);
                 jLabel12.setVisible(true);

            }
        }
    }//GEN-LAST:event_user_dobFocusLost

    private void user_typeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_user_typeFocusLost
  
           if(user_type.getSelectedItem().equals(""))
      {
          user_type.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel13.setEnabled(true);
          jLabel13.setForeground(Color.red);
          jLabel13.setVisible(true);
             
      }  
      else
      {
           user_type.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel13.setEnabled(false);  
           jLabel13.setVisible(false);
           p=1;
      }
    }//GEN-LAST:event_user_typeFocusLost

    private void user_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_user_nameActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton reset;
    private javax.swing.JButton save;
    private javax.swing.JPasswordField user_conf_pass;
    private javax.swing.JTextField user_dob;
    private javax.swing.JTextField user_id;
    private javax.swing.JTextField user_name;
    private javax.swing.JPasswordField user_pass;
    private javax.swing.JComboBox user_type;
    // End of variables declaration//GEN-END:variables
}
