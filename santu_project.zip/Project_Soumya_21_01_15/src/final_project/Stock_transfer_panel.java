package final_project;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author virtual vista
 */
public class Stock_transfer_panel extends javax.swing.JPanel {
    
    Font myFont = new Font("",Font.PLAIN,9);
    
     int i=0,j=0,k=0,l=0;     // For Mandatory

    /**
     * Creates new form Stock_transfer_panel
     */
     public void set()
     {
         no.requestFocusInWindow();
         no.setFocusable(true);
     }
     
     public void user(String u_name){
         jLabel10.setText(u_name);
     }
     
    public Stock_transfer_panel() {
        initComponents();
        jLabel10.setVisible(false);
        table.setRowHeight(35);
        try{
        
           
           Connection con = Database.getConnection();
         Statement ps2 =con.createStatement();
            ResultSet rs2=ps2.executeQuery("select distinct gd_name from godown order by gd_id");
            
               while(rs2.next())
              {
                  String name2=rs2.getString("gd_name");
                  from.addItem(name2);
                  to.addItem(name2);
              }
       
          
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
       
         try{
        
           
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct product_name from product");
          while(rs.next())
          {
             
            item_combo.addItem(rs.getString("product_name"));
            
          }
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
         try{
        
           
           Connection con = Database.getConnection();
        Statement ps =con.createStatement();
           ResultSet rs=ps.executeQuery("select distinct u_name from unit");
          while(rs.next())
          {
             
            unit_combo.addItem(rs.getString("u_name"));
            
          }
         
         
        }catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
        
         
        jLabel1.setFont(myFont);
        jLabel1.setEnabled(false);
        jLabel1.setVisible(false);
        
        jLabel2.setFont(myFont);
        jLabel2.setEnabled(false);
        jLabel2.setVisible(false);
        
        jLabel7.setFont(myFont);
        jLabel7.setEnabled(false);
        jLabel7.setVisible(false);
        
        jLabel8.setFont(myFont);
        jLabel8.setEnabled(false);
        jLabel8.setVisible(false);
         
         
    }
    
    // Form
    
    public void from(){
           if(from.getSelectedItem().equals(""))
      {
          from.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel1.setEnabled(true);
          jLabel1.setForeground(Color.red);
          jLabel1.setVisible(true);
             
      }  
      else
      {
           from.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel1.setEnabled(false);  
           jLabel1.setVisible(false);
           i=1;
      }
        
    }
    
      // Form
    
    public void to(){
           if(to.getSelectedItem().equals(""))
      {
          to.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel2.setEnabled(true);
          jLabel2.setForeground(Color.red);
          jLabel2.setVisible(true);
             
      }  
      else
      {
           to.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel2.setEnabled(false);  
           jLabel2.setVisible(false);
           j=1;
      }
        
    }
    
    // No
    
    public void no(){
                if(no.getText().length()==0)
      {
          no.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel7.setEnabled(true);
          jLabel7.setForeground(Color.red);
          jLabel7.setVisible(true);
             
      }  
      else
      {
           no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel7.setEnabled(false);  
           jLabel7.setVisible(false);
           k=1;
          
      }
    }
    
    
    // Date
    
    public void date(){
                 if(date.getText().length()==0)
       {
             date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel8.setEnabled(true);
             jLabel8.setForeground(Color.red);
             jLabel8.setVisible(true);
           
       }
       else
       {
           
       
                 String content = date.getText();
                 Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
                 Matcher m = p.matcher(content);
                 boolean matchFound = m.matches();
                 System.out.println(matchFound);
                 date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                 jLabel8.setEnabled(false);  
                 jLabel8.setVisible(false);
                 l=1;
          
          if(!matchFound)
          { 
             date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel8.setEnabled(true);
             jLabel8.setForeground(Color.red);
             jLabel8.setVisible(true);
          }
       }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        quantity = new numeric.textField.NumericTextField();
        item_combo = new javax.swing.JComboBox();
        unit_combo = new javax.swing.JComboBox();
        jOptionPane1 = new javax.swing.JOptionPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        transfer_button = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        from = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        to = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        no = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        stock_trans_narration = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();

        quantity.setText("numericTextField1");

        item_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        unit_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Stock Transfer", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(0, 0, 255))); // NOI18N
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Material Name", "Quantity", "Unit"
            }
        ));
        jScrollPane3.setViewportView(table);
        table.getColumn("Quantity").setCellEditor(new DefaultCellEditor(quantity));
        table.getColumn("Material Name").setCellEditor(new DefaultCellEditor(item_combo));
        table.getColumn("Unit").setCellEditor(new DefaultCellEditor(unit_combo));

        transfer_button.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        transfer_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Cow-wagon-icon.png"))); // NOI18N
        transfer_button.setText("TRANSFER");
        transfer_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transfer_buttonActionPerformed(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rows", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, new java.awt.Color(0, 51, 255)));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/add-2-icon.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/final_project/Icons/Action-remove-icon.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 444, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(transfer_button)
                .addGap(209, 209, 209))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(transfer_button)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Godowns", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, java.awt.Color.blue));

        from.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        from.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fromFocusLost(evt);
            }
        });

        jLabel1.setText("Select One!");

        to.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "" }));
        to.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toActionPerformed(evt);
            }
        });
        to.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                toFocusLost(evt);
            }
        });

        jLabel5.setForeground(java.awt.Color.blue);
        jLabel5.setText("To:");

        jLabel2.setText("Select One!");

        jLabel3.setForeground(java.awt.Color.blue);
        jLabel3.setText("From:");

        no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        no.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                noFocusLost(evt);
            }
        });

        jLabel4.setForeground(java.awt.Color.blue);
        jLabel4.setText("No.");

        date.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                dateFocusLost(evt);
            }
        });

        jLabel6.setForeground(java.awt.Color.blue);
        jLabel6.setText("Date:");

        jLabel7.setText("Enter No:");

        jLabel8.setText("Enter Valid Date!");

        jLabel9.setForeground(java.awt.Color.blue);
        jLabel9.setText("Narration:");

        stock_trans_narration.setColumns(20);
        stock_trans_narration.setRows(5);
        jScrollPane1.setViewportView(stock_trans_narration);

        jLabel10.setText("jLabel10");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(no, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(from, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(44, 44, 44)
                                        .addComponent(jLabel5))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel6))))
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                                .addGap(149, 149, 149))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(to, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel10)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {from, to});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(no, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)))
                .addGap(1, 1, 1)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addGap(3, 3, 3)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(from, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(to, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabel9))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(106, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jScrollPane2.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 494, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void toActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_toActionPerformed

    private void fromFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fromFocusLost
          if(from.getSelectedItem().equals(""))
      {
          from.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel1.setEnabled(true);
          jLabel1.setForeground(Color.red);
          jLabel1.setVisible(true);
             
      }  
      else
      {
           from.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel1.setEnabled(false);  
           jLabel1.setVisible(false);
           i=1;
      }
    }//GEN-LAST:event_fromFocusLost

    private void toFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_toFocusLost
          if(to.getSelectedItem().equals(""))
      {
          to.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel2.setEnabled(true);
          jLabel2.setForeground(Color.red);
          jLabel2.setVisible(true);
             
      }  
      else
      {
           to.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel2.setEnabled(false);  
           jLabel2.setVisible(false);
           j=1;
      }
    }//GEN-LAST:event_toFocusLost

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        DefaultTableModel y = (DefaultTableModel)table.getModel();

        int a=y.getRowCount()- 1;

        y.removeRow(a);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void transfer_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transfer_buttonActionPerformed
        from();
        to();
        no();
        date();

        if(i==1&&j==1&&k==1&&l==1)
        {
            //DefaultTableModel y = (DefaultTableModel)table.getModel();
            
//            int row=y.getRowCount();
//            if(row==1){
//                JOptionPane.showMessageDialog(null, "Fill Stock Information");
//            }
             try{
        
           
           Connection con = Database.getConnection();
        
            int p=table.getRowCount();
          for(int i=0;i<p;i++)
         {
          String item=table.getValueAt(i,0).toString();
           String quantity=table.getValueAt(i,1).toString();
            String unit=table.getValueAt(i,2).toString();
            
            log_table.table_create("godown_detail",  from.getSelectedItem().toString());
           log_table.table_insert("godown_detail", from.getSelectedItem().toString());
            PreparedStatement gds=con.prepareStatement("insert into godown_detail (gd_name_from, item, t_quantity, unit,invoice,type,gd_name_to,date)values('"+from.getSelectedItem().toString()+"','"+item+"','"+quantity+"','"+unit+"','"+no.getText()+"','STOCK TRANSFER','"+to.getSelectedItem().toString()+"','"+date.getText()+"')");

                gds.executeBatch();
                gds.executeUpdate();

           
         }
            jOptionPane1.showMessageDialog(this,"Stock Transfer Done");
            DefaultTableModel y1 = (DefaultTableModel)table.getModel();
        int fr = y1.getRowCount();
        while (fr>=1)
        {
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
        }
        no.setText("");
        to.setSelectedIndex(-1);
        from.setSelectedIndex(-1);
        con.close();
}catch (SQLException e){
        System.out.println("Sql Exception" + e.toString());
        }
         
        }
    }//GEN-LAST:event_transfer_buttonActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        DefaultTableModel y = (DefaultTableModel)table.getModel();

        Vector <String> r = new Vector <String>();
        y.addRow(r);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void noFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_noFocusLost
                if(no.getText().length()==0)
      {
          no.setBorder(BorderFactory.createLineBorder(Color.red));
          jLabel7.setEnabled(true);
          jLabel7.setForeground(Color.red);
          jLabel7.setVisible(true);
             
      }  
      else
      {
           no.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
           jLabel7.setEnabled(false);  
           jLabel7.setVisible(false);
           k=1;
          
      }
    }//GEN-LAST:event_noFocusLost

    private void dateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dateFocusLost
                 if(date.getText().length()==0)
       {
             date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel8.setEnabled(true);
             jLabel8.setForeground(Color.red);
             jLabel8.setVisible(true);
           
       }
       else
       {
           
       
                 String content = date.getText();
                 Pattern p = Pattern.compile("^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d$");
                 Matcher m = p.matcher(content);
                 boolean matchFound = m.matches();
                 System.out.println(matchFound);
                 date.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
                 jLabel8.setEnabled(false);  
                 jLabel8.setVisible(false);
                 l=1;
          
          if(!matchFound)
          { 
             date.setBorder(BorderFactory.createLineBorder(Color.red));
             jLabel8.setEnabled(true);
             jLabel8.setForeground(Color.red);
             jLabel8.setVisible(true);
          }
       }
    }//GEN-LAST:event_dateFocusLost


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField date;
    private javax.swing.JComboBox from;
    private javax.swing.JComboBox item_combo;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField no;
    private numeric.textField.NumericTextField quantity;
    private javax.swing.JTextArea stock_trans_narration;
    private javax.swing.JTable table;
    private javax.swing.JComboBox to;
    private javax.swing.JButton transfer_button;
    private javax.swing.JComboBox unit_combo;
    // End of variables declaration//GEN-END:variables
}
