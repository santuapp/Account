/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package final_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author pc 5
 */
public class log_table {
    
   static String user_name;
   
   
  
    public static void table_create(String tbl_name,String value){
       
        String table1= tbl_name;
        String type1="create";
        
        String value1=value;
        DateFormat dateformat = new SimpleDateFormat("yyyy/mm/dd HH:mm:ss");
        Date date = new Date();
        try{
            
            Connection con = Database.getConnection();
            PreparedStatement ps=con.prepareStatement("insert into user_activity_table(query_type,table_name,create_date,create_user,value)values('"+type1+"','"+table1+"','"+date+"','"+user_name+"','"+value1+"')");
//            System.out.println(ps);
            ps.executeUpdate();
            con.close();
        }
        catch(Exception ex){
            
        }
        
    }
    public static void table_insert(String tbl_name,String value){
        
        String table= tbl_name;
        String type="insert";
        //String user1=user;
        
        String value1=value;
        
        DateFormat dateformat = new SimpleDateFormat("yyyy/mm/dd HH:mm:ss");
        Date date = new Date();
        try{
            Connection con1 = Database.getConnection();
            PreparedStatement ps=con1.prepareStatement("update user_activity_table SET query_type = '"+type+"' , update_user= '"+user_name+"' , update_date='"+date.toString()+"' where table_name= '"+table+"' and value='"+value1+"'");
           // System.out.println(ps);
            ps.executeUpdate();
            con1.close();
                      
        }
        catch(Exception ex){
            
        }
        
    }

    public static void table_update(String tbl_name,String value,String user_activity_id){
        
        String table= tbl_name;
        String type="update";
        //String user1=user;
        String value1=value;
        String u_id=user_activity_id;
        System.out.println("LOG UPDATE USER ID " + u_id);
                
        DateFormat dateformat = new SimpleDateFormat("yyyy/mm/dd HH:mm:ss");
        Date date = new Date();
        try{
            Connection con1 = Database.getConnection();
            PreparedStatement ps=con1.prepareStatement("update user_activity_table SET query_type = '"+type+"' , update_user= '"+user_name+"' , value='"+value1+"', update_date='"+date.toString()+"' where id='"+u_id+"'");
            System.out.println(ps);
            ps.executeUpdate();
            con1.close();
                      
        }
        catch(Exception ex){
            
        }
    }
    public static void table_delete(String tbl_name,String user){
   
        String table= tbl_name;
        String type="delete";
        String user1=user;
        DateFormat dateformat = new SimpleDateFormat("yyyy/mm/dd HH:mm:ss");
        Date date = new Date();
        try{
            Connection con1 = Database.getConnection();
            PreparedStatement ps=con1.prepareStatement("update user_activity_table SET query_type = '"+type+"' , update_user= '"+user_name+"' , update_date='"+date.toString()+"' where table_name= '"+table+"'");
//            System.out.println(ps);
            ps.executeUpdate();
            con1.close();

           
        }
        catch(Exception ex){
            
        }
        
    }
    public static void main(String args[]){
        String type="santu";
        String table_name="ledger";
      // table_create(table_name,);
//        table_insert(table_name);
//        table_update(table_name);
       // table_delete(table_name);
    }
    
}
