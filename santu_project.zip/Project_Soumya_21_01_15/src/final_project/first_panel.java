package final_project;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc2
 */
public class first_panel extends javax.swing.JPanel {
 String head_grp;
 String head_trans;
 String var_global="";
 String val="";   /**
     * Creates new form first_panel
     */
      public String s1="";
     public  int row,col;
    public first_panel() {
        initComponents();
         table_3.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),"enter");
        table_3.getActionMap().put("enter", new AbstractAction() 
        {
        public void actionPerformed(ActionEvent e) 
        {
            //action to be performed
        }

            
        });
       
    }
    
    public void print()
    
    {
        
           
       //  jLabel1.setEnabled(true);
    Integer row = table_3.getRowCount();
    
    //Inserting data into table for printing
    try{

                

                Connection con = Database.getConnection();
                

                //Deleting All Sale details from Sale Table 2
                PreparedStatement ps9=con.prepareStatement("DELETE FROM group_sum_fp_temp");
                ps9.executeUpdate();

                //Inserting data into table for printing
                for(int i=0;i<row;i++)
                {
                    String fp_part=table_3.getValueAt(i,0).toString();
                    String fp_dr=table_3.getValueAt(i,1).toString();
                    String fp_cr=table_3.getValueAt(i,2).toString();
                    
                    PreparedStatement ps10=con.prepareStatement("insert into group_sum_fp_temp (fp_particulars, fp_debit, fp_credit)values('"+fp_part+"','"+fp_dr+"','"+fp_cr+"')");

                    ps10.executeBatch();
                    ps10.executeUpdate();
                   
                }
                
               
            }catch (SQLException q){
                System.out.println("Sql Exception" + q.toString());
            }
           
          System.out.println(head_trans);
    HashMap param=new HashMap();
    param.put("group_main_id", head_trans);
    String url = System.getProperty("user.dir");
    System.out.println(url);
    MyReportViewer viewer1=new MyReportViewer(url+"\\src\\bits_reports\\group_summary_printable.jasper", param);
    viewer1.setVisible(true);   
    }
    
public void  add_panel_2(String click){
     h_label.setText(click);
        head_trans = click;
          var_global= click.trim();

  TableColumnModel cmodel = table_3.getColumnModel(); 
        TextAreaRenderer textAreaRenderer = new TextAreaRenderer(); 
        cmodel.getColumn(0).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(1).setCellRenderer(textAreaRenderer);
        cmodel.getColumn(2).setCellRenderer(textAreaRenderer);
        addRows(table_3);
        
        sum();
      
    }


 private void addRows(JTable table)
    
         
    { 
          System.out.println("fp"+var_global);
        DefaultTableModel y1 = (DefaultTableModel)table .getModel();
            int fr = y1.getRowCount();
            while (fr>=1)
            {   
            int a=y1.getRowCount()- 1;
            y1.removeRow(a);
            fr--;
            
            
        }
        
       try{
        
            Class.forName("com.mysql.jdbc.Driver");
            String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
            Connection con = (Connection) DriverManager.getConnection(ConnUrl);
            PreparedStatement ps90=con.prepareStatement("DELETE FROM group_sum_fp_temp");
                ps90.executeUpdate();
            Statement ps =con.createStatement();
            ResultSet rs=ps.executeQuery("SELECT l_name as PARTICULERS,SUM(debit) AS DEBIT,SUM(credit) AS CREDIT  FROM `"+var_global+"` GROUP BY L_NAME");
        
             
           while(rs.next())
                 {
                     

                   PreparedStatement ps101=con.prepareStatement("insert into group_sum_fp_temp (fp_particulars, fp_debit, fp_credit)values('"+rs.getString("PARTICULERS")+"','"+rs.getString("DEBIT")+"','"+rs.getString("CREDIT")+"')");

                   ps101.executeBatch();
                   ps101.executeUpdate();
                 }
           
                Statement pds =con.createStatement();
                ResultSet rds=pds.executeQuery("SELECT g_name  FROM acc_group where g_under='"+var_global+"' ");

                 while(rds.next())
                 {
                     
                      Statement pds1 =con.createStatement();
                ResultSet rds1=pds1.executeQuery("SELECT IFNULL(sum(debit),0) as DEBIT,IFNULL(sum(credit),0) as CREDIT FROM `"+rds.getString("g_name")+"`  ");

                 while(rds1.next())
                 {
                   PreparedStatement ps1015=con.prepareStatement("insert into group_sum_fp_temp (fp_particulars, fp_debit, fp_credit)values('"+rds.getString("g_name")+"','"+rds1.getString("DEBIT")+"','"+rds1.getString("CREDIT")+"')");

                   ps1015.executeBatch();
                   ps1015.executeUpdate();
                 }
                 }
            System.out.println("Done");
           Statement psw =con.createStatement();
            ResultSet rsw=psw.executeQuery("SELECT fp_particulars, fp_debit, fp_credit  FROM group_sum_fp_temp");
           int li_row=0;
           int rw = 0;
           Vector <String> r[] = (Vector <String> []) new Vector[1000];
           
           
        
           
           while(rsw.next())
                 {
                     
                 y1.addRow(r[rw]); 
                    
                 table_3.setValueAt(rsw.getString("fp_particulars"), li_row, 0);
                 table_3.setValueAt(rsw.getString("fp_debit"), li_row, 1);
                 table_3.setValueAt(rsw.getString("fp_credit"), li_row, 2);
                
                  
       
                 
                 rw++;
                 li_row++;
                  
                 }
         
            }catch (SQLException e)
                {
                System.out.println("Sql Exceptions" + e.toString());
                }
        catch(ClassNotFoundException ce)
        {
            System.out.println("ClassNotFoundException" + ce.toString());
        }
 }
 
 
 public void sum()

{
     
       try{
        
            Class.forName("com.mysql.jdbc.Driver");
            String ConnUrl="jdbc:mysql://localhost:3306/acc_database?" + "user=root&password=admin";
            Connection con = (Connection) DriverManager.getConnection(ConnUrl);
            
             Statement psw1 =con.createStatement();
            ResultSet rsw1=psw1.executeQuery("SELECT (IFNULL(sum(fp_credit),0) - IFNULL(sum(fp_debit),0)) as tot  FROM group_sum_fp_temp");
            
            while(rsw1.next())
                 {
                     val=rsw1.getString("tot");
                 }
                 }catch (SQLException e)
                {
                System.out.println("Sql Exceptions" + e.toString());
                }
        catch(ClassNotFoundException ce)
        {
            System.out.println("ClassNotFoundException" + ce.toString());
        }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        table_3 = new javax.swing.JTable();
        h_label = new javax.swing.JLabel();

        table_3.setForeground(new java.awt.Color(0, 0, 250));
        table_3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PARTICULERS", "DEBIT", "CREDIT"
            }
        ));
        jScrollPane1.setViewportView(table_3);

        h_label.setForeground(new java.awt.Color(0, 0, 255));
        h_label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        h_label.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
            .addComponent(h_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(h_label, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel h_label;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable table_3;
    // End of variables declaration//GEN-END:variables
}
